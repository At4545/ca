"""Load cluster metadata from clusters.json and expose ONLY safe fields.

The credentials section (and any other unknown key) is never copied out of
this module, so it can never reach the browser.
Python 3.9 compatible, standard library only.
"""
import json
import os
import re

VALID_ENVS = ("DEV", "TEST", "PROD")
_ENV_KEYS = ("environment", "env", "Environment", "Env")
_NAME_KEYS = ("name", "cluster_name", "clusterName", "Name", "cluster")
_URL_KEYS = ("api_url", "apiUrl", "api", "url", "api_server", "server", "apiURL")
_ENABLED_KEYS = ("enabled", "Enabled", "active", "status")


class ConfigError(Exception):
    pass


def _first(entry, keys):
    for k in keys:
        if k in entry:
            return entry[k]
    return None


def _as_bool(v):
    if v is None:
        return True  # default: enabled when the field is absent
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("true", "1", "yes", "enabled", "active")


def _entries(data):
    if isinstance(data, list):
        return [e for e in data if isinstance(e, dict)]
    if isinstance(data, dict):
        for key in ("clusters", "Clusters", "items"):
            if key in data:
                return _entries(data[key])
        if data and all(isinstance(v, dict) for v in data.values()):
            return [dict(v, _key=k) for k, v in data.items()]
    return []


def _slug(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "cluster"


def load_clusters(path):
    """Return a list of sanitized cluster dicts: id, name, environment, api_url, enabled."""
    if not os.path.isfile(path):
        raise ConfigError("Cluster configuration file not found: %s" % path)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError) as exc:
        raise ConfigError("Cluster configuration could not be read (%s)" % type(exc).__name__)

    result, seen = [], set()
    for entry in _entries(data):
        name = _first(entry, _NAME_KEYS) or entry.get("_key")
        env = _first(entry, _ENV_KEYS)
        url = _first(entry, _URL_KEYS)
        if not (isinstance(name, str) and name):
            continue
        env = str(env).strip().upper() if env else "UNKNOWN"
        cid, n = _slug(name), 2
        while cid in seen:
            cid = "%s-%d" % (_slug(name), n)
            n += 1
        seen.add(cid)
        result.append({
            "id": cid,
            "name": name,
            "environment": env,
            "api_url": url if isinstance(url, str) else "",
            "enabled": _as_bool(_first(entry, _ENABLED_KEYS)),
            "environment_valid": env in VALID_ENVS,
        })
    return result
