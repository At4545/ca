#!/usr/bin/env python3
"""Phase 1 - READ-ONLY environment discovery for OpenShift Dump Collector.

Standard library only (Python 3.6+ syntax). Makes NO network calls to any
cluster, installs nothing, changes nothing. Never prints credential values.

Usage:  python3 scripts/discover_env.py [--clusters clusters.json] [--storage DIR] [--port 8080]
"""
import argparse, json, os, platform, shutil, socket, stat, subprocess, sys
from importlib import util as importutil

SECRET_HINTS = ("password", "passwd", "secret", "token", "credential", "apikey", "api_key")


def run(args, timeout=15):
    """Run a fixed argument list (never a shell string)."""
    try:
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           universal_newlines=True, timeout=timeout)
        return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", "not found"
    except Exception as exc:  # timeout etc.
        return 1, "", type(exc).__name__


def section(title):
    print("\n== %s ==" % title)


def line(label, value):
    print("  %-26s %s" % (label + ":", value))


def os_info():
    section("Operating system / user")
    pretty = platform.platform()
    try:
        with open("/etc/os-release") as fh:
            for ln in fh:
                if ln.startswith("PRETTY_NAME="):
                    pretty = ln.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    line("OS", pretty)
    line("Kernel", platform.release())
    line("Running as", "uid=%d user=%s" % (os.getuid(), os.environ.get("USER", "?")))
    rc, out, _ = run(["getenforce"])
    line("SELinux", out if rc == 0 else "getenforce not available")


def python_info():
    section("Python")
    line("Interpreter", sys.executable)
    line("Version", platform.python_version())
    if sys.version_info < (3, 6):
        line("WARNING", "Python < 3.6; code targets 3.9")
    for mod in ("fastapi", "flask", "uvicorn", "requests", "yaml", "kubernetes",
                "openshift", "sqlite3", "ssl", "ldap3", "gssapi"):
        line("module " + mod, "available" if importutil.find_spec(mod) else "missing")
    print("  (Prototype needs only the standard library; sqlite3 is used for history in Phase 7.)")


def oc_info():
    section("OpenShift CLI")
    path = shutil.which("oc")
    line("oc path", path or "NOT FOUND")
    if not path:
        return
    rc, out, err = run(["oc", "version", "--client"])
    line("oc client version", out.replace("\n", " | ") if rc == 0 else "error: " + err[:120])
    kc = os.environ.get("KUBECONFIG")
    line("KUBECONFIG env", ("set (%s)" % kc) if kc else "not set (default ~/.kube/config)")
    default_kc = os.path.expanduser("~/.kube/config")
    target = kc.split(os.pathsep)[0] if kc else default_kc
    line("kubeconfig file exists", str(os.path.exists(target)))
    if os.path.exists(target):
        mode = stat.S_IMODE(os.stat(target).st_mode)
        line("kubeconfig mode", "%o %s" % (mode, "OK" if mode & 0o077 == 0 else "TOO OPEN (should be 600)"))
    rc, out, _ = run(["oc", "config", "get-contexts", "-o", "name"])
    names = out.splitlines() if rc == 0 and out else []
    line("local context count", len(names))
    for n in names[:25]:
        print("      - " + n)  # context names only, never contents
    rc, out, _ = run(["oc", "config", "current-context"])
    line("current context", out if rc == 0 else "none")
    print("  (Identity/permissions are NOT checked here; that is Phase 3.)")


def ansible_info():
    section("Ansible")
    if not shutil.which("ansible"):
        line("ansible", "NOT FOUND")
        return
    rc, out, _ = run(["ansible", "--version"])
    line("version", out.splitlines()[0] if out else "?")
    rc, out, _ = run(["ansible-galaxy", "collection", "list"], timeout=30)
    has = "kubernetes.core" in out
    line("collection kubernetes.core", "installed" if has else "not installed")
    line("python 'kubernetes' module", "available" if importutil.find_spec("kubernetes") else "missing")


def tools_info():
    section("Other tools")
    for t in ("tar", "jq", "gzip", "sha256sum", "systemctl", "httpd", "nginx", "firewall-cmd"):
        line(t, shutil.which(t) or "not found")


def storage_info(path):
    section("Storage candidate: " + path)
    target = path if os.path.exists(path) else os.path.dirname(os.path.abspath(path)) or "."
    try:
        du = shutil.disk_usage(target)
        line("free / total (GiB)", "%.1f / %.1f" % (du.free / 2**30, du.total / 2**30))
    except OSError as exc:
        line("disk usage", "error: %s" % exc)
    line("path exists", str(os.path.exists(path)))
    line("writable by this user", str(os.access(target, os.W_OK)))
    print("  Heap dumps can reach several GiB: confirm the approved location and quota.")


def port_info(port):
    section("Local port %d (loopback)" % port)
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", port))
        line("bind 127.0.0.1:%d" % port, "free")
    except OSError as exc:
        line("bind 127.0.0.1:%d" % port, "NOT free (%s)" % exc.strerror)
    finally:
        s.close()


def entries_of(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("clusters", "Clusters", "items"):
            if key in data:
                return entries_of(data[key])
        if all(isinstance(v, dict) for v in data.values()):
            return [dict(v, _key=k) for k, v in data.items()]
    return []


def clusters_info(path):
    section("clusters.json: " + path)
    if not os.path.exists(path):
        line("file", "NOT FOUND (use --clusters PATH)")
        return
    mode = stat.S_IMODE(os.stat(path).st_mode)
    line("file mode", "%o %s" % (mode, "OK" if mode & 0o077 == 0 else "READABLE BY OTHERS - restrict to 600"))
    try:
        with open(path) as fh:
            data = json.load(fh)
    except Exception as exc:
        line("parse", "FAILED: %s" % type(exc).__name__)
        return
    line("top-level type", type(data).__name__ + (" keys=%s" % sorted(data.keys()) if isinstance(data, dict) else ""))
    ents = entries_of(data)
    line("cluster entries found", len(ents))
    plaintext = 0
    for e in ents:
        keys = sorted(k for k in e.keys())
        for k, v in e.items():
            if any(h in k.lower() for h in SECRET_HINTS) and v:
                plaintext += 1
                if isinstance(v, dict) and any(isinstance(x, str) and x for x in v.values()):
                    plaintext += 0
        safe = {k: v for k, v in e.items() if not any(h in k.lower() for h in SECRET_HINTS)
                and isinstance(v, (str, bool, int))}
        print("      - fields=%s" % keys)
        print("        values (non-secret only)=%s" % json.dumps(safe))
    line("credential-like fields", "%d populated entries (values NOT shown)" % plaintext)
    if plaintext:
        print("  WARNING: credentials live in this file. The portal never serves it, and the final design should move them to an approved secret store.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", default="clusters.json")
    ap.add_argument("--storage", default="storage")
    ap.add_argument("--port", type=int, default=8080)
    a = ap.parse_args()
    print("OpenShift Dump Collector - Phase 1 discovery (read-only)")
    os_info(); python_info(); oc_info(); ansible_info(); tools_info()
    storage_info(a.storage); port_info(a.port); clusters_info(a.clusters)
    print("\nDone. Share this output (it contains no secrets) to finalize the Phase 3 plan.")


if __name__ == "__main__":
    main()
