# OpenShift Dump Collector

Status: **Phase 1 (discovery script) and Phase 2 (frontend prototype) are done and tested in a sandbox. Phases 3-8 are not started.**
Namespaces, pods, jobs and history in the UI are mock data. **No diagnostic collection exists yet.**

## Layout (only what exists today)
```
server.py                 stdlib dev server, loopback only, serves 3 static files + /api/clusters
backend/configuration.py  reads clusters.json, returns ONLY id/name/environment/api_url/enabled
index.html style.css script.js
scripts/discover_env.py   Phase 1 read-only discovery
tests/clusters.test.json  placeholder data for local tests only (not your real clusters)
storage/ logs/            reserved (empty; git-ignored)
```
More modules (namespace/pod/collection/storage/audit services, diagnostics/) are added only when their phase starts.

## Minimal plan and key decisions
| Topic | Decision | Why |
|---|---|---|
| Server | Python stdlib `ThreadingHTTPServer`, bound to 127.0.0.1 | Nothing to install. Access via SSH tunnel: `ssh -L 8080:127.0.0.1:8080 <jump-server>` |
| Cluster access | Backend runs `oc` with an **argument list** (never a shell string), a **per-job `KUBECONFIG`** and explicit `--server` | No reliance on the shared active context; no secrets in argv |
| Long jobs | Worker threads + subprocess per job, state in SQLite (stdlib `sqlite3`) | No Celery/Redis needed |
| Thread dump | `oc exec ... jcmd <pid> Thread.print` (or `jstack`), stdout streamed to a server-named file. If neither tool exists: clear error, no fallback | |
| Heap dump | `jcmd GC.heap_dump` to container `/tmp`, free-space check first, stream out with `oc exec ... cat`, delete remote file | Avoids needing `tar` for `oc cp` |
| TCP dump | **Needs a platform-team decision** (see below) | App images rarely contain `tcpdump`, and capture needs `NET_RAW` |

### Ansible vs. direct `oc` from Python
Recommendation: **direct `oc` from Python.** Each job is a handful of `oc` calls. Ansible adds seconds of startup, makes cancellation, streaming and stage reporting harder, and `kubernetes.core` plus the Python `kubernetes` library may not be installed. Reconsider Ansible only if your team wants reviewed playbooks as the control mechanism. If so, use fixed playbooks, validated `-e` vars from a JSON file (not user text), and `command: oc ...` tasks.

### Authentication (the open design question)
- **Prototype:** run the portal as your own jump-server user; it reuses your existing `oc login` session; reach it via SSH tunnel. SSH is the authentication layer, there is no shared credential, and no password is handled.
- **Multi-user (later):** either one instance per user (`systemd --user`), or a service with per-cluster least-privilege ServiceAccount tokens plus `--as` impersonation, fronted by approved SSO. The Python stdlib cannot do OIDC/Kerberos itself, so a multi-user deployment needs a front proxy (`httpd` + `mod_auth_gssapi`, or an approved equivalent). **This will need your approval before anything is installed.**

### TCP capture options (choose with the platform/security team)
1. Dedicated, approved diagnostic image run as an ephemeral/sidecar container with only `NET_RAW`, in agreed namespaces, via a purpose-built SCC/ServiceAccount.
2. Use `tcpdump` already baked into specific app images (works only where present).
3. Defer TCP capture; ship thread and heap first.
Privileged `oc debug node/...` is **not** proposed.

## Phase 1: Environment discovery
- **Files:** `scripts/discover_env.py`
- **Run (on the RHEL jump server):**
  ```bash
  cd openshift-dump-collector
  cp /path/to/clusters.json .            # chmod 600 clusters.json
  python3 scripts/discover_env.py --clusters clusters.json --storage /path/you/propose > discovery.txt
  ```
- **Expected output:** sections for OS, Python (module availability), `oc` (path, version, local context names only), Ansible (+ `kubernetes.core`), tools, storage free space, loopback port, and `clusters.json` structure with credential values hidden.
- **Validate:** `oc` found; Python 3.9.x; storage has several GiB free; `clusters.json` mode is 600.
- **Errors:** `oc NOT FOUND` means get it from the approved internal mirror (do not download ad hoc). Port busy means use `--port`. Parse failure means the JSON is invalid.
- **Security:** read-only, makes no network calls, never prints credential values. Review `discovery.txt` before sharing anyway. It includes cluster names/URLs and context names.

## Phase 2: Frontend prototype
- **Files:** `server.py`, `backend/__init__.py`, `backend/configuration.py`, `index.html`, `style.css`, `script.js`
- **Run:**
  ```bash
  python3 server.py --port 8080 --clusters clusters.json
  # from your workstation:  ssh -L 8080:127.0.0.1:8080 <jump-server>   then open http://127.0.0.1:8080
  ```
- **Expected:** startup line `OpenShift Dump Collector (Phase 2 prototype) on http://127.0.0.1:8080`; dashboard lists your configured clusters by DEV/TEST/PROD, with connectivity shown as **"not checked"**.
- **Validate:**
  ```bash
  curl -s localhost:8080/api/clusters                   # only id,name,environment,api_url,enabled
  curl -s localhost:8080/api/clusters | grep -ci password   # expect 0
  curl -s -o /dev/null -w '%{http_code}\n' localhost:8080/clusters.json   # expect 404
  ```
  In the UI: pick PROD + a cluster and click **Collect Dump**, and a confirmation dialog appears (heap dumps also require typing the cluster name). Afterwards a banner states that nothing was collected.
- **Errors:** if `clusters.json` has a different layout, the UI shows "Cluster configuration could not be loaded". Send the field names from the Phase 1 output and adjust the alias lists in `backend/configuration.py`. A clusters.json environment other than DEV/TEST/PROD is shown under "Unrecognised environment".
- **Security:** loopback-only (refuses other binds), `Host` header check, CSP with no inline script/style, whitelist of served files, no write endpoints, DOM built without `innerHTML`, no credentials leave the server.
- **Tested (sandbox, Python 3.12, headless Chromium):** API field filtering and no-leak check, file whitelist (404 for `clusters.json`, `server.py`, traversal), Host check, POST rejected, all five pages, cascading selectors, validation, PROD confirmation, history filtering, zero console errors. **Not tested:** Python 3.9 on your server (code uses only 3.9-safe syntax), real browsers other than Chromium.

## Next phases (not started)
3. Read-only discovery: `/api/clusters/<id>/check`, namespaces, pods, containers via `oc` (`oc whoami --show-server`, `oc auth can-i`, `oc get ns/pods -o json`). Test on DEV only.
4. Thread dump, 5. Heap dump, 6. TCP capture, 7. SQLite history + audit + retention, 8. Production readiness (HTTPS, RBAC, security review, runbook).
