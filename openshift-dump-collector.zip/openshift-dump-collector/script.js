/* OpenShift Dump Collector - Phase 2 frontend prototype.
 * Real data: cluster list from /api/clusters (credentials never included).
 * MOCK data: namespaces, pods, containers, jobs, history (clearly labelled).
 * Never executes cluster commands; never builds shell strings.
 * All DOM is built with textContent/createElement - no innerHTML with data.
 */
(function () {
  'use strict';

  var ENVS = ['DEV', 'TEST', 'PROD'];
  var DUMP_TYPES = [
    { id: 'thread', label: 'Thread Dump' },
    { id: 'heap', label: 'Heap Dump' },
    { id: 'tcp', label: 'TCP Dump' }
  ];
  /* Placeholder list: real approved filters must be agreed and mapped server-side. */
  var TCP_FILTERS = [
    { id: 'all', label: 'All traffic on the pod interface' },
    { id: 'tcp', label: 'TCP only' },
    { id: 'web', label: 'Ports 80 / 8080' },
    { id: 'tls', label: 'Ports 443 / 8443' },
    { id: 'dns', label: 'DNS (port 53)' }
  ];
  var LIMITS = {
    timeout: { min: 30, max: 1800, def: 300 },
    thread: { size: 50, count: { min: 1, max: 10, def: 3 }, interval: { min: 1, max: 60, def: 10 } },
    heap: { size: 4096 },
    tcp: { size: 500, duration: { min: 5, max: 300, def: 30 } }
  };
  var MOCK_NAMESPACES = {
    'sample-namespace-1': [
      { name: 'sample-app-7d9c-abcde', ready: '2/2', status: 'Running', containers: ['app', 'sidecar-proxy'] },
      { name: 'sample-app-7d9c-fghij', ready: '1/2', status: 'Running', containers: ['app', 'sidecar-proxy'] }
    ],
    'sample-namespace-2': [
      { name: 'sample-batch-5b6d-klmno', ready: '1/1', status: 'Running', containers: ['batch'] },
      { name: 'sample-batch-5b6d-pqrst', ready: '0/1', status: 'CrashLoopBackOff', containers: ['batch'] }
    ]
  };

  var state = { clusters: [], loadError: null, jobs: [], selectedJob: null, collect: {}, hist: { q: '', env: '', status: '', type: '' } };

  /* ---------- helpers ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    var a = attrs || {};
    Object.keys(a).forEach(function (k) {
      var v = a[k];
      if (v === false || v === null || v === undefined) return;
      if (k === 'class') el.className = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, String(v));
    });
    Array.prototype.slice.call(arguments, 2).forEach(function add(kid) {
      if (Array.isArray(kid)) return kid.forEach(add);
      if (kid === null || kid === undefined || kid === false) return;
      el.appendChild(kid.nodeType ? kid : document.createTextNode(String(kid)));
    });
    return el;
  }
  function badge(text, cls) { return h('span', { class: 'badge ' + cls }, text); }
  function mockTag() { return h('span', { class: 'mock', title: 'Mock data for the prototype' }, 'MOCK'); }
  function envBadge(env) { return badge(env, 'b-' + (ENVS.indexOf(env) >= 0 ? env : 'grey')); }
  var STATUS_CLS = { Pending: 'b-grey', Validating: 'b-info', Running: 'b-info', Completed: 'b-ok', Failed: 'b-bad', Cancelled: 'b-warn', Expired: 'b-grey' };
  function statusBadge(s) { return badge(s, STATUS_CLS[s] || 'b-grey'); }
  function fmtDate(d) { return d ? d.toLocaleString() : '-'; }
  function fmtDur(s) { if (s === null || s === undefined) return '-'; return s >= 60 ? Math.floor(s / 60) + 'm ' + (s % 60) + 's' : s + 's'; }
  function fmtSize(mb) { return mb === null || mb === undefined ? '-' : (mb >= 1024 ? (mb / 1024).toFixed(2) + ' GB' : mb + ' MB'); }
  function typeLabel(id) { var t = DUMP_TYPES.filter(function (x) { return x.id === id; })[0]; return t ? t.label : id; }
  function toast(msg) {
    var t = document.getElementById('toast'); t.textContent = msg; t.className = 'show';
    clearTimeout(toast.t); toast.t = setTimeout(function () { t.className = ''; }, 4500);
  }
  function clusterById(id) { return state.clusters.filter(function (c) { return c.id === id; })[0]; }
  function clearEl(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  /* ---------- data ---------- */
  function loadClusters() {
    return fetch('/api/clusters', { headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json().then(function (b) { if (!r.ok) throw new Error(b.error || ('HTTP ' + r.status)); return b; }); })
      .then(function (b) { state.clusters = b.clusters || []; state.loadError = null; })
      .catch(function (e) { state.clusters = []; state.loadError = e.message; });
  }
  function buildMockJobs() {
    var cs = state.clusters.filter(function (c) { return c.enabled; });
    if (!cs.length) { state.jobs = []; return; }
    var now = Date.now();
    function c(i) { return cs[i % cs.length]; }
    function job(i, o) {
      var cl = c(i);
      return Object.assign({ id: 'MOCK-' + (1000 + i), env: cl.environment, cluster: cl.name, ns: 'sample-namespace-1',
        pod: 'sample-app-7d9c-abcde', container: 'app', type: 'thread', by: 'mock.user', start: new Date(now - (i + 1) * 3600e3),
        status: 'Completed', stage: 'Finished', duration: 12, size: 1, error: null }, o);
    }
    state.jobs = [
      job(0, { status: 'Running', stage: 'Collecting thread dump 2 of 3', duration: null, size: null }),
      job(1, { type: 'heap', status: 'Completed', duration: 214, size: 1873 }),
      job(2, { type: 'tcp', ns: 'sample-namespace-2', pod: 'sample-batch-5b6d-klmno', container: 'batch', status: 'Failed',
        stage: 'Validating', duration: 4, size: null, error: 'Capture tool not available in container. No approved capture method is configured for this workload.' }),
      job(3, { status: 'Cancelled', stage: 'Cancelled by requester', duration: 9, size: null }),
      job(4, { type: 'heap', status: 'Expired', duration: 190, size: 2210, error: 'File removed by retention policy.' }),
      job(5, { status: 'Completed', duration: 31, size: 2 })
    ];
    state.selectedJob = state.jobs[0].id;
  }

  /* ---------- shared UI ---------- */
  function pageHead(title, sub, mock) {
    return [h('h1', null, title, mock ? mockTag() : null), h('p', { class: 'sub' }, sub)];
  }
  function loadErrorBox() {
    if (!state.loadError) return null;
    return h('div', { class: 'err-box' }, 'Cluster configuration could not be loaded: ' + state.loadError);
  }
  function jobsTable(jobs, withDownload) {
    var head = ['Job ID', 'Started', 'Env', 'Cluster', 'Type', 'Status', 'Size'];
    return h('div', { class: 'tablewrap' }, h('table', null,
      h('thead', null, h('tr', null, head.map(function (x) { return h('th', null, x); }))),
      h('tbody', null, jobs.length ? jobs.map(function (j) {
        return h('tr', null, h('td', null, j.id), h('td', null, fmtDate(j.start)), h('td', null, envBadge(j.env)),
          h('td', null, j.cluster), h('td', null, typeLabel(j.type)), h('td', null, statusBadge(j.status)), h('td', null, fmtSize(j.size)));
      }) : h('tr', null, h('td', { colspan: head.length, class: 'muted' }, 'No jobs.')))));
  }

  /* ---------- pages ---------- */
  function pageDashboard() {
    var enabled = state.clusters.filter(function (c) { return c.enabled; }).length;
    var ok = state.jobs.filter(function (j) { return j.status === 'Completed'; }).length;
    var bad = state.jobs.filter(function (j) { return j.status === 'Failed'; }).length;
    function stat(n, l, t) { return h('div', { class: 'card stat' }, h('div', { class: 'n' }, n), h('div', { class: 'l' }, l), t ? h('div', { class: 't' }, t) : null); }
    var envCards = ENVS.concat(['UNKNOWN']).map(function (env) {
      var list = state.clusters.filter(function (c) { return (ENVS.indexOf(c.environment) >= 0 ? c.environment : 'UNKNOWN') === env; });
      if (env === 'UNKNOWN' && !list.length) return null;
      return h('div', { class: 'card' },
        h('div', { class: 'env-head' }, h('h2', null, env === 'UNKNOWN' ? 'Unrecognised environment' : env), badge(list.length + ' cluster' + (list.length === 1 ? '' : 's'), 'b-grey')),
        list.length ? list.map(function (c) {
          return h('div', { class: 'cl' },
            h('div', null, h('span', { class: 'nm' }, c.name), ' ', badge(c.enabled ? 'Enabled' : 'Disabled', c.enabled ? 'b-ok' : 'b-grey'), ' ',
              badge('Connectivity: not checked', 'b-grey')),
            h('div', { class: 'url' }, c.api_url || '(no API URL configured)'));
        }) : h('div', { class: 'muted' }, 'No clusters configured.'));
    });
    return [pageHead('Dashboard', 'Overview of configured clusters and recent collection activity.'), loadErrorBox(),
      h('div', { class: 'grid stats' },
        stat(state.clusters.length, 'Configured clusters'),
        stat(enabled, 'Enabled clusters'),
        stat(ok, 'Successful jobs', 'Mock data'),
        stat(bad, 'Failed jobs', 'Mock data')),
      h('div', { class: 'info-box' }, 'Connectivity status will come from a real server-side check in Phase 3. Until then every cluster shows "not checked" rather than an assumed status.'),
      h('div', { class: 'grid envs' }, envCards),
      h('h2', null, 'Recent collection jobs', mockTag()), jobsTable(state.jobs.slice(0, 5))];
  }

  function field(labelText, control, hint, errId) {
    return h('label', null, labelText, control, hint ? h('small', null, hint) : null, h('span', { class: 'err', id: errId || '' }));
  }
  function opts(sel, placeholder, items, selected) {
    clearEl(sel);
    sel.appendChild(h('option', { value: '' }, placeholder));
    items.forEach(function (i) { sel.appendChild(h('option', { value: i.value, selected: i.value === selected }, i.label)); });
    sel.disabled = items.length === 0;
  }

  function pageCollect() {
    var s = state.collect;
    var f = {};
    function sel(id) { f[id] = h('select', { id: id, required: true }); return f[id]; }
    function num(id, v, min, max) { f[id] = h('input', { type: 'number', id: id, value: v, min: min, max: max, step: 1 }); return f[id]; }
    var summary = h('div', { class: 'info-box', id: 'clusterInfo' }, 'Select an environment and cluster.');
    var result = h('div', { id: 'result' });
    var typeBox = h('fieldset', { id: 'typeOpts' });

    var form = h('form', { novalidate: true, onsubmit: function (e) { e.preventDefault(); } },
      h('div', { class: 'row' },
        field('Environment', sel('env'), null, 'e_env'),
        field('Cluster', sel('cluster'), 'Enabled clusters in the selected environment', 'e_cluster')),
      summary,
      h('div', { class: 'row' },
        field('Namespace', sel('ns'), 'Mock list - real discovery arrives in Phase 3', 'e_ns'),
        field('Pod', sel('pod'), 'Readiness and status shown', 'e_pod'),
        field('Container', sel('container'), 'Multi-container pods supported', 'e_container'),
        field('Dump Type', sel('type'), null, 'e_type')),
      h('fieldset', null, h('legend', null, 'Advanced options'),
        h('div', { class: 'row' },
          field('Collection timeout (seconds)', num('timeout', LIMITS.timeout.def, LIMITS.timeout.min, LIMITS.timeout.max), LIMITS.timeout.min + '-' + LIMITS.timeout.max, 'e_timeout'),
          field('Output file size limit (MB)', num('size', 50, 1, 50000), 'Server enforces a hard maximum', 'e_size'),
          field('Output location', h('input', { type: 'text', value: 'Managed by the backend', disabled: true }), 'Not user-selectable', '')),
        typeBox),
      h('div', { class: 'actions' },
        h('button', { type: 'button', id: 'bValidate', onclick: onValidate }, 'Validate Request'),
        h('button', { type: 'button', class: 'primary', id: 'bCollect', onclick: onCollect }, 'Collect Dump'),
        h('button', { type: 'button', disabled: true, title: 'Available once the backend runs jobs (Phase 4)' }, 'Cancel Collection'),
        h('button', { type: 'button', disabled: true, title: 'Available after a job completes (Phase 4)' }, 'Download Result'),
        h('button', { type: 'button', onclick: function () { state.collect = {}; render(); } }, 'Reset Form')));

    var root = h('div', null, pageHead('Collect Dump', 'Choose a target and a diagnostic type. Requests are validated before anything runs.'), loadErrorBox(),
      h('div', { class: 'card' }, form, result));

    function v(id) { return f[id].value; }
    function remember() { ['env', 'cluster', 'ns', 'pod', 'container', 'type'].forEach(function (k) { s[k] = v(k); }); }

    function refreshEnv() { opts(f.env, 'Select environment', ENVS.map(function (e) { return { value: e, label: e }; }), s.env); }
    function refreshCluster() {
      var list = state.clusters.filter(function (c) { return c.enabled && c.environment === s.env; });
      opts(f.cluster, s.env ? (list.length ? 'Select cluster' : 'No enabled clusters') : 'Select environment first',
        list.map(function (c) { return { value: c.id, label: c.name }; }), s.cluster);
      var c = clusterById(s.cluster);
      clearEl(summary);
      if (c) { summary.appendChild(h('div', null, h('strong', null, c.name), ' ', envBadge(c.environment))); summary.appendChild(h('div', { class: 'muted' }, 'API endpoint: ' + (c.api_url || '(none configured)'))); }
      else summary.appendChild(document.createTextNode('Select an environment and cluster.'));
    }
    function refreshNs() {
      opts(f.ns, s.cluster ? 'Select namespace' : 'Select cluster first', s.cluster ? Object.keys(MOCK_NAMESPACES).map(function (n) { return { value: n, label: n }; }) : [], s.ns);
    }
    function refreshPod() {
      var pods = s.ns ? MOCK_NAMESPACES[s.ns] : [];
      opts(f.pod, s.ns ? 'Select pod' : 'Select namespace first', pods.map(function (p) { return { value: p.name, label: p.name + '  [' + p.ready + ' ' + p.status + ']' }; }), s.pod);
    }
    function refreshContainer() {
      var pod = s.ns && MOCK_NAMESPACES[s.ns].filter(function (p) { return p.name === s.pod; })[0];
      opts(f.container, pod ? 'Select container' : 'Select pod first', pod ? pod.containers.map(function (c) { return { value: c, label: c }; }) : [], s.container);
    }
    function refreshType() {
      opts(f.type, 'Select dump type', DUMP_TYPES.map(function (t) { return { value: t.id, label: t.label }; }), s.type);
      clearEl(typeBox);
      var t = s.type;
      if (t === 'thread') {
        typeBox.appendChild(h('legend', null, 'Thread dump options'));
        typeBox.appendChild(h('div', { class: 'row' },
          field('Repetitions', num('count', LIMITS.thread.count.def, LIMITS.thread.count.min, LIMITS.thread.count.max), '1-10', 'e_count'),
          field('Interval (seconds)', num('interval', LIMITS.thread.interval.def, LIMITS.thread.interval.min, LIMITS.thread.interval.max), '1-60', 'e_interval')));
      } else if (t === 'heap') {
        typeBox.appendChild(h('legend', null, 'Heap dump options'));
        typeBox.appendChild(h('div', { class: 'warn-box' }, 'Heap dumps can be several GB, pause the JVM and increase memory and disk use. Production collection requires explicit confirmation.'));
      } else if (t === 'tcp') {
        typeBox.appendChild(h('legend', null, 'TCP capture options'));
        typeBox.appendChild(h('div', { class: 'row' },
          field('Capture duration (seconds)', num('duration', LIMITS.tcp.duration.def, LIMITS.tcp.duration.min, LIMITS.tcp.duration.max), '5-300', 'e_duration'),
          field('Approved capture filter', sel('filter'), 'Selected from a fixed list; never free text', 'e_filter')));
        opts(f.filter, 'Select filter', TCP_FILTERS.map(function (x) { return { value: x.id, label: x.label }; }), s.filter);
        f.filter.required = true;
        f.filter.addEventListener('change', function () { s.filter = f.filter.value; });
      } else typeBox.appendChild(h('div', { class: 'muted' }, 'Select a dump type to see its options.'));
      if (t && LIMITS[t]) f.size.value = LIMITS[t].size;
      typeBox.hidden = false;
    }

    f.env.addEventListener('change', function () { remember(); s.cluster = s.ns = s.pod = s.container = ''; refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); });
    f.cluster.addEventListener('change', function () { remember(); s.ns = s.pod = s.container = ''; refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); });
    f.ns.addEventListener('change', function () { remember(); s.pod = s.container = ''; refreshPod(); refreshContainer(); });
    f.pod.addEventListener('change', function () { remember(); s.container = ''; refreshContainer(); });
    f.container.addEventListener('change', remember);
    f.type.addEventListener('change', function () { remember(); refreshType(); });

    refreshEnv(); refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); refreshType();

    function intIn(id, min, max, label, errs) {
      var el = f[id]; if (!el) return;
      var n = Number(el.value);
      if (el.value === '' || !Number.isInteger(n) || n < min || n > max) errs[id] = label + ' must be a whole number from ' + min + ' to ' + max + '.';
    }
    function validate() {
      remember();
      var errs = {};
      if (!s.env) errs.env = 'Required.';
      if (!s.cluster) errs.cluster = 'Required.';
      if (!s.ns) errs.ns = 'Required.';
      if (!s.pod) errs.pod = 'Required.';
      if (!s.container) errs.container = 'Required.';
      if (!s.type) errs.type = 'Required.';
      intIn('timeout', LIMITS.timeout.min, LIMITS.timeout.max, 'Timeout', errs);
      intIn('size', 1, 50000, 'Size limit', errs);
      if (s.type === 'thread') { intIn('count', 1, 10, 'Repetitions', errs); intIn('interval', 1, 60, 'Interval', errs); }
      if (s.type === 'tcp') { intIn('duration', 5, 300, 'Duration', errs); if (!f.filter.value) errs.filter = 'Select an approved filter.'; if (Number(f.timeout.value) <= Number(f.duration.value)) errs.timeout = 'Timeout must exceed the capture duration.'; }
      Object.keys(f).forEach(function (k) { f[k].classList.remove('invalid'); var e = document.getElementById('e_' + k); if (e) e.textContent = ''; });
      Object.keys(errs).forEach(function (k) { if (f[k]) f[k].classList.add('invalid'); var e = document.getElementById('e_' + k); if (e) e.textContent = errs[k]; });
      return Object.keys(errs).length === 0;
    }
    function showResult(ok, msg) { clearEl(result); result.appendChild(h('div', { class: (ok ? 'ok-box' : 'err-box') + ' mt' }, msg)); }
    function onValidate() {
      if (validate()) showResult(true, 'Client-side checks passed. Server-side validation (identity, namespace/pod access, container membership, tool availability) is not implemented yet.');
      else showResult(false, 'Please correct the highlighted fields.');
    }
    function onCollect() {
      if (!validate()) return showResult(false, 'Please correct the highlighted fields.');
      var c = clusterById(s.cluster);
      if (c && c.environment === 'PROD') return confirmProd(c);
      done();
    }
    function done() { showResult(false, 'Prototype only: the backend does not exist yet, so nothing was collected and no job was created.'); toast('No collection performed (prototype).'); }
    function confirmProd(c) {
      var dlg = document.getElementById('confirm'); clearEl(dlg);
      var needTyped = s.type === 'heap';
      var chk = h('input', { type: 'checkbox', id: 'ck' });
      var typed = h('input', { type: 'text', id: 'tp', autocomplete: 'off', placeholder: c.name });
      var go = h('button', { class: 'danger', type: 'button', disabled: true, onclick: function () { dlg.close(); done(); } }, 'Confirm collection on PROD');
      function upd() { go.disabled = !(chk.checked && (!needTyped || typed.value === c.name)); }
      chk.addEventListener('change', upd); typed.addEventListener('input', upd);
      dlg.appendChild(h('h2', null, 'Confirm PRODUCTION collection'));
      dlg.appendChild(h('p', null, typeLabel(s.type) + ' from ', h('strong', null, s.pod + ' / ' + s.container), ' in ', h('strong', null, s.ns), ' on ', h('strong', null, c.name), '.'));
      if (needTyped) dlg.appendChild(h('div', { class: 'warn-box' }, 'A heap dump can pause the JVM, consume significant memory and disk and affect live users.'));
      dlg.appendChild(h('label', { class: 'inline-label' }, chk, 'I understand this runs against a production workload and will be audited.'));
      if (needTyped) dlg.appendChild(h('label', { class: 'mt' }, 'Type the cluster name to confirm', typed));
      dlg.appendChild(h('div', { class: 'actions mt' }, go, h('button', { type: 'button', onclick: function () { dlg.close(); } }, 'Cancel')));
      dlg.showModal();
    }
    return root;
  }

  function jobDetail(j) {
    function item(k, val) { return h('div', null, h('dt', null, k), h('dd', null, val)); }
    return h('div', null,
      h('dl', { class: 'detail' },
        item('Job ID', j.id), item('Status', statusBadge(j.status)), item('Environment', envBadge(j.env)), item('Cluster', j.cluster),
        item('Namespace', j.ns), item('Pod', j.pod), item('Container', j.container), item('Dump type', typeLabel(j.type)),
        item('Requested by', j.by), item('Start time', fmtDate(j.start)),
        item('Current stage', h('span', { class: 'stage' }, j.stage)), item('Output size', fmtSize(j.size))),
      j.error ? h('div', { class: j.status === 'Failed' ? 'err-box' : 'info-box' }, j.error) : null,
      h('div', { class: 'info-box' }, 'No progress percentage is shown: the backend reports stages, not a calculated percentage.'),
      h('div', { class: 'actions' }, h('button', { type: 'button', disabled: true, title: 'Mock job - no file exists' }, 'Download Result')));
  }
  function pageProgress() {
    var detail = h('div', { class: 'card' });
    function show() { clearEl(detail); var j = state.jobs.filter(function (x) { return x.id === state.selectedJob; })[0]; detail.appendChild(j ? jobDetail(j) : h('div', { class: 'muted' }, 'Select a job.')); }
    var list = h('ul', { class: 'joblist' }, state.jobs.map(function (j) {
      function pick() { state.selectedJob = j.id; render(); }
      return h('li', { class: j.id === state.selectedJob ? 'sel' : '', tabindex: 0, role: 'button', onclick: pick,
        onkeydown: function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } } },
        h('div', null, h('strong', null, j.id), ' ', statusBadge(j.status)), h('div', { class: 'muted' }, typeLabel(j.type) + ' - ' + j.cluster));
    }));
    show();
    return [pageHead('Collection Progress', 'Status and current stage of collection jobs.', true),
      state.jobs.length ? h('div', { class: 'two' }, h('div', null, list), detail) : h('div', { class: 'card muted' }, 'No jobs to show.')];
  }

  function pageHistory() {
    var hf = state.hist;
    var tbody = h('tbody');
    var count = h('span', { class: 'muted' });
    function draw() {
      var q = hf.q.trim().toLowerCase();
      var rows = state.jobs.filter(function (j) {
        if (hf.env && j.env !== hf.env) return false;
        if (hf.status && j.status !== hf.status) return false;
        if (hf.type && j.type !== hf.type) return false;
        return !q || [j.id, j.cluster, j.ns, j.pod, j.container, j.by].join(' ').toLowerCase().indexOf(q) >= 0;
      });
      clearEl(tbody);
      count.textContent = rows.length + ' of ' + state.jobs.length + ' mock jobs';
      if (!rows.length) tbody.appendChild(h('tr', null, h('td', { colspan: 14, class: 'muted' }, 'No matching jobs.')));
      rows.forEach(function (j) {
        tbody.appendChild(h('tr', null, h('td', null, j.id), h('td', null, fmtDate(j.start)), h('td', null, envBadge(j.env)), h('td', null, j.cluster),
          h('td', null, j.ns), h('td', null, j.pod), h('td', null, j.container), h('td', null, typeLabel(j.type)), h('td', null, j.by),
          h('td', null, fmtDur(j.duration)), h('td', null, statusBadge(j.status)), h('td', null, fmtSize(j.size)),
          h('td', null, h('button', { type: 'button', disabled: true, title: 'Mock job - no file exists' }, 'Download')),
          h('td', { class: 'wrap' }, j.error || '-')));
      });
    }
    function select(key, label, items) {
      var el = h('select', { 'aria-label': label, onchange: function () { hf[key] = el.value; draw(); } },
        h('option', { value: '' }, label), items.map(function (i) { return h('option', { value: i.v, selected: hf[key] === i.v }, i.l); }));
      return el;
    }
    var search = h('input', { type: 'search', placeholder: 'Search job, cluster, namespace, pod, user...', value: hf.q, 'aria-label': 'Search history',
      oninput: function () { hf.q = search.value; draw(); } });
    var heads = ['Job ID', 'Date / time', 'Env', 'Cluster', 'Namespace', 'Pod', 'Container', 'Type', 'Requested by', 'Duration', 'Status', 'File size', 'Download', 'Failure details'];
    var page = [pageHead('Collection History', 'Searchable record of collection jobs. This prototype history is temporary mock data; durable, audited history is added in Phase 7.', true),
      h('div', { class: 'toolbar' }, search, select('env', 'All environments', ENVS.map(function (e) { return { v: e, l: e }; })),
        select('status', 'All statuses', Object.keys(STATUS_CLS).map(function (e) { return { v: e, l: e }; })),
        select('type', 'All types', DUMP_TYPES.map(function (t) { return { v: t.id, l: t.label }; })), count),
      h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, heads.map(function (x) { return h('th', null, x); }))), tbody))];
    draw();
    return page;
  }

  function pageClusters() {
    var rows = state.clusters.map(function (c) {
      var toggle = h('input', { type: 'checkbox', checked: c.enabled, 'aria-label': 'Enable ' + c.name, disabled: true, title: 'Enable/disable needs administrator authorization (backend, later phase)' });
      return h('tr', null, h('td', null, c.name), h('td', null, envBadge(c.environment)), h('td', { class: 'wrap' }, c.api_url || '-'),
        h('td', null, badge(c.enabled ? 'Enabled' : 'Disabled', c.enabled ? 'b-ok' : 'b-grey')),
        h('td', null, badge('No check performed', 'b-grey')),
        h('td', null, toggle), h('td', null, h('button', { type: 'button', disabled: true, title: 'Real connectivity checks arrive in Phase 3' }, 'Check connectivity')));
    });
    var heads = ['Cluster', 'Environment', 'API endpoint', 'Configured status', 'Latest connectivity check', 'Enabled in app', 'Action'];
    return [pageHead('Cluster Management', 'Read-only view of configured clusters. Credentials are never shown or sent to the browser.'), loadErrorBox(),
      h('div', { class: 'info-box' }, 'Connectivity checks and enable/disable are restricted administrator actions and are implemented server-side in later phases. This page offers no other cluster administration.'),
      h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, heads.map(function (x) { return h('th', null, x); }))),
        h('tbody', null, rows.length ? rows : h('tr', null, h('td', { colspan: heads.length, class: 'muted' }, 'No clusters configured.')))))];
  }

  /* ---------- router ---------- */
  var ROUTES = { dashboard: pageDashboard, collect: pageCollect, progress: pageProgress, history: pageHistory, clusters: pageClusters };
  function render() {
    var route = (location.hash.replace(/^#\//, '') || 'dashboard');
    if (!ROUTES[route]) route = 'dashboard';
    Array.prototype.forEach.call(document.querySelectorAll('#nav a'), function (a) {
      var on = a.getAttribute('data-route') === route; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    var view = document.getElementById('view'); clearEl(view);
    (function add(n) { if (Array.isArray(n)) return n.forEach(add); if (n) view.appendChild(n); })(ROUTES[route]());
  }
  window.addEventListener('hashchange', function () { render(); });
  loadClusters().then(function () { buildMockJobs(); render(); });
})();
