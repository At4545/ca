#!/usr/bin/env python3
"""OpenShift Dump Collector - Phase 2 local development server.

Standard library only (Python 3.9 compatible).
  * Binds to 127.0.0.1 by default (use an SSH tunnel from your workstation).
  * Serves ONLY index.html, style.css, script.js. clusters.json is never served.
  * /api/clusters returns sanitized metadata (no credentials).
  * NOT a production server: no authentication, no HTTPS. See README.
"""
import argparse
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from backend.configuration import ConfigError, load_clusters

ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/script.js": ("script.js", "application/javascript; charset=utf-8"),
}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")


class Handler(BaseHTTPRequestHandler):
    server_version = "DumpCollector/0.2"
    sys_version = ""

    def _host_ok(self):
        # Mitigates DNS-rebinding: only accept the host:port we are bound to.
        host = (self.headers.get("Host") or "").lower()
        return host in self.server.allowed_hosts

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json")

    def do_GET(self):
        if not self._host_ok():
            return self._json(400, {"error": "Unexpected Host header"})
        path = self.path.split("?", 1)[0]
        if path in STATIC:
            fname, ctype = STATIC[path]
            with open(os.path.join(ROOT, fname), "rb") as fh:
                return self._send(200, fh.read(), ctype)
        if path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        if path == "/api/health":
            return self._json(200, {"status": "ok", "phase": 2})
        if path == "/api/clusters":
            try:
                clusters = load_clusters(self.server.clusters_path)
            except ConfigError as exc:
                return self._json(500, {"error": str(exc)})
            return self._json(200, {"clusters": clusters})
        return self._json(404, {"error": "Not found"})

    def do_POST(self):
        self._json(405, {"error": "No write endpoints exist in Phase 2"})

    do_PUT = do_DELETE = do_PATCH = do_POST

    def log_message(self, fmt, *args):  # request line only; no headers/bodies
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--clusters", default=os.path.join(ROOT, "clusters.json"))
    a = ap.parse_args()
    if a.host not in ("127.0.0.1", "localhost", "::1"):
        print("Refusing non-loopback bind: Phase 2 has no authentication or HTTPS.", file=sys.stderr)
        sys.exit(2)
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    srv.clusters_path = a.clusters
    srv.allowed_hosts = {"127.0.0.1:%d" % a.port, "localhost:%d" % a.port}
    print("OpenShift Dump Collector (Phase 2 prototype) on http://%s:%d  [clusters: %s]"
          % (a.host, a.port, a.clusters))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
