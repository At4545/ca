/* OpenShift Dump Collector - frontend (Phase 4).
 * Talks only to the portal's own JSON API. Never builds or sends commands, never receives
 * secrets. All DOM is built with textContent/createElement (no innerHTML with data).
 * Implemented: thread dump. Heap/TCP are listed but disabled until their phases.
 */
(function () {
  'use strict';

  var ENVS = ['DEV', 'TEST', 'PROD'];
  var DUMP_TYPES = [
    { id: 'thread', label: 'Thread Dump', ok: true },
    { id: 'heap', label: 'Heap Dump (not available yet - Phase 5)', ok: false },
    { id: 'tcp', label: 'TCP Dump (not available yet - Phase 6)', ok: false }
  ];
  var ACTIVE = ['Pending', 'Validating', 'Running'];
  var STATUS_CLS = { Pending: 'b-grey', Validating: 'b-info', Running: 'b-info', Completed: 'b-ok', Failed: 'b-bad', Cancelled: 'b-warn', Expired: 'b-grey' };
  var LIM = { timeout: [30, 1800, 300], size: [1, 50, 50], count: [1, 10, 3], interval: [1, 60, 10] };

  var state = { clusters: [], loadError: null, jobs: [], me: null, selectedJob: null, collect: {}, hist: { q: '', env: '', status: '', type: '' }, updatePanel: null };
  var poll = { timer: null };

  /* ---------- helpers ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    var a = attrs || {};
    Object.keys(a).forEach(function (k) {
      var v = a[k];
      if (v === false || v === null || v === undefined) return;
      if (k === 'class') el.className = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, String(v));
    });
    Array.prototype.slice.call(arguments, 2).forEach(function add(kid) {
      if (Array.isArray(kid)) return kid.forEach(add);
      if (kid === null || kid === undefined || kid === false) return;
      el.appendChild(kid.nodeType ? kid : document.createTextNode(String(kid)));
    });
    return el;
  }
  function clearEl(el) { while (el.firstChild) el.removeChild(el.firstChild); }
  function badge(text, cls) { return h('span', { class: 'badge ' + cls }, text); }
  function envBadge(env) { return badge(env, 'b-' + (ENVS.indexOf(env) >= 0 ? env : 'grey')); }
  function statusBadge(s) { return badge(s, STATUS_CLS[s] || 'b-grey'); }
  function fmtDate(ts) { return ts ? new Date(ts * 1000).toLocaleString() : '-'; }
  function fmtDur(s) { if (s === null || s === undefined) return '-'; s = Math.round(s); return s >= 60 ? Math.floor(s / 60) + 'm ' + (s % 60) + 's' : s + 's'; }
  function fmtSize(b) {
    if (b === null || b === undefined) return '-';
    if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
    if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB';
    if (b >= 1024) return (b / 1024).toFixed(1) + ' KB';
    return b + ' B';
  }
  function typeLabel(id) { return id === 'thread' ? 'Thread Dump' : id === 'heap' ? 'Heap Dump' : id === 'tcp' ? 'TCP Dump' : id; }
  function toast(msg) {
    var t = document.getElementById('toast'); t.textContent = msg; t.className = 'show';
    clearTimeout(toast.t); toast.t = setTimeout(function () { t.className = ''; }, 4500);
  }
  function clusterById(id) { return state.clusters.filter(function (c) { return c.id === id; })[0]; }
  function jobById(id) { return state.jobs.filter(function (j) { return j.id === id; })[0]; }
  function route() { var r = location.hash.replace(/^#\//, '') || 'dashboard'; return ROUTES[r] ? r : 'dashboard'; }

  function api(method, path, body) {
    var opts = { method: method, headers: { Accept: 'application/json' } };
    if (method === 'POST') { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body || {}); }
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (b) {
        if (!r.ok) { var e = new Error(b.error || ('HTTP ' + r.status)); e.details = b.details; e.status = r.status; throw e; }
        return b;
      });
    });
  }

  /* ---------- data ---------- */
  function loadClusters() {
    return api('GET', '/api/clusters').then(function (b) { state.clusters = b.clusters || []; state.loadError = null; })
      .catch(function (e) { state.clusters = []; state.loadError = e.message; });
  }
  function loadJobs() { return api('GET', '/api/jobs').then(function (b) { state.jobs = b.jobs || []; }); }
  function anyActive() { return state.jobs.some(function (j) { return j.active; }); }
  function startPolling() {
    if (poll.timer) return;
    poll.timer = setInterval(function () {
      loadJobs().then(function () {
        var r = route();
        if (r === 'progress' || r === 'dashboard') render();
        else if (r === 'collect' && state.updatePanel) state.updatePanel();
        if (!anyActive()) { clearInterval(poll.timer); poll.timer = null; }
      }).catch(function () { });
    }, 2000);
  }

  /* ---------- shared UI ---------- */
  function pageHead(title, sub) { return [h('h1', null, title), h('p', { class: 'sub' }, sub)]; }
  function loadErrorBox() { return state.loadError ? h('div', { class: 'err-box' }, 'Cluster configuration could not be loaded: ' + state.loadError) : null; }
  function downloadBtn(j) {
    return j && j.download_available ? h('a', { class: 'btn primary', href: '/api/jobs/' + encodeURIComponent(j.id) + '/download' }, 'Download Result')
      : h('button', { type: 'button', disabled: true, title: 'Available after a job completes' }, 'Download Result');
  }
  function checksList(checks) {
    if (!checks || !checks.length) return null;
    return h('ul', { class: 'checks' }, checks.map(function (c) {
      var cls = c.skipped ? 'chk-skip' : c.ok ? 'chk-ok' : 'chk-bad';
      return h('li', null, h('span', { class: cls }, c.skipped ? '\u25CB ' : c.ok ? '\u2714 ' : '\u2718 '), h('span', { class: 'nm' }, c.name + ': '), c.message);
    }));
  }
  function jobsTable(jobs) {
    var head = ['Job ID', 'Started', 'Env', 'Cluster', 'Type', 'Status', 'Size'];
    return h('div', { class: 'tablewrap' }, h('table', null,
      h('thead', null, h('tr', null, head.map(function (x) { return h('th', null, x); }))),
      h('tbody', null, jobs.length ? jobs.map(function (j) {
        return h('tr', null, h('td', null, j.id), h('td', null, fmtDate(j.created)), h('td', null, envBadge(j.env)), h('td', null, j.cluster),
          h('td', null, typeLabel(j.dump_type)), h('td', null, statusBadge(j.status)), h('td', null, fmtSize(j.size_bytes)));
      }) : h('tr', null, h('td', { colspan: head.length, class: 'muted' }, 'No collection jobs yet.')))));
  }

  /* ---------- Dashboard ---------- */
  function pageDashboard() {
    var enabled = state.clusters.filter(function (c) { return c.enabled; }).length;
    var ok = state.jobs.filter(function (j) { return j.status === 'Completed'; }).length;
    var bad = state.jobs.filter(function (j) { return j.status === 'Failed'; }).length;
    function stat(n, l) { return h('div', { class: 'card stat' }, h('div', { class: 'n' }, n), h('div', { class: 'l' }, l)); }
    var envCards = ENVS.concat(['UNKNOWN']).map(function (env) {
      var list = state.clusters.filter(function (c) { return (ENVS.indexOf(c.environment) >= 0 ? c.environment : 'UNKNOWN') === env; });
      if (env === 'UNKNOWN' && !list.length) return null;
      return h('div', { class: 'card' },
        h('div', { class: 'env-head' }, h('h2', null, env === 'UNKNOWN' ? 'Unrecognised environment' : env), badge(list.length + ' cluster' + (list.length === 1 ? '' : 's'), 'b-grey')),
        list.length ? list.map(function (c) {
          return h('div', { class: 'cl' },
            h('div', null, h('span', { class: 'nm' }, c.name), ' ', badge(c.enabled ? 'Enabled' : 'Disabled', c.enabled ? 'b-ok' : 'b-grey'), ' ', badge('Connectivity: not checked', 'b-grey')),
            h('div', { class: 'url' }, c.api_url || '(no API URL configured)'));
        }) : h('div', { class: 'muted' }, 'No clusters configured.'));
    });
    return [pageHead('Dashboard', 'Overview of configured clusters and recent collection activity.'), loadErrorBox(),
      h('div', { class: 'grid stats' }, stat(state.clusters.length, 'Configured clusters'), stat(enabled, 'Enabled clusters'), stat(ok, 'Successful jobs'), stat(bad, 'Failed jobs')),
      h('div', { class: 'info-box' }, 'Dedicated connectivity checks are not implemented yet, so status shows "not checked". A cluster is verified for real when you list its namespaces or start a collection.'),
      h('div', { class: 'grid envs' }, envCards), h('h2', null, 'Recent collection jobs'), jobsTable(state.jobs.slice(0, 5))];
  }

  /* ---------- Collect Dump ---------- */
  function field(labelText, control, hint, errId) {
    return h('label', null, labelText, control, hint ? h('small', null, hint) : null, h('span', { class: 'err', id: errId || '' }));
  }
  function fillSelect(sel, placeholder, items, selected) {
    clearEl(sel);
    sel.appendChild(h('option', { value: '' }, placeholder));
    items.forEach(function (i) { sel.appendChild(h('option', { value: i.value, selected: i.value === selected, disabled: !!i.disabled }, i.label)); });
    sel.disabled = items.length === 0;
  }

  function pageCollect() {
    var s = state.collect = { jobId: state.collect.jobId };
    var f = {}, nsList = [], podList = [], seq = 0;
    function sel(id) { f[id] = h('select', { id: id, required: true }); return f[id]; }
    function num(id, d, lim) { f[id] = h('input', { type: 'number', id: id, value: d, min: lim[0], max: lim[1], step: 1 }); return f[id]; }
    var summary = h('div', { class: 'info-box' }, 'Select an environment and cluster.');
    var discErr = h('div', { class: 'err-box', hidden: true });
    var result = h('div', { id: 'result' });
    var panel = h('div', { class: 'mt' });

    var form = h('form', { novalidate: true, onsubmit: function (e) { e.preventDefault(); } },
      h('div', { class: 'row' }, field('Environment', sel('env'), null, 'e_env'), field('Cluster', sel('cluster'), 'Enabled clusters in the selected environment', 'e_cluster')),
      summary, discErr,
      h('div', { class: 'row' },
        field('Namespace', sel('ns'), 'Only namespaces your oc login can access', 'e_ns'),
        field('Pod', sel('pod'), 'Readiness and status shown; only Running pods can be selected', 'e_pod'),
        field('Container', sel('container'), 'Multi-container pods supported', 'e_container'),
        field('Dump Type', sel('type'), null, 'e_type')),
      h('fieldset', null, h('legend', null, 'Advanced options'),
        h('div', { class: 'row' },
          field('Collection timeout (seconds)', num('timeout', LIM.timeout[2], LIM.timeout), '30-1800', 'e_timeout'),
          field('Output file size limit (MB)', num('size', LIM.size[2], LIM.size), '1-50 for thread dumps', 'e_size'),
          field('Thread dumps to take', num('count', LIM.count[2], LIM.count), '1-10', 'e_count'),
          field('Interval between dumps (seconds)', num('interval', LIM.interval[2], LIM.interval), '1-60', 'e_interval'),
          field('Output location', h('input', { type: 'text', value: 'Managed by the backend', disabled: true }), 'Not user-selectable'))),
      h('div', { class: 'actions' },
        h('button', { type: 'button', onclick: onValidate }, 'Validate Request'),
        h('button', { type: 'button', class: 'primary', id: 'bCollect', onclick: onCollect }, 'Collect Dump'),
        h('button', { type: 'button', id: 'bCancel', disabled: true, onclick: onCancel }, 'Cancel Collection'),
        h('span', { id: 'dlslot' }, downloadBtn(null)),
        h('button', { type: 'button', onclick: function () { state.collect = {}; render(); } }, 'Reset Form')));

    var root = h('div', null, pageHead('Collect Dump', 'Choose a target and run a thread dump. Every request is re-validated on the server before anything runs.'),
      loadErrorBox(), h('div', { class: 'card' }, form, result, panel));

    function v(id) { return f[id].value; }
    function remember() { ['env', 'cluster', 'ns', 'pod', 'container', 'type'].forEach(function (k) { s[k] = v(k); }); }
    function showDisc(msg) { discErr.hidden = !msg; discErr.textContent = msg || ''; }

    function refreshEnv() { fillSelect(f.env, 'Select environment', ENVS.map(function (e) { return { value: e, label: e }; }), s.env); }
    function refreshCluster() {
      var list = state.clusters.filter(function (c) { return c.enabled && c.environment === s.env; });
      fillSelect(f.cluster, s.env ? (list.length ? 'Select cluster' : 'No enabled clusters') : 'Select environment first', list.map(function (c) { return { value: c.id, label: c.name }; }), s.cluster);
      var c = clusterById(s.cluster); clearEl(summary);
      if (c) { summary.appendChild(h('div', null, h('strong', null, c.name), ' ', envBadge(c.environment))); summary.appendChild(h('div', { class: 'muted' }, 'API endpoint: ' + (c.api_url || '(none configured)'))); }
      else summary.appendChild(document.createTextNode('Select an environment and cluster.'));
    }
    function refreshNs() { fillSelect(f.ns, s.cluster ? (nsList.length ? 'Select namespace' : 'Loading...') : 'Select cluster first', nsList.map(function (n) { return { value: n, label: n }; }), s.ns); }
    function refreshPod() {
      fillSelect(f.pod, s.ns ? (podList.length ? 'Select pod' : 'Loading...') : 'Select namespace first', podList.map(function (p) {
        return { value: p.name, label: p.name + '  [' + p.ready + ' ' + p.phase + ']', disabled: p.phase !== 'Running' };
      }), s.pod);
    }
    function refreshContainer() {
      var pod = podList.filter(function (p) { return p.name === s.pod; })[0];
      fillSelect(f.container, pod ? 'Select container' : 'Select pod first', pod ? pod.containers.map(function (c) { return { value: c.name, label: c.name + '  [' + c.state + ']' }; }) : [], s.container);
    }
    function refreshType() { fillSelect(f.type, 'Select dump type', DUMP_TYPES.map(function (t) { return { value: t.id, label: t.label, disabled: !t.ok }; }), s.type); }

    function loadNamespaces() {
      var my = ++seq; nsList = []; podList = []; refreshNs(); refreshPod(); refreshContainer(); showDisc('');
      if (!s.cluster) return;
      api('GET', '/api/clusters/' + encodeURIComponent(s.cluster) + '/namespaces').then(function (b) {
        if (my !== seq) return; nsList = b.namespaces; refreshNs();
        if (!nsList.length) { f.ns.options[0].textContent = 'No accessible namespaces'; f.ns.disabled = true; }
      }).catch(function (e) { if (my !== seq) return; refreshNs(); f.ns.options[0].textContent = 'Unavailable'; f.ns.disabled = true; showDisc(e.message); });
    }
    function loadPods() {
      var my = ++seq; podList = []; refreshPod(); refreshContainer(); showDisc('');
      if (!s.ns) return;
      api('GET', '/api/clusters/' + encodeURIComponent(s.cluster) + '/namespaces/' + encodeURIComponent(s.ns) + '/pods').then(function (b) {
        if (my !== seq) return; podList = b.pods; refreshPod();
        if (!podList.length) { f.pod.options[0].textContent = 'No pods in this namespace'; f.pod.disabled = true; }
      }).catch(function (e) { if (my !== seq) return; refreshPod(); f.pod.options[0].textContent = 'Unavailable'; f.pod.disabled = true; showDisc(e.message); });
    }

    f.env.addEventListener('change', function () { remember(); s.cluster = s.ns = s.pod = s.container = ''; nsList = []; podList = []; seq++; refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); showDisc(''); });
    f.cluster.addEventListener('change', function () { remember(); s.ns = s.pod = s.container = ''; refreshCluster(); loadNamespaces(); });
    f.ns.addEventListener('change', function () { remember(); s.pod = s.container = ''; loadPods(); });
    f.pod.addEventListener('change', function () { remember(); s.container = ''; refreshContainer(); });
    f.container.addEventListener('change', remember);
    f.type.addEventListener('change', remember);
    refreshEnv(); refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); refreshType();

    function intIn(id, lim, label, errs) {
      var n = Number(f[id].value);
      if (f[id].value === '' || !Number.isInteger(n) || n < lim[0] || n > lim[1]) errs[id] = label + ' must be a whole number from ' + lim[0] + ' to ' + lim[1] + '.';
    }
    function validateLocal() {
      remember(); var errs = {};
      ['env', 'cluster', 'ns', 'pod', 'container', 'type'].forEach(function (k) { if (!s[k]) errs[k] = 'Required.'; });
      intIn('timeout', LIM.timeout, 'Timeout', errs); intIn('size', LIM.size, 'Size limit', errs);
      intIn('count', LIM.count, 'Count', errs); intIn('interval', LIM.interval, 'Interval', errs);
      if (!errs.timeout && !errs.count && !errs.interval && (Number(v('count')) - 1) * Number(v('interval')) + 10 >= Number(v('timeout'))) errs.timeout = 'Too short for that many dumps and interval.';
      Object.keys(f).forEach(function (k) { f[k].classList.remove('invalid'); var e = document.getElementById('e_' + k); if (e) e.textContent = ''; });
      Object.keys(errs).forEach(function (k) { if (f[k]) f[k].classList.add('invalid'); var e = document.getElementById('e_' + k); if (e) e.textContent = errs[k]; });
      return Object.keys(errs).length === 0;
    }
    function body(confirmProd) {
      return { cluster: s.cluster, namespace: s.ns, pod: s.pod, container: s.container, dump_type: s.type,
        options: { timeout: Number(v('timeout')), size_limit_mb: Number(v('size')), count: Number(v('count')), interval: Number(v('interval')) }, confirm_prod: !!confirmProd };
    }
    function showBox(cls, msg, extra) { clearEl(result); result.appendChild(h('div', { class: cls + ' mt' }, msg)); if (extra) result.appendChild(extra); }

    function onValidate() {
      if (!validateLocal()) return showBox('err-box', 'Please correct the highlighted fields.');
      showBox('info-box', 'Validating on the server...');
      api('POST', '/api/validate', body(false)).then(function (r) {
        showBox(r.ok ? 'ok-box' : 'err-box', r.ok ? 'All pre-collection checks passed.' : 'Validation failed. Nothing was collected.', checksList(r.checks));
      }).catch(function (e) { showBox('err-box', e.message); });
    }
    function onCollect() {
      if (!validateLocal()) return showBox('err-box', 'Please correct the highlighted fields.');
      var c = clusterById(s.cluster);
      if (c && c.environment === 'PROD') return confirmProd(c);
      submit(false);
    }
    function submit(confirmed) {
      clearEl(result);
      api('POST', '/api/jobs', body(confirmed)).then(function (r) {
        s.jobId = r.job.id; state.jobs = [r.job].concat(state.jobs.filter(function (j) { return j.id !== r.job.id; }));
        state.selectedJob = r.job.id; updatePanel(); startPolling(); toast('Job ' + r.job.id + ' queued.');
      }).catch(function (e) {
        var d = e.details ? ' ' + Object.keys(e.details).map(function (k) { return k + ': ' + e.details[k]; }).join('; ') : '';
        showBox('err-box', e.message + d);
      });
    }
    function onCancel() {
      if (!s.jobId) return;
      api('POST', '/api/jobs/' + encodeURIComponent(s.jobId) + '/cancel', {}).then(function () { toast('Cancel requested.'); return loadJobs(); }).then(updatePanel)
        .catch(function (e) { toast(e.message); });
    }
    function updatePanel() {
      var j = s.jobId && jobById(s.jobId);
      clearEl(panel);
      var slot = document.getElementById('dlslot'); if (slot) { clearEl(slot); slot.appendChild(downloadBtn(j)); }
      var cancelBtn = document.getElementById('bCancel'); if (cancelBtn) cancelBtn.disabled = !(j && j.active);
      if (!j) return;
      panel.appendChild(h('div', { class: 'info-box' }, h('strong', null, 'Job ' + j.id + ' '), statusBadge(j.status), ' ', h('span', { class: 'stage' }, j.stage), ' ',
        h('a', { href: '#/progress' }, 'View on Progress page')));
      if (j.error) panel.appendChild(h('div', { class: j.status === 'Failed' ? 'err-box' : 'info-box' }, j.error));
      if (j.status === 'Failed') panel.appendChild(checksList(j.checks));
      if (j.status === 'Completed') panel.appendChild(h('div', { class: 'ok-box' }, 'Completed: ' + fmtSize(j.size_bytes) + ' in ' + fmtDur(j.duration) + '.'));
    }
    state.updatePanel = updatePanel;
    function confirmProd(c) {
      var dlg = document.getElementById('confirm'); clearEl(dlg);
      var chk = h('input', { type: 'checkbox', id: 'ck' });
      var go = h('button', { class: 'danger', type: 'button', disabled: true, onclick: function () { dlg.close(); submit(true); } }, 'Confirm collection on PROD');
      chk.addEventListener('change', function () { go.disabled = !chk.checked; });
      dlg.appendChild(h('h2', null, 'Confirm PRODUCTION collection'));
      dlg.appendChild(h('p', null, 'Thread dump from ', h('strong', null, s.pod + ' / ' + s.container), ' in ', h('strong', null, s.ns), ' on ', h('strong', null, c.name), '.'));
      dlg.appendChild(h('div', { class: 'warn-box' }, 'Thread dumps briefly pause the JVM at a safepoint. Taking several in a row on a busy production service can add latency.'));
      dlg.appendChild(h('label', { class: 'inline-label' }, chk, 'I understand this runs against a production workload and will be audited.'));
      dlg.appendChild(h('div', { class: 'actions mt' }, go, h('button', { type: 'button', onclick: function () { dlg.close(); } }, 'Cancel')));
      dlg.showModal();
    }
    updatePanel();
    return root;
  }

  /* ---------- Progress ---------- */
  function jobDetail(j) {
    function item(k, val) { return h('div', null, h('dt', null, k), h('dd', null, val)); }
    return h('div', null,
      h('dl', { class: 'detail' }, item('Job ID', j.id), item('Status', statusBadge(j.status)), item('Environment', envBadge(j.env)), item('Cluster', j.cluster),
        item('Namespace', j.namespace), item('Pod', j.pod), item('Container', j.container), item('Dump type', typeLabel(j.dump_type)),
        item('Requested by', j.requested_by), item('Cluster identity', j.identity || '-'), item('Start time', fmtDate(j.created)),
        item('Current stage', h('span', { class: 'stage' }, j.stage)), item('Output size', fmtSize(j.size_bytes)), item('Duration', fmtDur(j.duration))),
      j.error ? h('div', { class: j.status === 'Failed' ? 'err-box' : 'info-box' }, j.error) : null,
      checksList(j.checks),
      h('div', { class: 'info-box' }, 'No percentage is shown: the backend reports the current stage, not a calculated progress value.'),
      h('div', { class: 'actions' }, downloadBtn(j),
        j.active ? h('button', { type: 'button', onclick: function () { api('POST', '/api/jobs/' + encodeURIComponent(j.id) + '/cancel', {}).then(function () { toast('Cancel requested.'); return loadJobs(); }).then(render).catch(function (e) { toast(e.message); }); } }, 'Cancel Collection') : null));
  }
  function pageProgress() {
    if (!state.selectedJob && state.jobs.length) state.selectedJob = state.jobs[0].id;
    var j = jobById(state.selectedJob);
    var list = h('ul', { class: 'joblist' }, state.jobs.slice(0, 30).map(function (x) {
      function pick() { state.selectedJob = x.id; render(); }
      return h('li', { class: x.id === state.selectedJob ? 'sel' : '', tabindex: 0, role: 'button', onclick: pick, onkeydown: function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } } },
        h('div', null, h('strong', null, x.id), ' ', statusBadge(x.status)), h('div', { class: 'muted' }, typeLabel(x.dump_type) + ' - ' + x.cluster));
    }));
    return [pageHead('Collection Progress', 'Status and current stage of collection jobs.'),
      state.jobs.length ? h('div', { class: 'two' }, h('div', null, list), h('div', { class: 'card' }, j ? jobDetail(j) : h('div', { class: 'muted' }, 'Select a job.'))) : h('div', { class: 'card muted' }, 'No collection jobs yet.')];
  }

  /* ---------- History ---------- */
  function pageHistory() {
    var hf = state.hist, tbody = h('tbody'), count = h('span', { class: 'muted' });
    function draw() {
      var q = hf.q.trim().toLowerCase();
      var rows = state.jobs.filter(function (j) {
        if (hf.env && j.env !== hf.env) return false; if (hf.status && j.status !== hf.status) return false; if (hf.type && j.dump_type !== hf.type) return false;
        return !q || [j.id, j.cluster, j.namespace, j.pod, j.container, j.requested_by].join(' ').toLowerCase().indexOf(q) >= 0;
      });
      clearEl(tbody); count.textContent = rows.length + ' of ' + state.jobs.length + ' jobs';
      if (!rows.length) tbody.appendChild(h('tr', null, h('td', { colspan: 14, class: 'muted' }, 'No matching jobs.')));
      rows.forEach(function (j) {
        tbody.appendChild(h('tr', null, h('td', null, j.id), h('td', null, fmtDate(j.created)), h('td', null, envBadge(j.env)), h('td', null, j.cluster), h('td', null, j.namespace), h('td', null, j.pod),
          h('td', null, j.container), h('td', null, typeLabel(j.dump_type)), h('td', null, j.requested_by), h('td', null, fmtDur(j.duration)), h('td', null, statusBadge(j.status)),
          h('td', null, fmtSize(j.size_bytes)), h('td', null, j.download_available ? h('a', { class: 'btn', href: '/api/jobs/' + encodeURIComponent(j.id) + '/download' }, 'Download') : '-'),
          h('td', { class: 'wrap' }, j.error || '-')));
      });
    }
    function select(key, label, items) {
      var el = h('select', { 'aria-label': label, onchange: function () { hf[key] = el.value; draw(); } }, h('option', { value: '' }, label),
        items.map(function (i) { return h('option', { value: i.v, selected: hf[key] === i.v }, i.l); })); return el;
    }
    var search = h('input', { type: 'search', placeholder: 'Search job, cluster, namespace, pod, user...', value: hf.q, 'aria-label': 'Search history', oninput: function () { hf.q = search.value; draw(); } });
    var heads = ['Job ID', 'Date / time', 'Env', 'Cluster', 'Namespace', 'Pod', 'Container', 'Type', 'Requested by', 'Duration', 'Status', 'File size', 'Download', 'Failure details'];
    var page = [pageHead('Collection History', 'Persisted on the server and kept until the retention period ends' + (state.me ? ' (' + state.me.retention_days + ' days for files)' : '') + '. Metadata survives restarts; files are deleted by retention.'),
      h('div', { class: 'toolbar' }, search, select('env', 'All environments', ENVS.map(function (e) { return { v: e, l: e }; })),
        select('status', 'All statuses', Object.keys(STATUS_CLS).map(function (e) { return { v: e, l: e }; })), select('type', 'All types', [{ v: 'thread', l: 'Thread Dump' }, { v: 'heap', l: 'Heap Dump' }, { v: 'tcp', l: 'TCP Dump' }]),
        h('button', { type: 'button', onclick: function () { loadJobs().then(render); } }, 'Refresh'), count),
      h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, heads.map(function (x) { return h('th', null, x); }))), tbody))];
    draw(); return page;
  }

  /* ---------- Clusters ---------- */
  function pageClusters() {
    var rows = state.clusters.map(function (c) {
      return h('tr', null, h('td', null, c.name), h('td', null, envBadge(c.environment)), h('td', { class: 'wrap' }, c.api_url || '-'),
        h('td', null, badge(c.enabled ? 'Enabled' : 'Disabled', c.enabled ? 'b-ok' : 'b-grey')), h('td', null, badge('No check performed', 'b-grey')),
        h('td', null, h('button', { type: 'button', disabled: true, title: 'Connectivity checks and enable/disable arrive in Phase 3' }, 'Check connectivity')));
    });
    var heads = ['Cluster', 'Environment', 'API endpoint', 'Configured status', 'Latest connectivity check', 'Action'];
    return [pageHead('Cluster Management', 'Read-only view of configured clusters. Credentials are never shown or sent to the browser.'), loadErrorBox(),
      h('div', { class: 'info-box' }, 'Connectivity checks and administrator enable/disable are not implemented yet.'),
      h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, heads.map(function (x) { return h('th', null, x); }))),
        h('tbody', null, rows.length ? rows : h('tr', null, h('td', { colspan: heads.length, class: 'muted' }, 'No clusters configured.')))))];
  }

  /* ---------- router ---------- */
  var ROUTES = { dashboard: pageDashboard, collect: pageCollect, progress: pageProgress, history: pageHistory, clusters: pageClusters };
  function render() {
    var r = route();
    Array.prototype.forEach.call(document.querySelectorAll('#nav a'), function (a) {
      var on = a.getAttribute('data-route') === r; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    state.updatePanel = null;
    var view = document.getElementById('view'); clearEl(view);
    (function add(n) { if (Array.isArray(n)) return n.forEach(add); if (n) view.appendChild(n); })(ROUTES[r]());
  }
  window.addEventListener('hashchange', function () { loadJobs().catch(function () { }).then(function () { render(); if (anyActive()) startPolling(); }); });
  Promise.all([loadClusters(), loadJobs().catch(function () { }), api('GET', '/api/me').then(function (m) { state.me = m; }).catch(function () { })]).then(function () {
    var who = document.getElementById('who');
    if (state.me) who.textContent = 'User: ' + state.me.user + (state.me.oc_available ? '' : '  |  oc CLI NOT FOUND');
    render(); if (anyActive()) startPolling();
  });
})();
