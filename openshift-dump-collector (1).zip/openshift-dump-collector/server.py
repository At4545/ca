#!/usr/bin/env python3
"""OpenShift Dump Collector - local development server (Phase 4).

Standard library only (Python 3.9 compatible).
  * Binds to loopback only; reach it through an SSH tunnel. No built-in authentication
    or HTTPS: this is NOT a production server (see README).
  * Serves only index.html, style.css, script.js. clusters.json is never served.
  * Mutating requests require Content-Type: application/json and a same-origin Origin.
  * The browser never sends commands: only validated identifiers and bounded numbers.
"""
import argparse
import json
import logging
import os
import re
import shutil
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from backend.app import App
from backend.configuration import ConfigError, Settings
from backend.errors import ApiError
from backend.validation import CLUSTER_ID_RE, JOB_ID_RE, parse_request, valid_namespace

ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/script.js": ("script.js", "application/javascript; charset=utf-8"),
}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
MAX_BODY = 16 * 1024
R_NS = re.compile(r"/api/clusters/([^/]+)/namespaces")
R_PODS = re.compile(r"/api/clusters/([^/]+)/namespaces/([^/]+)/pods")
R_JOB = re.compile(r"/api/jobs/([^/]+)")
R_JOB_ACT = re.compile(r"/api/jobs/([^/]+)/(cancel|download)")
log = logging.getLogger("dumpcollector")


class Handler(BaseHTTPRequestHandler):
    server_version = "DumpCollector/0.4"
    sys_version = ""

    # ---- plumbing ------------------------------------------------------------------------
    def _headers(self, code, ctype, length, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self._headers(code, "application/json", len(body))
        self.wfile.write(body)

    def _read_body(self):
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(415, "Content-Type must be application/json")
        origin = self.headers.get("Origin")
        if origin and origin != "http://" + (self.headers.get("Host") or ""):
            raise ApiError(403, "Cross-origin request refused")
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError(400, "Bad Content-Length")
        if n > MAX_BODY:
            raise ApiError(413, "Request too large")
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except ValueError:
            raise ApiError(400, "Body is not valid JSON")

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    do_DELETE = do_PATCH = do_PUT

    def _dispatch(self, method):
        try:
            if (self.headers.get("Host") or "").lower() not in self.server.allowed_hosts:
                raise ApiError(400, "Unexpected Host header")
            path = urlsplit(self.path).path
            if method == "GET" and path in STATIC:
                fname, ctype = STATIC[path]
                with open(os.path.join(ROOT, fname), "rb") as fh:
                    data = fh.read()
                self._headers(200, ctype, len(data))
                self.wfile.write(data)
            elif method == "GET" and path == "/favicon.ico":
                self._headers(204, "image/x-icon", 0)
            elif path.startswith("/api/"):
                self._api(method, path)
            else:
                raise ApiError(404, "Not found")
        except ApiError as exc:
            payload = {"error": exc.message}
            if exc.details:
                payload["details"] = exc.details
            self._json(exc.code, payload)
        except ConfigError as exc:
            self._json(500, {"error": str(exc)})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            log.exception("Unhandled error")
            self._json(500, {"error": "Internal server error"})

    # ---- API -----------------------------------------------------------------------------
    def _api(self, method, path):
        app = self.server.app
        if method == "GET":
            if path == "/api/health":
                return self._json(200, {"status": "ok"})
            if path == "/api/me":
                return self._json(200, {"user": app.user, "oc_available": app.oc.available,
                                        "retention_days": app.settings.retention_days})
            if path == "/api/clusters":
                return self._json(200, {"clusters": app.clusters()})
            m = R_PODS.fullmatch(path)
            if m:
                self._check_cluster_ns(m.group(1), m.group(2))
                return self._json(200, app.pods(m.group(1), m.group(2)))
            m = R_NS.fullmatch(path)
            if m:
                self._check_cluster_ns(m.group(1), None)
                return self._json(200, app.namespaces(m.group(1)))
            if path == "/api/jobs":
                return self._json(200, {"jobs": app.jobs.list()})
            m = R_JOB_ACT.fullmatch(path)
            if m and m.group(2) == "download":
                return self._download(app, m.group(1))
            m = R_JOB.fullmatch(path)
            if m:
                return self._json(200, {"job": app.jobs.public(app.jobs.get(m.group(1)))})
        elif method == "POST":
            if path == "/api/validate":
                return self._json(200, app.jobs.validate(parse_request(self._read_body()), app.user))
            if path == "/api/jobs":
                return self._json(202, {"job": app.jobs.create(parse_request(self._read_body()), app.user)})
            m = R_JOB_ACT.fullmatch(path)
            if m and m.group(2) == "cancel":
                self._read_body()
                return self._json(200, {"job": app.jobs.cancel(m.group(1), app.user)})
        else:
            raise ApiError(405, "Method not allowed")
        raise ApiError(404, "Not found")

    @staticmethod
    def _check_cluster_ns(cluster_id, ns):
        if not CLUSTER_ID_RE.fullmatch(cluster_id):
            raise ApiError(404, "Unknown cluster")
        if ns is not None and not valid_namespace(ns):
            raise ApiError(400, "Invalid namespace name")

    def _download(self, app, job_id):
        path, name, size = app.jobs.download_info(job_id, app.user)
        self._headers(200, "application/octet-stream", size,
                      {"Content-Disposition": 'attachment; filename="%s"' % name})
        with open(path, "rb") as fh:
            shutil.copyfileobj(fh, self.wfile, 1 << 20)

    def log_message(self, fmt, *args):  # request line only; never headers or bodies
        log.info("%s - %s", self.address_string(), fmt % args)


def main():
    ap = argparse.ArgumentParser(description="OpenShift Dump Collector (dev server)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--clusters", default=os.path.join(ROOT, "clusters.json"))
    ap.add_argument("--storage", default=os.path.join(ROOT, "storage"))
    ap.add_argument("--logs", default=os.path.join(ROOT, "logs"))
    ap.add_argument("--oc-path", default="oc")
    ap.add_argument("--max-concurrent", type=int, default=2)
    ap.add_argument("--retention-days", type=int, default=7)
    a = ap.parse_args()
    if a.host not in ("127.0.0.1", "localhost", "::1"):
        print("Refusing non-loopback bind: this server has no authentication or HTTPS.", file=sys.stderr)
        sys.exit(2)
    os.umask(0o077)  # every file we create is private to this user
    os.makedirs(a.logs, mode=0o700, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.StreamHandler(), logging.FileHandler(os.path.join(a.logs, "app.log"))])
    settings = Settings(a.clusters, a.storage, a.logs, a.oc_path, a.max_concurrent, 10, a.retention_days)
    app = App(settings)
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    srv.app = app
    srv.allowed_hosts = {"127.0.0.1:%d" % a.port, "localhost:%d" % a.port}
    log.info("OpenShift Dump Collector on http://%s:%d as user '%s' (oc: %s)", a.host, a.port, app.user,
             app.oc.path or "NOT FOUND")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("Stopped.")


if __name__ == "__main__":
    main()
