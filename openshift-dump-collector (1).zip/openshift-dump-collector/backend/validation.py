"""Strict server-side validation of every request field. Python 3.9 compatible."""
import re

from .errors import ApiError

CLUSTER_ID_RE = re.compile(r"[a-z0-9][a-z0-9-]{0,79}")
NS_RE = re.compile(r"[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?")           # DNS-1123 label
POD_RE = re.compile(r"[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?")        # DNS-1123 subdomain
CONTAINER_RE = NS_RE
JOB_ID_RE = re.compile(r"\d{8}-\d{6}-[0-9a-f]{8}")

DUMP_TYPES = ("thread", "heap", "tcp")
IMPLEMENTED = ("thread",)   # heap = Phase 5, tcp = Phase 6
# name: (min, max, default)
LIMITS = {
    "timeout": (30, 1800, 300),
    "size_limit_mb": (1, 50, 50),
    "count": (1, 10, 3),
    "interval": (1, 60, 10),
}


def _int(value, name, errors):
    lo, hi, default = LIMITS[name]
    if value is None:
        return default
    if isinstance(value, str) and value.strip().isdigit():
        value = int(value.strip())
    if isinstance(value, bool) or not isinstance(value, int) or value < lo or value > hi:
        errors[name] = "must be a whole number from %d to %d" % (lo, hi)
        return None
    return value


def valid_namespace(ns):
    return isinstance(ns, str) and NS_RE.fullmatch(ns) is not None


def parse_request(body):
    """Return a clean request dict or raise ApiError(400) listing every bad field."""
    if not isinstance(body, dict):
        raise ApiError(400, "Request body must be a JSON object")
    errors = {}

    def text(name, rx):
        v = body.get(name)
        if not isinstance(v, str) or rx.fullmatch(v) is None:
            errors[name] = "missing or invalid"
            return None
        return v

    clean = {
        "cluster": text("cluster", CLUSTER_ID_RE),
        "namespace": text("namespace", NS_RE),
        "pod": text("pod", POD_RE),
        "container": text("container", CONTAINER_RE),
    }
    dt = body.get("dump_type")
    if not isinstance(dt, str) or dt not in DUMP_TYPES:
        errors["dump_type"] = "must be one of: " + ", ".join(DUMP_TYPES)
    elif dt not in IMPLEMENTED:
        errors["dump_type"] = "%s is not available yet (not implemented in this phase)" % dt
    clean["dump_type"] = dt

    opts = body.get("options")
    if opts is None:
        opts = {}
    if not isinstance(opts, dict):
        errors["options"] = "must be an object"
        opts = {}
    unknown = sorted(set(opts) - set(LIMITS))
    if unknown:
        errors["options"] = "unknown option(s): " + ", ".join(str(u)[:30] for u in unknown)
    for name in LIMITS:
        clean[name] = _int(opts.get(name), name, errors)

    if not errors and clean["dump_type"] == "thread":
        needed = (clean["count"] - 1) * clean["interval"] + 10
        if needed >= clean["timeout"]:
            errors["timeout"] = "too short for %d dumps %ds apart (needs more than %ds)" % (
                clean["count"], clean["interval"], needed)

    clean["confirm_prod"] = body.get("confirm_prod") is True
    if errors:
        raise ApiError(400, "Invalid request", errors)
    return clean
