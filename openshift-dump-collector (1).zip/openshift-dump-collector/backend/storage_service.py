"""Restricted on-disk storage for dump files and job metadata (outside the web root)."""
import hashlib
import json
import os
import re
import shutil

SAFE_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,120}")


class Storage(object):
    def __init__(self, root):
        self.root = os.path.abspath(root)
        self.dumps = os.path.join(self.root, "dumps")
        self.jobs = os.path.join(self.root, "jobs")
        for d in (self.root, self.dumps, self.jobs):
            os.makedirs(d, mode=0o700, exist_ok=True)
            os.chmod(d, 0o700)

    def free_mb(self):
        return shutil.disk_usage(self.dumps).free // (1024 * 1024)

    def path_for(self, name):
        """Server-generated names only; refuse anything that could leave the dumps dir."""
        if not SAFE_NAME.fullmatch(name or ""):
            raise ValueError("unsafe file name")
        p = os.path.join(self.dumps, name)
        if os.path.dirname(os.path.realpath(p)) != os.path.realpath(self.dumps):
            raise ValueError("path escapes storage directory")
        return p

    def remove(self, name):
        try:
            os.remove(self.path_for(name))
            return True
        except (OSError, ValueError):
            return False

    def cleanup_partials(self):
        removed = 0
        for n in os.listdir(self.dumps):
            if n.endswith(".part") and self.remove(n):
                removed += 1
        return removed

    @staticmethod
    def sha256(path):
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()

    def save_job(self, job):
        final = os.path.join(self.jobs, job["id"] + ".json")
        tmp = final + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            json.dump(job, fh)
        os.replace(tmp, final)

    def load_jobs(self):
        jobs = []
        for n in sorted(os.listdir(self.jobs)):
            if n.endswith(".json"):
                try:
                    with open(os.path.join(self.jobs, n)) as fh:
                        jobs.append(json.load(fh))
                except (OSError, ValueError):
                    continue
        return jobs
