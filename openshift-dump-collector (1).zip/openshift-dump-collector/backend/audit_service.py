"""Append-only JSON-lines audit log. Never receives secrets or dump contents."""
import json
import os
import threading
import time

from .process import clean_text


class Audit(object):
    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)

    def log(self, event, user, **fields):
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event, "user": user}
        for k, v in fields.items():
            if v is None:
                continue
            rec[k] = clean_text(v, 300) if isinstance(v, str) else v
        line = (json.dumps(rec, sort_keys=True) + "\n").encode("utf-8")
        with self.lock:
            fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
            try:
                os.write(fd, line)
            finally:
                os.close(fd)
