"""Thin, safe wrapper around the existing `oc` CLI.

* Arguments are always lists; user input never reaches a shell.
* The target cluster is chosen EXPLICITLY with --context, resolved by matching the
  configured API URL to a context in the user's existing kubeconfig. The shared
  "current context" is never relied on.
* No credentials are read, stored or passed: the existing `oc login` session is reused.
"""
import json
import os
import shutil

from . import process
from .process import clean_text

_ENV_KEEP = ("PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "KUBECONFIG", "TMPDIR",
             "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "no_proxy",
             "SSL_CERT_FILE", "SSL_CERT_DIR")


class OcError(Exception):
    def __init__(self, message, code="oc_error"):
        Exception.__init__(self, message)
        self.message = message
        self.code = code   # auth | forbidden | unreachable | notfound | timeout | cancelled | oc_error


def _norm_url(u):
    return (u or "").strip().rstrip("/").lower()


class OcClient(object):
    def __init__(self, oc_path="oc"):
        self.path = shutil.which(oc_path)

    @property
    def available(self):
        return self.path is not None

    def _env(self):
        return {k: os.environ[k] for k in _ENV_KEEP if k in os.environ}

    def _require(self):
        if not self.path:
            raise OcError("The OpenShift CLI (oc) was not found on this server.", "oc_error")

    def describe_failure(self, res, what):
        """Translate a failed RunResult into a clear, redacted, user-facing message."""
        if res.error:
            return res.error
        if res.cancelled:
            return "%s was cancelled" % what
        if res.timed_out:
            return "%s timed out" % what
        low = (res.err or "").lower()
        if "forbidden" in low:
            return "%s: access denied by the cluster. Your account lacks permission for this operation." % what
        if ("unauthorized" in low or "must be logged in" in low or "provide credentials" in low
                or "token" in low and ("expired" in low or "invalid" in low)):
            return ("%s: not logged in to this cluster, or the session expired. "
                    "Run `oc login` for this cluster on the jump server and retry." % what)
        if "x509" in low or "certificate" in low:
            return "%s: TLS certificate problem contacting the cluster (verification is not bypassed)." % what
        if any(s in low for s in ("connection refused", "no such host", "i/o timeout", "unreachable",
                                   "timeout", "deadline exceeded")):
            return "%s: the cluster API is unreachable from this server." % what
        if "notfound" in low or "not found" in low:
            return "%s: not found (%s)" % (what, clean_text(res.err, 160))
        return "%s failed (exit %s): %s" % (what, res.rc, clean_text(res.err, 250) or "no error output")

    def _code(self, res):
        low = (res.err or "").lower()
        if res.cancelled:
            return "cancelled"
        if res.timed_out:
            return "timeout"
        if "forbidden" in low:
            return "forbidden"
        if "unauthorized" in low or "must be logged in" in low or "provide credentials" in low:
            return "auth"
        if "notfound" in low or "not found" in low:
            return "notfound"
        if any(s in low for s in ("connection refused", "no such host", "i/o timeout", "unreachable")):
            return "unreachable"
        return "oc_error"

    def _call(self, args, what, timeout=30, context=None, cancel=None, request_timeout=True):
        self._require()
        cmd = [self.path]
        if context:
            cmd += ["--context", context]
        if request_timeout:
            cmd += ["--request-timeout=%ds" % max(5, timeout - 5)]
        cmd += list(args)
        res = process.run(cmd, timeout, cancel=cancel, env=self._env())
        if res.rc != 0 or res.error or res.timed_out or res.cancelled:
            raise OcError(self.describe_failure(res, what), self._code(res))
        return res

    # ---- cluster selection / identity -------------------------------------------------
    def resolve_context(self, api_url):
        res = self._call(["config", "view", "-o", "json"], "Reading local oc configuration", 20, request_timeout=False)
        try:
            data = json.loads(res.out)
        except ValueError:
            raise OcError("Could not parse the local oc configuration.")
        servers = {}
        for c in data.get("clusters") or []:
            servers[c.get("name")] = _norm_url((c.get("cluster") or {}).get("server"))
        matches = [c.get("name") for c in data.get("contexts") or []
                   if servers.get((c.get("context") or {}).get("cluster")) == _norm_url(api_url)]
        if not matches:
            raise OcError("No local oc login found for %s. Run `oc login %s` on the jump server first."
                          % (api_url, api_url), "auth")
        if len(matches) == 1:
            return matches[0]
        if data.get("current-context") in matches:
            return data.get("current-context")
        raise OcError("Several oc logins match %s; make the intended one current with "
                      "`oc config use-context` and retry." % api_url, "auth")

    def server_of(self, context):
        return self._call(["whoami", "--show-server"], "Reading API endpoint", 20, context).out.strip()

    def whoami(self, context):
        return self._call(["whoami"], "Checking identity", 20, context).out.strip()

    def connect(self, api_url):
        """Resolve context, verify the REAL endpoint equals the configured one, return (context, identity)."""
        ctx = self.resolve_context(api_url)
        actual = self.server_of(ctx)
        if _norm_url(actual) != _norm_url(api_url):
            raise OcError("Context points at a different API endpoint than configured; refusing to continue.", "oc_error")
        return ctx, self.whoami(ctx)

    # ---- read-only discovery ---------------------------------------------------------------
    def list_namespaces(self, context):
        try:
            res = self._call(["get", "projects", "-o", "json"], "Listing projects", 30, context)
        except OcError as first:
            if first.code != "notfound":
                raise
            res = self._call(["get", "namespaces", "-o", "json"], "Listing namespaces", 30, context)
        items = json.loads(res.out).get("items") or []
        return sorted(i["metadata"]["name"] for i in items)

    @staticmethod
    def pod_summary(item):
        status = item.get("status") or {}
        cstat = {c.get("name"): c for c in status.get("containerStatuses") or []}
        containers = []
        for c in (item.get("spec") or {}).get("containers") or []:
            s = cstat.get(c.get("name")) or {}
            state = s.get("state") or {}
            if "running" in state:
                st = "Running"
            elif "waiting" in state:
                st = (state["waiting"] or {}).get("reason") or "Waiting"
            elif "terminated" in state:
                st = (state["terminated"] or {}).get("reason") or "Terminated"
            else:
                st = "Unknown"
            containers.append({"name": c.get("name"), "ready": bool(s.get("ready")), "state": st,
                               "restarts": s.get("restartCount", 0)})
        phase = status.get("phase") or "Unknown"
        if (item.get("metadata") or {}).get("deletionTimestamp"):
            phase = "Terminating"
        ready = sum(1 for c in containers if c["ready"])
        return {"name": item["metadata"]["name"], "phase": phase,
                "ready": "%d/%d" % (ready, len(containers)), "containers": containers}

    def list_pods(self, context, namespace):
        res = self._call(["get", "pods", "-n", namespace, "-o", "json"], "Listing pods", 30, context)
        return sorted((self.pod_summary(i) for i in json.loads(res.out).get("items") or []),
                      key=lambda p: p["name"])

    def get_pod(self, context, namespace, pod):
        res = self._call(["get", "pod", pod, "-n", namespace, "-o", "json"], "Reading pod", 30, context)
        return self.pod_summary(json.loads(res.out))

    def can_exec(self, context, namespace):
        self._require()
        res = process.run([self.path, "--context", context, "auth", "can-i", "create", "pods/exec",
                           "-n", namespace], 20, env=self._env())
        if res.out.strip().lower() == "yes":
            return True
        if res.out.strip().lower() == "no":
            return False
        raise OcError(self.describe_failure(res, "Checking exec permission"), self._code(res))

    # ---- exec (fixed argument lists only) ----------------------------------------------------
    def exec_run(self, context, namespace, pod, container, command, timeout, cancel=None, sink=None, max_bytes=1 << 20):
        self._require()
        cmd = [self.path, "--context", context, "exec", pod, "-n", namespace, "-c", container, "--"] + list(command)
        return process.run(cmd, timeout, cancel=cancel, sink=sink, max_bytes=max_bytes, env=self._env())
