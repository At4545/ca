"""Job manager: pre-collection checks, background execution, cancellation, downloads,
retention. Jobs run on a small thread pool so long collections never block the UI.
Job metadata is persisted as JSON files (durable across restarts); Phase 7 may move it to SQLite."""
import logging
import os
import secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from diagnostics import thread_dump
from diagnostics.thread_dump import Cancelled, DiagnosticError

from .configuration import ConfigError, load_clusters
from .errors import ApiError
from .oc_client import OcError
from .validation import JOB_ID_RE

log = logging.getLogger("dumpcollector")
ACTIVE = ("Pending", "Validating", "Running")
PUBLIC_KEYS = ("id", "status", "stage", "env", "cluster", "namespace", "pod", "container", "dump_type",
               "requested_by", "identity", "created", "started", "finished", "duration", "size_bytes",
               "sha256", "error", "checks", "options")


class JobManager(object):
    def __init__(self, app):
        self.app = app
        self.lock = threading.RLock()
        self.jobs = {}
        self.cancels = {}
        self.pool = ThreadPoolExecutor(max_workers=app.settings.max_concurrent, thread_name_prefix="job")
        self._last_sweep = 0.0

    # ---- lifecycle -------------------------------------------------------------------------
    def recover(self):
        """On startup: no job can still be running; fail interrupted ones and drop partial files."""
        self.app.storage.cleanup_partials()
        for j in self.app.storage.load_jobs():
            if j.get("status") in ACTIVE:
                j.update(status="Failed", stage="Interrupted", finished=time.time(),
                         error="The portal restarted while this job was active; the partial file was discarded.")
                self.app.storage.save_job(j)
                self.app.audit.log("job_failed", j.get("requested_by"), job_id=j["id"], detail="interrupted by restart")
            self.jobs[j["id"]] = j
        self.sweep(force=True)

    def _save(self, job):
        self.app.storage.save_job(job)

    def _set(self, job, **kw):
        with self.lock:
            job.update(kw)
            self._save(job)

    def public(self, job):
        out = {k: job.get(k) for k in PUBLIC_KEYS}
        out["download_available"] = job.get("status") == "Completed" and bool(job.get("file"))
        out["download_name"] = job.get("file") if out["download_available"] else None
        out["active"] = job.get("status") in ACTIVE
        return out

    def list(self):
        self.sweep()
        with self.lock:
            return [self.public(j) for j in sorted(self.jobs.values(), key=lambda j: j["created"], reverse=True)][:300]

    def get(self, job_id):
        if not JOB_ID_RE.fullmatch(job_id or ""):
            raise ApiError(404, "Job not found")
        with self.lock:
            j = self.jobs.get(job_id)
        if not j:
            raise ApiError(404, "Job not found")
        return j

    # ---- pre-collection checks ------------------------------------------------------------
    def preflight(self, clean, cancel=None, dry_run=False):
        """Run the ordered checks. Returns (ok, checks, facts). Stops at the first hard failure."""
        oc = self.app.oc
        checks, facts = [], {}

        def add(name, ok, msg, skipped=False):
            checks.append({"name": name, "ok": ok, "message": msg, "skipped": skipped})
            return ok

        try:
            cluster = {c["id"]: c for c in load_clusters(self.app.settings.clusters_path)}.get(clean["cluster"])
        except ConfigError as exc:
            add("Cluster configuration", False, str(exc))
            return False, checks, facts
        if not cluster:
            add("Cluster configuration", False, "Unknown cluster id.")
            return False, checks, facts
        if not cluster["enabled"]:
            add("Cluster configuration", False, "Cluster '%s' is disabled." % cluster["name"])
            return False, checks, facts
        if not cluster["environment_valid"] or not cluster["api_url"]:
            add("Cluster configuration", False, "Cluster has no valid environment/API URL configured.")
            return False, checks, facts
        facts["cluster"] = cluster
        add("Cluster configuration", True, "%s (%s) is configured and enabled." % (cluster["name"], cluster["environment"]))

        if not oc.available:
            add("OpenShift CLI", False, "The oc CLI was not found on this server.")
            return False, checks, facts
        try:
            ctx, identity = oc.connect(cluster["api_url"])
        except OcError as exc:
            add("API endpoint and identity", False, exc.message)
            return False, checks, facts
        facts["ctx"], facts["identity"] = ctx, identity
        add("API endpoint and identity", True, "Endpoint matches configuration; authenticated as '%s'." % identity)

        try:
            pod = oc.get_pod(ctx, clean["namespace"], clean["pod"])
        except OcError as exc:
            add("Namespace and pod access", False, exc.message)
            return False, checks, facts
        add("Namespace and pod access", True, "Pod '%s' is readable in namespace '%s'." % (clean["pod"], clean["namespace"]))

        try:
            can = oc.can_exec(ctx, clean["namespace"])
        except OcError as exc:
            add("Exec permission", False, exc.message)
            return False, checks, facts
        if not add("Exec permission", can, "You may exec into pods in this namespace." if can else
                   "Your account is not allowed to exec into pods in '%s'." % clean["namespace"]):
            return False, checks, facts

        cont = [c for c in pod["containers"] if c["name"] == clean["container"]]
        if not cont:
            add("Container", False, "Container '%s' does not belong to pod '%s' (available: %s)." % (
                clean["container"], clean["pod"], ", ".join(c["name"] for c in pod["containers"]) or "none"))
            return False, checks, facts
        if pod["phase"] != "Running" or cont[0]["state"] != "Running":
            add("Container", False, "Pod is %s and container is %s; it must be Running." % (pod["phase"], cont[0]["state"]))
            return False, checks, facts
        add("Container", True, "Container '%s' belongs to the pod and is running." % clean["container"])

        add("Diagnostic type", True, "Thread dump is supported.")

        if cluster["environment"] == "PROD":
            if clean["confirm_prod"]:
                add("PROD confirmation", True, "Explicit production confirmation received.")
            elif dry_run:
                add("PROD confirmation", True, "Will be required when you collect (not yet given).", skipped=True)
            else:
                add("PROD confirmation", False, "Production collection requires explicit confirmation.")
                return False, checks, facts

        need = max(self.app.settings.min_free_mb, clean["size_limit_mb"] * 2)
        free = self.app.storage.free_mb()
        if not add("Storage space", free >= need, "%d MB free; %d MB required." % (free, need)):
            return False, checks, facts

        if cluster["environment"] == "PROD" and not clean["confirm_prod"]:
            add("JVM diagnostic tools", True, "Not probed on PROD until you confirm.", skipped=True)
            return True, checks, facts
        try:
            info = thread_dump.probe(oc, ctx, clean["namespace"], clean["pod"], clean["container"], cancel)
        except Cancelled:
            add("JVM diagnostic tools", False, "Cancelled.")
            return False, checks, facts
        except DiagnosticError as exc:
            add("JVM diagnostic tools", False, str(exc))
            return False, checks, facts
        facts["probe"] = info
        add("JVM diagnostic tools", True, "Found %s and a single JVM (pid %d)." % (info["tool"], info["pid"]))
        return True, checks, facts

    def validate(self, clean, user):
        ok, checks, _ = self.preflight(clean, dry_run=True)
        self.app.audit.log("validate", user, cluster=clean["cluster"], namespace=clean["namespace"],
                           pod=clean["pod"], container=clean["container"], dump_type=clean["dump_type"], ok=ok)
        return {"ok": ok, "checks": checks}

    # ---- create / run / cancel -------------------------------------------------------------
    def create(self, clean, user):
        clusters = {c["id"]: c for c in load_clusters(self.app.settings.clusters_path)}
        cluster = clusters.get(clean["cluster"])
        if not cluster:
            raise ApiError(404, "Unknown cluster")
        with self.lock:
            active = [j for j in self.jobs.values() if j["status"] in ACTIVE]
            if len(active) >= self.app.settings.max_active_jobs:
                raise ApiError(429, "Too many active collection jobs; try again shortly.")
            for j in active:
                if (j["cluster_id"], j["namespace"], j["pod"], j["container"]) == (
                        clean["cluster"], clean["namespace"], clean["pod"], clean["container"]):
                    raise ApiError(409, "A collection is already active for this container (job %s)." % j["id"])
            job_id = time.strftime("%Y%m%d-%H%M%S", time.gmtime()) + "-" + secrets.token_hex(4)
            job = {"id": job_id, "status": "Pending", "stage": "Queued", "env": cluster["environment"],
                   "cluster_id": cluster["id"], "cluster": cluster["name"], "namespace": clean["namespace"],
                   "pod": clean["pod"], "container": clean["container"], "dump_type": clean["dump_type"],
                   "requested_by": user, "identity": None, "created": time.time(), "started": None,
                   "finished": None, "duration": None, "size_bytes": None, "sha256": None, "file": None,
                   "error": None, "checks": [], "confirm_prod": clean["confirm_prod"],
                   "options": {k: clean[k] for k in ("timeout", "size_limit_mb", "count", "interval")}}
            self.jobs[job_id] = job
            self.cancels[job_id] = threading.Event()
            self._save(job)
        self.app.audit.log("job_requested", user, job_id=job_id, env=cluster["environment"], cluster=cluster["name"],
                           namespace=clean["namespace"], pod=clean["pod"], container=clean["container"],
                           dump_type=clean["dump_type"], prod_confirmed=clean["confirm_prod"] or None,
                           options=job["options"])
        self.pool.submit(self._run, job_id, clean)
        return self.public(job)

    def cancel(self, job_id, user):
        job = self.get(job_id)
        with self.lock:
            if job["status"] not in ACTIVE:
                raise ApiError(409, "Job is not active (status: %s)." % job["status"])
            self.cancels[job_id].set()
            if job["status"] == "Pending":
                job["stage"] = "Cancelling"
        self.app.audit.log("cancel_requested", user, job_id=job_id, cluster=job["cluster"])
        return self.public(job)

    def _finish(self, job, status, stage, error=None, **extra):
        now = time.time()
        start = job.get("started") or job["created"]
        self._set(job, status=status, stage=stage, error=error, finished=now, duration=round(now - start, 1), **extra)
        ev = {"Completed": "job_completed", "Failed": "job_failed", "Cancelled": "job_cancelled"}[status]
        self.app.audit.log(ev, job["requested_by"], job_id=job["id"], env=job["env"], cluster=job["cluster"],
                           namespace=job["namespace"], pod=job["pod"], container=job["container"],
                           dump_type=job["dump_type"], status=status, file=job.get("file"),
                           size_bytes=job.get("size_bytes"), detail=error)

    def _run(self, job_id, clean):
        job = self.jobs[job_id]
        cancel = self.cancels[job_id]
        storage = self.app.storage
        part = None
        try:
            if cancel.is_set():
                return self._finish(job, "Cancelled", "Cancelled before start")
            self._set(job, status="Validating", stage="Pre-collection checks", started=time.time())
            ok, checks, facts = self.preflight(clean, cancel=cancel)
            self._set(job, checks=checks, identity=facts.get("identity"))
            if cancel.is_set():
                return self._finish(job, "Cancelled", "Cancelled during validation")
            if not ok:
                bad = [c for c in checks if not c["ok"]]
                return self._finish(job, "Failed", "Validation failed: " + (bad[0]["name"] if bad else "unknown"),
                                    error=bad[0]["message"] if bad else "Validation failed.")
            self.app.audit.log("job_started", job["requested_by"], job_id=job_id, cluster=job["cluster"],
                               namespace=job["namespace"], pod=job["pod"], identity=facts["identity"])
            self._set(job, status="Running", stage="Starting collection")
            name = "thread-dump_%s.txt" % job_id
            part = storage.path_for(name + ".part")
            size = thread_dump.collect(
                self.app.oc, facts["ctx"], clean["namespace"], clean["pod"], clean["container"], facts["probe"],
                clean["count"], clean["interval"], clean["timeout"], clean["size_limit_mb"] * 1024 * 1024,
                part, cancel, progress=lambda s: self._set(job, stage=s))
            final = storage.path_for(name)
            os.replace(part, final)
            part = None
            os.chmod(final, 0o600)
            self._finish(job, "Completed", "Finished", file=name, size_bytes=os.path.getsize(final),
                         sha256=storage.sha256(final))
        except Cancelled:
            self._finish(job, "Cancelled", "Cancelled by requester")
        except DiagnosticError as exc:
            self._finish(job, "Failed", "Collection failed", error=str(exc))
        except Exception:  # never leak internals to the UI
            log.exception("Unexpected error in job %s", job_id)
            self._finish(job, "Failed", "Internal error", error="Unexpected internal error; see the application log.")
        finally:
            if part:
                storage.remove(os.path.basename(part))

    # ---- downloads & retention -------------------------------------------------------------
    def download_info(self, job_id, user):
        job = self.get(job_id)
        if job["requested_by"] != user:
            raise ApiError(403, "You may only download your own collections.")
        if job["status"] != "Completed" or not job.get("file"):
            raise ApiError(409, "No downloadable file (status: %s)." % job["status"])
        try:
            path = self.app.storage.path_for(job["file"])
            size = os.path.getsize(path)
        except (OSError, ValueError):
            self.sweep(force=True)
            raise ApiError(410, "The file is no longer available.")
        if size != job["size_bytes"]:
            raise ApiError(500, "Stored file failed its integrity check; it was not served.")
        self.app.audit.log("file_download", user, job_id=job_id, file=job["file"], size_bytes=size)
        return path, job["file"], size

    def sweep(self, force=False):
        """Expire completed files past retention (or missing) and record the deletion."""
        now = time.time()
        if not force and now - self._last_sweep < 60:
            return
        self._last_sweep = now
        limit = self.app.settings.retention_days * 86400
        with self.lock:
            for j in list(self.jobs.values()):
                if j["status"] != "Completed" or not j.get("file"):
                    continue
                try:
                    exists = os.path.isfile(self.app.storage.path_for(j["file"]))
                except ValueError:
                    exists = False
                old = (now - (j.get("finished") or now)) > limit
                if old or not exists:
                    removed = self.app.storage.remove(j["file"]) if exists else False
                    reason = "retention policy" if old else "file missing from storage"
                    self.app.audit.log("file_deleted" if removed else "file_expired", j["requested_by"],
                                       job_id=j["id"], file=j["file"], detail=reason)
                    j.update(status="Expired", stage="Expired", error="File removed: " + reason + ".")
                    self._save(j)
