"""Run an external command safely: argument list only (never a shell), bounded
output, timeout, cancellation, whole-process-group kill. Python 3.9 compatible."""
import os
import re
import signal
import subprocess
import threading
import time

_REDACT = [
    (re.compile(r"sha256~[A-Za-z0-9_\-]+"), "sha256~[redacted]"),
    (re.compile(r"(?i)bearer\s+[A-Za-z0-9._~+/=\-]+"), "Bearer [redacted]"),
    (re.compile(r"(?i)\b(password|passwd|token|secret)\s*[=:]\s*\S+"), r"\1=[redacted]"),
]


def clean_text(text, limit=400):
    """Redact secret-looking strings and truncate. Use for ALL logged/displayed tool output."""
    text = (text or "").strip()
    for rx, repl in _REDACT:
        text = rx.sub(repl, text)
    text = " ".join(text.split())
    return text if len(text) <= limit else text[:limit] + "..."


class RunResult(object):
    def __init__(self):
        self.rc = None
        self.out = ""
        self.err = ""
        self.timed_out = False
        self.cancelled = False
        self.too_big = False
        self.error = None  # could not start / local I/O error


def _kill(proc):
    for sig in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(proc.pid, sig)
        except OSError:
            pass
        try:
            proc.wait(timeout=3)
            return
        except subprocess.TimeoutExpired:
            continue


def run(args, timeout, cancel=None, sink=None, max_bytes=1048576, env=None):
    """Run args (list). stdout goes to `sink` (binary file) or is returned in .out.
    More than max_bytes of stdout kills the process and sets too_big."""
    res = RunResult()
    try:
        proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, env=env, start_new_session=True)
    except OSError as exc:
        res.error = "Could not start %s (%s)" % (os.path.basename(args[0]), exc.strerror or type(exc).__name__)
        return res

    out_buf, err_buf = bytearray(), bytearray()
    st = {"n": 0, "big": False, "werr": None}

    def pump_out():
        fd = proc.stdout.fileno()
        while True:
            try:
                chunk = os.read(fd, 65536)
            except OSError:
                break
            if not chunk:
                break
            if st["big"] or st["werr"]:
                continue  # keep draining so the child never blocks
            if st["n"] + len(chunk) > max_bytes:
                chunk = chunk[:max_bytes - st["n"]]
                st["big"] = True
            try:
                if sink is not None:
                    sink.write(chunk)
                else:
                    out_buf.extend(chunk)
                st["n"] += len(chunk)
            except OSError as exc:
                st["werr"] = exc.strerror or "write error"

    def pump_err():
        fd = proc.stderr.fileno()
        while True:
            try:
                chunk = os.read(fd, 4096)
            except OSError:
                break
            if not chunk:
                break
            if len(err_buf) < 8192:
                err_buf.extend(chunk[:8192 - len(err_buf)])

    threads = [threading.Thread(target=pump_out), threading.Thread(target=pump_err)]
    for t in threads:
        t.daemon = True
        t.start()

    deadline = time.monotonic() + timeout
    while True:
        try:
            proc.wait(timeout=0.1)
            break
        except subprocess.TimeoutExpired:
            pass
        if cancel is not None and cancel.is_set():
            res.cancelled = True
            break
        if st["big"] or st["werr"]:
            break
        if time.monotonic() > deadline:
            res.timed_out = True
            break
    if proc.poll() is None:
        _kill(proc)
    for t in threads:
        t.join(5)
    for f in (proc.stdout, proc.stderr):
        try:
            f.close()
        except OSError:
            pass
    res.rc = proc.returncode
    res.too_big = st["big"]
    if st["werr"]:
        res.error = "Could not write output (%s)" % st["werr"]
    res.out = out_buf.decode("utf-8", "replace")
    res.err = err_buf.decode("utf-8", "replace")
    return res
