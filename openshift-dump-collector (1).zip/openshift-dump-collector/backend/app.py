"""Application container wiring settings, oc client, storage, audit and jobs together."""
import getpass
import os

from .audit_service import Audit
from .collection_service import JobManager
from .configuration import load_clusters
from .errors import ApiError
from .oc_client import OcClient, OcError
from .storage_service import Storage


class App(object):
    def __init__(self, settings):
        self.settings = settings
        self.user = getpass.getuser()
        self.oc = OcClient(settings.oc_path)
        self.storage = Storage(settings.storage_dir)
        self.audit = Audit(os.path.join(settings.log_dir, "audit.log"))
        self.jobs = JobManager(self)
        self.jobs.recover()

    def clusters(self):
        return load_clusters(self.settings.clusters_path)

    def cluster_or_error(self, cluster_id):
        for c in self.clusters():
            if c["id"] == cluster_id:
                if not c["enabled"]:
                    raise ApiError(409, "Cluster is disabled in the portal.")
                if not c["api_url"] or not c["environment_valid"]:
                    raise ApiError(409, "Cluster has no valid environment/API URL configured.")
                return c
        raise ApiError(404, "Unknown cluster")

    @staticmethod
    def _http(exc):
        code = {"auth": 401, "forbidden": 403, "notfound": 404}.get(exc.code, 502)
        return ApiError(code, exc.message)

    def namespaces(self, cluster_id):
        c = self.cluster_or_error(cluster_id)
        try:
            ctx, identity = self.oc.connect(c["api_url"])
            return {"identity": identity, "namespaces": self.oc.list_namespaces(ctx)}
        except OcError as exc:
            raise self._http(exc)

    def pods(self, cluster_id, namespace):
        c = self.cluster_or_error(cluster_id)
        try:
            ctx, _ = self.oc.connect(c["api_url"])
            return {"pods": self.oc.list_pods(ctx, namespace)}
        except OcError as exc:
            raise self._http(exc)
