# OpenShift Dump Collector

**Status:** Phase 1 (discovery script), Phase 2 (frontend), the read-only discovery subset of Phase 3 and **Phase 4 (thread dumps)** are implemented and tested against a *simulated* `oc`. They have **not** yet been run against a real cluster. Heap dumps (Phase 5), TCP capture (Phase 6), connectivity checks/cluster admin (rest of Phase 3), SQLite history (Phase 7) and production hardening (Phase 8) are **not implemented**.

## Layout
```
server.py                    stdlib HTTP server (loopback only) + JSON API
index.html style.css script.js
backend/
  configuration.py           clusters.json -> safe fields only; Settings
  validation.py              strict request validation (regexes, bounds)
  process.py                 safe subprocess runner (arg lists, timeout, cancel, size cap, redaction)
  oc_client.py               oc wrapper: explicit --context per cluster, endpoint + identity checks, discovery
  collection_service.py      pre-collection checks, job queue, cancel, download, retention
  storage_service.py         0700/0600 storage, safe paths, atomic metadata
  audit_service.py           append-only JSONL audit log
  app.py errors.py
diagnostics/thread_dump.py   JVM probe + jcmd/jstack collection
scripts/discover_env.py      Phase 1 read-only discovery
tests/                       test_backend.py (40 tests), fake `oc`, test clusters (placeholders)
storage/ logs/               runtime data (git-ignored)
```

## Run (on the RHEL jump server, as the user who is already `oc login`-ed)
```bash
cp /path/to/clusters.json . && chmod 600 clusters.json
python3 server.py --port 8080 --clusters clusters.json
# workstation:  ssh -L 8080:127.0.0.1:8080 <jump-server>   ->  http://127.0.0.1:8080
```
Options: `--storage DIR` (default ./storage, keep it outside any web root), `--logs DIR`, `--oc-path`, `--max-concurrent 2`, `--retention-days 7`.

## How a thread dump works
1. Browser sends only IDs and bounded numbers to `POST /api/jobs` (never commands or paths).
2. Server re-validates, then in a worker thread runs ordered checks: cluster configured+enabled -> local `oc` context whose server **equals** the configured API URL (explicit `--context`, never the shared current context) -> `oc whoami` identity -> pod readable -> `oc auth can-i create pods/exec` -> container belongs to pod and is Running -> PROD confirmation (server-enforced) -> free disk -> JVM probe.
3. JVM probe is one fixed read-only `sh -c` script: finds `jcmd`/`jstack` (PATH or `$JAVA_HOME/bin`) and exactly one `java` process via `/proc`. No tool, no shell, no JVM or several JVMs = clear error; no fallback guessing.
4. `oc exec ... -- <jcmd> <pid> Thread.print` (or `jstack <pid>`) streams to `thread-dump_<jobid>.txt.part`, capped at the size limit and timeout; output must contain `Full thread dump`. Only then is it renamed to its final name, hashed (SHA-256) and offered for download.
5. Failure, timeout, size overflow, cancel or restart => the partial file is deleted and the job shows the reason.

## Security notes
- No credentials are read, stored or passed. The portal reuses your existing `oc login`; secrets never reach the browser, logs or argv.
- **Authentication:** the prototype relies on the SSH tunnel and the OS user running the server. Everyone who can reach the port acts as that user. Do not expose it more widely until the multi-user design (Phase 8) is approved.
- POST requires `Content-Type: application/json` and same-origin `Origin`; `Host` is checked; CSP forbids inline script/style.
- Files are 0600 in a 0700 directory; names are server-generated; downloads are restricted to the requesting user, integrity-checked by size and served as attachments.
- Audit events (`logs/audit.log`): job_requested, validate, job_started, job_completed/failed/cancelled, cancel_requested, file_download, file_deleted/expired. Tool output in logs/UI is redacted and truncated; dump contents are never logged.
- Thread dumps briefly pause the JVM; on PROD the UI and server both require explicit confirmation.

## Tests
```bash
python3 -m unittest discover -s tests -v     # ~25 s; uses tests/bin/oc, a FAKE oc
```
The fake `oc` proves the portal's logic (validation, error handling, cancel, cleanup, audit). It cannot prove real `oc`/JVM behaviour.

## First real-cluster validation (DEV only)
1. Start the server; open the Collect page; pick a DEV cluster and confirm namespaces and pods match `oc get pods -n <ns>` as your user.
2. Pick a test Java pod; click **Validate Request** and read each check.
3. Collect with 1 dump, then 3; download; confirm the file contains `Full thread dump` sections.
4. Cancel a run; confirm no `.part` file remains in `storage/dumps`.
5. Check `logs/audit.log` for the events above.

## Known limits
- One JVM per container; the JVM must run as the same user as `jcmd`/`jstack` and allow attach.
- `jcmd`/`jstack` must exist in the application image (JRE-only/distroless images will fail with a clear message).
- Job metadata is JSON files; list is capped at the latest 300 jobs.
- Cluster connectivity is verified per request, not via a dashboard check yet.
