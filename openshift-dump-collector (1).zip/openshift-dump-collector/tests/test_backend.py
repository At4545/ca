"""Backend tests: run a real server process against the FAKE oc in tests/bin.
Run:  python3 -m unittest discover -s tests -v      (stdlib only)
"""
import json, os, socket, stat, subprocess, sys, tempfile, threading, time, unittest, urllib.error, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
FAKE_OC = os.path.join(ROOT, "tests", "bin", "oc")
CLUSTERS = os.path.join(ROOT, "tests", "clusters.test.json")


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class Api(object):
    def __init__(self, port):
        self.base = "http://127.0.0.1:%d" % port
        self.port = port

    def call(self, method, path, body=None, headers=None, raw=False):
        h = {"Content-Type": "application/json"} if method == "POST" else {}
        h.update(headers or {})
        data = json.dumps(body).encode() if body is not None else (b"{}" if method == "POST" else None)
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            r = urllib.request.urlopen(req, timeout=60)
            code, content = r.status, r.read()
            hdrs = r.headers
        except urllib.error.HTTPError as e:
            code, content, hdrs = e.code, e.read(), e.headers
        if raw:
            return code, content, hdrs
        try:
            return code, json.loads(content or b"null")
        except ValueError:
            return code, content


class ServerCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.port = free_port()
        cls.storage = os.path.join(cls.tmp, "storage")
        cls.logs = os.path.join(cls.tmp, "logs")
        cls.proc = subprocess.Popen([sys.executable, os.path.join(ROOT, "server.py"), "--port", str(cls.port),
                                     "--clusters", CLUSTERS, "--storage", cls.storage, "--logs", cls.logs,
                                     "--oc-path", FAKE_OC], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        cls.api = Api(cls.port)
        for _ in range(50):
            try:
                if cls.api.call("GET", "/api/health")[0] == 200:
                    break
            except Exception:
                time.sleep(0.1)

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(5)

    def req(self, cluster="example-dev-1", ns="demo-dev", pod="java-ok", container="app", **opts):
        body = {"cluster": cluster, "namespace": ns, "pod": pod, "container": container, "dump_type": "thread",
                "options": {"timeout": 60, "count": 1, "interval": 1, "size_limit_mb": 5}}
        body["options"].update(opts.pop("options", {}))
        body.update(opts)
        return body

    def wait(self, job_id, want=("Completed", "Failed", "Cancelled"), t=40):
        end = time.time() + t
        while time.time() < end:
            j = self.api.call("GET", "/api/jobs/" + job_id)[1]["job"]
            if j["status"] in want:
                return j
            time.sleep(0.3)
        self.fail("job did not finish: %s" % j)

    def run_job(self, body):
        code, r = self.api.call("POST", "/api/jobs", body)
        self.assertEqual(code, 202, r)
        return self.wait(r["job"]["id"])

    def audit(self):
        with open(os.path.join(self.logs, "audit.log")) as fh:
            return [json.loads(l) for l in fh]


class TestDiscovery(ServerCase):
    def test_clusters_no_credentials(self):
        code, raw, _ = self.api.call("GET", "/api/clusters", raw=True)
        self.assertEqual(code, 200)
        self.assertNotIn(b"SHOULD-NEVER-LEAK", raw)
        self.assertNotIn(b"password", raw.lower())

    def test_namespaces_ok_and_trailing_slash_url_matches(self):
        code, r = self.api.call("GET", "/api/clusters/example-dev-1/namespaces")
        self.assertEqual(code, 200)
        self.assertIn("demo-dev", r["namespaces"])
        self.assertEqual(r["identity"], "npid-dev")

    def test_cluster_without_login(self):
        code, r = self.api.call("GET", "/api/clusters/example-test-1/namespaces")
        self.assertEqual(code, 401)
        self.assertIn("oc login", r["error"])

    def test_expired_session(self):
        code, r = self.api.call("GET", "/api/clusters/example-dev-expired/namespaces")
        self.assertEqual(code, 401)
        self.assertIn("not logged in", r["error"].lower())

    def test_disabled_and_unknown_cluster(self):
        self.assertEqual(self.api.call("GET", "/api/clusters/example-dev-off/namespaces")[0], 409)
        self.assertEqual(self.api.call("GET", "/api/clusters/nope/namespaces")[0], 404)

    def test_pods_listing_and_forbidden(self):
        code, r = self.api.call("GET", "/api/clusters/example-dev-1/namespaces/demo-dev/pods")
        self.assertEqual(code, 200)
        byname = {p["name"]: p for p in r["pods"]}
        self.assertEqual(byname["java-multi"]["ready"], "2/2")
        self.assertEqual(byname["pending-pod"]["phase"], "Pending")
        code, r = self.api.call("GET", "/api/clusters/example-dev-1/namespaces/locked/pods")
        self.assertEqual(code, 403)
        self.assertIn("access denied", r["error"].lower())

    def test_bad_namespace_rejected(self):
        self.assertEqual(self.api.call("GET", "/api/clusters/example-dev-1/namespaces/Bad_NS/pods")[0], 400)


class TestRequestSecurity(ServerCase):
    def test_bad_content_type(self):
        code, _ = self.api.call("POST", "/api/validate", self.req(), headers={"Content-Type": "text/plain"})
        self.assertEqual(code, 415)

    def test_cross_origin(self):
        code, _ = self.api.call("POST", "/api/validate", self.req(), headers={"Origin": "http://evil.example"})
        self.assertEqual(code, 403)

    def test_bad_host(self):
        self.assertEqual(self.api.call("GET", "/api/clusters", headers={"Host": "evil.com"})[0], 400)

    def test_static_whitelist(self):
        for p in ("/clusters.json", "/server.py", "/backend/configuration.py", "/storage/jobs/x.json"):
            self.assertEqual(self.api.call("GET", p, raw=True)[0], 404, p)

    def test_invalid_inputs(self):
        bad = [self.req(pod="../etc/passwd"), self.req(pod="a; rm -rf /"), self.req(namespace="Bad_NS"),
               self.req(container="app\nid"), self.req(cluster="x" * 200),
               self.req(options={"timeout": 5}), self.req(options={"count": 99}),
               self.req(options={"bogus": 1}), self.req(options={"count": 5, "interval": 30, "timeout": 60}),
               self.req(dump_type="rm"), self.req(dump_type="heap"), self.req(dump_type="tcp")]
        for b in bad:
            code, r = self.api.call("POST", "/api/validate", b)
            self.assertEqual(code, 400, (b, r))

    def test_unknown_fields_ignored_not_executed(self):
        code, r = self.api.call("POST", "/api/validate", dict(self.req(), command="rm -rf /", shell=True))
        self.assertEqual(code, 200)


class TestValidateEndpoint(ServerCase):
    def checks(self, **kw):
        code, r = self.api.call("POST", "/api/validate", self.req(**kw))
        self.assertEqual(code, 200, r)
        return r

    def test_ok(self):
        r = self.checks()
        self.assertTrue(r["ok"], r)
        self.assertTrue(any("jcmd" in c["message"] for c in r["checks"]))

    def failing(self, **kw):
        r = self.checks(**kw)
        self.assertFalse(r["ok"], r)
        return [c for c in r["checks"] if not c["ok"]][0]

    def test_missing_pod(self):
        self.assertEqual(self.failing(pod="ghost")["name"], "Namespace and pod access")

    def test_forbidden_ns(self):
        c = self.failing(ns="locked"); self.assertIn("denied", c["message"].lower())

    def test_no_exec_permission(self):
        self.assertEqual(self.failing(ns="readonly")["name"], "Exec permission")

    def test_container_not_in_pod(self):
        c = self.failing(container="other"); self.assertEqual(c["name"], "Container"); self.assertIn("app", c["message"])

    def test_pod_not_running(self):
        self.assertEqual(self.failing(pod="pending-pod")["name"], "Container")
        self.assertEqual(self.failing(pod="crashing")["name"], "Container")

    def test_no_jdk_tools(self):
        c = self.failing(pod="no-jdk"); self.assertIn("Neither jcmd nor jstack", c["message"])

    def test_no_java_process(self):
        self.assertIn("No Java process", self.failing(pod="no-java")["message"])

    def test_two_jvms(self):
        self.assertIn("Several Java processes", self.failing(pod="two-jvm")["message"])

    def test_no_shell(self):
        self.assertIn("no /bin/sh", self.failing(pod="java-multi", container="sidecar")["message"])

    def test_prod_validate_does_not_probe_without_confirm(self):
        r = self.checks(cluster="example-prod-1", ns="demo-prod")
        self.assertTrue(r["ok"])
        self.assertTrue([c for c in r["checks"] if c["skipped"]])
        self.assertFalse(any("jcmd" in c["message"] or "single JVM" in c["message"] for c in r["checks"]))

    def test_unlogged_cluster(self):
        self.assertEqual(self.failing(cluster="example-test-1")["name"], "API endpoint and identity")


class TestCollection(ServerCase):
    def test_thread_dump_end_to_end(self):
        j = self.run_job(self.req(options={"count": 2, "interval": 1}))
        self.assertEqual(j["status"], "Completed", j)
        self.assertEqual(j["identity"], "npid-dev")
        self.assertGreater(j["size_bytes"], 100)
        code, raw, hdrs = self.api.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)
        self.assertEqual(code, 200)
        text = raw.decode()
        self.assertEqual(text.count("===== Thread dump"), 2)
        self.assertEqual(text.count("Full thread dump"), 2)
        self.assertIn("via=jcmd", text)
        self.assertIn("attachment", hdrs["Content-Disposition"])
        self.assertEqual(len(raw), j["size_bytes"])
        path = os.path.join(self.storage, "dumps", j["download_name"])
        self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(self.storage, "dumps")).st_mode), 0o700)
        self.assertFalse([n for n in os.listdir(os.path.join(self.storage, "dumps")) if n.endswith(".part")])
        events = [(e["event"]) for e in self.audit() if e.get("job_id") == j["id"]]
        for ev in ("job_requested", "job_started", "job_completed", "file_download"):
            self.assertIn(ev, events)

    def test_jstack_fallback(self):
        j = self.run_job(self.req(pod="jstack-only"))
        self.assertEqual(j["status"], "Completed", j)
        raw = self.api.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[1].decode()
        self.assertIn("via=jstack", raw)

    def test_failed_probe_fails_safely(self):
        j = self.run_job(self.req(pod="no-jdk"))
        self.assertEqual(j["status"], "Failed")
        self.assertIn("Neither jcmd nor jstack", j["error"])
        self.assertIsNone(j["download_name"])
        self.assertEqual(self.api.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 409)

    def test_attach_failure_and_garbage_output(self):
        j = self.run_job(self.req(pod="attach-fail"))
        self.assertEqual(j["status"], "Failed"); self.assertIn("refused the attach", j["error"])
        j = self.run_job(self.req(pod="garbage"))
        self.assertEqual(j["status"], "Failed"); self.assertIn("does not look like a thread dump", j["error"])
        self.assertFalse([n for n in os.listdir(os.path.join(self.storage, "dumps")) if "garbage" in n or n.endswith(".part")])

    def test_size_limit_enforced_and_cleaned(self):
        before = set(os.listdir(os.path.join(self.storage, "dumps")))
        j = self.run_job(self.req(pod="huge", options={"size_limit_mb": 1}))
        self.assertEqual(j["status"], "Failed"); self.assertIn("size limit", j["error"])
        self.assertEqual(set(os.listdir(os.path.join(self.storage, "dumps"))), before)

    def test_prod_requires_confirmation_server_side(self):
        j = self.run_job(self.req(cluster="example-prod-1", ns="demo-prod"))
        self.assertEqual(j["status"], "Failed"); self.assertIn("explicit confirmation", j["error"])
        j = self.run_job(self.req(cluster="example-prod-1", ns="demo-prod", confirm_prod=True))
        self.assertEqual(j["status"], "Completed", j)
        self.assertEqual(j["identity"], "npid-prod")
        ev = [e for e in self.audit() if e.get("job_id") == j["id"] and e["event"] == "job_requested"][0]
        self.assertTrue(ev["prod_confirmed"])

    def test_cancel_running_job_kills_and_cleans(self):
        code, r = self.api.call("POST", "/api/jobs", self.req(pod="slow"))
        jid = r["job"]["id"]
        self.wait(jid, want=("Running",))
        time.sleep(1)
        # duplicate for same container is refused while active
        self.assertEqual(self.api.call("POST", "/api/jobs", self.req(pod="slow"))[0], 409)
        t0 = time.time()
        self.assertEqual(self.api.call("POST", "/api/jobs/%s/cancel" % jid)[0], 200)
        j = self.wait(jid, t=15)
        self.assertEqual(j["status"], "Cancelled")
        self.assertLess(time.time() - t0, 15)
        self.assertFalse([n for n in os.listdir(os.path.join(self.storage, "dumps")) if n.endswith(".part")])
        self.assertEqual(self.api.call("POST", "/api/jobs/%s/cancel" % jid)[0], 409)
        self.assertIn("job_cancelled", [e["event"] for e in self.audit() if e.get("job_id") == jid])

    def test_download_path_safety(self):
        for jid in ("..%2f..%2fetc%2fpasswd", "20250101-000000-zzzzzzzz", "nope"):
            self.assertIn(self.api.call("GET", "/api/jobs/%s/download" % jid, raw=True)[0], (404,))

    def test_audit_has_no_secrets(self):
        self.run_job(self.req())
        with open(os.path.join(self.logs, "audit.log")) as fh:
            text = fh.read()
        for bad in ("SHOULD-NEVER-LEAK", "password", "sha256~", "Bearer"):
            self.assertNotIn(bad, text)
        for name in ("audit.log",):
            self.assertEqual(stat.S_IMODE(os.stat(os.path.join(self.logs, name)).st_mode), 0o600)


class TestUnits(unittest.TestCase):
    def test_process_timeout_cancel_bigoutput(self):
        from backend import process
        t0 = time.time()
        r = process.run(["sleep", "30"], 1)
        self.assertTrue(r.timed_out); self.assertLess(time.time() - t0, 6)
        ev = threading.Event(); threading.Timer(0.5, ev.set).start()
        r = process.run(["sleep", "30"], 20, cancel=ev)
        self.assertTrue(r.cancelled)
        r = process.run([sys.executable, "-c", "print('x'*5000000)"], 10, max_bytes=1000)
        self.assertTrue(r.too_big)
        r = process.run(["/nonexistent/binary"], 5)
        self.assertTrue(r.error)

    def test_no_shell_interpretation(self):
        from backend import process
        r = process.run(["echo", "$(id); `id` | cat"], 5)
        self.assertEqual(r.out.strip(), "$(id); `id` | cat")

    def test_redaction(self):
        from backend.process import clean_text
        s = clean_text("token=abc123 Bearer eyJhbGciOi sha256~AbCd_ef-12 password: hunter2")
        for bad in ("abc123", "eyJhbGciOi", "AbCd_ef", "hunter2"):
            self.assertNotIn(bad, s)

    def test_timeout_during_collect(self):
        from backend.oc_client import OcClient
        from diagnostics import thread_dump
        oc = OcClient(FAKE_OC)
        tmp = tempfile.mkdtemp(); part = os.path.join(tmp, "x.part")
        info = {"tool": "jcmd", "tool_path": "/opt/java/openjdk/bin/jcmd", "pid": 1}
        with self.assertRaises(thread_dump.DiagnosticError) as cm:
            thread_dump.collect(oc, "dev-ctx", "demo-dev", "slow", "app", info, 1, 1, 2, 1 << 20, part, threading.Event())
        self.assertIn("timed out", str(cm.exception))

    def test_restart_recovery_and_retention(self):
        from backend.app import App
        from backend.configuration import Settings
        tmp = tempfile.mkdtemp()
        st = os.path.join(tmp, "s"); lg = os.path.join(tmp, "l")
        os.makedirs(os.path.join(st, "dumps")); os.makedirs(os.path.join(st, "jobs"))
        base = {"requested_by": "u", "env": "DEV", "cluster": "c", "cluster_id": "c", "namespace": "n", "pod": "p",
                "container": "c", "dump_type": "thread", "created": time.time() - 99 * 86400}
        running = dict(base, id="20250101-000000-aaaaaaaa", status="Running", started=None, finished=None)
        old = dict(base, id="20250101-000000-bbbbbbbb", status="Completed", file="thread-dump_old.txt",
                   finished=time.time() - 30 * 86400, size_bytes=3)
        for j in (running, old):
            with open(os.path.join(st, "jobs", j["id"] + ".json"), "w") as fh: json.dump(j, fh)
        with open(os.path.join(st, "dumps", "thread-dump_old.txt"), "w") as fh: fh.write("abc")
        with open(os.path.join(st, "dumps", "orphan.part"), "w") as fh: fh.write("partial")
        app = App(Settings(CLUSTERS, st, lg, FAKE_OC, retention_days=7))
        self.assertEqual(app.jobs.jobs[running["id"]]["status"], "Failed")
        self.assertEqual(app.jobs.jobs[old["id"]]["status"], "Expired")
        self.assertEqual(os.listdir(os.path.join(st, "dumps")), [])
        with open(os.path.join(lg, "audit.log")) as fh:
            self.assertIn("file_deleted", fh.read())

    def test_config_hides_unknown_keys(self):
        from backend.configuration import load_clusters
        for c in load_clusters(CLUSTERS):
            self.assertEqual(set(c), {"id", "name", "environment", "api_url", "enabled", "environment_valid"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
