"""Thread-dump collection with jcmd (preferred) or jstack.

Only fixed argument lists run inside the container. The only values derived from
the container are the tool path (must match a strict regex) and a numeric PID.
If neither tool exists, or the JVM cannot be identified, we fail with a clear
message instead of trying something else.
"""
import os
import re
import time

from backend.process import clean_text

PATH_RE = re.compile(r"/[A-Za-z0-9_./+-]{1,200}")

# Fixed, reviewed, read-only script. No user input is interpolated into it.
DETECT_SCRIPT = r'''
for t in jcmd jstack; do
  p=$(command -v "$t" 2>/dev/null)
  if [ -z "$p" ] && [ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/$t" ]; then p="$JAVA_HOME/bin/$t"; fi
  if [ -n "$p" ]; then echo "tool=$t=$p"; fi
done
for d in /proc/[0-9]*; do
  e=$(readlink "$d/exe" 2>/dev/null) || continue
  case "$e" in */java) echo "pid=${d#/proc/}";; esac
done
exit 0
'''


class DiagnosticError(Exception):
    pass


class Cancelled(Exception):
    pass


def _check(res, oc, what):
    if res.cancelled:
        raise Cancelled()
    if res.timed_out:
        raise DiagnosticError("%s timed out." % what)
    if res.error:
        raise DiagnosticError(res.error)


def probe(oc, ctx, ns, pod, container, cancel=None):
    """Find a usable JVM tool and the single JVM PID. Returns {'tool','tool_path','pid'}."""
    res = oc.exec_run(ctx, ns, pod, container, ["sh", "-c", DETECT_SCRIPT], 30, cancel=cancel)
    _check(res, oc, "JVM probe")
    if res.rc != 0:
        low = res.err.lower()
        if "executable file not found" in low or "no such file" in low or res.rc in (126, 127):
            raise DiagnosticError("Container '%s' has no /bin/sh, so the JVM cannot be inspected safely. "
                                  "Use an image that includes a shell and JDK tools." % container)
        raise DiagnosticError(oc.describe_failure(res, "JVM probe"))
    tools, pids = {}, []
    for line in res.out.splitlines():
        line = line.strip()
        if line.startswith("tool="):
            parts = line.split("=", 2)
            if len(parts) == 3 and parts[1] in ("jcmd", "jstack") and PATH_RE.fullmatch(parts[2]):
                tools[parts[1]] = parts[2]
        elif line.startswith("pid=") and line[4:].isdigit():
            pids.append(int(line[4:]))
    if not tools:
        raise DiagnosticError("Neither jcmd nor jstack was found in container '%s' (JRE-only image?). "
                              "No other method was attempted." % container)
    if not pids:
        raise DiagnosticError("No Java process was found in container '%s'." % container)
    if len(pids) > 1:
        raise DiagnosticError("Several Java processes found in the container (PIDs %s); "
                              "automatic selection is not supported." % ", ".join(map(str, pids)))
    tool = "jcmd" if "jcmd" in tools else "jstack"
    return {"tool": tool, "tool_path": tools[tool], "pid": pids[0]}


def _interpret_failure(res, oc, tool):
    low = res.err.lower()
    if "unable to open socket file" in low or "attachnotsupported" in low or "disableattachmechanism" in low:
        return ("The JVM refused the attach request (attach disabled, different user, or /tmp not writable). "
                "Detail: " + clean_text(res.err, 200))
    return oc.describe_failure(res, "%s" % tool)


def collect(oc, ctx, ns, pod, container, probe_info, count, interval, timeout, max_bytes,
            part_path, cancel, progress=None):
    """Write `count` thread dumps into part_path. Returns bytes written. Raises
    DiagnosticError / Cancelled. The caller owns cleanup of part_path."""
    tool, path, pid = probe_info["tool"], probe_info["tool_path"], str(probe_info["pid"])
    command = [path, pid, "Thread.print"] if tool == "jcmd" else [path, pid]
    deadline = time.monotonic() + timeout
    fd = os.open(part_path, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w+b") as fh:
        total = 0
        for i in range(1, count + 1):
            if cancel.is_set():
                raise Cancelled()
            if progress:
                progress("Collecting thread dump %d of %d" % (i, count))
            header = ("===== Thread dump %d/%d | %s | %s/%s/%s | pid %s | %s =====\n" % (
                i, count, time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), ns, pod, container, pid, tool)
            ).encode("utf-8")
            fh.write(header)
            total += len(header)
            start = total
            remaining_t = deadline - time.monotonic()
            if remaining_t <= 0:
                raise DiagnosticError("Collection timeout reached before dump %d of %d." % (i, count))
            res = oc.exec_run(ctx, ns, pod, container, command, remaining_t, cancel=cancel,
                              sink=fh, max_bytes=max_bytes - total)
            if res.cancelled:
                raise Cancelled()
            if res.timed_out:
                raise DiagnosticError("Collection timed out during dump %d of %d." % (i, count))
            if res.too_big:
                raise DiagnosticError("Output exceeded the size limit (%d MB); collection stopped and the partial file was discarded."
                                      % (max_bytes // (1024 * 1024)))
            if res.error:
                raise DiagnosticError(res.error)
            if res.rc != 0:
                raise DiagnosticError(_interpret_failure(res, oc, tool))
            fh.flush()
            fh.seek(start)
            head = fh.read(4096)
            fh.seek(0, 2)
            total = fh.tell()
            if b"Full thread dump" not in head:
                raise DiagnosticError("The command ran but its output does not look like a thread dump "
                                      "(missing 'Full thread dump'); it was discarded.")
            total += 0
            if i < count:
                if progress:
                    progress("Waiting %ds before dump %d of %d" % (interval, i + 1, count))
                if cancel.wait(min(interval, max(0, deadline - time.monotonic()))):
                    raise Cancelled()
                fh.write(b"\n")
                total += 1
        fh.flush()
        os.fsync(fh.fileno())
    return total
