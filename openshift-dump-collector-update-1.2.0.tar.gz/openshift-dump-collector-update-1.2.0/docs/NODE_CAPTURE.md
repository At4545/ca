# TCP capture on the node (version 1.2)

## Why this exists
The original capture ran a `tcpdump` that already had to exist **inside the application's container**. Most application images do not
contain `tcpdump`, and OpenShift's default security policy drops the `NET_RAW` capability a capture needs, so it usually could not work.

The new capture method **"On the node"** follows the standard OpenShift troubleshooting runbook (debug pod on the node, enter the pod's
network namespace with `nsenter`, run `tcpdump` there). It does not need `tcpdump` or `NET_RAW` in the application image. The old method is
unchanged and remains the default.

## What it does, step by step
1. **Looks up the node** the pod runs on and checks that it is Ready (read-only).
2. **Debug pod 1 (discovery)** on that node: checks the debug image has `tcpdump`, `nsenter` and `timeout`, asks the node's container
   runtime (`crictl`) for the Ready sandbox of the target pod, and prints its description. The portal extracts the **network-namespace path**
   from that description in Python (no `jq`, no shell JSON parsing).
3. **Debug pod 2 (capture)**: enters **only that network namespace** with `nsenter` and runs `tcpdump -nn -i any ...`, streaming the pcap to
   the portal. **Nothing is written on the node.** (The manual runbook writes `/host/var/tmp/*.pcap`; the portal does not.)
4. The portal verifies the file is a valid pcap, hashes it, and offers it for download, exactly like the other diagnostics.
5. `oc debug` normally removes its temporary pod and namespace. The portal then checks whether a temporary `openshift-debug-*` namespace
   was left behind (for example after a cancel) and, if so, adds a **POSSIBLE LEFTOVER** note naming it and the command to remove it.

## What it requires
| Requirement | Detail |
|---|---|
| **The user's own token must be allowed** | Starting a privileged debug pod on a node needs cluster-level rights, typically **cluster-admin**. The portal grants nothing: if the token is not allowed, the cluster refuses and the portal says so |
| Early hints | Before starting anything the portal asks the cluster `can-i get nodes` and `can-i use scc/privileged` for the user's token and stops with a clear message if either is "no" |
| `oc debug node` must work on the cluster | Some managed platforms restrict it. Test it by hand first (section "Before you enable it") |
| A debug image with `tcpdump`, `nsenter`, `timeout` | The default image `oc debug` chooses normally has them. If your cluster cannot reach it (restricted registry), set `NODE_CAPTURE_IMAGE` to an approved image |
| `crictl` on the node host | Present on RHCOS nodes; the debug pod runs it through `chroot /host` |
| The portal server | Needs `oc` as before. No new software |

## Safeguards (all enforced by the server)
* **Off unless enabled per environment.** `NODE_CAPTURE_ENVS` (default `DEV,TEST`; PROD is opt-in; empty switches the method off entirely).
* **Optional user allow-list.** `NODE_CAPTURE_USERS` = `*` (anyone the cluster allows) or `cluster-id:identity` pairs. Recommended in production.
* **Explicit acknowledgement** of the privileged debug pod (server-enforced, recorded in the audit log). On PROD the usual PROD confirmation and a narrowed filter (a preset other than "all", or a peer IP) are also required.
* **No user text reaches a command or a script.** The two scripts are constants. Namespace, pod-name pattern, duration, namespace path, snap length, packet cap and filter are passed as separate arguments and only expanded inside double quotes. The filter comes from the fixed preset table (plus a validated IP); the node name and image name must match strict patterns.
* **Everything learned from the cluster is validated** before use: node name, 64-hex sandbox id and the number of matching sandboxes (exactly one), and the network-namespace path (only `/var/run/netns/<name>` or `/proc/<pid>/ns/net`).
* **Host-network pods are refused** (capturing them would capture all traffic of the node).
* **Bounded:** duration 5-300 s (enforced on the node by `timeout`), 500,000 packets, size cap 1-500 MB. **Headers only (128 bytes/packet) by default**; full packets need a separate consent.
* **One node-level capture at a time** on the whole portal, for any user.
* **Stray `oc` output is discarded.** The capture starts with a marker line; anything `oc` prints before it is dropped, and trailing text is trimmed by the pcap check.
* **Cleaned up on every ending path:** partial files are deleted; the private token file is deleted before the final status is shown.
* **Audited:** `job_requested` (method, acknowledgement), `job_started` (method, node, exact filter), `job_completed/failed/cancelled`, and `debug_namespace_leftover` when a leftover is detected.

## Using it
1. Collect Dump -> choose the pod -> **TCP Dump**.
2. **Capture method: On the node.** Read the warning, tick the acknowledgement.
3. The timeout is raised automatically (the debug pod needs time to start; the minimum is the duration + 180 s).
4. **Validate Request** is read-only: it checks permissions, policy and the node, but does **not** start a debug pod. The first real use of the debug pod is when you press Collect.
5. Collect, watch the stage text ("Starting a temporary debug pod on node ...", then "Capturing on node ..."), download the pcap.

## Settings
| `portal.conf` | Option | Default | Meaning |
|---|---|---|---|
| `NODE_CAPTURE_ENVS` | `--node-capture-envs` | `DEV,TEST` | Environments where the method is allowed. **Empty = off** |
| `NODE_CAPTURE_USERS` | `--node-capture-users` | `*` | Who may use it |
| `NODE_CAPTURE_IMAGE` | `--node-capture-image` | (oc default) | Debug-pod image; must contain `tcpdump`, `nsenter`, `timeout` |

## Before you enable it: verify by hand on a DEV cluster
These are the same steps the portal automates. Run them as the user who will use the portal (`oc login` with that user).
```bash
oc auth can-i get nodes ; oc auth can-i use scc/privileged                 # both "yes"
NODE=$(oc get pod <pod> -n <ns> -o jsonpath='{.spec.nodeName}')
oc debug node/$NODE --no-stdin --tty=false -- sh -c 'command -v tcpdump nsenter timeout'     # all three found
oc debug node/$NODE --no-stdin --tty=false -- chroot /host crictl pods --namespace <ns> --name '^<pod>$' --state Ready -q   # one 64-hex id
oc debug node/$NODE --no-stdin --tty=false -- chroot /host crictl inspectp <that id>        # look for "type": "network" and its "path"
oc get namespaces | grep openshift-debug                                    # nothing left behind afterwards
```
If a step fails by hand it will fail in the portal for the same reason.

## What has NOT been verified
This feature was built and tested against a **simulated `oc`** and with the two scripts run in a real shell against stub tools. It has **not**
been run on a real cluster. These assumptions about real behaviour need confirming on DEV:
* the exact `oc debug` flags (`--no-stdin`, `--tty=false`) and that it passes the remote command's stdout through unchanged;
* whether `oc debug` prints its informational lines to stdout or stderr (the portal tolerates either) and what exit code it returns for the remote command's code 124 (the portal accepts 0, 124, or "exit code 124" in the message);
* the output format of `crictl pods ... -q --state Ready` and `crictl inspectp` on your node version;
* that `oc auth can-i use scc/privileged` reflects your cluster's policy;
* that the temporary namespace really is named `openshift-debug-*` (used only for the best-effort leftover warning);
* that the default debug image contains `tcpdump`, `nsenter` and `timeout`;
* whether your platform (for example ARO) allows `oc debug node` for your users at all.

## Troubleshooting
| Message | Meaning / fix |
|---|---|
| "Node-level capture is not enabled for DEV ... (--node-capture-envs)" | Set `NODE_CAPTURE_ENVS` in `portal.conf` and restart |
| "is restricted to listed administrators (--node-capture-users)" | The user is not in `NODE_CAPTURE_USERS` |
| "Your account is not allowed to: read nodes; use the 'privileged' security context constraint" | The token lacks cluster-level rights; ask a cluster administrator, or capture some other way |
| "Starting a privileged debug pod on node ... is not allowed for your account" | The cluster refused `oc debug node` for this user |
| "could not start (image pull problem)" | The cluster cannot pull the debug image: set `NODE_CAPTURE_IMAGE` to an approved one |
| "The debug image ... does not contain: tcpdump ..." | Use an image that has `tcpdump`, `nsenter` and `timeout` |
| "no Ready pod ... (it may have restarted or moved)" | The pod was rescheduled or is not Ready; try again |
| "N Ready sandboxes match" | Ambiguous; the portal refuses to guess |
| "uses the node's own network (host network)" | Refused by design |
| "Node ... is not Ready" | A debug pod cannot start there |
| "Another node-level capture is already running" | One at a time; wait or cancel it |
| "Starting the debug pod used up most of the collection timeout" | Raise the timeout (duration + 180 s minimum) |
| "POSSIBLE LEFTOVER: the temporary debug namespace ..." | `oc` did not clean up (for example after a cancel). A cluster administrator can run the `oc delete namespace ...` command shown, if nothing else uses it |

## Limits
* Captures one pod's network namespace (all containers of the pod share it); `-i any` captures all its interfaces. It does not capture other pods or the node itself.
* Takes about a minute longer than the in-container method (two debug pods start, one after the other).
* Cancelling kills the local `oc debug`; the remote `tcpdump` is bounded by its own `timeout`, and the temporary namespace may be left behind (reported, not removed automatically).
* Needs a privileged debug pod: whether a given user or platform may do that is a policy decision for the platform and security teams.
