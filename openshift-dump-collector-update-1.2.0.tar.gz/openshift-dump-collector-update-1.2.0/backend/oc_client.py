"""Safe wrapper around the existing `oc` CLI, authenticated with the USER'S OWN token.

* Arguments are always lists; user input never reaches a shell.
* Each operation gets a private kubeconfig (server from clusters.json + the user's token) in a memory-backed
  0700 directory. The token is never on a command line, never in the environment, never in logs. The server's
  own kubeconfig / `oc login` is never used (KUBECONFIG is overridden).
* TLS verification is ON unless that specific cluster was explicitly configured otherwise.
"""
import json
import os
import re
import shutil

from . import process
from .process import clean_text

_ENV_KEEP = ("PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "TMPDIR",
             "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "no_proxy",
             "SSL_CERT_FILE", "SSL_CERT_DIR")
TOKEN_RE = re.compile(r"sha256~[A-Za-z0-9_\-]{20,100}")
DEBUG_NS_PREFIX = "openshift-debug-"


class OcError(Exception):
    def __init__(self, message, code="oc_error"):
        Exception.__init__(self, message)
        self.message = message
        self.code = code   # auth | forbidden | unreachable | notfound | tls | timeout | cancelled | oc_error


class Creds(object):
    """What a job/request needs to talk to ONE cluster as ONE user. Never serialised or logged."""
    __slots__ = ("cluster", "token", "identity")

    def __init__(self, cluster, token, identity=None):
        self.cluster, self.token, self.identity = cluster, token, identity

    def __repr__(self):
        return "Creds(%s)" % self.cluster.get("id")


def describe_failure(res, what):
    if res.error:
        return res.error
    if res.cancelled:
        return "%s was cancelled" % what
    if res.timed_out:
        return "%s timed out" % what
    low = (res.err or "").lower()
    if "forbidden" in low:
        return "%s: access denied by the cluster. Your account lacks permission for this operation." % what
    if "unauthorized" in low or "must be logged in" in low or "provide credentials" in low:
        return "%s: the cluster rejected your token (expired or revoked). Connect again with a fresh token." % what
    if "x509" in low or "certificate" in low:
        return ("%s: the cluster's TLS certificate is not trusted by this server. Verification was not bypassed; "
                "an administrator can mark this specific cluster tls_verify=false if that is acceptable." % what)
    if any(s in low for s in ("connection refused", "no such host", "i/o timeout", "unreachable", "timeout", "deadline exceeded")):
        return "%s: the cluster API is unreachable from this server." % what
    if "notfound" in low or "not found" in low:
        return "%s: not found (%s)" % (what, clean_text(res.err, 160))
    return "%s failed (exit %s): %s" % (what, res.rc, clean_text(res.err, 250) or "no error output")


def failure_code(res):
    low = (res.err or "").lower()
    if res.cancelled:
        return "cancelled"
    if res.timed_out:
        return "timeout"
    if "forbidden" in low:
        return "forbidden"
    if "unauthorized" in low or "must be logged in" in low or "provide credentials" in low:
        return "auth"
    if "x509" in low or "certificate" in low:
        return "tls"
    if "notfound" in low or "not found" in low:
        return "notfound"
    if any(s in low for s in ("connection refused", "no such host", "i/o timeout", "unreachable")):
        return "unreachable"
    return "oc_error"


class OcClient(object):
    def __init__(self, oc_path, runtime):
        self.path = shutil.which(oc_path)
        self.runtime = runtime

    @property
    def available(self):
        return self.path is not None

    def open(self, creds):
        if not self.path:
            raise OcError("The OpenShift CLI (oc) was not found on this server.")
        kc = self.runtime.new_kubeconfig(creds.cluster["api_url"], creds.token, not creds.cluster.get("tls_verify", True))
        return OcSession(self, kc)

    def anonymous(self, cluster):
        if not self.path:
            raise OcError("The OpenShift CLI (oc) was not found on this server.")
        kc = self.runtime.new_kubeconfig(cluster["api_url"], None, not cluster.get("tls_verify", True))
        return OcSession(self, kc)


class OcSession(object):
    def __init__(self, client, kubeconfig):
        self.client = client
        self.kc = kubeconfig
        env = {k: os.environ[k] for k in _ENV_KEEP if k in os.environ}
        env["KUBECONFIG"] = kubeconfig.path
        env["KUBECACHEDIR"] = kubeconfig.cache
        self.env = env

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.kc.close()

    describe_failure = staticmethod(describe_failure)

    def _call(self, args, what, timeout=30, cancel=None, request_timeout=True):
        cmd = [self.client.path]
        if request_timeout:
            cmd += ["--request-timeout=%ds" % max(5, int(timeout) - 5)]
        cmd += list(args)
        res = process.run(cmd, timeout, cancel=cancel, env=self.env)
        if res.rc != 0 or res.error or res.timed_out or res.cancelled:
            raise OcError(describe_failure(res, what), failure_code(res))
        return res

    def whoami(self):
        return self._call(["whoami"], "Checking your token", 20).out.strip()

    def probe_version(self):
        cmd = [self.client.path, "--request-timeout=6s", "get", "--raw=/version"]
        res = process.run(cmd, 15, env=self.env)
        low = (res.err or "").lower()
        if res.rc == 0:
            try:
                v = json.loads(res.out).get("gitVersion", "")
            except ValueError:
                v = ""
            return "reachable", "API server responded", v
        if "forbidden" in low or "unauthorized" in low:
            return "reachable", "API server is up (anonymous access to /version is not allowed)", ""
        if "x509" in low or "certificate" in low:
            return "tls_error", "TLS certificate is not trusted by this server", ""
        if res.timed_out or "timeout" in low or "deadline" in low:
            return "timeout", "No response within the time limit", ""
        if res.error:
            return "error", res.error, ""
        return "unreachable", clean_text(res.err, 160) or "Connection failed", ""

    def list_namespaces(self):
        try:
            res = self._call(["get", "projects", "-o", "json"], "Listing projects", 30)
        except OcError as first:
            if first.code != "notfound":
                raise
            res = self._call(["get", "namespaces", "-o", "json"], "Listing namespaces", 30)
        return sorted(i["metadata"]["name"] for i in json.loads(res.out).get("items") or [])

    @staticmethod
    def pod_summary(item):
        status = item.get("status") or {}
        cstat = {c.get("name"): c for c in status.get("containerStatuses") or []}
        containers = []
        for c in (item.get("spec") or {}).get("containers") or []:
            s = cstat.get(c.get("name")) or {}
            state = s.get("state") or {}
            if "running" in state:
                st = "Running"
            elif "waiting" in state:
                st = (state["waiting"] or {}).get("reason") or "Waiting"
            elif "terminated" in state:
                st = (state["terminated"] or {}).get("reason") or "Terminated"
            else:
                st = "Unknown"
            containers.append({"name": c.get("name"), "ready": bool(s.get("ready")), "state": st,
                               "restarts": s.get("restartCount", 0)})
        phase = status.get("phase") or "Unknown"
        if (item.get("metadata") or {}).get("deletionTimestamp"):
            phase = "Terminating"
        ready = sum(1 for c in containers if c["ready"])
        return {"name": item["metadata"]["name"], "phase": phase, "ready": "%d/%d" % (ready, len(containers)),
                "containers": containers}

    def list_pods(self, namespace):
        res = self._call(["get", "pods", "-n", namespace, "-o", "json"], "Listing pods", 30)
        return sorted((self.pod_summary(i) for i in json.loads(res.out).get("items") or []), key=lambda p: p["name"])

    def get_pod(self, namespace, pod):
        res = self._call(["get", "pod", pod, "-n", namespace, "-o", "json"], "Reading pod", 30)
        return self.pod_summary(json.loads(res.out))

    def can_exec(self, namespace):
        res = process.run([self.client.path, "auth", "can-i", "create", "pods/exec", "-n", namespace], 20, env=self.env)
        ans = res.out.strip().lower()
        if ans == "yes":
            return True
        if ans == "no":
            return False
        raise OcError(describe_failure(res, "Checking exec permission"), failure_code(res))

    def exec_run(self, namespace, pod, container, command, timeout, cancel=None, sink=None, max_bytes=1 << 20):
        cmd = [self.client.path, "exec", pod, "-n", namespace, "-c", container, "--"] + list(command)
        return process.run(cmd, timeout, cancel=cancel, sink=sink, max_bytes=max_bytes, env=self.env)

    # ---- node-level capture support (v1.2) -------------------------------------------------------------------
    def pod_node(self, namespace, pod):
        """Name of the node the pod is scheduled on ('' if none)."""
        res = self._call(["get", "pod", pod, "-n", namespace, "-o", "json"], "Reading pod", 30)
        return str(((json.loads(res.out).get("spec") or {}).get("nodeName")) or "")

    def node_ready(self, node):
        res = self._call(["get", "node", node, "-o", "json"], "Reading node", 30)
        conds = (json.loads(res.out).get("status") or {}).get("conditions") or []
        return any(c.get("type") == "Ready" and c.get("status") == "True" for c in conds)

    def can_i(self, *words):
        """True / False, or None when the cluster could not answer. words are fixed literals chosen by the portal."""
        res = process.run([self.client.path, "auth", "can-i"] + list(words), 20, env=self.env)
        ans = res.out.strip().lower()
        return True if ans == "yes" else False if ans == "no" else None

    def debug_namespaces(self):
        """{name: phase} of temporary debug namespaces; None if the user may not list namespaces."""
        try:
            res = self._call(["get", "namespaces", "-o", "json"], "Listing namespaces", 30)
        except OcError:
            return None
        out = {}
        for i in json.loads(res.out).get("items") or []:
            name = (i.get("metadata") or {}).get("name") or ""
            if name.startswith(DEBUG_NS_PREFIX):
                out[name] = (i.get("status") or {}).get("phase") or "Unknown"
        return out

    def debug_node(self, node, image, script, args, timeout, cancel=None, sink=None, max_bytes=1 << 20):
        """Run ONE fixed script in a temporary privileged debug pod on `node`. `script` is a constant owned by the
        portal; every variable value is passed as a separate argument ($1, $2, ...), never inside the script text."""
        cmd = [self.client.path, "debug", "node/" + node]
        if image:
            cmd.append("--image=" + image)
        cmd += ["--no-stdin", "--tty=false", "--", "sh", "-c", script, "portal"] + [str(a) for a in args]
        return process.run(cmd, timeout, cancel=cancel, sink=sink, max_bytes=max_bytes, env=self.env)
