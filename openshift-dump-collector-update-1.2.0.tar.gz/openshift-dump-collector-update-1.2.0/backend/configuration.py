"""Cluster metadata + server settings. Python 3.9 compatible, stdlib only.

clusters.json is read ONLY for: name, environment, API URL, enabled, and an optional explicit
"tls_verify": false. Everything else in it - including any credentials section - is never copied
anywhere and is never used to log in to a cluster.
"""
import json
import os
import re

VALID_ENVS = ("DEV", "TEST", "PROD")
_ENV_KEYS = ("environment", "env", "Environment", "Env")
_NAME_KEYS = ("name", "cluster_name", "clusterName", "Name", "cluster")
_URL_KEYS = ("api_url", "apiUrl", "api", "url", "api_server", "server", "apiURL")
_ENABLED_KEYS = ("enabled", "Enabled", "active", "status")
SECRET_HINTS = ("password", "passwd", "secret", "token", "credential", "apikey", "api_key")


class ConfigError(Exception):
    pass


class Settings(object):
    def __init__(self, clusters_path, storage_dir, log_dir, runtime_dir=None, oc_path="oc",
                 max_concurrent=2, max_active_jobs=10, max_user_jobs=3, max_heap_jobs=1,
                 retention_days=7, purge_on_logout=False, min_free_mb=500,
                 user_quota_mb=20480, total_quota_mb=51200, heap_max_mb=8192,
                 tcp_envs=("DEV", "TEST"), insecure_tls=(), admin_users=(),
                 idle_seconds=1800, max_session_seconds=28800, login_fail_limit=10, tick_seconds=15,
                 node_capture_envs=("DEV", "TEST"), node_capture_users=("*",), node_capture_image="",
                 max_node_jobs=1):
        self.clusters_path = clusters_path
        self.storage_dir = storage_dir
        self.log_dir = log_dir
        self.runtime_dir = runtime_dir
        self.oc_path = oc_path
        self.max_concurrent = max_concurrent
        self.max_active_jobs = max_active_jobs
        self.max_user_jobs = max_user_jobs
        self.max_heap_jobs = max_heap_jobs
        self.retention_days = retention_days
        self.purge_on_logout = purge_on_logout
        self.min_free_mb = min_free_mb
        self.user_quota_mb = user_quota_mb
        self.total_quota_mb = total_quota_mb
        self.heap_max_mb = heap_max_mb
        self.tcp_envs = tuple(e for e in tcp_envs if e in VALID_ENVS)
        self.insecure_tls = frozenset(insecure_tls)
        self.admin_users = frozenset(admin_users)
        self.idle_seconds = idle_seconds
        self.max_session_seconds = max_session_seconds
        self.login_fail_limit = login_fail_limit
        self.tick_seconds = tick_seconds
        # Node-level TCP capture (privileged debug pod on the pod's node). Separate from tcp_envs because it is a
        # much larger privilege than exec into one container. The user's own token must still be allowed by the cluster.
        self.node_capture_envs = tuple(e for e in node_capture_envs if e in VALID_ENVS)
        self.node_capture_users = tuple(node_capture_users)       # "*" or "cluster-id:identity" entries
        self.node_capture_image = node_capture_image or ""
        self.max_node_jobs = max_node_jobs

    def node_capture_allows(self, cluster_id, identity):
        return "*" in self.node_capture_users or ("%s:%s" % (cluster_id, identity)) in self.node_capture_users


def _first(entry, keys):
    for k in keys:
        if k in entry:
            return entry[k]
    return None


def _as_bool(v):
    if v is None:
        return True
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() in ("true", "1", "yes", "enabled", "active")


def _entries(data):
    if isinstance(data, list):
        return [e for e in data if isinstance(e, dict)]
    if isinstance(data, dict):
        for key in ("clusters", "Clusters", "items"):
            if key in data:
                return _entries(data[key])
        if data and all(isinstance(v, dict) for v in data.values()):
            return [dict(v, _key=k) for k, v in data.items()]
    return []


def _slug(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "cluster"


def _read(path):
    if not os.path.isfile(path):
        raise ConfigError("Cluster configuration file not found: %s" % path)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError) as exc:
        raise ConfigError("Cluster configuration could not be read (%s)" % type(exc).__name__)


def load_clusters(path, insecure_ids=()):
    """Sanitized cluster dicts: id, name, environment, api_url, enabled, tls_verify."""
    result, seen = [], set()
    for entry in _entries(_read(path)):
        name = _first(entry, _NAME_KEYS) or entry.get("_key")
        env = _first(entry, _ENV_KEYS)
        url = _first(entry, _URL_KEYS)
        if not (isinstance(name, str) and name):
            continue
        env = str(env).strip().upper() if env else "UNKNOWN"
        cid, n = _slug(name), 2
        while cid in seen:
            cid = "%s-%d" % (_slug(name), n)
            n += 1
        seen.add(cid)
        tls_verify = not (entry.get("tls_verify") is False or cid in insecure_ids)
        result.append({
            "id": cid, "name": name, "environment": env,
            "api_url": url if isinstance(url, str) else "",
            "enabled": _as_bool(_first(entry, _ENABLED_KEYS)),
            "environment_valid": env in VALID_ENVS,
            "tls_verify": tls_verify,
        })
    return result


def count_credential_fields(path):
    n = 0
    for e in _entries(_read(path)):
        for k, v in e.items():
            if any(h in k.lower() for h in SECRET_HINTS) and v:
                n += 1
    return n
