OpenShift Dump Collector - update 1.2.0  (TCP capture on the node)
==================================================================
Problem fixed: TCP capture only worked when the application's container already had tcpdump (and the NET_RAW capability), which
most images do not. New capture method "On the node": a temporary privileged debug pod on the pod's node enters the pod's network
namespace and runs tcpdump there (the manual runbook, automated and made safe). The old method is unchanged and still the default.

Needs an existing 1.0.x or 1.1.x install.

Also changed (found while testing): run.sh used to load portal.conf by SOURCING it as shell code, so a value such as
"x; id" or "$(id)" would have been executed. It now reads portal.conf as plain data (only known KEY=value lines; values are taken
literally; unknown keys such as PATH or LD_PRELOAD are ignored with a warning). Valid files behave exactly as before.

1. Stop the portal.
2. Apply:      ./apply_update.sh /path/to/installed/openshift-dump-collector [--dry-run]
               (backs up the replaced files to <install>.backup-update-<date>; keeps portal.conf, clusters.json, storage/, logs/, certs/)
3. Read:       docs/NODE_CAPTURE.md   (requirements, safeguards, settings, how to verify by hand on DEV first)
4. Check:      cd /path/to/installed/openshift-dump-collector && python3 -m unittest discover -s tests -p "test_node_capture.py"
               (about two minutes; your existing tests keep working)
5. Start the portal again (./run.sh).

Node-level capture is enabled for DEV and TEST by default (NODE_CAPTURE_ENVS in portal.conf). The USER'S OWN token must be allowed
to run privileged debug pods (typically cluster-admin). Set NODE_CAPTURE_ENVS= (empty) to switch it off.

Files replaced: server.py script.js run.sh VERSION backend/configuration.py backend/validation.py backend/collection_service.py
                backend/oc_client.py deploy/portal.conf.example
Files added:    diagnostics/node_capture.py docs/NODE_CAPTURE.md tests/test_node_capture.py tests/bin/oc_nodes
Rollback:       stop the portal, copy the files from the backup folder back.

Not yet verified on a real cluster (see "What has NOT been verified" in docs/NODE_CAPTURE.md).
