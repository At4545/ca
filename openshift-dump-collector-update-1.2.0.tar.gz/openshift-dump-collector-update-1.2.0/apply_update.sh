#!/usr/bin/env bash
# Applies the v1.2.0 update (TCP capture on the node) to an existing 1.0.x or 1.1.x install.
#   ./apply_update.sh /path/to/installed/openshift-dump-collector [--dry-run]
# Replaces whole files: server.py script.js run.sh VERSION backend/{configuration,validation,collection_service,oc_client}.py
#   deploy/portal.conf.example; adds diagnostics/node_capture.py docs/NODE_CAPTURE.md tests/test_node_capture.py tests/bin/oc_nodes.
# Keeps: portal.conf, clusters.json, storage/, logs/, certs/, every other file. A backup of each replaced file is saved in
# <install>.backup-update-<timestamp>. Stop the portal first; start it again afterwards.
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-}"; DRY=0; [ "${2:-}" = "--dry-run" ] && DRY=1
[ -n "$TARGET" ] || { sed -n '2,7p' "$0"; exit 2; }
TARGET="$(cd "$TARGET" 2>/dev/null && pwd)" || { echo "Folder not found: $1" >&2; exit 2; }
[ -f "$TARGET/server.py" ] && [ -d "$TARGET/backend" ] && [ -d "$TARGET/diagnostics" ] && [ -f "$TARGET/VERSION" ] || { echo "$TARGET does not look like an installed portal (server.py, backend/, diagnostics/ and VERSION expected)." >&2; exit 2; }
CUR="$(tr -d '[:space:]' < "$TARGET/VERSION")"
case "$CUR" in 1.0.*|1.1.*) ;; 1.2.*) echo "Already at version $CUR - nothing to do."; exit 0;; *) echo "Installed version is '$CUR'; this update is for 1.0.x and 1.1.x." >&2; exit 1;; esac
for f in backend/app.py backend/oc_client.py backend/sessions.py diagnostics/tcp_dump.py diagnostics/thread_dump.py diagnostics/heap_dump.py diagnostics/pcap.py; do
  [ -f "$TARGET/$f" ] || { echo "The install is missing $f; this update expects a standard 1.0/1.1 layout. Nothing was changed." >&2; exit 1; }
done
if pgrep -f "$TARGET/server.py" >/dev/null 2>&1 || pgrep -f "python.* server.py" >/dev/null 2>&1; then
  echo "WARNING: a portal process appears to be running. Stop it before applying (then start it again afterwards)."
fi
FILES="server.py script.js run.sh backend/configuration.py backend/validation.py backend/collection_service.py backend/oc_client.py diagnostics/node_capture.py deploy/portal.conf.example docs/NODE_CAPTURE.md tests/test_node_capture.py tests/bin/oc_nodes VERSION"   # VERSION last
for f in $FILES; do [ -f "$SRC/$f" ] || { echo "The update bundle is incomplete (missing $f). Nothing was changed." >&2; exit 1; }; done
BK="$TARGET.backup-update-$(date +%Y%m%d-%H%M%S)"
do_() { if [ "$DRY" = 1 ]; then echo "[dry-run] $*"; else "$@"; fi; }
do_ mkdir -p "$BK"
for f in $FILES; do
  if [ -e "$TARGET/$f" ]; then do_ mkdir -p "$BK/$(dirname "$f")"; do_ cp -a "$TARGET/$f" "$BK/$f"; fi
  do_ mkdir -p "$TARGET/$(dirname "$f")"
  do_ cp "$SRC/$f" "$TARGET/$f"
done
do_ chmod +x "$TARGET/run.sh" "$TARGET/tests/bin/oc_nodes"
do_ find "$TARGET" -name __pycache__ -type d -prune -exec rm -rf {} +
# add the new settings to the user's own portal.conf without touching what is there
if [ -f "$TARGET/portal.conf" ] && ! grep -q '^NODE_CAPTURE_ENVS' "$TARGET/portal.conf"; then
  if [ "$DRY" = 1 ]; then echo "[dry-run] append node-capture settings to portal.conf"; else
    { echo; echo "# ---- Node-level TCP capture (added by the v1.2 update) ----"; sed -n '/^NODE_CAPTURE_ENVS=/,/^NODE_CAPTURE_IMAGE=/p' "$SRC/deploy/portal.conf.example"; } >> "$TARGET/portal.conf"
  fi
fi
echo "Updated $TARGET from $CUR to $(tr -d '[:space:]' < "$SRC/VERSION"). Backup of replaced files: $BK"
echo
echo "NOTE: capture ON THE NODE is now available for DEV and TEST (NODE_CAPTURE_ENVS in portal.conf). It needs the user's own token to be"
echo "allowed to run privileged debug pods (typically cluster-admin). To switch it off set NODE_CAPTURE_ENVS= (empty); to restrict it set NODE_CAPTURE_USERS."
echo "Read docs/NODE_CAPTURE.md, then start the portal again."
echo "Rollback: stop the portal and copy the files from the backup folder back over the install."
