#!/usr/bin/env bash
# Starts the portal using portal.conf (if present). Safe to run by hand or from systemd.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
CONF="${PORTAL_CONF:-$HERE/portal.conf}"

# portal.conf is read as DATA, never executed: only KEY=value lines for the keys below are accepted, a value is taken literally
# (so "x; id" or "$(id)" are just text), optional surrounding quotes are removed and " # comment" tails are ignored.
known_key() {
  case "$1" in
    PORT|CLUSTERS_FILE|STORAGE_DIR|LOG_DIR|RUNTIME_DIR|IDLE_MINUTES|RETENTION_DAYS|PURGE_ON_LOGOUT|USER_QUOTA_MB|TOTAL_QUOTA_MB|\
    HEAP_MAX_MB|MAX_CONCURRENT|MAX_USER_JOBS|TCP_ENVS|ADMIN_USERS|INSECURE_TLS_CLUSTERS|NODE_CAPTURE_ENVS|NODE_CAPTURE_USERS|\
    NODE_CAPTURE_IMAGE|BIND_HOST|TLS_CERT|TLS_KEY|ALLOW_FROM|PUBLIC_HOSTS|PUBLIC_PORT|ALLOW_INSECURE_HTTP|OC_PATH|PYTHON|\
    HTTP_PROXY|HTTPS_PROXY|NO_PROXY|http_proxy|https_proxy|no_proxy|SSL_CERT_FILE|SSL_CERT_DIR) return 0;;
  esac
  return 1
}
load_conf() {
  local line key raw val n=0
  while IFS= read -r line || [ -n "$line" ]; do
    n=$((n + 1))
    line="${line%$'\r'}"
    line="${line#"${line%%[![:space:]]*}"}"
    case "$line" in ''|'#'*) continue;; esac
    if [[ ! "$line" =~ ^([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*=(.*)$ ]]; then
      echo "portal.conf line $n ignored (not KEY=value)" >&2; continue
    fi
    key="${BASH_REMATCH[1]}"; raw="${BASH_REMATCH[2]}"
    if ! known_key "$key"; then echo "portal.conf line $n: unknown setting '$key' ignored" >&2; continue; fi
    val="${raw#"${raw%%[![:space:]]*}"}"
    if [ "$val" != "$raw" ] && [ "${val:0:1}" = "#" ]; then val=""                      # KEY=   # comment  -> empty value
    elif [[ "$val" =~ ^\"([^\"]*)\"[[:space:]]*(#.*)?$ ]]; then val="${BASH_REMATCH[1]}"
    elif [[ "$val" =~ ^\'([^\']*)\'[[:space:]]*(#.*)?$ ]]; then val="${BASH_REMATCH[1]}"
    else
      val="${val%%[[:space:]]#*}"
      val="${val%"${val##*[![:space:]]}"}"
    fi
    printf -v "$key" '%s' "$val"
    export "$key"
  done < "$1"
}
if [ -f "$CONF" ]; then load_conf "$CONF"; fi

abs() { case "$1" in /*) printf '%s' "$1";; *) printf '%s/%s' "$HERE" "$1";; esac; }
PY="${PYTHON:-python3}"
args=(--port "${PORT:-8080}" --clusters "$(abs "${CLUSTERS_FILE:-clusters.json}")" --storage "$(abs "${STORAGE_DIR:-storage}")"
      --logs "$(abs "${LOG_DIR:-logs}")" --idle-minutes "${IDLE_MINUTES:-30}" --retention-days "${RETENTION_DAYS:-7}"
      --user-quota-mb "${USER_QUOTA_MB:-20480}" --total-quota-mb "${TOTAL_QUOTA_MB:-51200}" --heap-max-mb "${HEAP_MAX_MB:-8192}"
      --max-concurrent "${MAX_CONCURRENT:-2}" --max-user-jobs "${MAX_USER_JOBS:-3}" --tcp-envs "${TCP_ENVS:-DEV,TEST}")
[ -n "${RUNTIME_DIR:-}" ] && args+=(--runtime-dir "$(abs "$RUNTIME_DIR")")
[ "${PURGE_ON_LOGOUT:-0}" = "1" ] && args+=(--purge-on-logout)
[ -n "${ADMIN_USERS:-}" ] && args+=(--admin-users "$ADMIN_USERS")
[ -n "${INSECURE_TLS_CLUSTERS:-}" ] && args+=(--insecure-tls-clusters "$INSECURE_TLS_CLUSTERS")
[ -n "${OC_PATH:-}" ] && args+=(--oc-path "$OC_PATH")
# --- node-level TCP capture (v1.2). NODE_CAPTURE_ENVS unset = DEV,TEST; set it EMPTY to switch the method off completely.
args+=(--node-capture-envs "${NODE_CAPTURE_ENVS-DEV,TEST}" --node-capture-users "${NODE_CAPTURE_USERS:-*}")
[ -n "${NODE_CAPTURE_IMAGE:-}" ] && args+=(--node-capture-image "$NODE_CAPTURE_IMAGE")
# --- network access (v1.1). Leave BIND_HOST empty to stay on this machine only (127.0.0.1).
[ -n "${BIND_HOST:-}" ] && args+=(--host "$BIND_HOST")
[ -n "${TLS_CERT:-}" ] && args+=(--tls-cert "$(abs "$TLS_CERT")")
[ -n "${TLS_KEY:-}" ] && args+=(--tls-key "$(abs "$TLS_KEY")")
[ -n "${ALLOW_FROM:-}" ] && args+=(--allow-from "$ALLOW_FROM")
[ -n "${PUBLIC_HOSTS:-}" ] && args+=(--public-host "$PUBLIC_HOSTS")
[ -n "${PUBLIC_PORT:-}" ] && args+=(--public-port "$PUBLIC_PORT")
[ "${ALLOW_INSECURE_HTTP:-0}" = "1" ] && args+=(--allow-insecure-http)
umask 077
exec "$PY" server.py "${args[@]}" "$@"
