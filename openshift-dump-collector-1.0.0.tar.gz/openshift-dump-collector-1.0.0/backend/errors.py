"""Errors that are safe to show to the user."""


class ApiError(Exception):
    def __init__(self, code, message, details=None, reason=None):
        Exception.__init__(self, message)
        self.code = code
        self.message = message
        self.details = details
        self.reason = reason     # machine-readable hint for the UI, e.g. "not_connected"
