"""In-memory sessions holding each user's cluster tokens.

Tokens live ONLY in this process's memory: never on disk, never in logs, never sent back
to the browser. A session ends on sign-out, after `idle_seconds` without activity
(activity includes having a running job), or after `max_seconds` in total.
"""
import secrets
import threading
import time


class Session(object):
    def __init__(self, sid, now):
        self.sid = sid
        self.created = now
        self.last_active = now
        self.tokens = {}          # cluster_id -> {"token", "identity", "since"}

    def identities(self):
        return {(cid, t["identity"]) for cid, t in self.tokens.items()}


class SessionStore(object):
    def __init__(self, idle_seconds=1800, max_seconds=28800, has_active_jobs=None, on_end=None):
        self.idle = idle_seconds
        self.max = max_seconds
        self.lock = threading.RLock()
        self.sessions = {}
        self.has_active_jobs = has_active_jobs or (lambda sid: False)
        self.on_end = on_end or (lambda session, reason, connections: None)

    def create(self):
        now = time.time()
        s = Session(secrets.token_urlsafe(32), now)
        with self.lock:
            self.sessions[s.sid] = s
        return s

    def get(self, sid, touch=True):
        """Return the live session or None. Expired sessions are ended (tokens wiped) here too."""
        if not sid:
            return None
        with self.lock:
            s = self.sessions.get(sid)
            if s is None:
                return None
            reason = self._expired(s, time.time())
            if reason:
                self._end(s, reason)
                return None
            if touch:
                s.last_active = time.time()
            return s

    def _expired(self, s, now):
        if now - s.created > self.max:
            return "max_lifetime"
        if now - s.last_active > self.idle:
            if self.has_active_jobs(s.sid):
                s.last_active = now            # a running job keeps its owner's session alive
                return None
            return "idle"
        return None

    def _end(self, s, reason):
        connections = sorted(s.identities())
        self.sessions.pop(s.sid, None)
        s.tokens.clear()
        try:
            self.on_end(s, reason, connections)
        except Exception:
            pass

    def sweep(self):
        now = time.time()
        with self.lock:
            for s in list(self.sessions.values()):
                reason = self._expired(s, now)
                if reason:
                    self._end(s, reason)

    def end(self, sid, reason="signed_out"):
        with self.lock:
            s = self.sessions.get(sid)
            if s:
                self._end(s, reason)

    def set_token(self, s, cluster_id, token, identity):
        with self.lock:
            s.tokens[cluster_id] = {"token": token, "identity": identity, "since": time.time()}

    def drop_token(self, s, cluster_id):
        with self.lock:
            return s.tokens.pop(cluster_id, None)

    def expires_in(self, s):
        now = time.time()
        return int(max(0, min(self.idle - (now - s.last_active), self.max - (now - s.created))))
