"""Strict server-side validation of every request field. Python 3.9 compatible.
Options are validated per dump type; anything not allowed for that type is rejected."""
import ipaddress
import re

from diagnostics.tcp_dump import FILTER_PRESETS, PAYLOAD_MODES
from .errors import ApiError

CLUSTER_ID_RE = re.compile(r"[a-z0-9][a-z0-9-]{0,79}")
NS_RE = re.compile(r"[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?")           # DNS-1123 label
POD_RE = re.compile(r"[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?")        # DNS-1123 subdomain
CONTAINER_RE = NS_RE
JOB_ID_RE = re.compile(r"\d{8}-\d{6}-[0-9a-f]{8}")

DUMP_TYPES = ("thread", "heap", "tcp")
TCP_EXTRA = ("filter", "port", "peer_ip", "payload")
ALL_KEYS = ("timeout", "size_limit_mb", "count", "interval", "duration", "filter", "port", "peer_ip", "payload")
TCP_TIMEOUT_MARGIN = 20


def int_options(dump_type, heap_max_mb):
    """name -> (min, max, default)"""
    return {
        "thread": {"timeout": (30, 1800, 300), "size_limit_mb": (1, 50, 50), "count": (1, 10, 3), "interval": (1, 60, 10)},
        "tcp": {"timeout": (30, 1800, 300), "size_limit_mb": (1, 500, 100), "duration": (5, 300, 30)},
        "heap": {"timeout": (120, 7200, 1800), "size_limit_mb": (1, heap_max_mb, min(4096, heap_max_mb))},
    }[dump_type]


def _to_int(value, lo, hi):
    if isinstance(value, str) and re.fullmatch(r"\d{1,6}", value.strip()):
        value = int(value.strip())
    if isinstance(value, bool) or not isinstance(value, int) or value < lo or value > hi:
        return None
    return value


def valid_namespace(ns):
    return isinstance(ns, str) and NS_RE.fullmatch(ns) is not None


def parse_request(body, heap_max_mb=8192):
    """Return a clean request dict or raise ApiError(400) listing every bad field."""
    if not isinstance(body, dict):
        raise ApiError(400, "Request body must be a JSON object")
    errors = {}

    def text(name, rx):
        v = body.get(name)
        if not isinstance(v, str) or rx.fullmatch(v) is None:
            errors[name] = "missing or invalid"
            return None
        return v

    clean = {k: None for k in ALL_KEYS}
    clean.update({"cluster": text("cluster", CLUSTER_ID_RE), "namespace": text("namespace", NS_RE),
                  "pod": text("pod", POD_RE), "container": text("container", CONTAINER_RE)})
    dt = body.get("dump_type")
    specs = None
    if not isinstance(dt, str) or dt not in DUMP_TYPES:
        errors["dump_type"] = "must be one of: " + ", ".join(DUMP_TYPES)
    else:
        specs = int_options(dt, heap_max_mb)
    clean["dump_type"] = dt

    opts = body.get("options")
    if opts is None:
        opts = {}
    if not isinstance(opts, dict):
        errors["options"] = "must be an object"
        opts = {}
    if specs is not None:
        allowed = set(specs) | (set(TCP_EXTRA) if dt == "tcp" else set())
        unknown = sorted(set(opts) - allowed)
        if unknown:
            errors["options"] = "not valid for a %s request: %s" % (dt, ", ".join(str(u)[:30] for u in unknown))
        for name, (lo, hi, default) in specs.items():
            if opts.get(name) is None:
                clean[name] = default
                continue
            n = _to_int(opts[name], lo, hi)
            if n is None:
                errors[name] = "must be a whole number from %d to %d" % (lo, hi)
            clean[name] = n

    if specs is not None and dt == "tcp":
        flt = opts.get("filter", "all")
        if flt is None:
            flt = "all"
        if not isinstance(flt, str) or flt not in FILTER_PRESETS:
            errors["filter"] = "must be one of: " + ", ".join(sorted(FILTER_PRESETS))
            flt = None
        clean["filter"] = flt
        port = opts.get("port")
        if flt == "port":
            n = _to_int(port, 1, 65535) if port is not None else None
            if n is None:
                errors["port"] = "required for the 'port' filter: a whole number from 1 to 65535"
            clean["port"] = n
        elif port is not None and flt is not None:
            errors["port"] = "only valid with the 'port' filter"
        peer = opts.get("peer_ip")
        if peer not in (None, ""):
            ok = False
            if isinstance(peer, str) and len(peer) <= 45 and "%" not in peer and peer == peer.strip():
                try:
                    clean["peer_ip"] = str(ipaddress.ip_address(peer))
                    ok = True
                except ValueError:
                    pass
            if not ok:
                errors["peer_ip"] = "must be a plain IPv4 or IPv6 address"
        pay = opts.get("payload", "headers")
        if pay is None:
            pay = "headers"
        if not isinstance(pay, str) or pay not in PAYLOAD_MODES:
            errors["payload"] = "must be one of: " + ", ".join(sorted(PAYLOAD_MODES))
            pay = None
        clean["payload"] = pay

    if not errors and dt == "thread":
        needed = (clean["count"] - 1) * clean["interval"] + 10
        if needed >= clean["timeout"]:
            errors["timeout"] = "too short for %d dumps %ds apart (needs more than %ds)" % (clean["count"], clean["interval"], needed)
    if not errors and dt == "tcp" and clean["timeout"] < clean["duration"] + TCP_TIMEOUT_MARGIN:
        errors["timeout"] = "must be at least %ds longer than the capture duration (%ds)" % (TCP_TIMEOUT_MARGIN, clean["duration"])

    clean["confirm_prod"] = body.get("confirm_prod") is True
    clean["confirm_payload"] = body.get("confirm_payload") is True
    clean["confirm_heap"] = body.get("confirm_heap") is True
    cn = body.get("confirm_name")
    clean["confirm_name"] = cn if isinstance(cn, str) and len(cn) <= 120 else None
    if errors:
        raise ApiError(400, "Invalid request", errors)
    return clean


def options_of(clean, heap_max_mb=8192):
    keys = list(int_options(clean["dump_type"], heap_max_mb))
    if clean["dump_type"] == "tcp":
        keys += list(TCP_EXTRA)
    return {k: clean[k] for k in keys if clean.get(k) is not None}
