"""Job manager: pre-collection checks, background execution, cancellation, ownership, quotas,
downloads and retention. Jobs run on a small thread pool so long collections never block the UI.

Ownership: a job belongs to (cluster_id, identity) where identity is what the CLUSTER reported for
the user's token. A request may only see or touch jobs whose (cluster, identity) is currently
connected in its own session. Tokens are held in memory by the session and, while a job runs, by
that job's private kubeconfig (deleted when the job ends).
"""
import logging
import os
import secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from diagnostics import heap_dump, tcp_dump, thread_dump
from diagnostics.thread_dump import Cancelled, DiagnosticError

from .configuration import ConfigError
from .errors import ApiError
from .oc_client import Creds, OcError
from .validation import JOB_ID_RE, PAYLOAD_MODES, options_of

log = logging.getLogger("dumpcollector")
ACTIVE = ("Pending", "Validating", "Running")
LABELS = {"thread": "Thread dump", "tcp": "TCP capture", "heap": "Heap dump"}
MB = 1024 * 1024
PUBLIC_KEYS = ("id", "status", "stage", "env", "cluster", "cluster_id", "namespace", "pod", "container", "dump_type",
               "requested_by", "created", "started", "finished", "duration", "size_bytes", "sha256", "error", "checks",
               "options", "packets", "note")


class JobManager(object):
    def __init__(self, app):
        self.app = app
        self.lock = threading.RLock()
        self.jobs = {}
        self.cancels = {}
        self.job_session = {}          # job id -> session id (memory only; never persisted)
        self.pool = ThreadPoolExecutor(max_workers=app.settings.max_concurrent, thread_name_prefix="job")
        self._last_sweep = 0.0

    # ---- lifecycle -------------------------------------------------------------------------
    def recover(self):
        """On startup no job can still be running: fail interrupted ones and drop partial files."""
        self.app.storage.cleanup_partials()
        for j in self.app.db.load_jobs():
            if j.get("status") in ACTIVE:
                j.update(status="Failed", stage="Interrupted", finished=time.time(),
                         error="The portal restarted while this job was active; the partial file was discarded.")
                note = " If this was a heap dump, check /tmp in the container for a leftover portal-heap-*.hprof file." if j.get("dump_type") == "heap" else ""
                j["error"] += note
                self.app.db.save_job(j)
                self.app.audit.log("job_failed", j.get("requested_by"), job_id=j["id"], detail="interrupted by restart")
            self.jobs[j["id"]] = j
        self.sweep(force=True)

    def _save(self, job):
        self.app.db.save_job(job)

    def _set(self, job, **kw):
        with self.lock:
            job.update(kw)
            self._save(job)

    def public(self, job):
        out = {k: job.get(k) for k in PUBLIC_KEYS}
        out["download_available"] = job.get("status") == "Completed" and bool(job.get("file"))
        out["download_name"] = job.get("file") if out["download_available"] else None
        out["active"] = job.get("status") in ACTIVE
        return out

    def has_active_for_session(self, sid):
        with self.lock:
            return any(j["status"] in ACTIVE and self.job_session.get(j["id"]) == sid for j in self.jobs.values())

    # ---- ownership-scoped access ------------------------------------------------------------
    def list_for(self, session):
        self.sweep()
        mine = session.identities() if session else set()
        with self.lock:
            rows = [j for j in self.jobs.values() if (j["cluster_id"], j["requested_by"]) in mine]
        return [self.public(j) for j in sorted(rows, key=lambda j: j["created"], reverse=True)][:500]

    def get_for(self, session, job_id):
        """404 (not 403) for other people's jobs so their existence is not revealed."""
        if not JOB_ID_RE.fullmatch(job_id or ""):
            raise ApiError(404, "Job not found")
        with self.lock:
            j = self.jobs.get(job_id)
        if not j or not session or (j["cluster_id"], j["requested_by"]) not in session.identities():
            raise ApiError(404, "Job not found")
        return j

    # ---- usage / quotas ---------------------------------------------------------------------
    def stored_bytes(self, cluster_id=None, owner=None):
        with self.lock:
            return sum(j.get("size_bytes") or 0 for j in self.jobs.values()
                       if j["status"] == "Completed" and j.get("file")
                       and (cluster_id is None or j["cluster_id"] == cluster_id)
                       and (owner is None or j["requested_by"] == owner))

    # ---- pre-collection checks ------------------------------------------------------------
    def preflight(self, clean, creds, cancel=None, dry_run=False):
        """Ordered checks, as the user. Returns (ok, checks, facts). Stops at the first hard failure."""
        dt = clean["dump_type"]
        cfg = self.app.settings
        checks, facts = [], {}

        def add(name, ok, msg, skipped=False):
            checks.append({"name": name, "ok": ok, "message": msg, "skipped": skipped})
            return ok

        cluster = creds.cluster
        env = cluster["environment"]
        if not cluster["environment_valid"] or not cluster["api_url"]:
            add("Cluster configuration", False, "Cluster has no valid environment/API URL configured.")
            return False, checks, facts
        add("Cluster configuration", True, "%s (%s) is configured and enabled%s." % (
            cluster["name"], env, "" if cluster["tls_verify"] else "; TLS verification is OFF for this cluster"))

        if dt == "tcp":      # policy is decided from configuration alone, before touching the cluster
            if env not in cfg.tcp_envs:
                add("Capture policy", False, "TCP capture is not enabled for %s clusters in this portal (enabled for: %s). "
                    "An administrator can change this with the --tcp-envs server option." % (env, ", ".join(cfg.tcp_envs) or "none"))
                return False, checks, facts
            if env == "PROD" and clean["filter"] == "all" and not clean["peer_ip"]:
                add("Capture policy", False, "Captures on PROD must be narrowed: choose a filter other than 'all' or set a peer IP.")
                return False, checks, facts
            if clean["payload"] == "full" and not clean["confirm_payload"]:
                add("Capture policy", False, "Full-packet capture can record credentials, tokens and personal data. "
                    "Confirm that you accept this, or use headers-only.")
                return False, checks, facts
            facts["expression"] = tcp_dump.build_expression(clean["filter"], clean["port"], clean["peer_ip"])
            add("Capture policy", True, "%d s, %s, filter: %s, size cap %d MB." % (
                clean["duration"], "headers only (%d bytes/packet)" % PAYLOAD_MODES["headers"] if clean["payload"] == "headers" else "FULL packets",
                facts["expression"] or "none (all traffic)", clean["size_limit_mb"]))

        if dt == "heap":
            if not clean["confirm_heap"]:
                if dry_run:
                    add("Heap dump policy", True, "You will have to acknowledge the heap-dump risks when you collect.", skipped=True)
                else:
                    add("Heap dump policy", False, "Heap dumps pause the JVM, can use gigabytes of memory/disk and contain secrets that "
                        "were in memory. Acknowledge these risks to continue.")
                    return False, checks, facts
            elif env == "PROD" and clean["confirm_name"] != cluster["name"]:
                if dry_run:
                    add("Heap dump policy", True, "On PROD you will have to type the cluster name '%s' to confirm." % cluster["name"], skipped=True)
                else:
                    add("Heap dump policy", False, "On PROD, type the exact cluster name '%s' to confirm the heap dump." % cluster["name"])
                    return False, checks, facts
            else:
                add("Heap dump policy", True, "Heap-dump risks acknowledged%s." % (" and cluster name confirmed" if env == "PROD" else ""))

        try:
            with self.app.oc.open(creds) as oc:
                return self._preflight_cluster(oc, clean, creds, cluster, env, dt, add, checks, facts, cancel, dry_run)
        except OcError as exc:
            add("Credentials and identity", False, exc.message)
            return False, checks, facts

    def _preflight_cluster(self, oc, clean, creds, cluster, env, dt, add, checks, facts, cancel, dry_run):
        cfg = self.app.settings
        try:
            identity = oc.whoami()
        except OcError as exc:
            add("Credentials and identity", False, exc.message)
            return False, checks, facts
        if identity != creds.identity:
            add("Credentials and identity", False, "The token now belongs to '%s', not '%s'. Connect again." % (identity, creds.identity))
            return False, checks, facts
        facts["identity"] = identity
        add("Credentials and identity", True, "Your token is valid on %s; authenticated as '%s'." % (cluster["api_url"], identity))

        try:
            pod = oc.get_pod(clean["namespace"], clean["pod"])
        except OcError as exc:
            add("Namespace and pod access", False, exc.message)
            return False, checks, facts
        add("Namespace and pod access", True, "Pod '%s' is readable in namespace '%s'." % (clean["pod"], clean["namespace"]))
        try:
            can = oc.can_exec(clean["namespace"])
        except OcError as exc:
            add("Exec permission", False, exc.message)
            return False, checks, facts
        if not add("Exec permission", can, "You may exec into pods in this namespace." if can else
                   "Your account is not allowed to exec into pods in '%s'." % clean["namespace"]):
            return False, checks, facts
        cont = [c for c in pod["containers"] if c["name"] == clean["container"]]
        if not cont:
            add("Container", False, "Container '%s' does not belong to pod '%s' (available: %s)." % (
                clean["container"], clean["pod"], ", ".join(c["name"] for c in pod["containers"]) or "none"))
            return False, checks, facts
        if pod["phase"] != "Running" or cont[0]["state"] != "Running":
            add("Container", False, "Pod is %s and container is %s; it must be Running." % (pod["phase"], cont[0]["state"]))
            return False, checks, facts
        add("Container", True, "Container '%s' belongs to the pod and is running." % clean["container"])
        add("Diagnostic type", True, "%s is supported." % LABELS[dt])

        if env == "PROD":
            if clean["confirm_prod"]:
                add("PROD confirmation", True, "Explicit production confirmation received.")
            elif dry_run:
                add("PROD confirmation", True, "Will be required when you collect (not yet given).", skipped=True)
            else:
                add("PROD confirmation", False, "Production collection requires explicit confirmation.")
                return False, checks, facts

        reserve = clean["size_limit_mb"] * MB
        free = self.app.storage.free_mb()
        if not add("Storage space", free >= max(cfg.min_free_mb, clean["size_limit_mb"] * 2) if dt != "heap" else True,
                   "%d MB free on the portal server." % free if dt != "heap" else "Checked against the estimated size below."):
            return False, checks, facts
        facts["reserve"] = reserve

        tool_check = {"thread": "JVM diagnostic tools", "heap": "JVM tools and heap size", "tcp": "Capture tool and permission"}[dt]
        if env == "PROD" and not clean["confirm_prod"]:
            add(tool_check, True, "Not probed on PROD until you confirm.", skipped=True)
            return True, checks, facts
        try:
            if dt == "thread":
                info = thread_dump.probe(oc, clean["namespace"], clean["pod"], clean["container"], cancel)
                add(tool_check, True, "Found %s and a single JVM (pid %d)." % (info["tool"], info["pid"]))
            elif dt == "tcp":
                info = tcp_dump.probe(oc, clean["namespace"], clean["pod"], clean["container"], cancel)
                add(tool_check, True, "tcpdump %s is present and the container may capture (verified with a <=%ds, 1-packet, "
                    "header-only test whose output was discarded)." % (info["version"], tcp_dump.SELFTEST_SECONDS))
            else:
                info = heap_dump.probe(oc, clean["namespace"], clean["pod"], clean["container"], cancel)
                est = heap_dump.estimate_used(oc, clean["namespace"], clean["pod"], clean["container"], info, cancel)
                ok, msg, need = heap_dump.plan(est, info["tmpfree_kb"], reserve)
                if not ok:
                    add(tool_check, False, msg)
                    return False, checks, facts
                facts["need"] = need
                add(tool_check, True, "Found %s and a single JVM (pid %d). %s" % (info["tool"], info["pid"], msg))
            facts["probe"] = info
        except Cancelled:
            add(tool_check, False, "Cancelled.")
            return False, checks, facts
        except DiagnosticError as exc:
            add(tool_check, False, str(exc))
            return False, checks, facts

        need = facts.get("need", reserve)
        user_used = self.stored_bytes(cluster["id"], identity)
        total_used = self.stored_bytes()
        free_b = self.app.storage.free_mb() * MB
        if free_b < need + cfg.min_free_mb * MB:
            add("Storage space", False, "Not enough free disk on the portal server (%d MB free, ~%d MB needed plus %d MB reserve)." % (
                free_b // MB, need // MB, cfg.min_free_mb))
            return False, checks, facts
        if user_used + need > cfg.user_quota_mb * MB:
            add("Storage quota", False, "Your stored dumps use %d MB of your %d MB quota; this job needs about %d MB. Delete older results first." % (
                user_used // MB, cfg.user_quota_mb, need // MB))
            return False, checks, facts
        if total_used + need > cfg.total_quota_mb * MB:
            add("Storage quota", False, "The portal's total dump storage quota (%d MB) would be exceeded. Ask an administrator or wait for retention cleanup." % cfg.total_quota_mb)
            return False, checks, facts
        add("Storage quota", True, "%d MB of your %d MB quota in use; about %d MB reserved for this job." % (user_used // MB, cfg.user_quota_mb, need // MB))
        return True, checks, facts

    def validate(self, clean, creds):
        ok, checks, _ = self.preflight(clean, creds, dry_run=True)
        self.app.audit.log("validate", creds.identity, cluster=creds.cluster["name"], namespace=clean["namespace"],
                           pod=clean["pod"], container=clean["container"], dump_type=clean["dump_type"], ok=ok)
        return {"ok": ok, "checks": checks}

    # ---- create / run / cancel -------------------------------------------------------------
    def create(self, clean, creds, session_id):
        cluster, cfg = creds.cluster, self.app.settings
        owner = creds.identity
        with self.lock:
            active = [j for j in self.jobs.values() if j["status"] in ACTIVE]
            if len(active) >= cfg.max_active_jobs:
                raise ApiError(429, "Too many active collection jobs on this portal; try again shortly.")
            if sum(1 for j in active if j["requested_by"] == owner and j["cluster_id"] == cluster["id"]) >= cfg.max_user_jobs:
                raise ApiError(429, "You already have %d active collections; wait for one to finish or cancel it." % cfg.max_user_jobs)
            if clean["dump_type"] == "heap" and sum(1 for j in active if j["dump_type"] == "heap") >= cfg.max_heap_jobs:
                raise ApiError(429, "Another heap dump is already running on this portal; heap dumps run one at a time.")
            for j in active:
                if (j["cluster_id"], j["namespace"], j["pod"], j["container"]) == (cluster["id"], clean["namespace"], clean["pod"], clean["container"]):
                    mine = j["requested_by"] == owner
                    raise ApiError(409, "A collection is already active for this container%s." % (" (job %s)" % j["id"] if mine else ""))
            job_id = time.strftime("%Y%m%d-%H%M%S", time.gmtime()) + "-" + secrets.token_hex(4)
            job = {"id": job_id, "status": "Pending", "stage": "Queued", "env": cluster["environment"],
                   "cluster_id": cluster["id"], "cluster": cluster["name"], "namespace": clean["namespace"],
                   "pod": clean["pod"], "container": clean["container"], "dump_type": clean["dump_type"],
                   "requested_by": owner, "created": time.time(), "started": None, "finished": None, "duration": None,
                   "size_bytes": None, "sha256": None, "file": None, "error": None, "checks": [],
                   "confirm_prod": clean["confirm_prod"], "packets": None, "note": None,
                   "options": options_of(clean, cfg.heap_max_mb)}
            self.jobs[job_id] = job
            self.cancels[job_id] = threading.Event()
            self.job_session[job_id] = session_id
            self._save(job)
        self.app.audit.log("job_requested", owner, job_id=job_id, env=cluster["environment"], cluster=cluster["name"],
                           namespace=clean["namespace"], pod=clean["pod"], container=clean["container"], dump_type=clean["dump_type"],
                           prod_confirmed=clean["confirm_prod"] or None, payload_confirmed=clean["confirm_payload"] or None,
                           heap_acknowledged=clean["confirm_heap"] or None, tls_verify=cluster["tls_verify"], options=job["options"])
        self.pool.submit(self._run, job_id, clean, Creds(cluster, creds.token, creds.identity))
        return self.public(job)

    def cancel(self, session, job_id):
        job = self.get_for(session, job_id)
        with self.lock:
            if job["status"] not in ACTIVE:
                raise ApiError(409, "Job is not active (status: %s)." % job["status"])
            self.cancels[job_id].set()
            if job["status"] == "Pending":
                job["stage"] = "Cancelling"
        self.app.audit.log("cancel_requested", job["requested_by"], job_id=job_id, cluster=job["cluster"])
        return self.public(job)

    def cancel_for_session(self, sid, cluster_id=None, reason="signed out"):
        """Used on sign-out / disconnect: the user wants their token gone, so their running jobs stop."""
        with self.lock:
            for j in self.jobs.values():
                if j["status"] in ACTIVE and self.job_session.get(j["id"]) == sid and (cluster_id is None or j["cluster_id"] == cluster_id):
                    self.cancels[j["id"]].set()
                    self.app.audit.log("cancel_requested", j["requested_by"], job_id=j["id"], cluster=j["cluster"], detail=reason)

    def _finish(self, job, status, stage, error=None, **extra):
        now = time.time()
        self._set(job, status=status, stage=stage, error=error, finished=now,
                  duration=round(now - (job.get("started") or job["created"]), 1), **extra)
        ev = {"Completed": "job_completed", "Failed": "job_failed", "Cancelled": "job_cancelled"}[status]
        self.app.audit.log(ev, job["requested_by"], job_id=job["id"], env=job["env"], cluster=job["cluster"],
                           namespace=job["namespace"], pod=job["pod"], container=job["container"], dump_type=job["dump_type"],
                           status=status, file=job.get("file"), size_bytes=job.get("size_bytes"), packets=job.get("packets"), detail=error)
        with self.lock:
            self.job_session.pop(job["id"], None)

    def _run(self, job_id, clean, creds):
        job, cancel, storage = self.jobs[job_id], self.cancels[job_id], self.app.storage
        part = None
        try:
            if cancel.is_set():
                return self._finish(job, "Cancelled", "Cancelled before start")
            self._set(job, status="Validating", stage="Pre-collection checks", started=time.time())
            ok, checks, facts = self.preflight(clean, creds, cancel=cancel)
            self._set(job, checks=checks)
            if cancel.is_set():
                return self._finish(job, "Cancelled", "Cancelled during validation")
            if not ok:
                bad = [c for c in checks if not c["ok"]]
                return self._finish(job, "Failed", "Validation failed: " + (bad[0]["name"] if bad else "unknown"),
                                    error=bad[0]["message"] if bad else "Validation failed.")
            self.app.audit.log("job_started", job["requested_by"], job_id=job_id, cluster=job["cluster"], namespace=job["namespace"],
                               pod=job["pod"], filter_expression=facts.get("expression"))
            self._set(job, status="Running", stage="Starting collection")
            progress = lambda s: self._set(job, stage=s)  # noqa: E731
            extra, notes = {}, []
            max_bytes = clean["size_limit_mb"] * MB
            with self.app.oc.open(creds) as oc:      # the token's kubeconfig lives exactly as long as this block
                if clean["dump_type"] == "thread":
                    name = "thread-dump_%s.txt" % job_id
                    part = storage.path_for(name + ".part")
                    thread_dump.collect(oc, clean["namespace"], clean["pod"], clean["container"], facts["probe"], clean["count"],
                                        clean["interval"], clean["timeout"], max_bytes, part, cancel, progress=progress)
                elif clean["dump_type"] == "tcp":
                    name = "tcp-capture_%s.pcap" % job_id
                    part = storage.path_for(name + ".part")
                    r = tcp_dump.collect(oc, clean["namespace"], clean["pod"], clean["container"], clean["duration"],
                                         PAYLOAD_MODES[clean["payload"]], facts["expression"], clean["timeout"], max_bytes, part, cancel, progress=progress)
                    extra["packets"] = r["packets"]
                    if r["packets"] == 0:
                        notes.append("The capture is valid but contains 0 packets: no traffic matched the filter during the capture window.")
                    if r["trimmed"]:
                        notes.append("%d trailing bytes of an incomplete final packet were removed." % r["trimmed"])
                else:
                    name = "heap-dump_%s.hprof" % job_id
                    part = storage.path_for(name + ".part")
                    free_local = lambda: storage.free_mb() * MB - self.app.settings.min_free_mb * MB  # noqa: E731
                    heap_dump.collect(oc, clean["namespace"], clean["pod"], clean["container"], facts["probe"], job_id,
                                      clean["timeout"], max_bytes, part, cancel, free_local, progress=progress)
                    left = heap_dump.cleanup_failed_for(job_id)
                    if left:
                        notes.append("ACTION NEEDED: the temporary dump file %s could not be deleted from the container. "
                                     "Remove it manually (it uses disk space and contains memory contents)." % left)
            final = storage.path_for(name)
            os.replace(part, final)
            part = None
            os.chmod(final, 0o600)
            if clean["dump_type"] == "heap":
                self._set(job, stage="Verifying (SHA-256)")
            self._finish(job, "Completed", "Finished", file=name, size_bytes=os.path.getsize(final), sha256=storage.sha256(final),
                         note=" ".join(notes) or None, **extra)
        except Cancelled:
            self._cancel_note(job, clean)
        except DiagnosticError as exc:
            self._fail_note(job, clean, "Collection failed", str(exc))
        except OcError as exc:
            self._fail_note(job, clean, "Collection failed", exc.message)
        except Exception:
            log.exception("Unexpected error in job %s", job_id)
            self._fail_note(job, clean, "Internal error", "Unexpected internal error; see the application log.")
        finally:
            if part:
                storage.remove(os.path.basename(part))
            creds.token = None          # drop this job's reference to the token

    def _leftover(self, job, clean):
        if clean["dump_type"] != "heap":
            return None
        left = heap_dump.cleanup_failed_for(job["id"])
        return ("ACTION NEEDED: the temporary dump file %s could not be deleted from the container; remove it manually." % left) if left else None

    def _cancel_note(self, job, clean):
        self._finish(job, "Cancelled", "Cancelled by requester", note=self._leftover(job, clean))

    def _fail_note(self, job, clean, stage, msg):
        self._finish(job, "Failed", stage, error=msg, note=self._leftover(job, clean))

    # ---- downloads, deletion, retention ---------------------------------------------------
    def download_info(self, session, job_id):
        job = self.get_for(session, job_id)
        if job["status"] != "Completed" or not job.get("file"):
            raise ApiError(409, "No downloadable file (status: %s)." % job["status"])
        try:
            path = self.app.storage.path_for(job["file"])
            size = os.path.getsize(path)
        except (OSError, ValueError):
            self.sweep(force=True)
            raise ApiError(410, "The file is no longer available.")
        if size != job["size_bytes"]:
            raise ApiError(500, "Stored file failed its integrity check; it was not served.")
        self.app.audit.log("file_download", job["requested_by"], job_id=job_id, file=job["file"], size_bytes=size)
        return path, job["file"], size

    def _expire(self, job, reason, error):
        removed = self.app.storage.remove(job["file"]) if job.get("file") else False
        self.app.audit.log("file_deleted" if removed else "file_expired", job["requested_by"], job_id=job["id"], file=job.get("file"), detail=reason)
        job.update(status="Expired", stage="Expired", error=error)
        self._save(job)

    def delete_result(self, session, job_id):
        job = self.get_for(session, job_id)
        with self.lock:
            if job["status"] != "Completed" or not job.get("file"):
                raise ApiError(409, "There is no stored file to delete (status: %s)." % job["status"])
            self._expire(job, "deleted by owner", "File deleted by its owner.")
        return self.public(job)

    def purge_owner(self, cluster_id, identity, reason):
        """purge-on-logout: remove a user's stored results when their connection ends."""
        with self.lock:
            for j in self.jobs.values():
                if j["cluster_id"] == cluster_id and j["requested_by"] == identity and j["status"] == "Completed" and j.get("file"):
                    self._expire(j, reason, "File removed when its owner's session ended (purge-on-logout is enabled).")

    def sweep(self, force=False):
        """Results are kept while the owner keeps logging in: they expire `retention_days` after the
        owner's last successful login (or the job's completion, whichever is later), or immediately
        if the file has gone missing."""
        now = time.time()
        if not force and now - self._last_sweep < 30:
            return
        self._last_sweep = now
        limit = self.app.settings.retention_days * 86400
        with self.lock:
            for j in list(self.jobs.values()):
                if j["status"] != "Completed" or not j.get("file"):
                    continue
                try:
                    exists = os.path.isfile(self.app.storage.path_for(j["file"]))
                except ValueError:
                    exists = False
                anchor = max(self.app.db.last_login(j["cluster_id"], j["requested_by"]) or 0, j.get("finished") or 0)
                old = (now - anchor) > limit
                if old or not exists:
                    self._expire(j, "retention policy" if old else "file missing from storage",
                                 "File removed: %s." % ("retention period after the owner's last login elapsed" if old else "it was missing from storage"))
