"""SQLite persistence (stdlib sqlite3): job history, per-user login times, cluster overrides.
The file is created 0600. NO tokens or credentials are ever stored here."""
import json
import os
import sqlite3
import threading
import time


class Database(object):
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
        os.close(fd)
        os.chmod(path, 0o600)
        self.cx = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.cx.execute("PRAGMA journal_mode=WAL")
        self.cx.execute("PRAGMA synchronous=NORMAL")
        self.cx.executescript("""
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, cluster_id TEXT NOT NULL, owner TEXT NOT NULL,
                                            created REAL NOT NULL, status TEXT NOT NULL, doc TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS jobs_owner ON jobs(cluster_id, owner, created);
            CREATE TABLE IF NOT EXISTS users(cluster_id TEXT NOT NULL, identity TEXT NOT NULL,
                                             first_login REAL NOT NULL, last_login REAL NOT NULL,
                                             PRIMARY KEY(cluster_id, identity));
            CREATE TABLE IF NOT EXISTS cluster_state(cluster_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL,
                                                     changed_by TEXT, changed_at REAL);
        """)
        for suffix in ("", "-wal", "-shm"):
            if os.path.exists(path + suffix):
                os.chmod(path + suffix, 0o600)

    def save_job(self, job):
        with self.lock:
            self.cx.execute("INSERT OR REPLACE INTO jobs(id,cluster_id,owner,created,status,doc) VALUES(?,?,?,?,?,?)",
                            (job["id"], job["cluster_id"], job["requested_by"], job["created"], job["status"], json.dumps(job)))

    def load_jobs(self):
        with self.lock:
            rows = self.cx.execute("SELECT doc FROM jobs ORDER BY created").fetchall()
        out = []
        for (doc,) in rows:
            try:
                out.append(json.loads(doc))
            except ValueError:
                continue
        return out

    def touch_login(self, cluster_id, identity):
        now = time.time()
        with self.lock:       # UPDATE-then-INSERT works on old SQLite versions too (no UPSERT needed)
            cur = self.cx.execute("UPDATE users SET last_login=? WHERE cluster_id=? AND identity=?", (now, cluster_id, identity))
            if cur.rowcount == 0:
                self.cx.execute("INSERT INTO users(cluster_id,identity,first_login,last_login) VALUES(?,?,?,?)", (cluster_id, identity, now, now))

    def last_login(self, cluster_id, identity):
        with self.lock:
            r = self.cx.execute("SELECT last_login FROM users WHERE cluster_id=? AND identity=?", (cluster_id, identity)).fetchone()
        return r[0] if r else None

    def set_last_login(self, cluster_id, identity, ts):      # used by tests / admin tooling
        with self.lock:
            self.cx.execute("UPDATE users SET last_login=? WHERE cluster_id=? AND identity=?", (ts, cluster_id, identity))

    def cluster_overrides(self):
        with self.lock:
            rows = self.cx.execute("SELECT cluster_id, enabled, changed_by, changed_at FROM cluster_state").fetchall()
        return {r[0]: {"enabled": bool(r[1]), "changed_by": r[2], "changed_at": r[3]} for r in rows}

    def set_cluster_enabled(self, cluster_id, enabled, by):
        with self.lock:
            self.cx.execute("INSERT OR REPLACE INTO cluster_state(cluster_id,enabled,changed_by,changed_at) VALUES(?,?,?,?)",
                            (cluster_id, 1 if enabled else 0, by, time.time()))

    def close(self):
        with self.lock:
            self.cx.close()
