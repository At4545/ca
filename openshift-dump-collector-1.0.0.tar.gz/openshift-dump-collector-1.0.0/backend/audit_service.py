"""Append-only JSON-lines audit log with size-based rotation.
Never receives tokens, passwords or dump contents (values are also redacted defensively)."""
import json
import os
import threading
import time

from .process import clean_text


class Audit(object):
    def __init__(self, path, max_bytes=20 * 1024 * 1024, backups=10):
        self.path = path
        self.max_bytes = max_bytes
        self.backups = backups
        self.lock = threading.Lock()
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)

    def _rotate(self):
        for i in range(self.backups - 1, 0, -1):
            src = "%s.%d" % (self.path, i)
            if os.path.exists(src):
                os.replace(src, "%s.%d" % (self.path, i + 1))
        os.replace(self.path, self.path + ".1")

    def log(self, event, user, **fields):
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event, "user": user}
        for k, v in fields.items():
            if v is None:
                continue
            rec[k] = clean_text(v, 300) if isinstance(v, str) else v
        line = (json.dumps(rec, sort_keys=True) + "\n").encode("utf-8")
        with self.lock:
            try:
                if os.path.getsize(self.path) + len(line) > self.max_bytes:
                    self._rotate()
            except OSError:
                pass
            fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
            try:
                os.write(fd, line)
            finally:
                os.close(fd)
