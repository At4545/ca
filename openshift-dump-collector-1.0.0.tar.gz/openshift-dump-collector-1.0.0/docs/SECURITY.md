# Security notes

## Data flow
Browser -(JSON over loopback/SSH tunnel)-> portal process -(`oc` CLI as the user)-> cluster API / `oc exec` into the pod -> files in `storage/dumps/` -> authenticated download.
The browser never runs cluster commands and never receives any token, kubeconfig, or credentials from `clusters.json`.

## How a user token is handled
1. Typed into a password field; sent once as JSON to `POST /api/auth/login` (never in a URL, never in browser storage; the field is cleared on success).
2. Format-checked (`sha256~` + URL-safe characters, i.e. OpenShift user OAuth tokens only), then verified by `oc whoami` against the **configured** API URL. The identity comes from the cluster. `system:*` identities (service accounts etc.) are rejected.
3. Held **only in the portal process's memory**, inside a session identified by a random 256-bit cookie (`HttpOnly`, `SameSite=Strict`).
4. To run `oc`, the portal writes a one-off kubeconfig (JSON) into a **0700 directory on tmpfs** with mode **0600**, passes only its *path* in `KUBECONFIG`, and deletes it (after overwriting with zeros) when the call or job ends.
   `oc`'s cache directory is redirected into the same folder. The server's own `KUBECONFIG` is never inherited.
5. **Never**: in command-line arguments (`ps`), environment variables, log files, audit log, SQLite, dump files, HTTP responses, or error messages (output is redacted - `sha256~…`, JWTs, `Bearer …`, `password=…`).
6. Ends on sign-out/disconnect (running jobs are cancelled), after the idle limit (running jobs keep it alive) or at the 8 h cap, or when the cluster rejects it (then dropped immediately). A running job finishes with its own copy even after the session cap.

The test suite checks (3)-(5) automatically: the simulated `oc` records any token in argv/env and any kubeconfig with the wrong mode, and tests scan every file the server wrote for token text.

## Authorisation model
* Everything the portal does on a cluster is done **as the user** - namespaces, pods, exec. The portal adds no privileges and has no service credentials.
* A job belongs to *(cluster, identity-reported-by-the-cluster)*. A session sees, downloads, cancels or deletes only jobs whose pair it is currently connected as; others get a 404 (existence is not revealed).
* The same person with the same token in another browser sees the same jobs; a different cluster's identity with the same username does not.
* PROD: server-enforced confirmation; heap dumps also need the typed cluster name; TCP capture is off for PROD unless enabled, and must be narrowed.
* Enable/disable of clusters: only `cluster-id:identity` pairs listed in `ADMIN_USERS` (none by default). It only affects the portal, never the cluster.

## Threat model
| Threat | Control | Residual risk |
|---|---|---|
| Token theft via browser | Never stored/echoed; password field; `HttpOnly` cookie; CSP forbids inline script/style; DOM built without `innerHTML` | Browser extensions/malware on the workstation |
| Token on the wire | Loopback only (refuses other binds); SSH tunnel; cluster TLS verified by default | **No TLS to the portal** (loopback only). Clusters marked `tls_verify:false` can be impersonated |
| Token read from server | Memory/tmpfs only; 0600/0700; `PR_SET_DUMPABLE=0`, no core dumps; scrub on delete | `root` and the OS account running the portal can read process memory; tmpfs/memory may be swapped (use encrypted swap); Python strings are not wipeable |
| Other local OS users | Loopback port still reachable, but every action needs the caller's own token | Run one instance per admin / dedicated account |
| Cross-user data access | Ownership by (cluster, identity); 404 on others' jobs; server-generated file names; path-traversal-proof storage | A bug in one shared process could mix sessions - covered by tests, not by isolation |
| CSRF / DNS rebinding | JSON-only POST, same-origin `Origin` check, `SameSite=Strict`, `Host` allow-list | - |
| Command injection | Argument lists only (no shell); strict regexes for cluster/namespace/pod/container; fixed filter presets; IPs via `ipaddress`; fixed in-container script with no interpolation | The in-container probe uses `sh -c` with a **fixed** script |
| Brute force / token guessing | Cluster-side validation; throttle of 10 failures/min | Shared limit can be used to lock others out briefly |
| Resource abuse | Concurrency, per-user job limit, one heap dump at a time, quotas, size/time/packet caps, free-space checks | - |
| Sensitive data in dumps | 0600/0700 files, owner-only download, retention, delete button, heap/payload warnings and acknowledgements, audit trail | Dumps contain secrets by nature; users must handle downloads securely |
| Production impact | Pre-checks, confirmations, bounded durations, cleanup of remote files | Heap dumps pause the JVM; capture adds CPU - cannot be zero-risk |
| Privilege escalation in clusters | None attempted: no privileged pods, no SCC/RBAC changes, no node access, no installs | TCP/heap only work where the workload already permits |
| Tampering with audit | Append-only open flags, 0600, rotation | A privileged local user can edit files; forward to central logging if required |

## Not provided (by design or not yet)
TLS termination, SSO/OIDC, portal-level RBAC beyond the admin list, encryption of dump files at rest (use an encrypted filesystem), central log forwarding, malware scanning of uploads (there are none).

## Review checklist for your security team
- [ ] Confirm loopback + SSH tunnel is acceptable, or choose an approved TLS/SSO front end.
- [ ] Decide on `purge-on-logout`, retention days and quotas for heap dumps (sensitive data at rest).
- [ ] Decide whether PROD may be added to `TCP_ENVS`, and approve the filter presets in `diagnostics/tcp_dump.py`.
- [ ] Review the single fixed in-container script (`DETECT_SCRIPT` in `diagnostics/thread_dump.py`) and the list of commands run via `oc exec` (jcmd/jstack/jmap/tcpdump/timeout/wc/cat/rm).
- [ ] Confirm swap/disk encryption policy for the jump server (tokens in memory/tmpfs).
- [ ] Run the "First real-cluster validation" in the Admin Guide, especially steps 4, 6, 9 and 10.
- [ ] Rotate and remove the credentials found in `clusters.json`.
