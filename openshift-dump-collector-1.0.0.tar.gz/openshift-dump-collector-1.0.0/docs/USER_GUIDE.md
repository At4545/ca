# User guide

## 1. Connect to a cluster
The portal acts as **you**, so it needs your own OpenShift token for each cluster.
1. Log in to the cluster's web console. Click your name (top right) > **Copy login command** > **Display Token**.
2. Copy the value after `--token=` (it starts with `sha256~`). Alternatively, where you are already logged in with `oc`, run `oc whoami -t`.
3. In the portal choose the cluster (Collect Dump page, Dashboard or Clusters page), click **Connect**, paste the token, press **Connect**.

The header then shows `cluster · your-username`. Connect separately to each cluster you need (DEV, TEST, PROD tokens are different).
* Only **user** tokens work. Service-account tokens (long `eyJ...` strings) and `system:` identities are refused.
* Your token is sent once, held only in the server's memory and never saved. It is discarded when you click **Sign out** (or the `×` on one cluster)
  or after **30 minutes without activity**. A running job keeps your session alive until it finishes.
* OpenShift tokens also expire on the cluster (often after 24 hours). If a call says the cluster rejected your token, get a fresh one and reconnect.

## 2. Collect a dump
**Collect Dump** page: Environment > Cluster > Namespace > Pod > Container > Dump Type, then **Validate Request** (optional but recommended) and **Collect Dump**.
* Namespaces and pods shown are the ones **your token** may access. Only *Running* pods can be chosen.
* **Validate Request** runs the same checks a real collection runs (identity, access, exec permission, container, tools, space/quota) and tells you what is wrong.
* **Cancel Collection** stops a running job and removes partial files. **Reset Form** clears the form.
* Progress shows the **stage** (e.g. "Capturing: 20s of 60s elapsed", "Transferring 800 of 1500 MB"). There are no made-up percentages.
* On **PROD** you get a confirmation dialog. For **heap dumps on PROD you must also type the cluster name**.

### Thread dump
Takes 1-10 JVM thread dumps, N seconds apart, into one text file. Needs `jcmd` or `jstack` in the container image and exactly one Java process. Briefly pauses the JVM each time.

### Heap dump  (use with care)
Writes a file the size of the live heap into the container's `/tmp`, copies it here, then deletes it from the container.
* **Risks:** the JVM pauses (a full GC runs by default), memory and disk are used, and the file contains **everything that was in memory - passwords, tokens, personal data**. Handle it accordingly.
* The portal estimates the size first and refuses if the container's `/tmp`, your size limit, your storage quota or this server's disk cannot hold it.
  If it refuses with "Estimated dump size ... above your size limit", raise the limit (up to the server maximum shown in the form).
* One heap dump runs at a time on the portal. If the final message says **ACTION NEEDED**, the temporary file could not be deleted from the container - remove the named file manually.

### TCP capture
Runs the `tcpdump` that already exists **inside the container**; the portal never installs tools or starts privileged pods.
* Duration 5-300 s. Filter is chosen from a fixed list (all / tcp / dns / http / tls / one port) plus an optional peer IP.
* Default is **headers only** (first 128 bytes of each packet). Full packets can contain credentials and need an explicit tick-box.
* On ordinary OpenShift pods this will often be refused: the container needs `tcpdump` **and** the `NET_RAW` capability. That is expected; ask the platform team for a capture-enabled workload.
* PROD captures must be narrowed (a filter other than "all", or a peer IP).
* A capture with **0 packets** is valid: nothing matched the filter during the window.

## 3. Download, keep, delete
* **Download Result** appears when a job completes. Open pcap files with Wireshark; hprof files with Eclipse MAT or VisualVM; thread dumps with any text viewer.
* Only **you** can see or download your files (identified by the username the cluster reports for your token).
* **Retention:** results stay available after you sign out and are there again when you reconnect with the same identity. They are deleted
  *N days after your last login* (the History page shows N), or immediately when you sign out if the administrator enabled "purge on logout". Use **Delete file** to remove one earlier and free your quota.

## 4. Common messages
| Message | Meaning / what to do |
|---|---|
| "does not look like an OpenShift user OAuth token" | Wrong kind of token; use the console "Display Token" value (starts `sha256~`). |
| "the cluster rejected your token" | Expired or revoked. Get a new token, Reconnect. |
| "Only OpenShift user OAuth tokens are accepted" | You pasted a service-account/system token. |
| "TLS certificate is not trusted by this server" | The jump server does not trust that cluster's certificate. Tell your admin (see Admin Guide). |
| "Not connected to this cluster" | Your session ended (idle/sign-out). Connect again. |
| "access denied ... lacks permission" | Your OpenShift account is not allowed that action (e.g. list pods, or `pods/exec`). Ask the project admin. |
| "Neither jcmd nor jstack was found" | The image is JRE-only. Use an image with JDK tools. |
| "refused the attach request" | JVM attach disabled, or the exec user differs from the JVM user. |
| "not permitted to capture packets" / "tcpdump was not found" | See TCP capture above. |
| "Storage quota" | Delete older results, or ask the admin to raise the quota. |
| "already active for this container" | Another job is running on that container; wait or cancel it. |
