# Administrator guide

## 1. Requirements (all already on your jump server except possibly `oc`)
| Need | Detail |
|---|---|
| OS | RHEL (any with a recent systemd/tmpfs); SELinux is not changed by the portal |
| Python | 3.9 or newer, **standard library only** (uses `sqlite3`, `http.server`, `subprocess`, ...) |
| `oc` CLI | In `PATH` of the user running the portal (from your approved internal mirror). The portal never uses that user's own `oc login` |
| `/dev/shm` | tmpfs, writable. Holds the short-lived kubeconfig files that carry users' tokens (or set `RUNTIME_DIR`) |
| Disk | Room for dumps. Heap dumps can be several GB; defaults: 20 GB per user, 50 GB total, 500 MB always left free |
| Network | The jump server must reach each cluster's API (HTTPS). Proxy variables (`HTTPS_PROXY`, `NO_PROXY`) are passed to `oc` |
| Not needed | pip packages, Node.js, nginx/httpd, Ansible, root/sudo |

`python3 scripts/discover_env.py` checks all of this read-only and prints a PROBLEM line for anything blocking.

## 2. Install
```bash
./deploy/install.sh --prefix ~/openshift-dump-collector [--with-user-service] [--dry-run]
```
Copies the files, creates `storage/` and `logs/` (mode 700), creates `portal.conf` from the example (mode 600). It does not install
packages, use sudo, start anything, or overwrite an existing `clusters.json`/`portal.conf`. Re-running it keeps a rollback copy of the previous code.

## 3. Configuration
### clusters.json
The portal reads only: cluster **name**, **environment** (DEV/TEST/PROD), **API URL**, **enabled**, and an optional **`"tls_verify": false`**.
Field-name variants are accepted (`environment`/`env`, `api_url`/`url`/`server`, ...). **Everything else, including any credentials section, is ignored: the file is parsed as JSON, but those values are never copied out,
stored, logged, sent to the browser or used to log in; only a count of credential-like fields is reported** (the startup log warns - remove them and rotate those passwords).

### portal.conf (read by `run.sh`; see `deploy/portal.conf.example`)
| Setting | Default | Meaning |
|---|---|---|
| `PORT` | 8080 | Loopback port |
| `IDLE_MINUTES` | 30 | Session idle limit. A running job keeps its owner's session alive. Hard cap 8 h |
| `RETENTION_DAYS` | 7 | Results are deleted this long after the owner's **last login** (or job completion if later) |
| `PURGE_ON_LOGOUT` | 0 | 1 = delete a user's results the moment their session/connection ends |
| `USER_QUOTA_MB` / `TOTAL_QUOTA_MB` | 20480 / 51200 | Stored results per user per cluster / overall |
| `HEAP_MAX_MB` | 8192 | Largest heap-dump limit a user may request |
| `MAX_CONCURRENT`, `MAX_USER_JOBS` | 2, 3 | Jobs running at once; active jobs per user per cluster. One heap dump at a time is fixed |
| `TCP_ENVS` | DEV,TEST | Where TCP capture is allowed. **PROD is opt-in** |
| `ADMIN_USERS` | (empty) | `cluster-id:identity` pairs that may enable/disable clusters; empty = nobody |
| `INSECURE_TLS_CLUSTERS` | (empty) | Cluster ids whose certificate is **not verified** (see below) |
| `RUNTIME_DIR` | /dev/shm/openshift-dump-collector-UID | Where temporary kubeconfig files live |

### Cluster TLS certificates
By default the portal **verifies** each cluster's certificate using the jump server's trust store (same as `oc`). Sending a bearer token over an
unverified connection lets anyone who can impersonate the API server capture it, so skipping verification is **per cluster and opt-in**, never global:
* preferred fix: add the cluster CA to the system trust store (`update-ca-trust`);
* otherwise mark just that cluster `"tls_verify": false` in `clusters.json` or list it in `INSECURE_TLS_CLUSTERS`. It is logged at startup, audited on every login,
  and shown as **TLS verify OFF** in the UI and in the connect dialog.

## 4. Running it
* By hand: `./run.sh` (stop with Ctrl-C). As a service: `./deploy/install.sh --with-user-service`, review the unit, then
  `systemctl --user daemon-reload && systemctl --user enable --now openshift-dump-collector` (`loginctl enable-linger $USER` to survive logout).
* **Access:** loopback only (`127.0.0.1`); the server refuses any other bind. From a workstation: `ssh -L 8080:127.0.0.1:8080 <jump-server>`.
* **Shared jump server:** every local OS user can reach a loopback port, and the OS account running the portal can read its memory. Prefer **one instance per admin**
  (own OS account, own port), or a dedicated service account that only your admins can SSH into. Users still need their own cluster tokens either way.
* There is no TLS/SSO inside the portal. If you later need direct browser access, put an approved TLS/SSO front end in front of it (needs installation approval).

## 5. Operation
* **Logs** (`logs/`): `app.log` (10 MB x 5 rotated) and `audit.log` (20 MB x 10 rotated). Audit events: `login_success`, `login_failed`, `logout`, `session_ended`,
  `validate`, `job_requested` (options, confirmations, TLS state), `job_started` (exact tcpdump filter), `job_completed/failed/cancelled`, `cancel_requested`, `file_download`,
  `file_deleted/expired`, `cluster_toggle`. They never contain tokens, passwords or dump contents.
* **Data:** `storage/portal.db` (SQLite: job history, last-login times, cluster on/off overrides; no secrets) and `storage/dumps/`. Both mode 600/700.
  Back up `portal.db` if you need history to survive disk loss; dumps are transient by design.
* **Retention & purge:** housekeeping runs every 15 s. A completed result expires `RETENTION_DAYS` after its owner's last login, or at once if its file goes missing.
  Users can delete their own files. Quotas are enforced before a job starts.
* **Restarts:** all sessions end (tokens lived only in memory), jobs that were running are marked Failed, partial files are removed, kubeconfigs in the runtime dir are purged.
  Users reconnect and find their completed results.
* **Heap-dump safeguards:** needs `jcmd`/`jmap` and a writable `/tmp` in the container; estimates size from `GC.heap_info`; requires size x 1.25 free in the container's `/tmp`, under the user's limit,
  within quota and with disk to spare here; verifies bytes received equal the remote size and the HPROF header; always deletes the remote file (two attempts) and says **ACTION NEEDED** if it cannot.

## 6. First real-cluster validation (do this on DEV before wider use)
The code was written against documented `oc` behaviour and a simulator, not a live cluster. Check, in order:
1. `python3 scripts/discover_env.py ...` reports no problems; `./run.sh` starts and logs the `clusters.json` warning if credentials are present.
2. Dashboard shows each cluster's real reachability. A cluster showing "Certificate not trusted" needs the CA (or an explicit `tls_verify:false`).
3. Connect to DEV with your own token. The header shows your username. Namespaces match `oc get projects` as you.
4. Connect with a *different* user's token in a second browser profile: different namespaces, and neither sees the other's jobs.
5. Thread dump on a test Java pod: Validate, collect 1 then 3, download, confirm `Full thread dump` sections; cancel one and confirm no `.part` file remains in `storage/dumps`.
6. While a job is running, `ps aux | grep oc` must **not** show your token anywhere; `ls /dev/shm/openshift-dump-collector-*` shows a `kc-*` folder only while a call/job is active.
7. Heap dump on a **small** non-production app with a low limit: confirm the file opens in a heap analyser and that `/tmp/portal-heap-*.hprof` is gone from the container afterwards. Try a limit that is too low and confirm the refusal.
8. TCP capture on a pod you know has `tcpdump` + `NET_RAW`; on an ordinary pod expect a clear refusal. After cancelling a capture confirm no `tcpdump` process lingers once the duration passes.
9. Sign out: your chips disappear, `/dev/shm/...` is empty, History is empty until you reconnect. Wait out the idle limit and confirm the next action asks you to reconnect.
10. Review `logs/audit.log` for the events above and `grep -r 'sha256~' logs storage` returns nothing.

## 7. Troubleshooting
| Symptom | Likely cause | Fix |
|---|---|---|
| Startup: "Runtime directory ... must be owned by the current user" | Stale/foreign directory | Remove it or set `RUNTIME_DIR` |
| Startup: "/dev/shm ... not available" | No tmpfs | Set `RUNTIME_DIR` to a tmpfs directory |
| "oc CLI NOT FOUND on server" badge | `oc` not in the service's `PATH` | Add it to `PATH` or set `OC_PATH` in `portal.conf` |
| Everyone gets "TLS certificate is not trusted" | Cluster CA not in system trust | Add CA, or per-cluster `tls_verify:false` |
| Connectivity shows Unreachable/Timed out | Firewall/proxy/DNS from the jump server | Test `oc get --raw=/version --server=<url>` by hand; set `HTTPS_PROXY` |
| Connectivity "Reachable" but login fails | Token wrong/expired, or cluster uses a different OAuth flow | Use the console "Display Token" value |
| "Too many failed connection attempts" | 10 failed logins in a minute (all users share the limit) | Wait a minute |
| Users logged out unexpectedly | Idle limit, server restart, or the cluster revoked the token | Reconnect; adjust `IDLE_MINUTES` |
| Namespace list empty / "access denied" | User cannot `list projects` | Ask the cluster admin for access |
| Jobs fail at "Exec permission" | User lacks `create pods/exec` in that namespace | Grant the standard RBAC |
| Heap: "has N MB free" | Container `/tmp` too small | Use another pod or a bigger `emptyDir`; do not raise limits blindly |
| Heap/TCP/thread tool errors | Image lacks JDK tools / tcpdump / `NET_RAW` | Use a suitable image or an approved platform method |
| `ACTION NEEDED` note | Remote temp file could not be deleted | `oc exec` in and `rm` the named `/tmp/portal-heap-*.hprof` |
| Results disappeared | Retention elapsed, owner deleted them, or purge-on-logout is on | Check `audit.log` for `file_deleted` |

## 8. Upgrade, rollback, uninstall
* **Upgrade:** stop the portal, run the new `install.sh` against the same prefix (code is replaced; `portal.conf`, `clusters.json`, `storage/`, `logs/` are kept; a `*.backup-<date>` folder keeps the old code), start it.
* **Rollback:** stop the portal, copy the contents of the newest `*.backup-*` folder over the install directory, start it. The SQLite schema only gains tables; older code ignores them.
* **Uninstall:** `systemctl --user disable --now openshift-dump-collector`, delete the install directory and `~/.config/systemd/user/openshift-dump-collector.service`. Dump files are in `storage/dumps/` - delete deliberately; they may contain sensitive data.

## 9. Known limitations
* Not yet exercised on a real cluster, real JVMs, Python 3.9 or systemd (see section 6).
* No TLS/SSO in the portal (loopback + SSH tunnel by design). Admin rights are by `cluster-id:username` string.
* Heap transfer uses `oc exec ... cat`: multi-GB files can be slow and cannot resume; a dropped connection fails the job and cleans up.
* A killed `oc exec` cannot always stop the in-container process instantly; remote work is bounded by the remote `timeout` (TCP) and cleanup (heap). Verify with validation step 8.
* One JVM per container; the exec user must be able to attach to it.
* Quotas count completed results only; in-flight jobs reserve space per job at start.
