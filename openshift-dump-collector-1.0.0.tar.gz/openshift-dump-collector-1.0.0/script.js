/* OpenShift Dump Collector - frontend (v1.0).
 * Talks only to the portal's own JSON API. Users connect to each cluster with THEIR OWN OpenShift token
 * (typed into a password field, sent once, never stored in the browser: no localStorage/cookies/URL).
 * Never builds or sends commands. All DOM is built with textContent/createElement (no innerHTML with data).
 */
(function () {
  'use strict';

  var ENVS = ['DEV', 'TEST', 'PROD'];
  var DUMP_TYPES = [{ id: 'thread', label: 'Thread Dump' }, { id: 'heap', label: 'Heap Dump' }, { id: 'tcp', label: 'TCP Dump' }];
  /* Must mirror FILTER_PRESETS in diagnostics/tcp_dump.py; the server is the authority. */
  var TCP_FILTERS = [
    { id: 'all', label: 'All traffic (not allowed on PROD without a peer IP)' }, { id: 'tcp', label: 'TCP only' },
    { id: 'dns', label: 'DNS (port 53)' }, { id: 'web', label: 'HTTP (ports 80 / 8080)' },
    { id: 'tls', label: 'TLS (ports 443 / 8443)' }, { id: 'port', label: 'TCP on one specific port...' }
  ];
  var PAYLOADS = [
    { id: 'headers', label: 'Headers only - first 128 bytes per packet (recommended)' },
    { id: 'full', label: 'Full packets (may contain credentials / personal data)' }
  ];
  var STATUS_CLS = { Pending: 'b-grey', Validating: 'b-info', Running: 'b-info', Completed: 'b-ok', Failed: 'b-bad', Cancelled: 'b-warn', Expired: 'b-grey' };
  var CONN_CLS = { reachable: 'b-ok', tls_error: 'b-bad', unreachable: 'b-bad', timeout: 'b-bad', error: 'b-bad' };
  var CONN_TXT = { reachable: 'Reachable', tls_error: 'Certificate not trusted', unreachable: 'Unreachable', timeout: 'Timed out', error: 'Error' };
  var LIM = { thread: { size: [1, 50, 50], timeout: [30, 1800, 300] }, tcp: { size: [1, 500, 100], timeout: [30, 1800, 300] }, heap: { size: [1, 8192, 4096], timeout: [120, 7200, 1800] } };
  var TCP_MARGIN = 20;
  var RECONNECT = ['not_connected', 'no_session', 'token_rejected'];

  var state = { clusters: [], loadError: null, jobs: [], me: null, session: { connected: [], admin: false, expires_in: null }, selectedJob: null,
    collect: {}, hist: { q: '', env: '', status: '', type: '' }, updatePanel: null, checking: false };
  var poll = { timer: null };

  /* ---------- helpers ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    var a = attrs || {};
    Object.keys(a).forEach(function (k) {
      var v = a[k];
      if (v === false || v === null || v === undefined) return;
      if (k === 'class') el.className = v;
      else if (k.indexOf('on') === 0) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, String(v));
    });
    Array.prototype.slice.call(arguments, 2).forEach(function add(kid) {
      if (Array.isArray(kid)) return kid.forEach(add);
      if (kid === null || kid === undefined || kid === false) return;
      el.appendChild(kid.nodeType ? kid : document.createTextNode(String(kid)));
    });
    return el;
  }
  function clearEl(el) { while (el.firstChild) el.removeChild(el.firstChild); }
  function badge(text, cls) { return h('span', { class: 'badge ' + cls }, text); }
  function envBadge(env) { return badge(env, 'b-' + (ENVS.indexOf(env) >= 0 ? env : 'grey')); }
  function statusBadge(s) { return badge(s, STATUS_CLS[s] || 'b-grey'); }
  function fmtDate(ts) { return ts ? new Date(ts * 1000).toLocaleString() : '-'; }
  function fmtDur(s) { if (s === null || s === undefined) return '-'; s = Math.round(s); return s >= 60 ? Math.floor(s / 60) + 'm ' + (s % 60) + 's' : s + 's'; }
  function fmtSize(b) {
    if (b === null || b === undefined) return '-';
    if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
    if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB';
    if (b >= 1024) return (b / 1024).toFixed(1) + ' KB';
    return b + ' B';
  }
  function typeLabel(id) { return id === 'thread' ? 'Thread Dump' : id === 'heap' ? 'Heap Dump' : id === 'tcp' ? 'TCP Dump' : id; }
  function filterLabel(id) { var f = TCP_FILTERS.filter(function (x) { return x.id === id; })[0]; return f ? f.label.split(' (')[0] : id; }
  function optsText(j) {
    var o = j.options || {};
    if (j.dump_type === 'tcp') return o.duration + ' s, filter: ' + filterLabel(o.filter) + (o.filter === 'port' ? ' ' + o.port : '') + (o.peer_ip ? ', peer ' + o.peer_ip : '') + ', ' + (o.payload === 'full' ? 'FULL packets' : 'headers only');
    if (j.dump_type === 'thread') return o.count + ' dump(s), ' + o.interval + ' s apart';
    if (j.dump_type === 'heap') return 'size limit ' + o.size_limit_mb + ' MB, timeout ' + o.timeout + ' s';
    return '-';
  }
  function toast(msg) {
    var t = document.getElementById('toast'); t.textContent = msg; t.className = 'show';
    clearTimeout(toast.t); toast.t = setTimeout(function () { t.className = ''; }, 5000);
  }
  function clusterById(id) { return state.clusters.filter(function (c) { return c.id === id; })[0]; }
  function jobById(id) { return state.jobs.filter(function (j) { return j.id === id; })[0]; }
  function connection(cid) { return state.session.connected.filter(function (c) { return c.cluster_id === cid; })[0]; }
  function route() { var r = location.hash.replace(/^#\//, '') || 'dashboard'; return ROUTES[r] ? r : 'dashboard'; }
  function errText(e) { return e.message + (e.details ? ' ' + Object.keys(e.details).map(function (k) { return k + ': ' + e.details[k]; }).join('; ') : ''); }

  function api(method, path, body) {
    var opts = { method: method, headers: { Accept: 'application/json' }, credentials: 'same-origin' };
    if (method === 'POST') { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body || {}); }
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (b) {
        if (!r.ok) {
          var e = new Error(b.error || ('HTTP ' + r.status)); e.details = b.details; e.status = r.status; e.reason = b.reason;
          if (RECONNECT.indexOf(b.reason) >= 0) refreshSession(true);
          throw e;
        }
        return b;
      });
    });
  }

  /* ---------- data ---------- */
  function loadClusters() {
    return api('GET', '/api/clusters').then(function (b) { state.clusters = b.clusters || []; state.loadError = null; })
      .catch(function (e) { state.clusters = []; state.loadError = e.message; });
  }
  function loadJobs() { return api('GET', '/api/jobs').then(function (b) { state.jobs = b.jobs || []; }); }
  function anyActive() { return state.jobs.some(function (j) { return j.active; }); }
  function refreshSession(announce) {
    var before = state.session.connected.length;
    return api('GET', '/api/session').then(function (s) {
      state.session = s; renderWho();
      if (announce && s.connected.length < before) toast('A connection ended (signed out, idle, or the cluster rejected your token). Connect again to continue.');
      return loadClusters().then(function () { if (route() === 'clusters' || route() === 'dashboard') render(); else if (route() === 'collect' && state.sessionHook) state.sessionHook(); });
    }).catch(function () { });
  }
  function startPolling() {
    if (poll.timer) return;
    poll.timer = setInterval(function () {
      loadJobs().then(function () {
        var r = route();
        if (r === 'progress' || r === 'dashboard') render(); else if (r === 'collect' && state.updatePanel) state.updatePanel();
        if (!anyActive()) { clearInterval(poll.timer); poll.timer = null; }
      }).catch(function () { });
    }, 2000);
  }
  setInterval(function () { refreshSession(true); }, 20000);       /* detects idle expiry; does not keep the session alive */

  /* ---------- header: who am I connected as ---------- */
  function renderWho() {
    var who = document.getElementById('who'); clearEl(who);
    if (state.me && !state.me.oc_available) who.appendChild(badge('oc CLI NOT FOUND on server', 'b-bad'));
    state.session.connected.forEach(function (c) {
      who.appendChild(h('span', { class: 'chip', title: 'Connected to ' + c.cluster }, c.cluster + ' \u00B7 ' + c.identity,
        h('button', { type: 'button', 'aria-label': 'Disconnect from ' + c.cluster, title: 'Disconnect (cancels your running jobs on this cluster)', onclick: function () { disconnect(c.cluster_id); } }, '\u00D7')));
    });
    if (state.session.connected.length) who.appendChild(h('button', { type: 'button', class: 'signout', onclick: signOut }, 'Sign out'));
    else who.appendChild(document.createTextNode('Not connected to any cluster'));
  }
  function disconnect(cid) {
    api('POST', '/api/auth/logout', { cluster: cid }).then(function (s) { state.session = s; renderWho(); state.jobs = []; return loadJobs(); }).then(function () { toast('Disconnected.'); return loadClusters(); }).then(render).catch(function (e) { toast(e.message); });
  }
  function signOut() {
    api('POST', '/api/auth/logout', {}).then(function (s) { state.session = s; renderWho(); state.jobs = []; state.selectedJob = null; toast('Signed out. Your token was discarded.'); return loadClusters(); }).then(render).catch(function (e) { toast(e.message); });
  }

  /* ---------- connect dialog (token entry) ---------- */
  function openConnect(clusterId, done) {
    var c = clusterById(clusterId); if (!c) return;
    var dlg = document.getElementById('connect'); clearEl(dlg);
    var input = h('input', { type: 'password', id: 'tokenInput', autocomplete: 'off', spellcheck: 'false', placeholder: 'sha256~...', 'aria-label': 'OpenShift token' });
    var err = h('div', { class: 'err-box', hidden: true });
    var btn = h('button', { type: 'button', class: 'primary', id: 'bConnect' }, 'Connect');
    function close() { input.value = ''; dlg.close(); }
    function go() {
      var t = input.value.trim(); if (!t) { err.hidden = false; err.textContent = 'Paste your token first.'; return; }
      btn.disabled = true; btn.textContent = 'Connecting...'; err.hidden = true;
      api('POST', '/api/auth/login', { cluster: c.id, token: t }).then(function (s) {
        input.value = ''; state.session = s; renderWho(); dlg.close(); toast('Connected to ' + c.name + ' as ' + (connection(c.id) || {}).identity + '.');
        return Promise.all([loadClusters(), loadJobs().catch(function () { })]).then(function () { if (done) done(); else render(); });
      }).catch(function (e) { btn.disabled = false; btn.textContent = 'Connect'; err.hidden = false; err.textContent = e.message; input.select(); });
    }
    btn.addEventListener('click', go);
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } });
    dlg.addEventListener('cancel', function () { input.value = ''; });
    dlg.appendChild(h('h2', null, 'Connect to ', c.name, ' ', envBadge(c.environment)));
    dlg.appendChild(h('p', { class: 'muted' }, 'API endpoint: ' + c.api_url));
    if (!c.tls_verify) dlg.appendChild(h('div', { class: 'warn-box' }, 'TLS certificate verification is switched OFF for this cluster by the administrator. Your token could be intercepted by anyone able to impersonate the API server.'));
    dlg.appendChild(h('ol', { class: 'steps' },
      h('li', null, 'Log in to the OpenShift web console for this cluster.'),
      h('li', null, 'Click your name (top right) > ', h('strong', null, 'Copy login command'), ' > ', h('strong', null, 'Display Token'), '.'),
      h('li', null, 'Copy the value after ', h('code', null, '--token='), ' (it starts with ', h('code', null, 'sha256~'), '). Or run ', h('code', null, 'oc whoami -t'), ' where you are already logged in to this cluster.')));
    dlg.appendChild(h('label', null, 'OpenShift token', input));
    dlg.appendChild(h('p', { class: 'muted' }, 'Sent once to this portal, kept only in its memory, never written to disk or logs. You act with your own permissions' +
      (state.me ? '. It is discarded when you sign out or after ' + Math.round(state.me.idle_seconds / 60) + ' minutes without activity.' : '.')));
    dlg.appendChild(err);
    dlg.appendChild(h('div', { class: 'actions' }, btn, h('button', { type: 'button', onclick: close }, 'Cancel')));
    dlg.showModal(); input.focus();
  }

  /* ---------- shared UI ---------- */
  function pageHead(title, sub) { return [h('h1', null, title), h('p', { class: 'sub' }, sub)]; }
  function loadErrorBox() { return state.loadError ? h('div', { class: 'err-box' }, 'Cluster configuration could not be loaded: ' + state.loadError) : null; }
  function connectBtn(c, small) {
    return h('button', { type: 'button', class: small ? 'small' : '', onclick: function () { openConnect(c.id); } }, connection(c.id) ? 'Reconnect' : 'Connect');
  }
  function downloadBtn(j) {
    return j && j.download_available ? h('a', { class: 'btn primary', href: '/api/jobs/' + encodeURIComponent(j.id) + '/download' }, 'Download Result')
      : h('button', { type: 'button', disabled: true, title: 'Available after a job completes' }, 'Download Result');
  }
  function deleteBtn(j, after) {
    if (!j || !j.download_available) return null;
    return h('button', { type: 'button', class: 'small', title: 'Delete the stored file now (frees your quota)', onclick: function () {
      if (!window.confirm('Delete the stored result file for job ' + j.id + '? This cannot be undone.')) return;
      api('POST', '/api/jobs/' + encodeURIComponent(j.id) + '/delete', {}).then(function () { toast('Result deleted.'); return loadJobs(); }).then(after || render).catch(function (e) { toast(e.message); });
    } }, 'Delete file');
  }
  function checksList(checks) {
    if (!checks || !checks.length) return null;
    return h('ul', { class: 'checks' }, checks.map(function (c) {
      var cls = c.skipped ? 'chk-skip' : c.ok ? 'chk-ok' : 'chk-bad';
      return h('li', null, h('span', { class: cls }, c.skipped ? '\u25CB ' : c.ok ? '\u2714 ' : '\u2718 '), h('span', { class: 'nm' }, c.name + ': '), c.message);
    }));
  }
  function connBadge(c) {
    var r = c.connectivity;
    if (state.checking && !r) return badge('Checking...', 'b-info');
    if (!r) return badge('Not checked', 'b-grey');
    return h('span', { title: r.note || '' }, badge(CONN_TXT[r.status] || r.status, CONN_CLS[r.status] || 'b-grey'), ' ', h('span', { class: 'muted' }, r.latency_ms + ' ms' + (r.version ? ' \u00B7 ' + r.version : '')));
  }
  function jobsTable(jobs) {
    var head = ['Job ID', 'Started', 'Env', 'Cluster', 'Type', 'Status', 'Size'];
    return h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, head.map(function (x) { return h('th', null, x); }))),
      h('tbody', null, jobs.length ? jobs.map(function (j) {
        return h('tr', null, h('td', null, j.id), h('td', null, fmtDate(j.created)), h('td', null, envBadge(j.env)), h('td', null, j.cluster), h('td', null, typeLabel(j.dump_type)), h('td', null, statusBadge(j.status)), h('td', null, fmtSize(j.size_bytes)));
      }) : h('tr', null, h('td', { colspan: head.length, class: 'muted' }, state.session.connected.length ? 'No collection jobs yet.' : 'Connect to a cluster to see your jobs.')))));
  }
  function runChecks(force) {
    state.checking = true;
    var req = force ? api('POST', '/api/clusters/' + force + '/check', {}) : api('POST', '/api/clusters/check', {});
    return req.then(function (b) { state.clusters = b.clusters; }).catch(function () { }).then(function () { state.checking = false; var r = route(); if (r === 'dashboard' || r === 'clusters') render(); });
  }

  /* ---------- Dashboard ---------- */
  function pageDashboard() {
    var enabled = state.clusters.filter(function (c) { return c.enabled; }).length;
    var ok = state.jobs.filter(function (j) { return j.status === 'Completed'; }).length;
    var bad = state.jobs.filter(function (j) { return j.status === 'Failed'; }).length;
    function stat(n, l) { return h('div', { class: 'card stat' }, h('div', { class: 'n' }, n), h('div', { class: 'l' }, l)); }
    var envCards = ENVS.concat(['UNKNOWN']).map(function (env) {
      var list = state.clusters.filter(function (c) { return (ENVS.indexOf(c.environment) >= 0 ? c.environment : 'UNKNOWN') === env; });
      if (env === 'UNKNOWN' && !list.length) return null;
      return h('div', { class: 'card' },
        h('div', { class: 'env-head' }, h('h2', null, env === 'UNKNOWN' ? 'Unrecognised environment' : env), badge(list.length + ' cluster' + (list.length === 1 ? '' : 's'), 'b-grey')),
        list.length ? list.map(function (c) {
          var conn = connection(c.id);
          return h('div', { class: 'cl' },
            h('div', null, h('span', { class: 'nm' }, c.name), ' ', badge(c.enabled ? 'Enabled' : 'Disabled', c.enabled ? 'b-ok' : 'b-grey'), ' ', c.tls_verify ? null : badge('TLS verify OFF', 'b-warn')),
            h('div', null, connBadge(c)),
            h('div', { class: 'url' }, c.api_url || '(no API URL configured)'),
            h('div', null, conn ? badge('Connected as ' + conn.identity, 'b-ok') : badge('Not connected', 'b-grey'), ' ', c.enabled ? connectBtn(c, true) : null));
        }) : h('div', { class: 'muted' }, 'No clusters configured.'));
    });
    return [pageHead('Dashboard', 'Cluster status is checked live. Job counts cover only the clusters you are connected to.'), loadErrorBox(),
      h('div', { class: 'grid stats' }, stat(state.clusters.length, 'Configured clusters'), stat(enabled, 'Enabled clusters'), stat(state.session.connected.length, 'Connected by you'),
        stat(ok, 'Your successful jobs'), stat(bad, 'Your failed jobs')),
      h('div', { class: 'actions' }, h('button', { type: 'button', onclick: function () { runChecks(); } }, 'Re-check connectivity')),
      h('div', { class: 'grid envs mt' }, envCards), h('h2', null, 'Your recent collection jobs'), jobsTable(state.jobs.slice(0, 5))];
  }

  /* ---------- Collect Dump ---------- */
  function field(labelText, control, hint, errId) { return h('label', null, labelText, control, hint ? h('small', null, hint) : null, h('span', { class: 'err', id: errId || '' })); }
  function fillSelect(sel, placeholder, items, selected, noBlank) {
    clearEl(sel);
    if (!noBlank) sel.appendChild(h('option', { value: '' }, placeholder));
    items.forEach(function (i) { sel.appendChild(h('option', { value: i.value, selected: i.value === selected, disabled: !!i.disabled }, i.label)); });
    sel.disabled = items.length === 0;
  }

  function pageCollect() {
    var prev = jobById(state.collect.jobId);
    var s = state.collect = { jobId: prev && prev.active ? prev.id : undefined };
    var f = {}, nsList = [], podList = [], seq = 0;
    var heapMax = (state.me && state.me.limits && state.me.limits.heap_max_mb) || 8192;
    function sel(id) { f[id] = h('select', { id: id }); return f[id]; }
    function num(id, d, lo, hi) { f[id] = h('input', { type: 'number', id: id, value: d, min: lo, max: hi, step: 1 }); return f[id]; }
    var summary = h('div', { class: 'info-box' }, 'Select an environment and cluster.');
    var connectBar = h('div', { class: 'warn-box', hidden: true });
    var discErr = h('div', { class: 'err-box', hidden: true });
    var result = h('div', { id: 'result' });
    var panel = h('div', { class: 'mt' });
    var typeBox = h('div', { id: 'typeOpts' });

    var form = h('form', { novalidate: true, onsubmit: function (e) { e.preventDefault(); } },
      h('div', { class: 'row' }, field('Environment', sel('env'), null, 'e_env'), field('Cluster', sel('cluster'), 'Enabled clusters in the selected environment', 'e_cluster')),
      summary, connectBar, discErr,
      h('div', { class: 'row' },
        field('Namespace', sel('ns'), 'Only namespaces YOUR token can access', 'e_ns'),
        field('Pod', sel('pod'), 'Readiness and status shown; only Running pods can be selected', 'e_pod'),
        field('Container', sel('container'), 'Multi-container pods supported', 'e_container'),
        field('Dump Type', sel('type'), null, 'e_type')),
      h('fieldset', null, h('legend', null, 'Advanced options'),
        h('div', { class: 'row' },
          field('Collection timeout (seconds)', num('timeout', 300, 30, 7200), 'Thread/TCP 30-1800; heap 120-7200', 'e_timeout'),
          field('Output file size limit (MB)', num('size', 50, 1, 500), 'Hard maximum enforced by the server', 'e_size'),
          field('Output location', h('input', { type: 'text', value: 'Managed by the backend', disabled: true }), 'Not user-selectable')),
        typeBox),
      h('div', { class: 'actions' },
        h('button', { type: 'button', onclick: onValidate }, 'Validate Request'),
        h('button', { type: 'button', class: 'primary', id: 'bCollect', onclick: onCollect }, 'Collect Dump'),
        h('button', { type: 'button', id: 'bCancel', disabled: true, onclick: onCancel }, 'Cancel Collection'),
        h('span', { id: 'dlslot' }, downloadBtn(null)),
        h('button', { type: 'button', onclick: function () { state.collect = {}; render(); } }, 'Reset Form')));

    var root = h('div', null, pageHead('Collect Dump', 'Choose a target and a diagnostic. Everything runs with your own OpenShift permissions and is re-validated on the server.'),
      loadErrorBox(), h('div', { class: 'card' }, form, result, panel));

    function v(id) { return f[id] ? f[id].value : ''; }
    function remember() { ['env', 'cluster', 'ns', 'pod', 'container', 'type'].forEach(function (k) { s[k] = v(k); }); }
    function showDisc(msg) { discErr.hidden = !msg; discErr.textContent = msg || ''; }
    function tcpEnvs() { return (state.me && state.me.tcp_envs) || []; }

    function refreshEnv() { fillSelect(f.env, 'Select environment', ENVS.map(function (e) { return { value: e, label: e }; }), s.env); }
    function refreshCluster() {
      var list = state.clusters.filter(function (c) { return c.enabled && c.environment === s.env; });
      fillSelect(f.cluster, s.env ? (list.length ? 'Select cluster' : 'No enabled clusters') : 'Select environment first', list.map(function (c) { return { value: c.id, label: c.name }; }), s.cluster);
      var c = clusterById(s.cluster); clearEl(summary); clearEl(connectBar); connectBar.hidden = true;
      if (c) {
        var conn = connection(c.id);
        summary.appendChild(h('div', null, h('strong', null, c.name), ' ', envBadge(c.environment), ' ', conn ? badge('Connected as ' + conn.identity, 'b-ok') : badge('Not connected', 'b-warn'), ' ', c.tls_verify ? null : badge('TLS verify OFF', 'b-warn')));
        summary.appendChild(h('div', { class: 'muted' }, 'API endpoint: ' + (c.api_url || '(none configured)')));
        if (!conn) { connectBar.hidden = false; connectBar.appendChild(document.createTextNode('You are not connected to this cluster. ')); connectBar.appendChild(h('button', { type: 'button', class: 'primary small', id: 'bOpenConnect', onclick: function () { openConnect(c.id, function () { refreshCluster(); loadNamespaces(); }); } }, 'Connect with your token')); }
      } else summary.appendChild(document.createTextNode('Select an environment and cluster.'));
    }
    function refreshNs() { fillSelect(f.ns, s.cluster ? (nsList.length ? 'Select namespace' : (connection(s.cluster) ? 'Loading...' : 'Connect first')) : 'Select cluster first', nsList.map(function (n) { return { value: n, label: n }; }), s.ns); }
    function refreshPod() {
      fillSelect(f.pod, s.ns ? (podList.length ? 'Select pod' : 'Loading...') : 'Select namespace first', podList.map(function (p) {
        return { value: p.name, label: p.name + '  [' + p.ready + ' ' + p.phase + ']', disabled: p.phase !== 'Running' };
      }), s.pod);
    }
    function refreshContainer() {
      var pod = podList.filter(function (p) { return p.name === s.pod; })[0];
      fillSelect(f.container, pod ? 'Select container' : 'Select pod first', pod ? pod.containers.map(function (c) { return { value: c.name, label: c.name + '  [' + c.state + ']' }; }) : [], s.container);
    }
    function refreshType() { fillSelect(f.type, 'Select dump type', DUMP_TYPES.map(function (t) { return { value: t.id, label: t.label }; }), s.type); }

    function refreshTypeOptions() {
      ['count', 'interval', 'duration', 'filter', 'port', 'peer', 'payload', 'cpay', 'hack'].forEach(function (k) { delete f[k]; });
      clearEl(typeBox);
      var t = s.type, lim = LIM[t];
      if (lim) {
        var max = t === 'heap' ? Math.min(lim.size[1], heapMax) : lim.size[1];
        f.size.min = lim.size[0]; f.size.max = max; f.size.value = Math.min(lim.size[2], max);
        f.timeout.min = lim.timeout[0]; f.timeout.max = lim.timeout[1]; f.timeout.value = lim.timeout[2];
      }
      if (t === 'thread') {
        typeBox.appendChild(h('fieldset', null, h('legend', null, 'Thread dump options'), h('div', { class: 'row' },
          field('Thread dumps to take', num('count', 3, 1, 10), '1-10', 'e_count'), field('Interval between dumps (seconds)', num('interval', 10, 1, 60), '1-60', 'e_interval'))));
      } else if (t === 'heap') {
        typeBox.appendChild(h('fieldset', null, h('legend', null, 'Heap dump safeguards'),
          h('div', { class: 'warn-box' }, h('strong', null, 'Read before continuing. '), 'A heap dump pauses the JVM (and by default runs a full GC), writes a file the size of the live heap into the container\'s /tmp first, then copies it here. ' +
            'It can use gigabytes of memory and disk and slow or destabilise the application. The file contains everything that was in memory, including passwords and personal data. ' +
            'The server checks free space first and refuses if the container or this server cannot hold it. Maximum limit on this server: ' + heapMax + ' MB. One heap dump runs at a time.'),
          h('label', { class: 'inline-label' }, (f.hack = h('input', { type: 'checkbox', id: 'hack' })), 'I understand the risks above and I am authorised to take and handle this dump.'),
          h('span', { class: 'err', id: 'e_hack' })));
      } else if (t === 'tcp') {
        var envOk = !s.env || tcpEnvs().indexOf(s.env) >= 0;
        var portLbl = field('Port', num('port', 8080, 1, 65535), '1-65535', 'e_port');
        var cpayLbl = h('label', { class: 'inline-label', id: 'cpayLbl', hidden: true }, (f.cpay = h('input', { type: 'checkbox', id: 'cpay' })), 'I understand full packets may contain credentials, tokens or personal data, and I am authorised to capture them.');
        typeBox.appendChild(h('fieldset', null, h('legend', null, 'TCP capture options'),
          envOk ? null : h('div', { class: 'warn-box' }, 'TCP capture is currently enabled only for: ' + (tcpEnvs().join(', ') || 'no environments') + '. The server will refuse other environments.'),
          h('div', { class: 'info-box' }, 'Uses a tcpdump that is already inside the selected container (no privileged pods, no installs). It refuses to run if the container lacks tcpdump or permission to capture. Captures are capped by duration, packet count and file size.'),
          h('div', { class: 'row' },
            field('Capture duration (seconds)', num('duration', 30, 5, 300), '5-300', 'e_duration'),
            field('Approved capture filter', sel('filter'), 'Fixed list; never free text', 'e_filter'), portLbl,
            field('Peer IP address (optional)', (f.peer = h('input', { type: 'text', id: 'peer', placeholder: 'e.g. 10.128.2.15', autocomplete: 'off', maxlength: 45 })), 'Only traffic to/from this address', 'e_peer'),
            field('Packet detail', sel('payload'), 'Headers only is the safe default', 'e_payload')), cpayLbl));
        fillSelect(f.filter, '', TCP_FILTERS.map(function (x) { return { value: x.id, label: x.label }; }), 'all', true);
        fillSelect(f.payload, '', PAYLOADS.map(function (x) { return { value: x.id, label: x.label }; }), 'headers', true);
        var sync = function () { portLbl.hidden = f.filter.value !== 'port'; cpayLbl.hidden = f.payload.value !== 'full'; };
        f.filter.addEventListener('change', sync); f.payload.addEventListener('change', sync); sync();
      } else typeBox.appendChild(h('div', { class: 'muted' }, 'Select a dump type to see its options.'));
    }

    function loadNamespaces() {
      var my = ++seq; nsList = []; podList = []; refreshNs(); refreshPod(); refreshContainer(); showDisc('');
      if (!s.cluster || !connection(s.cluster)) return;
      api('GET', '/api/clusters/' + encodeURIComponent(s.cluster) + '/namespaces').then(function (b) {
        if (my !== seq) return; nsList = b.namespaces; refreshNs();
        if (!nsList.length) { f.ns.options[0].textContent = 'No accessible namespaces'; f.ns.disabled = true; }
      }).catch(function (e) { if (my !== seq) return; refreshNs(); f.ns.options[0].textContent = 'Unavailable'; f.ns.disabled = true; showDisc(e.message); refreshCluster(); });
    }
    function loadPods() {
      var my = ++seq; podList = []; refreshPod(); refreshContainer(); showDisc('');
      if (!s.ns) return;
      api('GET', '/api/clusters/' + encodeURIComponent(s.cluster) + '/namespaces/' + encodeURIComponent(s.ns) + '/pods').then(function (b) {
        if (my !== seq) return; podList = b.pods; refreshPod();
        if (!podList.length) { f.pod.options[0].textContent = 'No pods in this namespace'; f.pod.disabled = true; }
      }).catch(function (e) { if (my !== seq) return; refreshPod(); f.pod.options[0].textContent = 'Unavailable'; f.pod.disabled = true; showDisc(e.message); });
    }

    f.env.addEventListener('change', function () { var t = s.type; remember(); s.cluster = s.ns = s.pod = s.container = ''; nsList = []; podList = []; seq++; refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); showDisc(''); if (t === 'tcp') refreshTypeOptions(); });
    f.cluster.addEventListener('change', function () { remember(); s.ns = s.pod = s.container = ''; refreshCluster(); loadNamespaces(); });
    f.ns.addEventListener('change', function () { remember(); s.pod = s.container = ''; loadPods(); });
    f.pod.addEventListener('change', function () { remember(); s.container = ''; refreshContainer(); });
    f.container.addEventListener('change', remember);
    f.type.addEventListener('change', function () { remember(); refreshTypeOptions(); });
    refreshEnv(); refreshCluster(); refreshNs(); refreshPod(); refreshContainer(); refreshType(); refreshTypeOptions();

    function intIn(id, lo, hi, label, errs) {
      var n = Number(f[id].value);
      if (f[id].value === '' || !Number.isInteger(n) || n < lo || n > hi) errs[id] = label + ' must be a whole number from ' + lo + ' to ' + hi + '.';
    }
    function validateLocal() {
      remember(); var errs = {};
      ['env', 'cluster', 'ns', 'pod', 'container', 'type'].forEach(function (k) { if (!s[k]) errs[k] = 'Required.'; });
      var lim = LIM[s.type];
      if (lim) { intIn('timeout', lim.timeout[0], lim.timeout[1], 'Timeout', errs); intIn('size', Number(f.size.min), Number(f.size.max), 'Size limit', errs); }
      if (s.type === 'thread') {
        intIn('count', 1, 10, 'Count', errs); intIn('interval', 1, 60, 'Interval', errs);
        if (!errs.timeout && !errs.count && !errs.interval && (Number(v('count')) - 1) * Number(v('interval')) + 10 >= Number(v('timeout'))) errs.timeout = 'Too short for that many dumps and interval.';
      }
      if (s.type === 'heap' && !f.hack.checked) errs.hack = 'Tick the confirmation to continue.';
      if (s.type === 'tcp') {
        intIn('duration', 5, 300, 'Duration', errs);
        if (!errs.timeout && !errs.duration && Number(v('timeout')) < Number(v('duration')) + TCP_MARGIN) errs.timeout = 'Timeout must be at least ' + TCP_MARGIN + ' s longer than the capture duration.';
        if (v('filter') === 'port') intIn('port', 1, 65535, 'Port', errs);
        var peer = v('peer').trim();
        if (peer && !/^[0-9A-Fa-f:.]{2,45}$/.test(peer)) errs.peer = 'Enter a plain IPv4 or IPv6 address.';
        if (v('payload') === 'full' && !f.cpay.checked) errs.payload = 'Tick the confirmation below to capture full packets.';
      }
      if (s.cluster && !connection(s.cluster)) errs.cluster = 'Connect to this cluster first.';
      Object.keys(f).forEach(function (k) { f[k].classList.remove('invalid'); var e = document.getElementById('e_' + k); if (e) e.textContent = ''; });
      Object.keys(errs).forEach(function (k) { if (f[k]) f[k].classList.add('invalid'); var e = document.getElementById('e_' + k); if (e) e.textContent = errs[k]; });
      return Object.keys(errs).length === 0;
    }
    function body(confirmProd, typedName) {
      var o = { timeout: Number(v('timeout')), size_limit_mb: Number(v('size')) }, b;
      if (s.type === 'thread') { o.count = Number(v('count')); o.interval = Number(v('interval')); }
      if (s.type === 'tcp') { o.duration = Number(v('duration')); o.filter = v('filter'); o.payload = v('payload'); if (o.filter === 'port') o.port = Number(v('port')); if (v('peer').trim()) o.peer_ip = v('peer').trim(); }
      b = { cluster: s.cluster, namespace: s.ns, pod: s.pod, container: s.container, dump_type: s.type, options: o, confirm_prod: !!confirmProd };
      if (s.type === 'tcp' && o.payload === 'full' && f.cpay.checked) b.confirm_payload = true;
      if (s.type === 'heap') { b.confirm_heap = !!f.hack.checked; if (typedName) b.confirm_name = typedName; }
      return b;
    }
    function showBox(cls, msg, extra) { clearEl(result); result.appendChild(h('div', { class: cls + ' mt' }, msg)); if (extra) result.appendChild(extra); }
    function onValidate() {
      if (!validateLocal()) return showBox('err-box', 'Please correct the highlighted fields.');
      showBox('info-box', 'Validating on the server' + (s.type === 'tcp' ? ' (includes a brief permission test inside the container)' : s.type === 'heap' ? ' (includes a read-only heap size check)' : '') + '...');
      api('POST', '/api/validate', body(false)).then(function (r) {
        showBox(r.ok ? 'ok-box' : 'err-box', r.ok ? 'All pre-collection checks passed.' : 'Validation failed. Nothing was collected.', checksList(r.checks));
        if (r.token_rejected) refreshSession(true);
      }).catch(function (e) { showBox('err-box', errText(e)); });
    }
    function onCollect() {
      if (!validateLocal()) return showBox('err-box', 'Please correct the highlighted fields.');
      var c = clusterById(s.cluster);
      if (c && c.environment === 'PROD') return confirmProd(c);
      submit(false, null);
    }
    function submit(confirmed, typedName) {
      clearEl(result);
      api('POST', '/api/jobs', body(confirmed, typedName)).then(function (r) {
        s.jobId = r.job.id; state.jobs = [r.job].concat(state.jobs.filter(function (j) { return j.id !== r.job.id; }));
        state.selectedJob = r.job.id; updatePanel(); startPolling(); toast('Job ' + r.job.id + ' queued.');
      }).catch(function (e) { showBox('err-box', errText(e)); });
    }
    function onCancel() {
      if (!s.jobId) return;
      api('POST', '/api/jobs/' + encodeURIComponent(s.jobId) + '/cancel', {}).then(function () { toast('Cancel requested.'); return loadJobs(); }).then(updatePanel).catch(function (e) { toast(e.message); });
    }
    function updatePanel() {
      var j = s.jobId && jobById(s.jobId);
      clearEl(panel);
      var slot = document.getElementById('dlslot'); if (slot) { clearEl(slot); slot.appendChild(downloadBtn(j)); }
      var cancelBtn = document.getElementById('bCancel'); if (cancelBtn) cancelBtn.disabled = !(j && j.active);
      if (!j) return;
      panel.appendChild(h('div', { class: 'info-box' }, h('strong', null, 'Job ' + j.id + ' '), statusBadge(j.status), ' ', h('span', { class: 'stage' }, j.stage), ' ', h('a', { href: '#/progress' }, 'View on Progress page')));
      if (j.error) panel.appendChild(h('div', { class: j.status === 'Failed' ? 'err-box' : 'info-box' }, j.error));
      if (j.status === 'Failed') panel.appendChild(checksList(j.checks));
      if (j.status === 'Completed') panel.appendChild(h('div', { class: 'ok-box' }, 'Completed: ' + fmtSize(j.size_bytes) + (j.packets !== null && j.packets !== undefined ? ', ' + j.packets + ' packets' : '') + ' in ' + fmtDur(j.duration) + '.'));
      if (j.note) panel.appendChild(h('div', { class: j.note.indexOf('ACTION NEEDED') === 0 ? 'err-box' : 'warn-box' }, j.note));
    }
    state.updatePanel = updatePanel;
    state.sessionHook = function () { refreshCluster(); };
    function confirmProd(c) {
      var dlg = document.getElementById('confirm'); clearEl(dlg);
      var chk = h('input', { type: 'checkbox', id: 'ck' });
      var typed = s.type === 'heap' ? h('input', { type: 'text', id: 'tp', autocomplete: 'off', placeholder: c.name }) : null;
      var go = h('button', { class: 'danger', type: 'button', disabled: true, onclick: function () { dlg.close(); submit(true, typed ? typed.value : null); } }, 'Confirm collection on PROD');
      function upd() { go.disabled = !(chk.checked && (!typed || typed.value === c.name)); }
      chk.addEventListener('change', upd); if (typed) typed.addEventListener('input', upd);
      dlg.appendChild(h('h2', null, 'Confirm PRODUCTION collection'));
      dlg.appendChild(h('p', null, typeLabel(s.type) + ' from ', h('strong', null, s.pod + ' / ' + s.container), ' in ', h('strong', null, s.ns), ' on ', h('strong', null, c.name), ', as ', h('strong', null, (connection(c.id) || {}).identity || '?'), '.'));
      dlg.appendChild(h('div', { class: 'warn-box' }, s.type === 'tcp'
        ? 'Packet capture runs tcpdump inside the live container for up to ' + v('duration') + ' s and adds CPU and memory load. It records traffic metadata' + (v('payload') === 'full' ? ' AND PAYLOAD' : '') + ' and is audited.'
        : s.type === 'heap' ? 'A heap dump pauses the production JVM, can consume gigabytes of memory and disk and affect live users. The file contains memory contents (secrets, personal data).'
        : 'Thread dumps briefly pause the JVM at a safepoint. Taking several in a row on a busy production service can add latency.'));
      dlg.appendChild(h('label', { class: 'inline-label' }, chk, 'I understand this runs against a production workload and will be audited.'));
      if (typed) dlg.appendChild(h('label', { class: 'mt' }, 'Type the cluster name (' + c.name + ') to confirm', typed));
      dlg.appendChild(h('div', { class: 'actions mt' }, go, h('button', { type: 'button', onclick: function () { dlg.close(); } }, 'Cancel')));
      dlg.showModal();
    }
    updatePanel();
    return root;
  }

  /* ---------- Progress ---------- */
  function jobDetail(j) {
    function item(k, val) { return h('div', null, h('dt', null, k), h('dd', null, val)); }
    return h('div', null,
      h('dl', { class: 'detail' }, item('Job ID', j.id), item('Status', statusBadge(j.status)), item('Environment', envBadge(j.env)), item('Cluster', j.cluster),
        item('Namespace', j.namespace), item('Pod', j.pod), item('Container', j.container), item('Dump type', typeLabel(j.dump_type)), item('Settings', optsText(j)),
        item('Requested by', j.requested_by), item('Start time', fmtDate(j.created)), item('Current stage', h('span', { class: 'stage' }, j.stage)),
        item('Output size', fmtSize(j.size_bytes)), j.packets !== null && j.packets !== undefined ? item('Packets', String(j.packets)) : null, item('Duration', fmtDur(j.duration))),
      j.error ? h('div', { class: j.status === 'Failed' ? 'err-box' : 'info-box' }, j.error) : null,
      j.note ? h('div', { class: j.note.indexOf('ACTION NEEDED') === 0 ? 'err-box' : 'warn-box' }, j.note) : null,
      checksList(j.checks),
      h('div', { class: 'info-box' }, 'No percentage is shown: the backend reports the current stage (with real elapsed time or bytes transferred), not a calculated progress value.'),
      h('div', { class: 'actions' }, downloadBtn(j), deleteBtn(j),
        j.active ? h('button', { type: 'button', onclick: function () { api('POST', '/api/jobs/' + encodeURIComponent(j.id) + '/cancel', {}).then(function () { toast('Cancel requested.'); return loadJobs(); }).then(render).catch(function (e) { toast(e.message); }); } }, 'Cancel Collection') : null));
  }
  function pageProgress() {
    if (!state.selectedJob && state.jobs.length) state.selectedJob = state.jobs[0].id;
    var j = jobById(state.selectedJob);
    var list = h('ul', { class: 'joblist' }, state.jobs.slice(0, 30).map(function (x) {
      function pick() { state.selectedJob = x.id; render(); }
      return h('li', { class: x.id === state.selectedJob ? 'sel' : '', tabindex: 0, role: 'button', onclick: pick, onkeydown: function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } } },
        h('div', null, h('strong', null, x.id), ' ', statusBadge(x.status)), h('div', { class: 'muted' }, typeLabel(x.dump_type) + ' - ' + x.cluster));
    }));
    return [pageHead('Collection Progress', 'Status and current stage of your collection jobs.'),
      state.jobs.length ? h('div', { class: 'two' }, h('div', null, list), h('div', { class: 'card' }, j ? jobDetail(j) : h('div', { class: 'muted' }, 'Select a job.')))
        : h('div', { class: 'card muted' }, state.session.connected.length ? 'No collection jobs yet.' : 'Connect to a cluster to see your jobs.')];
  }

  /* ---------- History ---------- */
  function pageHistory() {
    var hf = state.hist, tbody = h('tbody'), count = h('span', { class: 'muted' });
    function draw() {
      var q = hf.q.trim().toLowerCase();
      var rows = state.jobs.filter(function (j) {
        if (hf.env && j.env !== hf.env) return false; if (hf.status && j.status !== hf.status) return false; if (hf.type && j.dump_type !== hf.type) return false;
        return !q || [j.id, j.cluster, j.namespace, j.pod, j.container, j.requested_by].join(' ').toLowerCase().indexOf(q) >= 0;
      });
      clearEl(tbody); count.textContent = rows.length + ' of ' + state.jobs.length + ' jobs';
      if (!rows.length) tbody.appendChild(h('tr', null, h('td', { colspan: 14, class: 'muted' }, state.session.connected.length ? 'No matching jobs.' : 'Connect to a cluster to see your history.')));
      rows.forEach(function (j) {
        tbody.appendChild(h('tr', null, h('td', null, j.id), h('td', null, fmtDate(j.created)), h('td', null, envBadge(j.env)), h('td', null, j.cluster), h('td', null, j.namespace), h('td', null, j.pod),
          h('td', null, j.container), h('td', null, typeLabel(j.dump_type)), h('td', null, j.requested_by), h('td', null, fmtDur(j.duration)), h('td', null, statusBadge(j.status)), h('td', null, fmtSize(j.size_bytes)),
          h('td', null, j.download_available ? h('span', null, h('a', { class: 'btn small', href: '/api/jobs/' + encodeURIComponent(j.id) + '/download' }, 'Download'), ' ', deleteBtn(j)) : '-'),
          h('td', { class: 'wrap' }, j.error || j.note || '-')));
      });
    }
    function select(key, label, items) {
      var el = h('select', { 'aria-label': label, onchange: function () { hf[key] = el.value; draw(); } }, h('option', { value: '' }, label), items.map(function (i) { return h('option', { value: i.v, selected: hf[key] === i.v }, i.l); })); return el;
    }
    var search = h('input', { type: 'search', placeholder: 'Search job, cluster, namespace, pod...', value: hf.q, 'aria-label': 'Search history', oninput: function () { hf.q = search.value; draw(); } });
    var heads = ['Job ID', 'Date / time', 'Env', 'Cluster', 'Namespace', 'Pod', 'Container', 'Type', 'Requested by', 'Duration', 'Status', 'File size', 'Download', 'Failure details / notes'];
    var page = [pageHead('Collection History', 'Your jobs on the clusters you are connected to. Results are kept ' + (state.me ? (state.me.purge_on_logout ? 'only until you sign out' : 'for ' + state.me.retention_days + ' days after your last login') : '') + ' and are available again whenever you reconnect with the same identity.'),
      h('div', { class: 'toolbar' }, search, select('env', 'All environments', ENVS.map(function (e) { return { v: e, l: e }; })),
        select('status', 'All statuses', Object.keys(STATUS_CLS).map(function (e) { return { v: e, l: e }; })), select('type', 'All types', [{ v: 'thread', l: 'Thread Dump' }, { v: 'heap', l: 'Heap Dump' }, { v: 'tcp', l: 'TCP Dump' }]),
        h('button', { type: 'button', onclick: function () { loadJobs().then(render); } }, 'Refresh'), count),
      h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, heads.map(function (x) { return h('th', null, x); }))), tbody))];
    draw(); return page;
  }

  /* ---------- Clusters ---------- */
  function pageClusters() {
    var rows = state.clusters.map(function (c) {
      var conn = connection(c.id);
      var admin = state.session.admin;
      return h('tr', null, h('td', null, h('strong', null, c.name)), h('td', null, envBadge(c.environment)), h('td', { class: 'wrap' }, c.api_url || '-'),
        h('td', null, c.tls_verify ? badge('Verified', 'b-ok') : badge('OFF', 'b-warn')),
        h('td', null, badge(c.enabled ? 'Enabled' : 'Disabled', c.enabled ? 'b-ok' : 'b-grey'), c.enabled_by_admin ? h('div', { class: 'muted' }, 'set by ' + c.enabled_by_admin) : null),
        h('td', { class: 'wrap' }, connBadge(c), c.connectivity ? h('div', { class: 'muted' }, c.connectivity.note + ' (' + fmtDate(c.connectivity.checked_at) + ')') : null),
        h('td', null, conn ? badge('As ' + conn.identity, 'b-ok') : badge('Not connected', 'b-grey')),
        h('td', null, h('div', { class: 'actions' },
          h('button', { type: 'button', class: 'small', onclick: function () { runChecks(c.id); } }, 'Check connectivity'),
          c.enabled ? connectBtn(c, true) : null,
          conn ? h('button', { type: 'button', class: 'small', onclick: function () { disconnect(c.id); } }, 'Disconnect') : null,
          h('button', { type: 'button', class: 'small', disabled: !admin, title: admin ? '' : 'Only portal administrators (server --admin-users) can enable or disable clusters', onclick: function () {
            api('POST', '/api/clusters/' + encodeURIComponent(c.id) + '/enabled', { enabled: !c.enabled }).then(function (b) { state.clusters = b.clusters; render(); toast(c.name + (c.enabled ? ' disabled' : ' enabled') + '.'); }).catch(function (e) { toast(e.message); });
          } }, c.enabled ? 'Disable' : 'Enable'))));
    });
    var heads = ['Cluster', 'Environment', 'API endpoint', 'TLS verification', 'In portal', 'Connectivity (live)', 'Your connection', 'Actions'];
    return [pageHead('Cluster Management', 'Configured clusters. Credentials are never shown or sent to the browser. Connectivity is an anonymous reachability check; it uses no token.'), loadErrorBox(),
      h('div', { class: 'actions' }, h('button', { type: 'button', onclick: function () { runChecks(); } }, 'Check all')),
      h('div', { class: 'tablewrap mt' }, h('table', null, h('thead', null, h('tr', null, heads.map(function (x) { return h('th', null, x); }))),
        h('tbody', null, rows.length ? rows : h('tr', null, h('td', { colspan: heads.length, class: 'muted' }, 'No clusters configured.')))))];
  }

  /* ---------- router ---------- */
  var ROUTES = { dashboard: pageDashboard, collect: pageCollect, progress: pageProgress, history: pageHistory, clusters: pageClusters };
  function render() {
    var r = route();
    Array.prototype.forEach.call(document.querySelectorAll('#nav a'), function (a) {
      var on = a.getAttribute('data-route') === r; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    state.updatePanel = null; state.sessionHook = null;
    var view = document.getElementById('view'); clearEl(view);
    (function add(n) { if (Array.isArray(n)) return n.forEach(add); if (n) view.appendChild(n); })(ROUTES[r]());
  }
  window.addEventListener('hashchange', function () { loadJobs().catch(function () { }).then(function () { render(); if (anyActive()) startPolling(); if (route() === 'dashboard' && !state.checking) runChecks(); }); });
  Promise.all([loadClusters(), api('GET', '/api/me').then(function (m) { state.me = m; }).catch(function () { }), api('GET', '/api/session').then(function (s) { state.session = s; }).catch(function () { })])
    .then(function () { return loadJobs().catch(function () { }); }).then(function () {
      renderWho(); render(); if (anyActive()) startPolling(); runChecks();
    });
})();
