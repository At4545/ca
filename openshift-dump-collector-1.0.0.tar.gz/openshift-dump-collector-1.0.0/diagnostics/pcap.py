"""Minimal classic-pcap structure check (stdlib only): a file is only ever presented as a
successful capture if it parses; a trailing incomplete record is trimmed to the last whole packet."""
import os
import struct

_MAGICS = {0xA1B2C3D4: (">", False), 0xD4C3B2A1: ("<", False), 0xA1B23C4D: (">", True), 0x4D3CB2A1: ("<", True)}
GLOBAL_HDR = 24
REC_HDR = 16
MAX_PACKET = 262144 + 65536


class PcapError(Exception):
    pass


def scan(path):
    total = os.path.getsize(path)
    if total < GLOBAL_HDR:
        raise PcapError("file is shorter than a pcap header (%d bytes)" % total)
    with open(path, "rb") as fh:
        head = fh.read(GLOBAL_HDR)
        magic = struct.unpack(">I", head[:4])[0]
        if magic not in _MAGICS:
            if head[:4] == b"\x0a\x0d\x0d\x0a":
                raise PcapError("pcapng format is not supported")
            raise PcapError("missing pcap magic number")
        order = _MAGICS[magic][0]
        _, vmaj, vmin, _, _, snaplen, linktype = struct.unpack(order + "IHHiIII", head)
        if vmaj != 2:
            raise PcapError("unsupported pcap version %d.%d" % (vmaj, vmin))
        limit = min(max(snaplen if snaplen else MAX_PACKET, 65535), MAX_PACKET)
        pos, packets = GLOBAL_HDR, 0
        while True:
            fh.seek(pos)
            rec = fh.read(REC_HDR)
            if len(rec) < REC_HDR:
                break
            _, _, incl, orig = struct.unpack(order + "IIII", rec)
            if incl > limit or incl > orig:
                if packets == 0 and pos == GLOBAL_HDR:
                    raise PcapError("first packet record is malformed")
                break
            if pos + REC_HDR + incl > total:
                break
            pos += REC_HDR + incl
            packets += 1
    return {"valid_len": pos, "packets": packets, "snaplen": snaplen, "linktype": linktype, "trailing_bytes": total - pos}


def trim_to_valid(path):
    info = scan(path)
    if info["trailing_bytes"]:
        os.truncate(path, info["valid_len"])
    return info
