# OpenShift Dump Collector  v1.0.0

A small web portal that lets authorised people collect **thread dumps, heap dumps and TCP packet captures** from pods on
Red Hat OpenShift / Azure Red Hat OpenShift clusters, then download the results - without logging into each cluster, finding
pods by hand, running commands or copying files.

* **Runs as you.** Each user connects to each cluster with **their own OpenShift OAuth token**. They see only the projects their
  token can see and can only do what their token allows. Credentials in `clusters.json` and the server's own `oc login` are never used.
* **Tokens stay in memory.** Never on disk, in logs, on a command line, or in the browser. A session ends on sign-out or after
  30 idle minutes.
* **Standard library only.** Python 3.9+, the existing `oc` CLI, a browser. Nothing to `pip install`, no Node, no nginx, no Ansible.
* **Built for admins on a jump server:** binds to loopback only; reach it through an SSH tunnel.

## What's in the box
| Feature | Notes |
|---|---|
| Dashboard | Live cluster reachability (real check), your job counts, connect buttons |
| Collect Dump | Environment > cluster > namespace > pod > container > dump type; validate, collect, cancel, download |
| Thread dump | `jcmd Thread.print` (or `jstack`), 1-10 dumps at an interval |
| Heap dump | `jcmd GC.heap_dump` (or `jmap`), free-space and size checks, typed confirmation on PROD, remote file always cleaned up |
| TCP capture | tcpdump already inside the container; preset filters, bounded duration/size; headers-only by default |
| Progress / History | Stage text (never invented percentages), searchable history stored in SQLite, delete own files |
| Cluster page | Anonymous connectivity check, TLS status, connect/disconnect, admin enable/disable |
| Audit log | JSON lines, rotated; no secrets or dump contents |

## Quick start (on the RHEL jump server)
```bash
tar xzf openshift-dump-collector-1.0.0.tar.gz && cd openshift-dump-collector-1.0.0
./deploy/install.sh --prefix ~/openshift-dump-collector           # copies files, makes private dirs; installs nothing
cp /path/to/clusters.json ~/openshift-dump-collector/ && chmod 600 ~/openshift-dump-collector/clusters.json
python3 ~/openshift-dump-collector/scripts/discover_env.py --clusters ~/openshift-dump-collector/clusters.json
~/openshift-dump-collector/run.sh
# on your workstation:
ssh -L 8080:127.0.0.1:8080 <jump-server>     # then open http://127.0.0.1:8080
```

## Documentation
* [docs/USER_GUIDE.md](docs/USER_GUIDE.md) - getting a token, collecting dumps, what the messages mean
* [docs/ADMIN_GUIDE.md](docs/ADMIN_GUIDE.md) - install, configuration, operation, troubleshooting, upgrade/rollback, first real-cluster validation
* [docs/SECURITY.md](docs/SECURITY.md) - how tokens are handled, threat model, residual risks, review checklist

## Status - read this first
Built and tested **against a simulated `oc`** (a fake CLI that mimics per-user tokens, permissions, container filesystems and failures):
~80 automated tests plus a headless-browser run of the full UI. **It has not yet been run against a real OpenShift cluster, real JVMs,
Python 3.9, or under systemd.** Do the "First real-cluster validation" in the Admin Guide on a DEV cluster before wider use.
There is no TLS or SSO in the portal itself; that is why it is loopback-only.
