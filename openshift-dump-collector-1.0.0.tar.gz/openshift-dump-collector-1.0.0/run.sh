#!/usr/bin/env bash
# Starts the portal using portal.conf (if present). Safe to run by hand or from systemd.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
CONF="${PORTAL_CONF:-$HERE/portal.conf}"
if [ -f "$CONF" ]; then set -a; . "$CONF"; set +a; fi

abs() { case "$1" in /*) printf '%s' "$1";; *) printf '%s/%s' "$HERE" "$1";; esac; }
PY="${PYTHON:-python3}"
args=(--port "${PORT:-8080}" --clusters "$(abs "${CLUSTERS_FILE:-clusters.json}")" --storage "$(abs "${STORAGE_DIR:-storage}")"
      --logs "$(abs "${LOG_DIR:-logs}")" --idle-minutes "${IDLE_MINUTES:-30}" --retention-days "${RETENTION_DAYS:-7}"
      --user-quota-mb "${USER_QUOTA_MB:-20480}" --total-quota-mb "${TOTAL_QUOTA_MB:-51200}" --heap-max-mb "${HEAP_MAX_MB:-8192}"
      --max-concurrent "${MAX_CONCURRENT:-2}" --max-user-jobs "${MAX_USER_JOBS:-3}" --tcp-envs "${TCP_ENVS:-DEV,TEST}")
[ -n "${RUNTIME_DIR:-}" ] && args+=(--runtime-dir "$(abs "$RUNTIME_DIR")")
[ "${PURGE_ON_LOGOUT:-0}" = "1" ] && args+=(--purge-on-logout)
[ -n "${ADMIN_USERS:-}" ] && args+=(--admin-users "$ADMIN_USERS")
[ -n "${INSECURE_TLS_CLUSTERS:-}" ] && args+=(--insecure-tls-clusters "$INSECURE_TLS_CLUSTERS")
[ -n "${OC_PATH:-}" ] && args+=(--oc-path "$OC_PATH")
umask 077
exec "$PY" server.py "${args[@]}" "$@"
