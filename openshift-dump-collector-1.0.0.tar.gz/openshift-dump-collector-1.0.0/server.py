#!/usr/bin/env python3
"""OpenShift Dump Collector - server (v1.0).

Standard library only (Python 3.9 compatible).
  * Users authenticate to each cluster with THEIR OWN OpenShift OAuth token. Tokens live only in
    server memory; credentials in clusters.json and the server's own `oc login` are never used.
  * Binds to loopback only (run it on the admin's jump server and reach it via an SSH tunnel).
    There is no TLS here: pasting a token over plain HTTP is only acceptable on loopback.
  * Serves only index.html, style.css, script.js. clusters.json is never served.
  * Mutating requests require Content-Type: application/json and a same-origin Origin; the
    session cookie is HttpOnly + SameSite=Strict.
"""
import argparse
import json
import logging
import logging.handlers
import os
import re
import shutil
import sys
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from backend.app import App
from backend.configuration import VALID_ENVS, ConfigError, Settings, count_credential_fields
from backend.errors import ApiError
from backend.runtime import RuntimeError_
from backend.validation import CLUSTER_ID_RE, parse_request, valid_namespace

ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"), "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"), "/script.js": ("script.js", "application/javascript; charset=utf-8"),
}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
COOKIE = "dc_session"
MAX_BODY = 16 * 1024
R_NS = re.compile(r"/api/clusters/([^/]+)/namespaces")
R_PODS = re.compile(r"/api/clusters/([^/]+)/namespaces/([^/]+)/pods")
R_CL_ACT = re.compile(r"/api/clusters/([^/]+)/(check|enabled)")
R_JOB = re.compile(r"/api/jobs/([^/]+)")
R_JOB_ACT = re.compile(r"/api/jobs/([^/]+)/(cancel|download|delete)")
NO_TOUCH = ("/api/health", "/api/session", "/api/me")      # polling these must not keep a session alive
log = logging.getLogger("dumpcollector")


def version():
    try:
        with open(os.path.join(ROOT, "VERSION")) as fh:
            return fh.read().strip()
    except OSError:
        return "dev"


class Handler(BaseHTTPRequestHandler):
    server_version = "DumpCollector/" + version()
    sys_version = ""

    # ---- plumbing ------------------------------------------------------------------------
    def _headers(self, code, ctype, length, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        for c in self._set_cookies:
            self.send_header("Set-Cookie", c)
        self.end_headers()

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self._headers(code, "application/json", len(body))
        self.wfile.write(body)

    def _read_body(self):
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(415, "Content-Type must be application/json")
        origin = self.headers.get("Origin")
        if origin and origin != "http://" + (self.headers.get("Host") or ""):
            raise ApiError(403, "Cross-origin request refused")
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError(400, "Bad Content-Length")
        if n > MAX_BODY:
            raise ApiError(413, "Request too large")
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except ValueError:
            raise ApiError(400, "Body is not valid JSON")

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    do_DELETE = do_PATCH = do_PUT

    def _load_session(self, touch):
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        try:
            c = cookies.SimpleCookie(raw)
        except cookies.CookieError:
            return None
        m = c.get(COOKIE)
        return self.server.app.sessions.get(m.value, touch=touch) if m else None

    def _set_session_cookie(self, sid):
        self._set_cookies.append("%s=%s; HttpOnly; SameSite=Strict; Path=/" % (COOKIE, sid))

    def _clear_session_cookie(self):
        self._set_cookies.append("%s=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0" % COOKIE)

    def _dispatch(self, method):
        self._set_cookies = []
        try:
            if (self.headers.get("Host") or "").lower() not in self.server.allowed_hosts:
                raise ApiError(400, "Unexpected Host header")
            path = urlsplit(self.path).path
            if method == "GET" and path in STATIC:
                fname, ctype = STATIC[path]
                with open(os.path.join(ROOT, fname), "rb") as fh:
                    data = fh.read()
                self._headers(200, ctype, len(data))
                self.wfile.write(data)
            elif method == "GET" and path == "/favicon.ico":
                self._headers(204, "image/x-icon", 0)
            elif path.startswith("/api/"):
                self._api(method, path)
            else:
                raise ApiError(404, "Not found")
        except ApiError as exc:
            payload = {"error": exc.message}
            if exc.details:
                payload["details"] = exc.details
            if exc.reason:
                payload["reason"] = exc.reason
            self._json(exc.code, payload)
        except ConfigError as exc:
            self._json(500, {"error": str(exc)})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            log.exception("Unhandled error")
            self._json(500, {"error": "Internal server error"})

    # ---- API -----------------------------------------------------------------------------
    def _need_session(self, session):
        if session is None:
            raise ApiError(401, "Not connected. Connect to a cluster with your OpenShift token first.", reason="no_session")
        return session

    def _api(self, method, path):
        app = self.server.app
        session = self._load_session(touch=path not in NO_TOUCH)
        if method == "GET":
            if path == "/api/health":
                return self._json(200, {"status": "ok"})
            if path == "/api/me":
                s = app.settings
                return self._json(200, {"oc_available": app.oc.available, "version": version(), "retention_days": s.retention_days,
                                        "purge_on_logout": s.purge_on_logout, "tcp_envs": list(s.tcp_envs), "idle_seconds": s.idle_seconds,
                                        "user_quota_mb": s.user_quota_mb, "limits": {"heap_max_mb": s.heap_max_mb}})
            if path == "/api/session":
                return self._json(200, app.session_info(session))
            if path == "/api/clusters":
                mine = dict(session.tokens) if session else {}
                out = []
                for c in app.clusters():
                    c = dict(c)
                    c["connected_as"] = mine[c["id"]]["identity"] if c["id"] in mine else None
                    out.append(c)
                return self._json(200, {"clusters": out})
            m = R_PODS.fullmatch(path)
            if m:
                self._check_cluster_ns(m.group(1), m.group(2))
                return self._json(200, app.pods(session, m.group(1), m.group(2)))
            m = R_NS.fullmatch(path)
            if m:
                self._check_cluster_ns(m.group(1), None)
                return self._json(200, app.namespaces(session, m.group(1)))
            if path == "/api/jobs":
                return self._json(200, {"jobs": app.jobs.list_for(session)})
            m = R_JOB_ACT.fullmatch(path)
            if m and m.group(2) == "download":
                return self._download(app, session, m.group(1))
            m = R_JOB.fullmatch(path)
            if m:
                return self._json(200, {"job": app.jobs.public(app.jobs.get_for(session, m.group(1)))})
        elif method == "POST":
            if path == "/api/auth/login":
                body = self._read_body()
                cid = body.get("cluster") if isinstance(body, dict) else None
                if not isinstance(cid, str) or not CLUSTER_ID_RE.fullmatch(cid):
                    raise ApiError(400, "Choose a cluster.")
                was = session
                session = app.login(session, cid, body.get("token"))
                if was is None:
                    self._set_session_cookie(session.sid)
                info = app.session_info(session)
                return self._json(200, info)
            if path == "/api/auth/logout":
                body = self._read_body()
                if session is not None:
                    cid = body.get("cluster") if isinstance(body, dict) else None
                    if cid:
                        if not isinstance(cid, str) or not CLUSTER_ID_RE.fullmatch(cid):
                            raise ApiError(400, "Invalid cluster")
                        app.disconnect(session, cid)
                    else:
                        app.sign_out(session)
                    if not session.tokens:
                        self._clear_session_cookie()
                    return self._json(200, app.session_info(app.sessions.get(session.sid, touch=False)))
                self._clear_session_cookie()
                return self._json(200, app.session_info(None))
            if path == "/api/clusters/check":
                self._read_body()
                return self._json(200, {"clusters": app.check_all()})
            m = R_CL_ACT.fullmatch(path)
            if m:
                body = self._read_body()
                self._check_cluster_ns(m.group(1), None)
                if m.group(2) == "check":
                    c = [x for x in app.clusters() if x["id"] == m.group(1)]
                    if not c:
                        raise ApiError(404, "Unknown cluster")
                    app.check_cluster(c[0], force=True)
                else:
                    if not isinstance(body, dict) or not isinstance(body.get("enabled"), bool):
                        raise ApiError(400, "'enabled' must be true or false")
                    app.set_enabled(self._need_session(session), m.group(1), body["enabled"])
                return self._json(200, {"clusters": app.clusters()})
            if path == "/api/validate":
                clean = parse_request(self._read_body(), app.settings.heap_max_mb)
                return self._json(200, app.validate(self._need_session(session), clean))
            if path == "/api/jobs":
                clean = parse_request(self._read_body(), app.settings.heap_max_mb)
                return self._json(202, {"job": app.create_job(self._need_session(session), clean)})
            m = R_JOB_ACT.fullmatch(path)
            if m and m.group(2) in ("cancel", "delete"):
                self._read_body()
                fn = app.jobs.cancel if m.group(2) == "cancel" else app.jobs.delete_result
                return self._json(200, {"job": fn(self._need_session(session), m.group(1))})
        else:
            raise ApiError(405, "Method not allowed")
        raise ApiError(404, "Not found")

    @staticmethod
    def _check_cluster_ns(cluster_id, ns):
        if not CLUSTER_ID_RE.fullmatch(cluster_id):
            raise ApiError(404, "Unknown cluster")
        if ns is not None and not valid_namespace(ns):
            raise ApiError(400, "Invalid namespace name")

    def _download(self, app, session, job_id):
        path, name, size = app.jobs.download_info(self._need_session(session), job_id)
        self._headers(200, "application/octet-stream", size, {"Content-Disposition": 'attachment; filename="%s"' % name})
        with open(path, "rb") as fh:
            shutil.copyfileobj(fh, self.wfile, 1 << 20)

    def log_message(self, fmt, *args):     # request line only; never headers, cookies or bodies
        log.info("%s - %s", self.address_string(), fmt % args)


def harden_process():
    """No core dumps and no same-user ptrace/proc-mem reads of this process (tokens live in its memory)."""
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except Exception:
        pass
    try:
        import ctypes
        ctypes.CDLL(None).prctl(4, 0, 0, 0, 0)      # PR_SET_DUMPABLE = 0
    except Exception:
        pass


def csv(value, upper=False):
    items = [x.strip() for x in (value or "").split(",") if x.strip()]
    return tuple(x.upper() for x in items) if upper else tuple(items)


def main():
    ap = argparse.ArgumentParser(description="OpenShift Dump Collector")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--clusters", default=os.path.join(ROOT, "clusters.json"))
    ap.add_argument("--storage", default=os.path.join(ROOT, "storage"), help="dump files + portal.db (keep outside any web root)")
    ap.add_argument("--logs", default=os.path.join(ROOT, "logs"))
    ap.add_argument("--runtime-dir", default=None, help="memory-backed dir for temporary kubeconfigs (default /dev/shm/openshift-dump-collector-<uid>)")
    ap.add_argument("--oc-path", default="oc")
    ap.add_argument("--max-concurrent", type=int, default=2, help="jobs running at once")
    ap.add_argument("--max-user-jobs", type=int, default=3, help="active jobs per user per cluster")
    ap.add_argument("--retention-days", type=int, default=7, help="days a result is kept after its owner's last login")
    ap.add_argument("--purge-on-logout", action="store_true", help="delete a user's stored results as soon as their session ends")
    ap.add_argument("--idle-minutes", type=int, default=30, help="end a session after this many idle minutes (running jobs keep it alive)")
    ap.add_argument("--idle-seconds", type=int, default=None, help=argparse.SUPPRESS)       # testing: overrides --idle-minutes
    ap.add_argument("--tick-seconds", type=int, default=15, help=argparse.SUPPRESS)
    ap.add_argument("--login-fail-limit", type=int, default=10, help="failed connection attempts per minute before throttling")
    ap.add_argument("--min-free-mb", type=int, default=500, help="disk space always left free on the portal server")
    ap.add_argument("--user-quota-mb", type=int, default=20480)
    ap.add_argument("--total-quota-mb", type=int, default=51200)
    ap.add_argument("--heap-max-mb", type=int, default=8192, help="largest heap-dump size limit a user may request")
    ap.add_argument("--tcp-envs", default="DEV,TEST", help="environments where TCP capture is allowed (PROD is opt-in)")
    ap.add_argument("--insecure-tls-clusters", default="", help="comma-separated cluster ids for which TLS verification is OFF (default: all verify)")
    ap.add_argument("--admin-users", default="", help="comma-separated cluster-id:identity pairs allowed to enable/disable clusters")
    a = ap.parse_args()
    if a.host not in ("127.0.0.1", "localhost", "::1"):
        print("Refusing non-loopback bind: tokens are entered in this UI and there is no TLS.", file=sys.stderr)
        sys.exit(2)
    tcp_envs = csv(a.tcp_envs, upper=True)
    bad = [e for e in tcp_envs if e not in VALID_ENVS]
    if bad:
        print("Invalid --tcp-envs value(s): %s (allowed: %s)" % (", ".join(bad), ", ".join(VALID_ENVS)), file=sys.stderr)
        sys.exit(2)
    os.umask(0o077)
    harden_process()
    os.makedirs(a.logs, mode=0o700, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[
        logging.StreamHandler(),
        logging.handlers.RotatingFileHandler(os.path.join(a.logs, "app.log"), maxBytes=10 * 1024 * 1024, backupCount=5)])
    settings = Settings(a.clusters, a.storage, a.logs, a.runtime_dir, a.oc_path, a.max_concurrent, 10, a.max_user_jobs, 1,
                        a.retention_days, a.purge_on_logout, a.min_free_mb, a.user_quota_mb, a.total_quota_mb, a.heap_max_mb, tcp_envs,
                        csv(a.insecure_tls_clusters), csv(a.admin_users), a.idle_seconds or a.idle_minutes * 60,
                        28800, a.login_fail_limit, a.tick_seconds)
    try:
        n = count_credential_fields(a.clusters)
        if n:
            log.warning("clusters.json contains %d credential-like field(s). They are IGNORED by this portal (users supply their own "
                        "tokens). Remove them from the file and rotate those passwords.", n)
        app = App(settings)
    except (ConfigError, RuntimeError_) as exc:
        print("Startup error: %s" % exc, file=sys.stderr)
        sys.exit(1)
    for c in app.clusters():
        if not c["tls_verify"]:
            log.warning("TLS verification is OFF for cluster '%s' (explicit setting). Tokens sent there could be intercepted.", c["id"])
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    srv.app = app
    srv.allowed_hosts = {"127.0.0.1:%d" % a.port, "localhost:%d" % a.port}
    log.info("OpenShift Dump Collector %s on http://%s:%d (oc: %s; sessions idle out after %d s; results kept %d days after last login%s)",
             version(), a.host, a.port, app.oc.path or "NOT FOUND", settings.idle_seconds, a.retention_days,
             "; purge-on-logout ON" if a.purge_on_logout else "")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("Stopped.")
    finally:
        app.close()


if __name__ == "__main__":
    main()
