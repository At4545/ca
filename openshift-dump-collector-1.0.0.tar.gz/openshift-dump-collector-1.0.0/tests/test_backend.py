"""Backend tests: a real server process against the FAKE oc in tests/bin.
Run:  python3 -m unittest discover -s tests -v      (stdlib only; ~2 min)

Test tokens look like  sha256~<env>-<name>-xxxx...  (see tests/bin/oc). Users: alice (broad access),
bob (demo-dev only), carol (cannot exec). Each server runs with a BOGUS inherited KUBECONFIG to prove
the portal never uses the server's own login.
"""
import glob, http.cookies, json, os, socket, sqlite3, stat, struct, subprocess, sys, tempfile, threading, time, unittest
import urllib.error, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
FAKE_OC = os.path.join(ROOT, "tests", "bin", "oc")
CLUSTERS = os.path.join(ROOT, "tests", "clusters.test.json")
MB = 1024 * 1024


def put(path, data, mode="wb"):
    with open(path, mode) as fh:
        fh.write(data)
    return path


def tok(env, name):
    return "sha256~%s-%s-%s" % (env, name, "x" * 24)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class Client(object):
    """A 'browser': keeps its own session cookie."""
    def __init__(self, port):
        self.base = "http://127.0.0.1:%d" % port
        self.cookie = None
        self.last_set_cookie = None

    def call(self, method, path, body=None, headers=None, raw=False):
        h = {"Content-Type": "application/json"} if method == "POST" else {}
        if self.cookie:
            h["Cookie"] = "dc_session=" + self.cookie
        h.update(headers or {})
        data = json.dumps(body).encode() if body is not None else (b"{}" if method == "POST" else None)
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            r = urllib.request.urlopen(req, timeout=60)
            code, content, hdrs = r.status, r.read(), r.headers
        except urllib.error.HTTPError as e:
            code, content, hdrs = e.code, e.read(), e.headers
        for sc in hdrs.get_all("Set-Cookie") or []:
            self.last_set_cookie = sc
            m = http.cookies.SimpleCookie(sc).get("dc_session")
            if m is not None:
                self.cookie = m.value or None
        if raw:
            return code, content, hdrs
        try:
            return code, json.loads(content or b"null")
        except ValueError:
            return code, content

    def login(self, cluster="example-dev-1", env="dev", name="alice"):
        return self.call("POST", "/api/auth/login", {"cluster": cluster, "token": tok(env, name)})

    def logout(self, cluster=None):
        return self.call("POST", "/api/auth/logout", {"cluster": cluster} if cluster else {})


class ServerCase(unittest.TestCase):
    EXTRA = []
    CLUSTERS_FILE = CLUSTERS

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.port = free_port()
        cls.storage = os.path.join(cls.tmp, "storage")
        cls.logs = os.path.join(cls.tmp, "logs")
        cls.rt = os.path.join(cls.tmp, "rt")
        env = dict(os.environ, TMPDIR=cls.tmp, KUBECONFIG="/nonexistent/admin-kubeconfig")
        cls.proc = subprocess.Popen(
            [sys.executable, os.path.join(ROOT, "server.py"), "--port", str(cls.port), "--clusters", cls.CLUSTERS_FILE,
             "--storage", cls.storage, "--logs", cls.logs, "--runtime-dir", cls.rt, "--oc-path", FAKE_OC,
             "--tcp-envs", "DEV,PROD", "--max-concurrent", "4", "--login-fail-limit", "100", "--heap-max-mb", "64"] + cls.EXTRA,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
        cls.admin = Client(cls.port)
        for _ in range(60):
            try:
                if cls.admin.call("GET", "/api/health")[0] == 200:
                    break
            except Exception:
                time.sleep(0.1)

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(5)

    # ---- helpers
    def user(self, name="alice", env="dev", cluster="example-dev-1"):
        c = Client(self.port)
        code, r = c.login(cluster, env, name)
        self.assertEqual(code, 200, r)
        return c

    def req(self, cluster="example-dev-1", ns="demo-dev", pod="java-ok", container="app", **opts):
        body = {"cluster": cluster, "namespace": ns, "pod": pod, "container": container, "dump_type": "thread",
                "options": {"timeout": 60, "count": 1, "interval": 1, "size_limit_mb": 5}}
        body["options"].update(opts.pop("options", {}))
        body.update(opts)
        return body

    def treq(self, cluster="example-dev-1", ns="demo-dev", pod="tcp-ok", container="app", **opts):
        body = {"cluster": cluster, "namespace": ns, "pod": pod, "container": container, "dump_type": "tcp",
                "options": {"timeout": 60, "duration": 5, "size_limit_mb": 5}}
        body["options"].update(opts.pop("options", {}))
        body.update(opts)
        return body

    def hreq(self, cluster="example-dev-1", ns="demo-dev", pod="heap-ok", container="app", **opts):
        body = {"cluster": cluster, "namespace": ns, "pod": pod, "container": container, "dump_type": "heap",
                "options": {"timeout": 120, "size_limit_mb": 5}, "confirm_heap": True}
        body["options"].update(opts.pop("options", {}))
        body.update(opts)
        return body

    def wait(self, c, job_id, want=("Completed", "Failed", "Cancelled"), t=40):
        end, j = time.time() + t, None
        while time.time() < end:
            j = c.call("GET", "/api/jobs/" + job_id)[1]["job"]
            if j["status"] in want:
                return j
            time.sleep(0.3)
        self.fail("job did not finish: %s" % j)

    def run_job(self, c, body):
        code, r = c.call("POST", "/api/jobs", body)
        self.assertEqual(code, 202, r)
        return self.wait(c, r["job"]["id"])

    def audit(self):
        with open(os.path.join(self.logs, "audit.log")) as fh:
            return [json.loads(l) for l in fh]

    def dumps_dir(self):
        return os.listdir(os.path.join(self.storage, "dumps"))

    def validate(self, c, body):
        code, r = c.call("POST", "/api/validate", body)
        self.assertEqual(code, 200, r)
        return r

    def failing(self, c, body):
        r = self.validate(c, body)
        self.assertFalse(r["ok"], r)
        return [x for x in r["checks"] if not x["ok"]][0]

    def fake_log(self):
        p = os.path.join(self.tmp, "fake-oc.log")
        if not os.path.exists(p):
            return []
        with open(p) as fh:
            return [json.loads(l) for l in fh]

    def remote(self, pod):
        d = os.path.join(self.tmp, "fakefs", pod)
        return os.listdir(d) if os.path.isdir(d) else []


# ======================================================================= authentication & sessions
class TestAuth(ServerCase):
    def test_login_ok_cookie_flags_and_no_token_echo(self):
        c = Client(self.port)
        code, raw, hdrs = c.call("POST", "/api/auth/login", {"cluster": "example-dev-1", "token": tok("dev", "alice")}, raw=True)
        self.assertEqual(code, 200)
        self.assertNotIn(b"sha256~", raw); self.assertNotIn(b"xxxxxxxx", raw)
        self.assertIn("HttpOnly", c.last_set_cookie); self.assertIn("SameSite=Strict", c.last_set_cookie)
        info = json.loads(raw)
        self.assertEqual([(x["cluster_id"], x["identity"]) for x in info["connected"]], [("example-dev-1", "alice")])
        code, raw, _ = c.call("GET", "/api/session", raw=True)
        self.assertNotIn(b"sha256~", raw)

    def test_whitespace_around_token_is_tolerated(self):
        c = Client(self.port)
        code, _ = c.call("POST", "/api/auth/login", {"cluster": "example-dev-1", "token": "  " + tok("dev", "alice") + "\n"})
        self.assertEqual(code, 200)

    def test_bad_token_formats_rejected_before_contacting_cluster(self):
        n0 = len(self.fake_log())
        for bad in ("", "abc", "sha256~short", "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ4In0.abcdefghijklmnop", "sha256~" + "a" * 200,
                    "sha256~dev-alice-xxxxxxxxxxxxxxxxxxxxxxxx; id", None, 12345, ["sha256~dev-alice-" + "x" * 24]):
            c = Client(self.port)
            code, r = c.call("POST", "/api/auth/login", {"cluster": "example-dev-1", "token": bad})
            self.assertEqual((code, r.get("reason")), (400, "bad_token_format"), bad)
            self.assertIsNone(c.cookie)
        self.assertEqual(len(self.fake_log()), n0)

    def test_service_account_or_system_identity_rejected(self):
        c = Client(self.port)
        code, r = c.login(name="systemadmin")
        self.assertEqual((code, r["reason"]), (401, "not_a_user_token")); self.assertIsNone(c.cookie)

    def test_expired_and_wrong_cluster_tokens_rejected(self):
        c = Client(self.port)
        code, r = c.login(name="expired"); self.assertEqual((code, r["reason"]), (401, "token_rejected")); self.assertIsNone(c.cookie)
        code, r = c.login(env="prod", name="alice")            # a PROD token must not work on a DEV cluster
        self.assertEqual(code, 401); self.assertIsNone(c.cookie)
        self.assertNotIn("sha256~", json.dumps(r))

    def test_untrusted_certificate_refused_by_default_but_explicit_opt_out_works(self):
        c = Client(self.port)
        code, r = c.login("example-test-1", "test", "alice")
        self.assertEqual(code, 502); self.assertIn("not trusted", r["error"]); self.assertIn("tls_verify", r["error"])
        code, r = c.login("example-selfsigned", "selfsigned", "alice")     # tls_verify:false in clusters.json for this one
        self.assertEqual(code, 200, r)
        seen = {(e["server"], e["insecure"]) for e in self.fake_log()}
        self.assertIn(("https://api.dev.example.com:6443", False) if False else ("https://api.selfsigned.example.com:6443", True), seen)
        self.assertTrue(all(not ins for srv, ins in seen if "dev.example" in srv or "test.example" in srv))
        self.assertTrue([e for e in self.audit() if e["event"] == "login_success" and e["cluster"] == "example-selfsigned" and e["tls_verify"] is False])

    def test_disabled_cluster_cannot_be_logged_into(self):
        self.assertEqual(Client(self.port).login("example-dev-off", "dev", "alice")[0], 409)

    def test_endpoints_require_a_connection(self):
        c = Client(self.port)
        code, r = c.call("GET", "/api/clusters/example-dev-1/namespaces"); self.assertEqual((code, r["reason"]), (401, "not_connected"))
        self.assertEqual(c.call("GET", "/api/clusters/example-dev-1/namespaces/demo-dev/pods")[0], 401)
        self.assertEqual(c.call("POST", "/api/validate", self.req())[0], 401)
        self.assertEqual(c.call("POST", "/api/jobs", self.req())[0], 401)
        self.assertEqual(c.call("GET", "/api/jobs")[1]["jobs"], [])
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"], [])

    def test_connected_to_one_cluster_is_not_connected_to_another(self):
        c = self.user()
        self.assertEqual(c.call("GET", "/api/clusters/example-prod-1/namespaces")[1]["reason"], "not_connected")

    def test_users_only_see_what_their_own_token_allows(self):
        a, b = self.user("alice"), self.user("bob")
        self.assertEqual(a.call("GET", "/api/clusters/example-dev-1/namespaces")[1]["namespaces"], ["demo-dev", "demo-prod", "locked", "readonly"])
        r = b.call("GET", "/api/clusters/example-dev-1/namespaces")[1]
        self.assertEqual((r["namespaces"], r["identity"]), (["demo-dev"], "bob"))
        self.assertEqual(b.call("GET", "/api/clusters/example-dev-1/namespaces/demo-prod/pods")[0], 403)
        self.assertEqual(a.call("GET", "/api/clusters/example-dev-1/namespaces/demo-prod/pods")[0], 200)
        self.assertEqual(self.failing(b, self.req(ns="demo-prod"))["name"], "Namespace and pod access")
        self.assertEqual(self.failing(self.user("carol"), self.req())["name"], "Exec permission")

    def test_token_revoked_on_the_cluster_is_dropped_by_the_server(self):
        c = self.user("dave")
        self.assertEqual(c.call("GET", "/api/clusters/example-dev-1/namespaces")[0], 200)
        put(os.path.join(self.tmp, "revoked-dave"), "", "w")               # the cluster now rejects dave's token
        code, r = c.call("GET", "/api/clusters/example-dev-1/namespaces")
        self.assertEqual((code, r["reason"]), (401, "token_rejected")); self.assertIn("rejected your token", r["error"])
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"], [])      # server stopped holding it
        self.assertEqual(c.call("GET", "/api/clusters/example-dev-1/namespaces")[1]["reason"], "not_connected")
        os.remove(os.path.join(self.tmp, "revoked-dave"))
        c = self.user("dave"); put(os.path.join(self.tmp, "revoked-dave"), "", "w")
        code, r = c.call("POST", "/api/validate", self.req())                    # validate path drops it too
        self.assertEqual(code, 200); self.assertTrue(r["token_rejected"]); self.assertFalse(r["ok"])
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"], [])
        os.remove(os.path.join(self.tmp, "revoked-dave"))

    def test_logout_one_cluster_then_all(self):
        c = self.user("alice"); self.assertEqual(c.login("example-selfsigned", "selfsigned", "alice")[0], 200)
        code, r = c.logout("example-dev-1"); self.assertEqual(code, 200)
        self.assertEqual([x["cluster_id"] for x in r["connected"]], ["example-selfsigned"])
        self.assertEqual(c.call("GET", "/api/clusters/example-dev-1/namespaces")[0], 401)
        self.assertEqual(c.call("GET", "/api/clusters/example-selfsigned/namespaces")[0], 200)
        code, r = c.logout(); self.assertEqual(r["connected"], [])
        self.assertEqual(c.call("GET", "/api/clusters/example-selfsigned/namespaces")[0], 401)
        self.assertIn("Max-Age=0", c.last_set_cookie)
        ev = [e["event"] for e in self.audit()]; self.assertIn("logout", ev); self.assertIn("session_ended", ev)

    def test_forged_or_garbage_cookie_is_not_a_session(self):
        c = Client(self.port); c.cookie = "A" * 43
        self.assertEqual(c.call("GET", "/api/clusters/example-dev-1/namespaces")[0], 401)
        self.assertEqual(c.call("GET", "/api/jobs", headers={"Cookie": "dc_session=;;;\x00bad"})[1]["jobs"], [])

    def test_token_never_in_argv_env_files_logs_or_db(self):
        a = self.user("alice")
        self.run_job(a, self.req()); self.run_job(a, self.hreq())
        log = self.fake_log()
        self.assertTrue(log)
        self.assertEqual([e for e in log if e["violations"]], [])                 # no token in argv/env, modes 0600/0700
        self.assertTrue(all(e["kubeconfig"].startswith(self.rt + os.sep) for e in log))   # never the inherited KUBECONFIG
        self.assertEqual(os.listdir(self.rt), [])                                  # every kubeconfig deleted after use
        self.assertEqual(stat.S_IMODE(os.stat(self.rt).st_mode), 0o700)
        needle = b"sha256~"
        for root, _, files in os.walk(self.tmp):
            for f in files:
                p = os.path.join(root, f)
                if "fake-oc.log" in p or "/fakefs/" in p or p.endswith(".hprof") or "/dumps/" in p:
                    continue
                with open(p, "rb") as fh:
                    self.assertNotIn(needle, fh.read(), p)                          # audit/app logs, sqlite db, wal

    def test_audit_has_no_secrets(self):
        self.user("alice")
        with open(os.path.join(self.logs, "audit.log")) as fh:
            text = fh.read()
        for bad in ("SHOULD-NEVER-LEAK", "password", "sha256~", "Bearer", "xxxxxxxx"):
            self.assertNotIn(bad, text)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(self.logs, "audit.log")).st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(self.storage, "portal.db")).st_mode), 0o600)


class TestLoginThrottle(ServerCase):
    EXTRA = ["--login-fail-limit", "3"]

    def test_repeated_failures_are_throttled(self):
        c = Client(self.port)
        for _ in range(3):
            self.assertEqual(c.login(name="expired")[0], 401)
        code, r = c.login(name="alice")
        self.assertEqual((code, r["reason"]), (429, "rate_limited"))


class TestSessionExpiry(ServerCase):
    EXTRA = ["--idle-seconds", "2", "--tick-seconds", "1"]

    def test_idle_session_is_ended_and_token_forgotten(self):
        c = self.user()
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"][0]["identity"], "alice")
        time.sleep(4)
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"], [])
        self.assertEqual(c.call("GET", "/api/clusters/example-dev-1/namespaces")[0], 401)
        self.assertIn("idle", [e.get("reason") for e in self.audit() if e["event"] == "session_ended"])

    def test_activity_keeps_session_alive(self):
        c = self.user()
        for _ in range(5):
            time.sleep(1); self.assertEqual(c.call("GET", "/api/clusters")[0], 200)
        self.assertEqual(len(c.call("GET", "/api/session")[1]["connected"]), 1)

    def test_polling_session_status_does_not_keep_it_alive(self):
        c = self.user()
        for _ in range(8):
            time.sleep(0.5); c.call("GET", "/api/session")
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"], [])

    def test_running_job_keeps_session_alive_until_it_ends(self):
        c = self.user()
        code, r = c.call("POST", "/api/jobs", self.req(pod="slow")); jid = r["job"]["id"]
        self.wait(c, jid, want=("Running",))
        time.sleep(4.5)                                                            # idle limit is 2 s
        self.assertEqual(len(c.call("GET", "/api/session", )[1]["connected"]), 1)
        c.call("POST", "/api/jobs/%s/cancel" % jid); self.wait(c, jid, t=15)
        time.sleep(4)
        self.assertEqual(c.call("GET", "/api/session")[1]["connected"], [])


class TestOwnership(ServerCase):
    def test_jobs_are_private_to_their_owner(self):
        a, b = self.user("alice"), self.user("bob")
        j = self.run_job(a, self.req())
        self.assertEqual(j["status"], "Completed"); self.assertEqual(j["requested_by"], "alice")
        self.assertIn(j["id"], [x["id"] for x in a.call("GET", "/api/jobs")[1]["jobs"]])
        self.assertEqual(b.call("GET", "/api/jobs")[1]["jobs"], [])
        for path in ("/api/jobs/" + j["id"], "/api/jobs/%s/download" % j["id"]):
            self.assertEqual(b.call("GET", path, raw=True)[0], 404, path)
        self.assertEqual(b.call("POST", "/api/jobs/%s/cancel" % j["id"])[0], 404)
        self.assertEqual(b.call("POST", "/api/jobs/%s/delete" % j["id"])[0], 404)
        self.assertEqual(Client(self.port).call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 401)
        self.assertEqual(a.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 200)

    def test_same_identity_in_another_browser_sees_the_same_jobs(self):
        a1 = self.user("alice"); j = self.run_job(a1, self.req())
        a2 = self.user("alice")
        self.assertIn(j["id"], [x["id"] for x in a2.call("GET", "/api/jobs")[1]["jobs"]])
        self.assertEqual(a2.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 200)

    def test_jobs_are_bound_to_the_cluster(self):
        a = self.user("alice"); j = self.run_job(a, self.req())
        p = self.user("alice", "prod", "example-prod-1")      # same name on a different cluster is a different identity
        self.assertNotIn(j["id"], [x["id"] for x in p.call("GET", "/api/jobs")[1]["jobs"]])

    def test_results_survive_logout_and_relogin_by_default(self):
        a = self.user("alice"); j = self.run_job(a, self.req()); a.logout()
        self.assertEqual(a.call("GET", "/api/jobs")[1]["jobs"], [])
        again = self.user("alice")
        got = [x for x in again.call("GET", "/api/jobs")[1]["jobs"] if x["id"] == j["id"]][0]
        self.assertEqual(got["status"], "Completed")
        self.assertEqual(again.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 200)

    def test_owner_can_delete_result(self):
        a = self.user("alice"); j = self.run_job(a, self.req())
        r = a.call("POST", "/api/jobs/%s/delete" % j["id"])[1]["job"]
        self.assertEqual(r["status"], "Expired"); self.assertFalse(r["download_available"])
        self.assertNotIn(j["download_name"], self.dumps_dir())
        self.assertEqual(a.call("POST", "/api/jobs/%s/delete" % j["id"])[0], 409)
        self.assertIn("file_deleted", [e["event"] for e in self.audit() if e.get("job_id") == j["id"]])

    def test_logout_cancels_running_jobs_and_cleans_up(self):
        a = self.user("alice")
        code, r = a.call("POST", "/api/jobs", self.req(pod="slow")); jid = r["job"]["id"]
        self.wait(a, jid, want=("Running",)); a.logout()
        b = self.user("alice")                                               # same identity, new session
        j = self.wait(b, jid, t=20)
        self.assertEqual(j["status"], "Cancelled")
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")])
        self.assertEqual(os.listdir(self.rt), [])


class TestPurgeOnLogout(ServerCase):
    EXTRA = ["--purge-on-logout"]

    def test_results_are_removed_when_the_session_ends(self):
        a = self.user("alice"); j = self.run_job(a, self.req())
        self.assertIn(j["download_name"], self.dumps_dir())
        a.logout()
        self.assertNotIn(j["download_name"], self.dumps_dir())
        b = self.user("alice")
        got = [x for x in b.call("GET", "/api/jobs")[1]["jobs"] if x["id"] == j["id"]][0]
        self.assertEqual(got["status"], "Expired"); self.assertIn("purge-on-logout", got["error"])
        self.assertEqual(b.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 409)


# ======================================================================= connectivity & admin
class TestConnectivity(ServerCase):
    def test_real_checks_without_any_login(self):
        c = Client(self.port)
        code, r = c.call("POST", "/api/clusters/check")
        self.assertEqual(code, 200)
        by = {x["id"]: x["connectivity"] for x in r["clusters"]}
        self.assertEqual(by["example-dev-1"]["status"], "reachable"); self.assertEqual(by["example-dev-1"]["version"], "v1.27.6+fake")
        self.assertEqual(by["example-prod-1"]["status"], "reachable"); self.assertIn("anonymous", by["example-prod-1"]["note"])
        self.assertEqual(by["example-test-1"]["status"], "tls_error")
        self.assertEqual(by["example-selfsigned"]["status"], "reachable")        # explicit tls_verify:false
        self.assertEqual(by["example-down"]["status"], "unreachable")
        self.assertTrue(all(v["latency_ms"] >= 0 for v in by.values()))
        self.assertEqual(c.call("GET", "/api/clusters")[1]["clusters"][0]["connectivity"]["status"], "reachable")

    def test_results_are_cached_briefly_and_single_check_forces_refresh(self):
        c = Client(self.port)
        t1 = {x["id"]: x["connectivity"]["checked_at"] for x in c.call("POST", "/api/clusters/check")[1]["clusters"]}
        t2 = {x["id"]: x["connectivity"]["checked_at"] for x in c.call("POST", "/api/clusters/check")[1]["clusters"]}
        self.assertEqual(t1, t2)
        t3 = {x["id"]: x["connectivity"]["checked_at"] for x in c.call("POST", "/api/clusters/example-dev-1/check")[1]["clusters"]}
        self.assertGreater(t3["example-dev-1"], t1["example-dev-1"]); self.assertEqual(t3["example-prod-1"], t1["example-prod-1"])
        self.assertEqual(c.call("POST", "/api/clusters/nope/check")[0], 404)

    def test_probe_sends_no_token(self):
        Client(self.port).call("POST", "/api/clusters/check")
        probes = [e for e in self.fake_log() if e["argv"][:1] == ["get"] and not e["has_token"]]
        self.assertTrue(probes)


class TestAdmin(ServerCase):
    EXTRA = ["--admin-users", "example-dev-1:alice"]

    def test_only_listed_admins_can_toggle(self):
        self.assertEqual(Client(self.port).call("POST", "/api/clusters/example-selfsigned/enabled", {"enabled": False})[0], 401)
        b = self.user("bob")
        code, r = b.call("POST", "/api/clusters/example-selfsigned/enabled", {"enabled": False}); self.assertEqual((code, r["reason"]), (403, "not_admin"))
        self.assertFalse(b.call("GET", "/api/session")[1]["admin"])
        a = self.user("alice"); self.assertTrue(a.call("GET", "/api/session")[1]["admin"])
        self.assertEqual(a.call("POST", "/api/clusters/example-selfsigned/enabled", {"enabled": "no"})[0], 400)
        self.assertEqual(a.call("POST", "/api/clusters/nope/enabled", {"enabled": False})[0], 404)
        code, r = a.call("POST", "/api/clusters/example-selfsigned/enabled", {"enabled": False}); self.assertEqual(code, 200)
        c = [x for x in r["clusters"] if x["id"] == "example-selfsigned"][0]
        self.assertFalse(c["enabled"]); self.assertEqual(c["enabled_by_admin"], "alice")
        self.assertEqual(Client(self.port).login("example-selfsigned", "selfsigned", "alice")[0], 409)
        a.call("POST", "/api/clusters/example-selfsigned/enabled", {"enabled": True})
        self.assertEqual(Client(self.port).login("example-selfsigned", "selfsigned", "alice")[0], 200)
        ev = [e for e in self.audit() if e["event"] == "cluster_toggle"]; self.assertEqual([e["enabled"] for e in ev], [False, True])

    def test_admin_on_other_cluster_identity_does_not_count(self):
        # 'alice' on the selfsigned cluster is NOT the configured admin (the list names example-dev-1:alice)
        c = Client(self.port); c.login("example-selfsigned", "selfsigned", "alice")
        self.assertFalse(c.call("GET", "/api/session")[1]["admin"])


class TestInsecureFlag(ServerCase):
    EXTRA = ["--insecure-tls-clusters", "example-test-1"]

    def test_cli_flag_enables_untrusted_cluster_only_where_named(self):
        c = Client(self.port)
        self.assertEqual(c.login("example-test-1", "test", "alice")[0], 200)
        cl = {x["id"]: x["tls_verify"] for x in c.call("GET", "/api/clusters")[1]["clusters"]}
        self.assertEqual((cl["example-test-1"], cl["example-dev-1"], cl["example-selfsigned"]), (False, True, False))

    def test_tcp_policy_refuses_environments_that_are_not_enabled_before_contacting_the_cluster(self):
        c = Client(self.port); c.login("example-test-1", "test", "alice")               # TEST is not in --tcp-envs (DEV,PROD here)
        n0 = len(self.fake_log())
        j = self.run_job(c, self.treq(cluster="example-test-1"))
        self.assertEqual(j["status"], "Failed"); self.assertIn("not enabled for TEST", j["error"])
        self.assertEqual([x["name"] for x in j["checks"]], ["Cluster configuration", "Capture policy"])
        self.assertEqual(len(self.fake_log()), n0)                                       # no oc call was made at all


# ======================================================================= request security & validation
class TestRequestSecurity(ServerCase):
    def test_bad_content_type_origin_host(self):
        a = self.user()
        self.assertEqual(a.call("POST", "/api/validate", self.req(), headers={"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(a.call("POST", "/api/validate", self.req(), headers={"Origin": "http://evil.example"})[0], 403)
        self.assertEqual(a.call("POST", "/api/auth/login", {"cluster": "example-dev-1", "token": tok("dev", "alice")},
                                headers={"Origin": "http://evil.example"})[0], 403)
        self.assertEqual(a.call("GET", "/api/clusters", headers={"Host": "evil.com"})[0], 400)

    def test_static_whitelist(self):
        a = Client(self.port)
        for p in ("/clusters.json", "/server.py", "/backend/configuration.py", "/diagnostics/heap_dump.py", "/storage/portal.db",
                  "/VERSION", "/tests/bin/oc"):
            self.assertEqual(a.call("GET", p, raw=True)[0], 404, p)

    def test_clusters_endpoint_hides_credentials(self):
        code, raw, _ = Client(self.port).call("GET", "/api/clusters", raw=True)
        self.assertNotIn(b"SHOULD-NEVER-LEAK", raw); self.assertNotIn(b"password", raw.lower())

    def test_invalid_inputs(self):
        a = self.user()
        bad = [self.req(pod="../etc/passwd"), self.req(pod="a; rm -rf /"), self.req(namespace="Bad_NS"), self.req(container="app\nid"),
               self.req(cluster="x" * 200), self.req(options={"timeout": 5}), self.req(options={"count": 99}),
               self.req(options={"bogus": 1}), self.req(options={"count": 5, "interval": 30, "timeout": 60}), self.req(dump_type="rm"),
               self.req(options={"filter": "tcp"}), self.req(options={"duration": 10}),
               self.hreq(options={"size_limit_mb": 65}), self.hreq(options={"timeout": 60}), self.hreq(options={"count": 2}),
               self.hreq(options={"filter": "tcp"}), self.hreq(options={"size_limit_mb": 0})]
        for b in bad:
            code, r = a.call("POST", "/api/validate", b)
            self.assertEqual(code, 400, (b["options"], r))

    def test_unknown_fields_ignored_not_executed(self):
        a = self.user()
        self.assertEqual(a.call("POST", "/api/validate", dict(self.req(), command="rm -rf /", shell=True, token="x"))[0], 200)


class TestValidateEndpoint(ServerCase):
    def test_ok_and_checks_run_as_the_user(self):
        a = self.user(); r = self.validate(a, self.req())
        self.assertTrue(r["ok"], r)
        self.assertTrue(any("authenticated as 'alice'" in c["message"] for c in r["checks"]))
        self.assertTrue(any("jcmd" in c["message"] for c in r["checks"]))

    def test_failures(self):
        a = self.user()
        self.assertEqual(self.failing(a, self.req(pod="ghost"))["name"], "Namespace and pod access")
        self.assertIn("denied", self.failing(a, self.req(ns="locked"))["message"].lower())
        self.assertEqual(self.failing(a, self.req(ns="readonly"))["name"], "Exec permission")
        c = self.failing(a, self.req(container="other")); self.assertEqual(c["name"], "Container"); self.assertIn("app", c["message"])
        self.assertEqual(self.failing(a, self.req(pod="pending-pod"))["name"], "Container")
        self.assertIn("Neither jcmd nor jstack", self.failing(a, self.req(pod="no-jdk"))["message"])
        self.assertIn("No Java process", self.failing(a, self.req(pod="no-java"))["message"])
        self.assertIn("Several Java processes", self.failing(a, self.req(pod="two-jvm"))["message"])
        self.assertIn("no /bin/sh", self.failing(a, self.req(pod="java-multi", container="sidecar"))["message"])

    def test_prod_validate_does_not_probe_without_confirm(self):
        p = self.user("alice", "prod", "example-prod-1")
        r = self.validate(p, self.req(cluster="example-prod-1", ns="demo-prod"))
        self.assertTrue(r["ok"]); self.assertTrue([c for c in r["checks"] if c["skipped"]])
        self.assertFalse(any("single JVM" in c["message"] for c in r["checks"]))


# ======================================================================= thread dump
class TestThreadCollection(ServerCase):
    def test_end_to_end(self):
        a = self.user(); j = self.run_job(a, self.req(options={"count": 2, "interval": 1}))
        self.assertEqual(j["status"], "Completed", j); self.assertEqual(j["requested_by"], "alice")
        code, raw, hdrs = a.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)
        self.assertEqual(code, 200); text = raw.decode()
        self.assertEqual(text.count("===== Thread dump"), 2); self.assertEqual(text.count("Full thread dump"), 2)
        self.assertIn("attachment", hdrs["Content-Disposition"]); self.assertEqual(len(raw), j["size_bytes"])
        path = os.path.join(self.storage, "dumps", j["download_name"])
        self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(os.stat(os.path.join(self.storage, "dumps")).st_mode), 0o700)
        ev = [e["event"] for e in self.audit() if e.get("job_id") == j["id"]]
        for x in ("job_requested", "job_started", "job_completed", "file_download"):
            self.assertIn(x, ev)
        self.assertTrue(all(e["user"] == "alice" for e in self.audit() if e.get("job_id") == j["id"]))

    def test_jstack_fallback_and_failures(self):
        a = self.user()
        self.assertIn("via=jstack", a.call("GET", "/api/jobs/%s/download" % self.run_job(a, self.req(pod="jstack-only"))["id"], raw=True)[1].decode())
        j = self.run_job(a, self.req(pod="no-jdk")); self.assertEqual(j["status"], "Failed"); self.assertIsNone(j["download_name"])
        self.assertEqual(a.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 409)
        j = self.run_job(a, self.req(pod="attach-fail")); self.assertIn("refused the attach", j["error"])
        j = self.run_job(a, self.req(pod="garbage")); self.assertIn("does not look like a thread dump", j["error"])
        before = set(self.dumps_dir())
        j = self.run_job(a, self.req(pod="huge", options={"size_limit_mb": 1})); self.assertIn("size limit", j["error"])
        self.assertEqual(set(self.dumps_dir()) - before, set())
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")])

    def test_prod_requires_confirmation_server_side(self):
        p = self.user("alice", "prod", "example-prod-1")
        j = self.run_job(p, self.req(cluster="example-prod-1", ns="demo-prod")); self.assertIn("explicit confirmation", j["error"])
        j = self.run_job(p, self.req(cluster="example-prod-1", ns="demo-prod", confirm_prod=True)); self.assertEqual(j["status"], "Completed", j)

    def test_cancel_kills_and_cleans_and_limits(self):
        a = self.user(); code, r = a.call("POST", "/api/jobs", self.req(pod="slow")); jid = r["job"]["id"]
        self.wait(a, jid, want=("Running",)); time.sleep(1)
        self.assertEqual(a.call("POST", "/api/jobs", self.req(pod="slow"))[0], 409)
        b = self.user("bob"); code, r2 = b.call("POST", "/api/jobs", self.req(pod="slow"))
        self.assertEqual(code, 409); self.assertNotIn(jid, json.dumps(r2))        # other users' job ids are not revealed
        t0 = time.time(); self.assertEqual(a.call("POST", "/api/jobs/%s/cancel" % jid)[0], 200)
        j = self.wait(a, jid, t=15); self.assertEqual(j["status"], "Cancelled"); self.assertLess(time.time() - t0, 15)
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")])
        self.assertEqual(a.call("POST", "/api/jobs/%s/cancel" % jid)[0], 409)
        self.assertEqual(os.listdir(self.rt), [])

    def test_download_path_safety(self):
        a = self.user()
        for jid in ("..%2f..%2fetc%2fpasswd", "20250101-000000-zzzzzzzz", "nope"):
            self.assertEqual(a.call("GET", "/api/jobs/%s/download" % jid, raw=True)[0], 404)


# ======================================================================= TCP capture
class TestTcp(ServerCase):
    def scan(self, raw):
        from diagnostics import pcap
        p = os.path.join(self.tmp, "dl.pcap")
        put(p, raw)
        return pcap.scan(p)

    def test_validation(self):
        a = self.user()
        bad = [self.treq(options={"filter": "rm -rf /"}), self.treq(options={"filter": "port"}), self.treq(options={"filter": "port", "port": 0}),
               self.treq(options={"filter": "port", "port": "80; id"}), self.treq(options={"filter": "tcp", "port": 80}),
               self.treq(options={"peer_ip": "1.2.3.4; id"}), self.treq(options={"peer_ip": "1.2.3.4 or host 5.6.7.8"}),
               self.treq(options={"peer_ip": "fe80::1%eth0"}), self.treq(options={"peer_ip": ["1.2.3.4"]}),
               self.treq(options={"payload": "everything"}), self.treq(options={"duration": 2}),
               self.treq(options={"duration": 50, "timeout": 60}), self.treq(options={"count": 3}), self.treq(options={"size_limit_mb": 501}),
               self.treq(options={"command": "tcpdump -w /etc/passwd"})]
        for b in bad:
            self.assertEqual(a.call("POST", "/api/validate", b)[0], 400, b["options"])

    def test_expression_builder_and_command(self):
        from diagnostics.tcp_dump import build_expression as b, capture_command
        self.assertIsNone(b("all")); self.assertEqual(b("port", 8080), "tcp port 8080")
        self.assertEqual(b("dns", None, "10.0.0.9"), "(port 53) and host 10.0.0.9")
        for args in (("bogus",), ("port", "x"), ("port", 0), ("all", None, "1.1.1.1; id")):
            with self.assertRaises(Exception): b(*args)
        cmd = capture_command(30, 128, "tcp port 80")
        self.assertEqual(cmd[:6], ["timeout", "-s", "INT", "30", "tcpdump", "-n"]); self.assertNotIn("sh", cmd)
        self.assertEqual(cmd[cmd.index("-w") + 1], "-")

    def test_policy_and_probe_failures(self):
        a = self.user()
        self.assertTrue(self.validate(a, self.treq())["ok"])
        c = self.failing(a, self.treq(pod="tcp-noperm")); self.assertIn("NET_RAW", c["message"]); self.assertIn("never grants", c["message"])
        self.assertIn("tcpdump was not found", self.failing(a, self.treq(pod="no-tcpdump"))["message"])
        self.assertIn("'timeout' utility is missing", self.failing(a, self.treq(pod="no-timeout"))["message"])
        self.assertEqual(self.failing(a, self.treq(options={"payload": "full"}))["name"], "Capture policy")
        self.assertTrue(self.validate(a, self.treq(options={"payload": "full"}, confirm_payload=True))["ok"])
        p = self.user("alice", "prod", "example-prod-1")
        c = self.failing(p, self.treq(cluster="example-prod-1", ns="demo-prod")); self.assertIn("narrowed", c["message"])
        self.assertTrue(self.validate(p, self.treq(cluster="example-prod-1", ns="demo-prod", options={"filter": "tcp"}))["ok"])

    def test_end_to_end(self):
        a = self.user()
        j = self.run_job(a, self.treq(options={"filter": "port", "port": 8080, "peer_ip": "10.1.2.3"}))
        self.assertEqual(j["status"], "Completed", j); self.assertEqual((j["packets"], j["note"]), (3, None))
        raw = a.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[1]
        info = self.scan(raw); self.assertEqual((info["packets"], info["trailing_bytes"]), (3, 0))
        text = raw.decode("latin1")
        self.assertIn("expr=(tcp port 8080) and host 10.1.2.3", text); self.assertIn("snap=128", text); self.assertIn("c=500000", text)
        ev = {e["event"]: e for e in self.audit() if e.get("job_id") == j["id"]}
        self.assertEqual(ev["job_started"]["filter_expression"], "(tcp port 8080) and host 10.1.2.3")
        self.assertEqual(ev["job_completed"]["packets"], 3)

    def test_failure_modes_leave_nothing_behind(self):
        a = self.user(); before = set(self.dumps_dir())
        self.assertIn("NET_RAW", self.run_job(a, self.treq(pod="tcp-noperm"))["error"])
        self.assertIn("not a valid pcap", self.run_job(a, self.treq(pod="tcp-garbage"))["error"])
        self.assertIn("size limit", self.run_job(a, self.treq(pod="tcp-huge", options={"size_limit_mb": 1}))["error"])
        self.assertIn("credentials", self.run_job(a, self.treq(options={"payload": "full"}))["error"])
        self.assertEqual(set(self.dumps_dir()), before)
        j = self.run_job(a, self.treq(pod="tcp-empty")); self.assertEqual((j["status"], j["packets"], j["size_bytes"]), ("Completed", 0, 24)); self.assertIn("0 packets", j["note"])
        j = self.run_job(a, self.treq(pod="tcp-trunc")); self.assertEqual((j["status"], j["packets"]), ("Completed", 3)); self.assertIn("incomplete final packet", j["note"])

    def test_prod_rules_end_to_end(self):
        p = self.user("alice", "prod", "example-prod-1")
        kw = dict(cluster="example-prod-1", ns="demo-prod")
        self.assertIn("narrowed", self.run_job(p, self.treq(**kw))["error"])
        self.assertIn("explicit confirmation", self.run_job(p, self.treq(options={"filter": "tls"}, **kw))["error"])
        j = self.run_job(p, self.treq(options={"filter": "tls"}, confirm_prod=True, **kw)); self.assertEqual(j["status"], "Completed", j)

    def test_cancel_and_progress_text(self):
        a = self.user(); code, r = a.call("POST", "/api/jobs", self.treq(pod="tcp-slow", options={"duration": 60, "timeout": 120})); jid = r["job"]["id"]
        self.wait(a, jid, want=("Running",)); time.sleep(0.6)
        j = a.call("GET", "/api/jobs/" + jid)[1]["job"]; self.assertIn("Capturing", j["stage"]); self.assertNotIn("%", j["stage"])
        self.assertEqual(a.call("POST", "/api/jobs", self.treq(pod="tcp-slow"))[0], 409)
        a.call("POST", "/api/jobs/%s/cancel" % jid); j = self.wait(a, jid, t=15); self.assertEqual(j["status"], "Cancelled")
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part") or jid in n])


# ======================================================================= heap dump
class TestHeap(ServerCase):
    def test_validation_and_dry_run_acknowledgement(self):
        a = self.user()
        r = self.validate(a, self.hreq(confirm_heap=False))
        self.assertTrue(r["ok"]); self.assertTrue([c for c in r["checks"] if c["name"] == "Heap dump policy" and c["skipped"]])
        r = self.validate(a, self.hreq()); self.assertTrue(r["ok"], r)
        self.assertTrue(any("Heap in use ~2 MB" in c["message"] for c in r["checks"]))

    def test_end_to_end(self):
        a = self.user(); j = self.run_job(a, self.hreq())
        self.assertEqual(j["status"], "Completed", j); self.assertEqual(j["size_bytes"], 1572864); self.assertIsNone(j["note"])
        self.assertTrue(j["download_name"].startswith("heap-dump_") and j["download_name"].endswith(".hprof"))
        code, raw, hdrs = a.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)
        self.assertEqual((code, len(raw)), (200, 1572864)); self.assertTrue(raw.startswith(b"JAVA PROFILE 1.0"))
        self.assertEqual(self.remote("heap-ok"), [])                                  # in-container file deleted
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")])
        path = os.path.join(self.storage, "dumps", j["download_name"]); self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
        self.assertEqual(len(j["sha256"]), 64)
        ev = [e for e in self.audit() if e.get("job_id") == j["id"]]
        self.assertTrue([e for e in ev if e["event"] == "job_requested" and e["heap_acknowledged"]])
        self.assertIn("job_completed", [e["event"] for e in ev])

    def test_jmap_only_and_unknown_heap_size(self):
        a = self.user()
        j = self.run_job(a, self.hreq(pod="heap-jmap")); self.assertEqual(j["status"], "Completed", j)
        j = self.run_job(a, self.hreq(pod="heap-noinfo")); self.assertEqual(j["status"], "Completed", j)
        self.assertTrue(any("could not be estimated" in c["message"] for c in j["checks"]))      # reserves the full limit instead

    def test_refusals_before_anything_is_dumped(self):
        a = self.user()
        for pod, text in (("heap-big", "Estimated dump size"), ("heap-nospace", "has 1 MB free"), ("heap-nodf", "could not be determined"),
                          ("heap-notmp", "not writable"), ("no-jdk", "Neither jcmd nor jmap")):
            j = self.run_job(a, self.hreq(pod=pod)); self.assertEqual(j["status"], "Failed", pod); self.assertIn(text, j["error"], pod)
            self.assertEqual(self.remote(pod), [], pod)
        self.assertIn("acknowledge", self.run_job(a, self.hreq(confirm_heap=False))["error"].lower())

    def test_failures_clean_both_sides(self):
        a = self.user(); before = set(self.dumps_dir())
        for pod, text in (("heap-fail", "Permission denied"), ("heap-toobig", "above your size limit"),
                          ("heap-trunc", "Incomplete transfer"), ("heap-garbage", "not a valid HPROF")):
            j = self.run_job(a, self.hreq(pod=pod)); self.assertEqual(j["status"], "Failed", pod); self.assertIn(text, j["error"], pod)
            self.assertEqual(self.remote(pod), [], pod)                               # remote file always deleted
            self.assertIsNone(j["download_name"])
        self.assertEqual(set(self.dumps_dir()), before)

    def test_remote_cleanup_failure_is_reported_loudly(self):
        a = self.user(); j = self.run_job(a, self.hreq(pod="heap-rmfail"))
        self.assertEqual(j["status"], "Completed", j)
        self.assertIn("ACTION NEEDED", j["note"]); self.assertIn("/tmp/portal-heap-%s.hprof" % j["id"], j["note"])
        self.assertEqual(self.remote("heap-rmfail"), ["portal-heap-%s.hprof" % j["id"]])

    def test_cancel_during_dump_removes_remote_file(self):
        a = self.user(); code, r = a.call("POST", "/api/jobs", self.hreq(pod="heap-slow")); jid = r["job"]["id"]
        self.wait(a, jid, want=("Running",))
        for _ in range(40):
            if self.remote("heap-slow"): break
            time.sleep(0.2)
        self.assertTrue(self.remote("heap-slow"))
        b = self.user("bob"); code, r2 = b.call("POST", "/api/jobs", self.hreq(pod="heap-ok"))
        self.assertEqual(code, 429); self.assertIn("one at a time", r2["error"])        # only one heap dump at a time
        a.call("POST", "/api/jobs/%s/cancel" % jid); j = self.wait(a, jid, t=30)
        self.assertEqual(j["status"], "Cancelled"); self.assertEqual(self.remote("heap-slow"), [])
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")]); self.assertEqual(os.listdir(self.rt), [])

    def test_prod_needs_confirmation_and_typed_cluster_name(self):
        p = self.user("alice", "prod", "example-prod-1"); kw = dict(cluster="example-prod-1", ns="demo-prod")
        r = self.validate(p, self.hreq(**kw)); self.assertTrue(r["ok"]); self.assertTrue([c for c in r["checks"] if c["skipped"]])
        self.assertIn("type the exact cluster name", self.run_job(p, self.hreq(confirm_prod=True, **kw))["error"].lower())
        self.assertIn("type the exact cluster name", self.run_job(p, self.hreq(confirm_prod=True, confirm_name="example-prod-2", **kw))["error"].lower())
        self.assertIn("explicit confirmation", self.run_job(p, self.hreq(confirm_name="example-prod-1", **kw))["error"])
        j = self.run_job(p, self.hreq(confirm_prod=True, confirm_name="example-prod-1", **kw)); self.assertEqual(j["status"], "Completed", j)


class TestQuotasAndLimits(ServerCase):
    EXTRA = ["--user-quota-mb", "3", "--max-user-jobs", "1"]

    def test_per_user_storage_quota(self):
        a = self.user()
        c = self.failing(a, self.req(options={"size_limit_mb": 4})); self.assertEqual(c["name"], "Storage quota")
        j = self.run_job(a, self.hreq()); self.assertEqual(j["status"], "Completed", j)                # 1.5 MB stored
        j2 = self.run_job(a, self.hreq(ns="demo-dev"))                                                  # 1.5 + 2.5 reserve > 3
        self.assertEqual(j2["status"], "Failed"); self.assertIn("quota", j2["error"].lower())
        a.call("POST", "/api/jobs/%s/delete" % j["id"])                                                 # deleting frees quota
        self.assertEqual(self.run_job(a, self.hreq())["status"], "Completed")
        self.assertEqual(self.run_job(self.user("bob"), self.hreq())["status"], "Completed")           # quota is per user

    def test_per_user_active_job_limit(self):
        small = {"size_limit_mb": 2}
        a = self.user(); code, r = a.call("POST", "/api/jobs", self.req(pod="slow", options=small)); jid = r["job"]["id"]
        self.wait(a, jid, want=("Running",))
        code, r2 = a.call("POST", "/api/jobs", self.req(pod="java-ok", options=small)); self.assertEqual(code, 429); self.assertIn("active collections", r2["error"])
        self.assertEqual(self.user("bob").call("POST", "/api/jobs", self.req(pod="java-ok", options=small))[0], 202)  # other users unaffected
        a.call("POST", "/api/jobs/%s/cancel" % jid); self.wait(a, jid, t=15)


# ======================================================================= units
class TestUnits(unittest.TestCase):
    def test_process_timeout_cancel_bigoutput_no_shell(self):
        from backend import process
        t0 = time.time(); r = process.run(["sleep", "30"], 1); self.assertTrue(r.timed_out); self.assertLess(time.time() - t0, 6)
        ev = threading.Event(); threading.Timer(0.5, ev.set).start(); self.assertTrue(process.run(["sleep", "30"], 20, cancel=ev).cancelled)
        self.assertTrue(process.run([sys.executable, "-c", "print('x'*5000000)"], 10, max_bytes=1000).too_big)
        self.assertTrue(process.run(["/nonexistent/binary"], 5).error)
        self.assertEqual(process.run(["echo", "$(id); `id` | cat"], 5).out.strip(), "$(id); `id` | cat")

    def test_redaction(self):
        from backend.process import clean_text
        s = clean_text("token=abc123 Bearer eyJhbGciOi sha256~AbCd_ef-12 password: hunter2 eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ4In0.abcdefghijk")
        for bad in ("abc123", "eyJhbGciOi", "AbCd_ef", "hunter2", "eyJzdWIiOiJ4In0"):
            self.assertNotIn(bad, s)

    def test_kubeconfig_private_scrubbed_and_removed(self):
        from backend.runtime import RuntimeDir, RuntimeError_
        d = tempfile.mkdtemp(); rt = RuntimeDir(os.path.join(d, "rt"))
        kc = rt.new_kubeconfig("https://x:6443", "sha256~secret-secret-secret-secret-12", skip_tls=True)
        self.assertEqual(stat.S_IMODE(os.stat(kc.path).st_mode), 0o600); self.assertEqual(stat.S_IMODE(os.stat(kc.dir).st_mode), 0o700)
        with open(kc.path) as fh:
            doc = json.load(fh)
        self.assertTrue(doc["clusters"][0]["cluster"]["insecure-skip-tls-verify"])
        kc.close(); self.assertFalse(os.path.exists(kc.dir))
        kc = rt.new_kubeconfig("https://x:6443", "t", skip_tls=False)
        with open(kc.path) as fh:
            self.assertNotIn("insecure-skip-tls-verify", json.load(fh)["clusters"][0]["cluster"])
        kc.close()
        os.makedirs(os.path.join(rt.root, "kc-stale")); RuntimeDir(rt.root); self.assertEqual(os.listdir(rt.root), [])     # stale purge
        with self.assertRaises(RuntimeError_): RuntimeDir("/proc/self")

    def test_session_store_rules(self):
        from backend.sessions import SessionStore
        ended = []
        active = {"yes": False}
        st = SessionStore(idle_seconds=1, max_seconds=3, has_active_jobs=lambda sid: active["yes"], on_end=lambda s, r, c: ended.append((r, c)))
        s = st.create(); st.set_token(s, "c1", "tok", "alice")
        self.assertIs(st.get(s.sid), s); time.sleep(1.2)
        active["yes"] = True; self.assertIs(st.get(s.sid), s)                       # running job keeps it alive
        active["yes"] = False; time.sleep(1.2); self.assertIsNone(st.get(s.sid))
        self.assertEqual(ended, [("idle", [("c1", "alice")])]); self.assertEqual(s.tokens, {})
        s2 = st.create(); st.set_token(s2, "c1", "tok", "bob"); active["yes"] = True; time.sleep(3.3)
        self.assertIsNone(st.get(s2.sid)); self.assertEqual(ended[-1][0], "max_lifetime")      # hard cap even with a running job
        self.assertIsNone(st.get(None)); self.assertIsNone(st.get("nope"))

    def test_database_persistence_and_overrides(self):
        from backend.db import Database
        p = os.path.join(tempfile.mkdtemp(), "t.db"); db = Database(p)
        job = {"id": "20250101-000000-aaaaaaaa", "cluster_id": "c", "requested_by": "alice", "created": 1.0, "status": "Completed"}
        db.save_job(job); job["status"] = "Expired"; db.save_job(job)
        db.touch_login("c", "alice"); db.set_cluster_enabled("c", False, "alice"); db.close()
        db = Database(p)
        self.assertEqual([j["status"] for j in db.load_jobs()], ["Expired"]); self.assertGreater(db.last_login("c", "alice"), 0)
        self.assertEqual(db.cluster_overrides()["c"]["enabled"], False); self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o600)

    def test_audit_rotation(self):
        from backend.audit_service import Audit
        d = tempfile.mkdtemp(); a = Audit(os.path.join(d, "audit.log"), max_bytes=500, backups=3)
        for i in range(60): a.log("e", "u", n=i, secret="token=abc123")
        names = sorted(os.listdir(d)); self.assertIn("audit.log.1", names); self.assertLessEqual(len(names), 4)
        blob = ""
        for n in names:
            with open(os.path.join(d, n)) as fh:
                blob += fh.read()
        self.assertNotIn("abc123", blob)

    def test_config_handling(self):
        from backend.configuration import load_clusters, count_credential_fields
        cl = {c["id"]: c for c in load_clusters(CLUSTERS)}
        for c in cl.values():
            self.assertEqual(set(c), {"id", "name", "environment", "api_url", "enabled", "environment_valid", "tls_verify"})
        self.assertTrue(cl["example-dev-1"]["tls_verify"]); self.assertFalse(cl["example-selfsigned"]["tls_verify"])
        self.assertFalse(load_clusters(CLUSTERS, ("example-dev-1",))[0]["tls_verify"])
        self.assertEqual(count_credential_fields(CLUSTERS), 2)

    def test_heap_helpers(self):
        from diagnostics import heap_dump as h
        g1 = " garbage-first heap   total 262144K, used 102400K [0x1, 0x2)\n  region size 1024K\n Metaspace       used 5K, committed 6K"
        self.assertEqual(h.parse_heap_used(g1), 102400 * 1024)
        par = " PSYoungGen      total 76288K, used 3932K [0x1)\n ParOldGen       total 175104K, used 100K [0x2)\n Metaspace used 1K, committed 2K"
        self.assertEqual(h.parse_heap_used(par), (3932 + 100) * 1024)
        self.assertEqual(h.parse_heap_used(" ZHeap           used 28M, capacity 64M, max capacity 8192M"), 28 * 1024 * 1024)
        self.assertIsNone(h.parse_heap_used("OK")); self.assertIsNone(h.parse_heap_used(""))
        ok, msg, need = h.plan(100 * MB, 1024 * 1024, 200 * MB); self.assertTrue(ok); self.assertEqual(need, 125 * MB)
        self.assertFalse(h.plan(100 * MB, 1024 * 1024, 110 * MB)[0])             # estimate+margin above the limit
        self.assertFalse(h.plan(100 * MB, 10 * 1024, 200 * MB)[0])               # container /tmp too small
        self.assertFalse(h.plan(None, None, 200 * MB)[0]); ok, msg, need = h.plan(None, 1024 * 1024, 200 * MB); self.assertEqual((ok, need), (True, 200 * MB))
        self.assertRegex(h.remote_path("20250101-000000-aaaaaaaa"), r"^/tmp/portal-heap-[0-9a-f-]+\.hprof$")

    def test_pcap(self):
        from diagnostics import pcap
        def mk(body, order="<", magic=0xa1b2c3d4):
            return put(tempfile.mktemp(), struct.pack(order + "IHHiIII", magic, 2, 4, 0, 0, 65535, 1) + body)
        pk = lambda d, o="<", incl=None: struct.pack(o + "IIII", 1, 2, len(d) if incl is None else incl, len(d) if incl is None else incl) + d
        for order, magic in (("<", 0xa1b2c3d4), (">", 0xa1b2c3d4), ("<", 0xa1b23c4d)):
            self.assertEqual(pcap.scan(mk(pk(b"abc", order) + pk(b"de", order), order, magic))["packets"], 2)
        p = mk(pk(b"abc") + pk(b"x" * 50)[:30]); self.assertEqual(pcap.trim_to_valid(p)["packets"], 1)
        with self.assertRaises(pcap.PcapError): pcap.scan(mk(pk(b"zz", incl=70000)))
        for content in (b"", b"hello world, this is not pcap!!", b"\x0a\x0d\x0d\x0a" + b"\0" * 40):
            with self.assertRaises(pcap.PcapError): pcap.scan(put(tempfile.mktemp(), content))

    def _app(self, **kw):
        from backend.app import App
        from backend.configuration import Settings
        tmp = tempfile.mkdtemp()
        return tmp, App(Settings(CLUSTERS, os.path.join(tmp, "s"), os.path.join(tmp, "l"), os.path.join(tmp, "rt"), FAKE_OC, **kw))

    def test_retention_counts_from_owners_last_login_and_restart_recovery(self):
        tmp, app = self._app(retention_days=7)
        def job(i, status, **kw):
            j = {"id": "20250101-000000-%08x" % i, "requested_by": "alice", "env": "DEV", "cluster": "c", "cluster_id": "example-dev-1",
                 "namespace": "n", "pod": "p", "container": "c", "dump_type": "heap", "created": time.time() - 40 * 86400, "status": status,
                 "finished": time.time() - 30 * 86400}
            j.update(kw); app.jobs.jobs[j["id"]] = j; app.db.save_job(j); return j
        for n in ("a.hprof", "b.hprof"): put(os.path.join(app.storage.dumps, n), b"abc")
        old = job(1, "Completed", file="a.hprof", size_bytes=3)
        kept = job(2, "Completed", file="b.hprof", size_bytes=3)
        app.db.touch_login("example-dev-1", "alice")                              # alice logged in just now ...
        app.db.set_last_login("example-dev-1", "alice", time.time() - 30 * 86400)
        app.jobs.sweep(force=True)
        self.assertEqual((old["status"], kept["status"]), ("Expired", "Expired"))   # no login for 30 days -> both expire
        self.assertEqual(os.listdir(app.storage.dumps), [])
        put(os.path.join(app.storage.dumps, "c.hprof"), b"abc")
        fresh = job(3, "Completed", file="c.hprof", size_bytes=3, finished=time.time() - 30 * 86400)
        app.db.touch_login("example-dev-1", "alice")                               # ... a recent login keeps old results alive
        app.jobs.sweep(force=True); self.assertEqual(fresh["status"], "Completed")
        job(4, "Running", dump_type="heap")
        put(os.path.join(app.storage.dumps, "x.hprof.part"), b"partial"); app.close()
        from backend.app import App
        app2 = App(app.settings)
        self.assertEqual(app2.jobs.jobs["20250101-000000-00000004"]["status"], "Failed")
        self.assertIn("leftover portal-heap", app2.jobs.jobs["20250101-000000-00000004"]["error"])
        self.assertFalse([n for n in os.listdir(app2.storage.dumps) if n.endswith(".part")]); app2.close()

    def test_tcp_envs_setting(self):
        from backend.configuration import Settings
        self.assertEqual(Settings("a", "b", "c").tcp_envs, ("DEV", "TEST"))
        self.assertEqual(Settings("a", "b", "c", tcp_envs=("DEV", "BOGUS")).tcp_envs, ("DEV",))

    def test_thread_and_tcp_timeouts(self):
        from backend.oc_client import OcClient, Creds
        from backend.runtime import RuntimeDir
        from diagnostics import tcp_dump, thread_dump
        tmp = tempfile.mkdtemp(); os.environ["TMPDIR"] = tmp
        oc = OcClient(FAKE_OC, RuntimeDir(os.path.join(tmp, "rt")))
        cl = {"id": "d", "api_url": "https://api.dev.example.com:6443", "tls_verify": True}
        with oc.open(Creds(cl, tok("dev", "alice"))) as s:
            part = os.path.join(tmp, "x.part")
            with self.assertRaises(thread_dump.DiagnosticError) as cm:
                thread_dump.collect(s, "demo-dev", "slow", "app", {"tool": "jcmd", "tool_path": "/opt/java/openjdk/bin/jcmd", "pid": 1}, 1, 1, 2, 1 << 20, part, threading.Event())
            self.assertIn("timed out", str(cm.exception))
            old = tcp_dump.STOP_GRACE; tcp_dump.STOP_GRACE = 1
            try:
                with self.assertRaises(tcp_dump.DiagnosticError) as cm:
                    tcp_dump.collect(s, "demo-dev", "tcp-stuck", "app", 5, 128, None, 60, 1 << 20, part, threading.Event())
                self.assertIn("did not stop", str(cm.exception))
            finally:
                tcp_dump.STOP_GRACE = old
            tcp_dump.STOP_GRACE = 15
            with self.assertRaises(tcp_dump.DiagnosticError) as cm:
                tcp_dump.collect(s, "demo-dev", "tcp-slow", "app", 5, 128, None, 2, 1 << 20, part, threading.Event())
            self.assertIn("collection timeout (2 s)", str(cm.exception))
        del os.environ["TMPDIR"]


if __name__ == "__main__":
    unittest.main(verbosity=2)
