# Security notes

## Data flow
Browser -(JSON over loopback/SSH tunnel or HTTPS)-> portal process -(`oc` CLI as the user)-> cluster API / `oc exec` into the pod / `oc debug node` -> files in `storage/dumps/` -> authenticated download.
The browser never runs cluster commands and never receives any token or credentials.

## How a user token is handled
1. Typed into a password field, sent once to `POST /api/auth/login`; cleared on success. Never in browser storage or a URL.
2. Format-checked (`sha256~...` user OAuth tokens only), then verified by `oc whoami` against the **configured** API URL. `system:*` identities are rejected.
3. Held **only in the portal's memory** in a session identified by a random 256-bit cookie (`HttpOnly`, `SameSite=Strict`, `Secure` over HTTPS).
4. For each `oc` call the portal writes a one-off kubeconfig into a **0700 directory on tmpfs** (mode **0600**), passes only its *path* in `KUBECONFIG`, and deletes it (zeroed first) when the call or job ends.
   The server's own kubeconfig is never inherited.
5. **Never** in command-line arguments, environment variables, logs, audit log, SQLite, dump files, HTTP responses or error messages (all tool output is redacted and truncated).
6. Ends on sign-out/disconnect (running jobs are cancelled), after the idle limit (running jobs keep it alive) or the 8 h cap, or when the cluster rejects it.

## Authorisation model
* Everything is done **as the user**. The portal adds no privileges and holds no service credentials.
* A job belongs to *(cluster, identity reported by the cluster)*; others get a 404.
* PROD: server-enforced confirmation; heap dumps also need the typed cluster name; TCP capture must be narrowed.
* **Node-level capture is the one privileged feature.** It starts a temporary privileged debug pod with the *user's own* token, so the cluster decides whether it is allowed. The portal adds:
  per-environment enablement (default DEV,TEST), an optional user allow-list, a server-enforced acknowledgement, one capture at a time, fixed constant scripts with arguments passed
  separately and expanded only inside double quotes, strict validation of everything learned from the cluster, refusal of host-network pods, and full audit.
* Enable/disable of clusters: only `cluster-id:identity` pairs in `ADMIN_USERS`.

## Threat model
| Threat | Control | Residual risk |
|---|---|---|
| Token theft via browser | Never stored/echoed; password field; `HttpOnly` cookie; CSP forbids inline script/style | Malware on the workstation |
| Token on the wire | Loopback by default; TLS 1.2+ for network mode; cluster TLS verified by default | Clusters marked `tls_verify:false` can be impersonated |
| Token read from server | Memory/tmpfs only; 0600/0700; non-dumpable process; no core dumps | `root` and the portal's OS account can read process memory; swap |
| Cross-user access | Ownership by (cluster, identity); 404; server-generated file names | A bug in the shared process |
| CSRF / DNS rebinding | JSON-only POST, same-origin check, `SameSite=Strict`, `Host` allow-list | - |
| Command injection | Argument lists only; fixed scripts; fixed filter presets; IPs via `ipaddress` | The in-container probe and the two node scripts use `sh -c` with **fixed** text |
| Abuse | Throttle, job limits, quotas, size/time/packet caps | - |
| Sensitive dumps | 0600 files, owner-only download, retention, delete, warnings, audit | Dumps contain secrets by nature |
| Privileged debug pod misuse | Cluster RBAC for the user's token; env + user allow-lists; acknowledgement; audit | A cluster-admin user can do this anyway; it is a policy decision for your security team |
| Privilege escalation in clusters | None attempted by the portal | - |
| `portal.conf` tampering | Read as data (never executed); unknown keys ignored | Anyone who can edit it can change settings |

## Review checklist
- [ ] Loopback + SSH tunnel acceptable, or approved TLS/SSO front end.
- [ ] Retention days, quotas and purge-on-logout decided for heap dumps.
- [ ] Whether PROD may be added to `TCP_ENVS` / `NODE_CAPTURE_ENVS`, and the approved filter presets in `diagnostics/tcp_dump.py`.
- [ ] **Whether node-level capture (privileged debug pod) is approved at all, and for whom (`NODE_CAPTURE_USERS`).**
- [ ] Review the fixed scripts: `DETECT_SCRIPT` (thread_dump.py), `DISCOVER_SCRIPT` and `CAPTURE_SCRIPT` (node_capture.py).
- [ ] Swap/disk encryption policy for the jump server.
- [ ] Run the real-cluster validation in the Admin Guide.
- [ ] Rotate and remove credentials found in `clusters.json`.
