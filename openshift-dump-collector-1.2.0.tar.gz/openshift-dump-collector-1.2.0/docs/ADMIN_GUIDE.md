# Administrator guide

## 1. Requirements
| Need | Detail |
|---|---|
| OS | RHEL (any with systemd and a tmpfs at /dev/shm). SELinux is not changed by the portal |
| Python | 3.9 or newer, **standard library only** |
| `oc` CLI | In the `PATH` of the account that runs the portal; it need not be logged in. The portal never uses that account's own login |
| `/dev/shm` | tmpfs, writable (holds short-lived kubeconfig files) or set `RUNTIME_DIR` |
| Disk | Room for dumps. Defaults: 20 GB per user, 50 GB total, 500 MB always free |
| Network | The server must reach each cluster's API over HTTPS. Proxy variables are passed to `oc` |
| Not needed | pip packages, Node.js, nginx/httpd, Ansible, root/sudo (except to open a firewall port) |

`python3 scripts/discover_env.py` checks all of this read-only.

## 2. Install / upgrade
```bash
./deploy/install.sh --prefix ~/openshift-dump-collector [--with-user-service] [--dry-run]
```
Copies files, creates `storage/` and `logs/` (700) and `portal.conf` (600). Installs no packages, uses no sudo, starts nothing, never overwrites `clusters.json`,
`portal.conf`, `storage/`, `logs/` or `certs/`. **Running it again upgrades**: the old code is saved to `<prefix>.backup-<date>`, and the node-capture settings are appended
to an older `portal.conf`. Then run `python3 -m unittest discover -s tests`.

## 3. Configuration
### clusters.json
Only **name**, **environment** (DEV/TEST/PROD), **API URL**, **enabled** and an optional **`"tls_verify": false`** are read; anything else (including credentials) is ignored.
The cluster id is the name in lower case with runs of non-alphanumerics replaced by `-`.

### portal.conf (read by `run.sh` as data, never executed; see `deploy/portal.conf.example`)
| Setting | Default | Meaning |
|---|---|---|
| `PORT` | 8080 | Loopback port |
| `IDLE_MINUTES` | 30 | Session idle limit (a running job keeps it alive; hard cap 8 h) |
| `RETENTION_DAYS` | 7 | Results are deleted this long after the owner's **last login** |
| `PURGE_ON_LOGOUT` | 0 | 1 = delete a user's results when their session ends |
| `USER_QUOTA_MB` / `TOTAL_QUOTA_MB` | 20480 / 51200 | Stored results per user per cluster / overall |
| `HEAP_MAX_MB` | 8192 | Largest heap-dump limit a user may request |
| `MAX_CONCURRENT`, `MAX_USER_JOBS` | 2, 3 | Jobs running at once; active jobs per user per cluster |
| `TCP_ENVS` | DEV,TEST | Where **in-container** TCP capture is allowed |
| `NODE_CAPTURE_ENVS` | DEV,TEST | Where **node-level** capture is allowed (empty = off; add PROD only if approved) |
| `NODE_CAPTURE_USERS` | `*` | Who may use node-level capture (`cluster-id:identity` pairs) |
| `NODE_CAPTURE_IMAGE` | (oc default) | Debug-pod image |
| `ADMIN_USERS` | (empty) | `cluster-id:identity` pairs that may enable/disable clusters |
| `INSECURE_TLS_CLUSTERS` | (empty) | Cluster ids whose API certificate is **not** verified |
| Network settings | see docs/NETWORK_ACCESS.md | `BIND_HOST`, `TLS_CERT`, `TLS_KEY`, `ALLOW_FROM`, `PUBLIC_HOSTS`, `PUBLIC_PORT`, `ALLOW_INSECURE_HTTP` |

### Cluster certificates
By default each cluster's certificate is **verified** with the server's trust store. Preferred fix for "not trusted": add the cluster CA
(`sudo cp ca.crt /etc/pki/ca-trust/source/anchors/ && sudo update-ca-trust`). Otherwise set `"tls_verify": false` for **that cluster only**; it is logged, audited and
shown as "TLS verify OFF".

## 4. Running it
* By hand: `./run.sh`. As a service: `./deploy/install.sh --with-user-service`, review the unit, then `systemctl --user enable --now openshift-dump-collector`.
* Access: loopback only by default (`ssh -L 8080:127.0.0.1:8080 <server>`). On a shared server prefer **one instance per admin**.

## 5. Operation
* **Logs** (`logs/`): `app.log` (10 MB x 5) and `audit.log` (20 MB x 10). Audit events: `login_*`, `logout`, `session_ended`, `validate`, `job_requested` (incl. TCP method and
  acknowledgements), `job_started` (exact tcpdump filter, node), `job_completed/failed/cancelled`, `debug_namespace_leftover`, `file_download`, `file_deleted/expired`, `cluster_toggle`.
  No tokens, passwords or dump contents.
* **Data:** `storage/portal.db` (SQLite) and `storage/dumps/`, modes 600/700.
* **Restarts** end all sessions, fail running jobs, remove partial files and purge token files. Completed results remain.
* **Heap dump safeguards:** estimate from `GC.heap_info`; needs size x 1.25 free in the container's `/tmp`; verifies size and HPROF header; always deletes the remote file and says **ACTION NEEDED** if it cannot.

## 6. First real-cluster validation (DEV, before wider use)
1. `scripts/discover_env.py` reports no problems; `./run.sh` starts.
2. Dashboard shows real reachability per cluster.
3. Connect with your own token: header shows your username; namespaces match `oc get projects` as you. A second user sees different namespaces and none of your jobs.
4. Thread dump on a test Java pod: Validate, collect 1 then 3, download; cancel one and confirm no `.part` file remains.
5. While a job runs `ps -eo args | grep -c 'sha256~'` is 0; `ls /dev/shm/openshift-dump-collector-*` shows a `kc-*` folder only while a call/job is active.
6. Heap dump on a **small** non-production app: file opens in a heap analyser; `/tmp/portal-heap-*.hprof` is gone from the container; a too-small limit is refused clearly.
7. TCP capture, **in the container** on a pod that has `tcpdump` + `NET_RAW`; on an ordinary pod expect a clear refusal.
8. TCP capture, **on the node**: first the by-hand commands in docs/NODE_CAPTURE.md, then Validate and Collect in the portal on a pod without tcpdump; `oc get namespaces | grep openshift-debug` is empty afterwards.
9. Sign out: chips disappear, `/dev/shm/...` is empty, History is empty until you reconnect.
10. `grep -r 'sha256~' logs storage` returns nothing.

## 7. Troubleshooting
| Symptom | Likely cause | Fix |
|---|---|---|
| Start-up: "Runtime directory ... must be owned by the current user" | Stale/foreign directory | Remove it or set `RUNTIME_DIR` |
| "oc CLI NOT FOUND" badge | `oc` not in the service's PATH | Add to PATH or set `OC_PATH` |
| "TLS certificate is not trusted" | Cluster CA not in system trust | Add CA, or per-cluster `tls_verify:false` |
| Unreachable / Timed out | Firewall, proxy, DNS from the portal server | Test from the server; set `HTTPS_PROXY` |
| "Too many failed connection attempts" | 10 failed logins in a minute (shared) | Wait a minute |
| Job fails at "Exec permission" | User lacks `pods/exec` | Grant the standard role |
| Heap: "has N MB free" | Container `/tmp` too small | Different pod or bigger scratch space |
| TCP: "tcpdump was not found" / "NET_RAW" | Image/SCC cannot capture | Use capture method **On the node** (docs/NODE_CAPTURE.md) |
| Node capture: "not allowed for your account" | Token lacks cluster-level rights | Ask a cluster administrator |
| `ACTION NEEDED` | Remote heap file not deleted | `oc exec ... -- rm -f /tmp/portal-heap-<jobid>.hprof` |
| `POSSIBLE LEFTOVER` | `oc debug` namespace not cleaned up | `oc delete namespace <name>` (cluster admin) |
| Tests: "Permission denied" or a traceback in `tests/bin/oc_nodes` | The fake `oc` lost its execute bit / has CRLF | The test modules repair this automatically; or `chmod +x tests/bin/*` |

## 8. Rollback / uninstall
Rollback: stop the portal and copy the contents of the newest `<prefix>.backup-*` folder over the install. Uninstall: disable the service, delete the install folder and
`~/.config/systemd/user/openshift-dump-collector.service`. Delete `storage/dumps/` deliberately; it may contain sensitive data.

## 9. Known limitations
* Not yet exercised on a real cluster, real JVMs, Python 3.9 or systemd.
* No TLS/SSO in the portal unless you enable network mode; admin rights are by `cluster-id:username` string.
* Heap transfer uses `oc exec ... cat`: multi-GB files are slow and cannot resume.
* Node capture needs cluster-level rights and a working `oc debug node`; it captures one pod's network namespace only.
