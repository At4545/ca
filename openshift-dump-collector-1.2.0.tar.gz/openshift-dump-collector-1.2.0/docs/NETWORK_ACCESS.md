# Network access (HTTPS)

By default the portal listens on **127.0.0.1** only (admins use an SSH tunnel). It can listen on the network **on purpose**, but because users paste tokens into the page it refuses
to open a network port unless *all* of these are set:

| Guard-rail | Setting | Why |
|---|---|---|
| Encryption | `TLS_CERT` + `TLS_KEY` | Tokens must not cross the network readable. Plain HTTP needs the explicit `ALLOW_INSECURE_HTTP=1` (then every page shows a red banner) |
| Who may connect | `ALLOW_FROM` (IPs/networks or `any`) | Others are cut off before any response; the machine itself is always allowed |
| Accepted addresses | automatic + `PUBLIC_HOSTS` | Requests with any other `Host` get HTTP 400 listing the valid addresses |

## Set it up
```bash
./scripts/make_self_signed_cert.sh --host jump01.corp.example,10.20.30.40     # or use your organisation's certificate
```
`portal.conf`:
```
PORT=8443
BIND_HOST=0.0.0.0
TLS_CERT=certs/portal.crt
TLS_KEY=certs/portal.key
ALLOW_FROM=10.20.0.0/16
PUBLIC_HOSTS=jump01.corp.example
```
Open the port (`sudo firewall-cmd --permanent --add-port=8443/tcp && sudo firewall-cmd --reload`), start `./run.sh`, and open one of the `open:` addresses it prints.
With a self-signed certificate compare the fingerprint the script printed with the one the browser shows.

## Things to know
* Ports below 1024 need root; use 8443. A path such as `/app` is not supported.
* Behind NAT or a proxy every user looks like one address; `X-Forwarded-For` is deliberately ignored.
* `ALLOW_FROM` is an address filter, **not a login**; users still need their own cluster token. There is no SSO.
* Logins record the client IP in the audit log. Going back: clear `BIND_HOST` and restart.
