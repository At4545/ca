# TCP capture on the node

## Why this exists
The in-container capture needs a `tcpdump` **inside the application's image**, and OpenShift's default policy drops the `NET_RAW` capability a capture needs.
Most images have neither, so that method usually cannot work. The method **"On the node"** follows the standard OpenShift troubleshooting runbook: a debug pod
on the node enters the pod's network namespace with `nsenter` and runs `tcpdump` there. The application image needs neither tool nor capability.

## What it does
1. Looks up the node the pod runs on and checks it is Ready (read-only).
2. **Debug pod 1 (discovery):** checks the debug image has `tcpdump`, `nsenter`, `timeout`; asks the node's runtime (`crictl`) for the Ready sandbox of the pod; prints its
   description. The portal extracts the **network-namespace path** in Python (no `jq`, no shell JSON parsing).
3. **Debug pod 2 (capture):** `nsenter --net=<that namespace>` then `tcpdump -nn -i any ...`, streamed straight to the portal. **Nothing is written on the node.**
4. The portal verifies the pcap, hashes it and offers it for download. It then checks for a leftover `openshift-debug-*` namespace and, if found, adds a
   **POSSIBLE LEFTOVER** note with the command to remove it.

## Requirements
| Requirement | Detail |
|---|---|
| The **user's own token** must be allowed | A privileged debug pod needs cluster-level rights (typically **cluster-admin**). The portal grants nothing; the cluster refuses otherwise |
| Early hints | The portal asks `can-i get nodes` and `can-i use scc/privileged` for the user's token and stops with a clear message if either is "no" |
| `oc debug node` must work on your cluster | Some managed platforms restrict it. Test it by hand first (below) |
| A debug image with `tcpdump`, `nsenter`, `timeout` | The default `oc debug` image usually has them; otherwise set `NODE_CAPTURE_IMAGE` |
| `crictl` on the node | Present on RHCOS; the debug pod runs it through `chroot /host` |

## Safeguards (all enforced by the server)
* **Off unless enabled per environment:** `NODE_CAPTURE_ENVS` (default `DEV,TEST`; PROD is opt-in; empty = off). Optional user allow-list: `NODE_CAPTURE_USERS`.
* **Explicit acknowledgement** of the privileged debug pod (recorded in the audit log). On PROD the usual confirmation and a narrowed filter are also required.
* **No user text reaches a command or script.** The two scripts are constants; every value is a separate argument expanded only inside double quotes; the filter comes from the
  fixed preset table (plus a validated IP); node and image names must match strict patterns.
* **Everything from the cluster is validated:** node name, a 64-hex sandbox id (exactly one match), and the namespace path (`/var/run/netns/<name>` or `/proc/<pid>/ns/net`).
* **Host-network pods are refused.** **Bounded:** duration (enforced on the node by `timeout`), 500,000 packets, size cap; headers-only by default.
* **One node-level capture at a time** on the whole portal. Stray `oc` output is discarded. The user's token file is deleted before the final status is shown.

## Settings (`portal.conf`)
| Setting | Default | Meaning |
|---|---|---|
| `NODE_CAPTURE_ENVS` | `DEV,TEST` | Where it is allowed. **Empty = off** |
| `NODE_CAPTURE_USERS` | `*` | `*` or `cluster-id:identity` pairs |
| `NODE_CAPTURE_IMAGE` | (oc default) | Debug-pod image with `tcpdump`, `nsenter`, `timeout` |

## Verify by hand on DEV first
Run as the user who will use the portal (`oc login` as that user):
```bash
oc auth can-i get nodes ; oc auth can-i use scc/privileged                  # both "yes"
NODE=$(oc get pod <pod> -n <ns> -o jsonpath='{.spec.nodeName}')
oc debug node/$NODE --no-stdin --tty=false -- sh -c 'command -v tcpdump nsenter timeout'
oc debug node/$NODE --no-stdin --tty=false -- chroot /host crictl pods --namespace <ns> --name '^<pod>$' --state Ready -q   # one 64-hex id
oc debug node/$NODE --no-stdin --tty=false -- chroot /host crictl inspectp <that id>        # "type": "network" with a "path"
oc get namespaces | grep openshift-debug                                    # nothing left behind afterwards
```

## What has NOT been verified
Built and tested against a **simulated `oc`** and with the two scripts run in a real shell against stub tools; **not** run on a real cluster. Please confirm on DEV:
the `oc debug` flags and that it passes the remote stdout through unchanged; where `oc debug` prints its info lines and what exit code it returns for the remote code 124
(the portal accepts 0, 124, or "exit code 124"); the `crictl` output formats on your node version; that the temp namespace is named `openshift-debug-*` (only used for the leftover
warning); that the default image has the three tools; and whether your platform (for example ARO) allows `oc debug node` for your users at all.

## Troubleshooting
| Message | Fix |
|---|---|
| "Node-level capture is not enabled for DEV" | Set `NODE_CAPTURE_ENVS` and restart |
| "restricted to listed administrators" | Add `cluster-id:username` to `NODE_CAPTURE_USERS` |
| "Your account is not allowed to: read nodes; use the 'privileged' ..." | The token lacks cluster-level rights |
| "Starting a privileged debug pod ... is not allowed" | The cluster refused `oc debug node` for this user |
| "image pull problem" | Set `NODE_CAPTURE_IMAGE` to an approved image |
| "The debug image ... does not contain: ..." | Use an image that has `tcpdump`, `nsenter`, `timeout` |
| "no Ready pod ..." / "N Ready sandboxes match" | Pod moved/not Ready, or ambiguous; try again |
| "uses the node's own network (host network)" | Refused by design |
| "Another node-level capture is already running" | One at a time |
| "Starting the debug pod used up most of the collection timeout" | Raise the timeout (duration + 180 s minimum) |
| "POSSIBLE LEFTOVER: the temporary debug namespace ..." | A cluster admin can run the `oc delete namespace ...` command shown |
