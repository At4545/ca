# User guide

## 1. Connect to a cluster
The portal acts as **you**, so it needs your own OpenShift token for each cluster.
1. Log in to the cluster's web console. Click your name (top right) > **Copy login command** > **Display Token**.
2. Copy the value after `--token=` (it starts with `sha256~`). Or, where you are already logged in with `oc`, run `oc whoami -t`.
3. In the portal choose the cluster (Collect Dump, Dashboard or Clusters page), click **Connect**, paste the token, press **Connect**.

The header then shows `cluster · your-username`. Connect separately to each cluster you need.
* Only **user** tokens work. Service-account tokens and `system:` identities are refused.
* Your token is sent once, held only in the server's memory and never saved. It is discarded on **Sign out** (or the `×` on one cluster), or after
  **30 minutes without activity**. A running job keeps your session alive until it finishes.
* OpenShift tokens also expire on the cluster. If a call says the cluster rejected your token, get a fresh one and reconnect.

## 2. Collect a dump
**Collect Dump**: Environment > Cluster > Namespace > Pod > Container > Dump Type, then **Validate Request** (recommended) and **Collect Dump**.
* The lists show what **your** token can see. Only *Running* pods can be chosen.
* **Validate Request** runs the same checks a real collection runs and tells you what is wrong. **Cancel Collection** stops a running job and removes partial files.
* Progress shows the **stage** ("Capturing: 20s of 60s elapsed", "Transferring 800 of 1500 MB"). There are no made-up percentages.
* On **PROD** you get a confirmation dialog; **heap dumps on PROD also need the cluster name typed**.

### Thread dump
1-10 JVM thread dumps, N seconds apart, in one text file. Needs `jcmd` or `jstack` in the image and exactly one Java process.

### Heap dump (use with care)
Writes a file the size of the live heap into the container's `/tmp`, copies it here, then deletes it from the container. The JVM pauses, memory and
disk are used, and the file contains **everything that was in memory (passwords, personal data)**. The portal estimates the size first and refuses if the
container's `/tmp`, your size limit, your quota or this server's disk cannot hold it. If the result says **ACTION NEEDED**, remove the named temporary
file from the container yourself.

### TCP capture: two methods
Choose the **Capture method**:
* **In the container**: runs a `tcpdump` that already exists in the image. If the message says *tcpdump was not found* or *NET_RAW*, your image cannot do this.
* **On the node** (for images without tcpdump): the portal starts a temporary **privileged debug pod** on the node that runs your pod and captures only that
  pod's traffic. It needs cluster-level rights (typically cluster-admin), you must tick the acknowledgement, it takes about a minute longer to start, and only
  one such capture runs at a time. If you get *Your account is not allowed ...*, ask a cluster administrator. Details: docs/NODE_CAPTURE.md.

For both: duration 5-300 s; the filter is chosen from a fixed list (+ optional peer IP); **headers only** by default (full packets can contain credentials and need a
separate tick-box); PROD captures must be narrowed; a capture with **0 packets** is valid (nothing matched the filter).

## 3. Download, keep, delete
* **Download Result** appears when a job completes (pcap: Wireshark; hprof: Eclipse MAT / VisualVM; thread dumps: any text viewer). Only **you** can see your files.
* Results survive sign-out and are there again when you reconnect with the same identity; they are deleted *N days after your last login* (shown on the History
  page), or when you sign out if the administrator enabled purge-on-logout. **Delete file** removes one earlier and frees your quota.

## 4. Common messages
| Message | Meaning / what to do |
|---|---|
| "does not look like an OpenShift user OAuth token" | Wrong kind of token; use the console's Display Token value (starts `sha256~`) |
| "the cluster rejected your token" | Expired or revoked. Get a new token and Reconnect |
| "TLS certificate is not trusted by this server" | Tell your administrator (Admin Guide, section 3) |
| "Not connected to this cluster" | Your session ended (idle/sign-out). Connect again |
| "access denied ... lacks permission" | Your OpenShift account may not do that (list pods, `pods/exec`, nodes ...). Ask the project/cluster admin |
| "Neither jcmd nor jstack/jmap was found" | JRE-only image. Use an image with JDK tools |
| "refused the attach request" | JVM attach disabled, or the exec user differs from the JVM user |
| "tcpdump was not found" / "NET_RAW" | Use capture method **On the node**, if enabled and permitted for you |
| "Your account is not allowed to: read nodes; use the 'privileged' ..." | Node capture needs cluster-level rights |
| "Storage quota" | Delete older results, or ask the admin to raise the quota |
| "already active for this container" | Another job is running on that container; wait or cancel it |
