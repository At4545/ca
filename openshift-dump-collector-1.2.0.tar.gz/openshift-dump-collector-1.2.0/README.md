# OpenShift Dump Collector  v1.2.0

A small web portal that lets authorised people collect **thread dumps, heap dumps and TCP packet captures** from pods on
Red Hat OpenShift / Azure Red Hat OpenShift clusters, then download the results, without logging in to each cluster, finding pods by
hand, running commands or copying files.

* **Runs as you.** Each user connects to each cluster with **their own OpenShift OAuth token**. They see only the projects their token can
  see and can only do what their token allows. Credentials in `clusters.json` and the server's own `oc login` are never used.
* **Tokens stay in memory.** Never on disk, in logs, on a command line, or in the browser. A session ends on sign-out or after 30 idle minutes.
* **Standard library only.** Python 3.9+, the existing `oc` CLI, a browser. Nothing to `pip install`, no Node, no nginx, no Ansible.
* **Local by default** (`127.0.0.1` + SSH tunnel); optional HTTPS network access with an allowed-client list (docs/NETWORK_ACCESS.md).

## Diagnostics
| Feature | How it works |
|---|---|
| Thread dump | `jcmd Thread.print` (or `jstack`) inside the container; 1-10 dumps at an interval |
| Heap dump | `jcmd GC.heap_dump` (or `jmap`); free-space and size checks first; typed confirmation on PROD; the dump is always deleted from the container |
| TCP capture, **in the container** | A `tcpdump` that is already in the image (and `NET_RAW`); preset filters; headers-only by default |
| TCP capture, **on the node** (v1.2) | For images **without tcpdump**: a temporary privileged debug pod on the pod's node enters only that pod's network namespace and runs `tcpdump`; needs cluster-level rights; DEV/TEST by default (docs/NODE_CAPTURE.md) |

## Quick start (RHEL jump server)
```bash
tar xzf openshift-dump-collector-1.2.0.tar.gz && cd openshift-dump-collector-1.2.0
./deploy/install.sh --prefix ~/openshift-dump-collector        # copies files, makes private dirs; installs nothing
cp /path/to/clusters.json ~/openshift-dump-collector/ && chmod 600 ~/openshift-dump-collector/clusters.json
python3 ~/openshift-dump-collector/scripts/discover_env.py --clusters ~/openshift-dump-collector/clusters.json
cd ~/openshift-dump-collector && python3 -m unittest discover -s tests     # optional, a few minutes
~/openshift-dump-collector/run.sh
# on your workstation:
ssh -L 8080:127.0.0.1:8080 <jump-server>     # then open http://127.0.0.1:8080
```
Upgrading an existing 1.0/1.1 install: run `deploy/install.sh --prefix <same folder>` again. It keeps `portal.conf`, `clusters.json`,
`storage/`, `logs/` and `certs/`, saves the old code to `<prefix>.backup-<date>`, and appends the new node-capture settings to your `portal.conf`.

## Documentation
* docs/USER_GUIDE.md: getting a token, collecting dumps, what the messages mean
* docs/ADMIN_GUIDE.md: install, configuration, operation, troubleshooting, upgrade/rollback, first real-cluster validation
* docs/NODE_CAPTURE.md: TCP capture on the node (requirements, safeguards, verify-by-hand commands)
* docs/NETWORK_ACCESS.md: HTTPS access for other machines
* docs/SECURITY.md: token handling, threat model, residual risks

## Tests
```bash
python3 -m unittest discover -s tests          # everything (about 5 minutes)
python3 -m unittest discover -s tests -p "test_node_capture.py"      # one file
```
`tests/bin/oc` and `tests/bin/oc_nodes` are FAKE `oc` programs. `tests/fakes.py` repairs them automatically if they lost their execute
permission, gained Windows line endings, or name a Python that does not exist on this machine.

## Status: read this first
Built and tested **against a simulated `oc`**: a fake CLI that mimics per-user tokens, permissions, container file systems, debug pods and many failures,
about 140 automated tests, and a headless-browser run of the UI. It has **not** been run against a real OpenShift cluster, real JVMs, Python 3.9
or under systemd. Do the checks in docs/ADMIN_GUIDE.md section 6 (and the by-hand commands in docs/NODE_CAPTURE.md) on a DEV cluster first.
