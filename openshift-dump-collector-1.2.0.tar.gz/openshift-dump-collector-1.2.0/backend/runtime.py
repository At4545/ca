"""Short-lived, private kubeconfig files for `oc`, kept in a memory-backed directory.

The user's token is written ONLY here (mode 0600, inside a 0700 directory, normally on tmpfs) so that it never
appears on a command line (`ps`) and never touches persistent storage. Each file is overwritten and deleted as
soon as the operation / job ends.
"""
import json
import os
import shutil
import stat
import tempfile


class RuntimeError_(Exception):
    pass


class RuntimeDir(object):
    def __init__(self, path=None):
        if path is None:
            if not os.path.isdir("/dev/shm"):
                raise RuntimeError_("/dev/shm (memory-backed storage) is not available; pass --runtime-dir explicitly.")
            path = "/dev/shm/openshift-dump-collector-%d" % os.getuid()
        self.root = os.path.abspath(path)
        os.makedirs(self.root, mode=0o700, exist_ok=True)
        st = os.lstat(self.root)
        if not stat.S_ISDIR(st.st_mode) or st.st_uid != os.getuid():
            raise RuntimeError_("Runtime directory %s must be a directory owned by the current user." % self.root)
        os.chmod(self.root, 0o700)
        self.purge_stale()

    def purge_stale(self):
        """Remove leftovers from a crashed previous run."""
        for n in os.listdir(self.root):
            shutil.rmtree(os.path.join(self.root, n), ignore_errors=True)

    def new_kubeconfig(self, server, token, skip_tls=False):
        d = tempfile.mkdtemp(prefix="kc-", dir=self.root)        # mkdtemp creates 0700
        cluster = {"server": server}
        if skip_tls:
            cluster["insecure-skip-tls-verify"] = True
        doc = {"apiVersion": "v1", "kind": "Config", "current-context": "portal",
               "clusters": [{"name": "target", "cluster": cluster}],
               "users": [{"name": "user", "user": {"token": token} if token else {}}],
               "contexts": [{"name": "portal", "context": {"cluster": "target", "user": "user"}}]}
        path = os.path.join(d, "kubeconfig")
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as fh:
            json.dump(doc, fh)
        return Kubeconfig(d, path)


class Kubeconfig(object):
    def __init__(self, directory, path):
        self.dir = directory
        self.path = path
        self.cache = os.path.join(directory, "cache")

    def close(self):
        try:                                    # best-effort scrub before unlink
            size = os.path.getsize(self.path)
            with open(self.path, "r+b") as fh:
                fh.write(b"\0" * size)
                fh.flush()
                os.fsync(fh.fileno())
        except OSError:
            pass
        shutil.rmtree(self.dir, ignore_errors=True)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
