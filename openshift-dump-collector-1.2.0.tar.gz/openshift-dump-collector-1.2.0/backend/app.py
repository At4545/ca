"""Application container: settings, runtime dir, oc client, storage, database, sessions, jobs.
Also login/logout (user tokens), discovery as the user, connectivity checks and admin toggles."""
import logging
import os
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor

from .audit_service import Audit
from .collection_service import JobManager
from .configuration import load_clusters
from .db import Database
from .errors import ApiError
from .oc_client import TOKEN_RE, Creds, OcClient, OcError
from .runtime import RuntimeDir
from .sessions import SessionStore
from .storage_service import Storage

log = logging.getLogger("dumpcollector")
CHECK_TTL = 10   # seconds a connectivity result is reused


class App(object):
    def __init__(self, settings):
        self.settings = settings
        self.runtime = RuntimeDir(settings.runtime_dir)
        self.oc = OcClient(settings.oc_path, self.runtime)
        self.storage = Storage(settings.storage_dir)
        self.db = Database(os.path.join(self.storage.root, "portal.db"))
        self.audit = Audit(os.path.join(settings.log_dir, "audit.log"))
        self.jobs = JobManager(self)
        self.sessions = SessionStore(settings.idle_seconds, settings.max_session_seconds,
                                     has_active_jobs=self.jobs.has_active_for_session, on_end=self._session_ended)
        self.conn_cache = {}
        self.conn_lock = threading.Lock()
        self.failures = deque()
        self.jobs.recover()
        self._stop = threading.Event()
        t = threading.Thread(target=self._tick, name="housekeeping")
        t.daemon = True
        t.start()

    def close(self):
        self._stop.set()
        self.db.close()

    def _tick(self):
        while not self._stop.wait(self.settings.tick_seconds):
            try:
                self.sessions.sweep()
                self.jobs.sweep()
            except Exception:
                log.exception("housekeeping failed")

    # ---- sessions ------------------------------------------------------------------------
    def _session_ended(self, session, reason, connections):
        for cid, ident in connections:
            self.audit.log("session_ended", ident, cluster=cid, reason=reason)
            if self.settings.purge_on_logout:
                self.jobs.purge_owner(cid, ident, "owner session ended (%s)" % reason)

    def is_admin(self, session):
        return bool(session) and any("%s:%s" % pair in self.settings.admin_users for pair in session.identities())

    def session_info(self, session):
        if not session:
            return {"connected": [], "expires_in": None, "admin": False, "idle_seconds": self.settings.idle_seconds}
        names = {c["id"]: c["name"] for c in self.clusters()}
        return {"connected": [{"cluster_id": cid, "cluster": names.get(cid, cid), "identity": t["identity"], "since": t["since"]}
                              for cid, t in sorted(session.tokens.items())],
                "expires_in": self.sessions.expires_in(session), "admin": self.is_admin(session),
                "idle_seconds": self.settings.idle_seconds}

    # ---- clusters ------------------------------------------------------------------------
    def clusters(self):
        cl = load_clusters(self.settings.clusters_path, self.settings.insecure_tls)
        ov = self.db.cluster_overrides()
        for c in cl:
            if c["id"] in ov:
                c["enabled"] = ov[c["id"]]["enabled"]
                c["enabled_by_admin"] = ov[c["id"]]["changed_by"]
            c["connectivity"] = self.conn_cache.get(c["id"])
        return cl

    def cluster_or_error(self, cluster_id):
        for c in self.clusters():
            if c["id"] == cluster_id:
                if not c["enabled"]:
                    raise ApiError(409, "Cluster is disabled in the portal.")
                if not c["api_url"] or not c["environment_valid"]:
                    raise ApiError(409, "Cluster has no valid environment/API URL configured.")
                return c
        raise ApiError(404, "Unknown cluster")

    def check_cluster(self, cluster, force=False):
        with self.conn_lock:
            cached = self.conn_cache.get(cluster["id"])
        if cached and not force and time.time() - cached["checked_at"] < CHECK_TTL:
            return cached
        t0 = time.time()
        if not cluster["api_url"].startswith("https://"):
            status, note, version = "error", "API URL is not an https:// address", ""
        else:
            try:
                with self.oc.anonymous(cluster) as oc:
                    status, note, version = oc.probe_version()
            except OcError as exc:
                status, note, version = "error", exc.message, ""
        res = {"status": status, "note": note, "version": version, "latency_ms": int((time.time() - t0) * 1000), "checked_at": time.time()}
        with self.conn_lock:
            self.conn_cache[cluster["id"]] = res
        return res

    def check_all(self):
        cl = self.clusters()
        with ThreadPoolExecutor(max_workers=8) as ex:
            list(ex.map(lambda c: self.check_cluster(c, force=False), cl))
        return self.clusters()

    def set_enabled(self, session, cluster_id, enabled):
        if not self.is_admin(session):
            raise ApiError(403, "Only portal administrators can enable or disable clusters.", reason="not_admin")
        if cluster_id not in {c["id"] for c in self.clusters()}:
            raise ApiError(404, "Unknown cluster")
        who = sorted(i for c, i in session.identities() if "%s:%s" % (c, i) in self.settings.admin_users)[0]
        self.db.set_cluster_enabled(cluster_id, bool(enabled), who)
        self.audit.log("cluster_toggle", who, cluster=cluster_id, enabled=bool(enabled))

    # ---- login / logout --------------------------------------------------------------------
    def _check_login_limit(self):
        now = time.time()
        while self.failures and now - self.failures[0] > 60:
            self.failures.popleft()
        if len(self.failures) >= self.settings.login_fail_limit:
            raise ApiError(429, "Too many failed connection attempts; wait a minute and try again.", reason="rate_limited")

    def login(self, session, cluster_id, token):
        if not isinstance(token, str):
            raise ApiError(400, "A token is required.", reason="bad_token_format")
        token = token.strip()
        if not TOKEN_RE.fullmatch(token):
            raise ApiError(400, "That does not look like an OpenShift user OAuth token (it should start with 'sha256~'). "
                           "Get one with `oc whoami -t` or the console's 'Copy login command' > 'Display Token' page.", reason="bad_token_format")
        cluster = self.cluster_or_error(cluster_id)
        self._check_login_limit()
        creds = Creds(cluster, token)
        try:
            with self.oc.open(creds) as oc:
                identity = oc.whoami()
        except OcError as exc:
            self.failures.append(time.time())
            self.audit.log("login_failed", None, cluster=cluster["name"], reason=exc.code, detail=exc.message, tls_verify=cluster["tls_verify"])
            raise ApiError(401 if exc.code in ("auth", "forbidden") else 502, exc.message,
                           reason="token_rejected" if exc.code in ("auth", "forbidden") else None)
        if not identity or identity.startswith("system:"):
            self.failures.append(time.time())
            self.audit.log("login_failed", None, cluster=cluster["name"], reason="not_a_user_token")
            raise ApiError(401, "Only OpenShift user OAuth tokens are accepted (this token belongs to a service account or system user).",
                           reason="not_a_user_token")
        if session is None:
            session = self.sessions.create()
        self.sessions.set_token(session, cluster["id"], token, identity)
        self.db.touch_login(cluster["id"], identity)
        self.audit.log("login_success", identity, cluster=cluster["name"], tls_verify=cluster["tls_verify"])
        return session

    def disconnect(self, session, cluster_id):
        t = session.tokens.get(cluster_id)
        if not t:
            return
        self.jobs.cancel_for_session(session.sid, cluster_id, "disconnected")
        self.sessions.drop_token(session, cluster_id)
        self.audit.log("logout", t["identity"], cluster=cluster_id)
        if self.settings.purge_on_logout:
            self.jobs.purge_owner(cluster_id, t["identity"], "owner disconnected")
        if not session.tokens:
            self.sessions.end(session.sid, "signed_out")

    def sign_out(self, session):
        self.jobs.cancel_for_session(session.sid, None, "signed out")
        self.sessions.end(session.sid, "signed_out")

    # ---- discovery, always AS THE USER ---------------------------------------------------------
    def creds_for(self, session, cluster_id):
        t = session.tokens.get(cluster_id) if session else None
        if not t:
            raise ApiError(401, "Not connected to this cluster. Connect with your OpenShift token first.", reason="not_connected")
        return Creds(self.cluster_or_error(cluster_id), t["token"], t["identity"])

    def _oc_error(self, session, cluster_id, exc):
        if exc.code == "auth":
            self.sessions.drop_token(session, cluster_id)      # the cluster rejected it: stop holding it
            return ApiError(401, exc.message, reason="token_rejected")
        return ApiError({"forbidden": 403, "notfound": 404}.get(exc.code, 502), exc.message)

    def namespaces(self, session, cluster_id):
        creds = self.creds_for(session, cluster_id)
        try:
            with self.oc.open(creds) as oc:
                return {"identity": creds.identity, "namespaces": oc.list_namespaces()}
        except OcError as exc:
            raise self._oc_error(session, cluster_id, exc)

    def pods(self, session, cluster_id, namespace):
        creds = self.creds_for(session, cluster_id)
        try:
            with self.oc.open(creds) as oc:
                return {"pods": oc.list_pods(namespace)}
        except OcError as exc:
            raise self._oc_error(session, cluster_id, exc)

    def validate(self, session, clean):
        creds = self.creds_for(session, clean["cluster"])
        result = self.jobs.validate(clean, creds)
        bad = [c for c in result["checks"] if not c["ok"]]
        if bad and bad[0]["name"] == "Credentials and identity" and "rejected your token" in bad[0]["message"]:
            self.sessions.drop_token(session, clean["cluster"])
            result["token_rejected"] = True
        return result

    def create_job(self, session, clean):
        creds = self.creds_for(session, clean["cluster"])
        return self.jobs.create(clean, creds, session.sid)
