#!/usr/bin/env bash
# Copies the portal to an install directory and prepares private folders. It does NOT install packages, does NOT
# use sudo, does NOT start anything and never overwrites clusters.json, portal.conf, storage/, logs/ or certs/.
# Safe to run again to upgrade an existing install (a rollback copy of the previous code is kept).
#   ./deploy/install.sh [--prefix DIR] [--with-user-service] [--dry-run]
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PREFIX="$HOME/openshift-dump-collector"; SERVICE=0; DRY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --prefix) PREFIX="$2"; shift 2;;
    --with-user-service) SERVICE=1; shift;;
    --dry-run) DRY=1; shift;;
    -h|--help) sed -n '2,6p' "$0"; exit 0;;
    *) echo "unknown option: $1" >&2; exit 2;;
  esac
done
do_() { if [ "$DRY" = 1 ]; then echo "[dry-run] $*"; else "$@"; fi; }

PY="${PYTHON:-python3}"
"$PY" - <<'PYEOF' || { echo "Python 3.9 or newer is required." >&2; exit 1; }
import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)
PYEOF
command -v oc >/dev/null 2>&1 || echo "WARNING: 'oc' was not found in PATH; the portal needs it at run time (use your approved internal mirror)."
[ -d /dev/shm ] || echo "WARNING: /dev/shm missing; set RUNTIME_DIR in portal.conf to another tmpfs directory."

ITEMS="server.py index.html style.css script.js VERSION run.sh README.md backend diagnostics scripts deploy docs tests"
echo "Installing to: $PREFIX"
if [ -e "$PREFIX/server.py" ]; then
  BK="$PREFIX.backup-$(date +%Y%m%d-%H%M%S)"
  echo "Existing install found; keeping a rollback copy of the code at $BK (data and config are left in place)"
  do_ mkdir -p "$BK"
  for f in $ITEMS; do [ -e "$PREFIX/$f" ] && do_ cp -a "$PREFIX/$f" "$BK/"; done
fi
do_ mkdir -p "$PREFIX"
for f in $ITEMS; do
  [ -e "$SRC/$f" ] || continue
  [ -d "$SRC/$f" ] && do_ rm -rf "$PREFIX/$f"
  do_ cp -a "$SRC/$f" "$PREFIX/"
done
do_ find "$PREFIX" -name __pycache__ -type d -prune -exec rm -rf {} +
do_ chmod +x "$PREFIX/run.sh" "$PREFIX/deploy/install.sh" "$PREFIX/scripts/make_self_signed_cert.sh" "$PREFIX/scripts/discover_env.py" || true
do_ find "$PREFIX/tests/bin" -type f -exec chmod +x {} + || true
do_ mkdir -p "$PREFIX/storage" "$PREFIX/logs"
do_ chmod 700 "$PREFIX/storage" "$PREFIX/logs"
[ -f "$PREFIX/portal.conf" ] || { do_ cp "$SRC/deploy/portal.conf.example" "$PREFIX/portal.conf"; do_ chmod 600 "$PREFIX/portal.conf"; }
if [ -f "$PREFIX/portal.conf" ] && ! grep -q '^NODE_CAPTURE_ENVS' "$PREFIX/portal.conf"; then
  if [ "$DRY" = 1 ]; then echo "[dry-run] append node-capture settings to portal.conf"; else
    { echo; echo "# ---- Node-level TCP capture (added by upgrade) ----"; sed -n '/^NODE_CAPTURE_ENVS=/,/^NODE_CAPTURE_IMAGE=/p' "$SRC/deploy/portal.conf.example"; } >> "$PREFIX/portal.conf"
  fi
fi
[ -f "$PREFIX/clusters.json" ] || echo "NEXT: copy your clusters.json to $PREFIX/clusters.json and chmod 600 it (it is never overwritten by this script)."
if [ "$SERVICE" = 1 ]; then
  UD="$HOME/.config/systemd/user"; do_ mkdir -p "$UD"
  if [ "$DRY" = 1 ]; then echo "[dry-run] write $UD/openshift-dump-collector.service"; else sed "s#@PREFIX@#$PREFIX#g" "$SRC/deploy/openshift-dump-collector.service" > "$UD/openshift-dump-collector.service"; fi
  echo "Service file written. Review it, then:  systemctl --user daemon-reload && systemctl --user enable --now openshift-dump-collector"
fi
echo
echo "Done. Next steps:"
echo "  1. python3 $PREFIX/scripts/discover_env.py --clusters $PREFIX/clusters.json --storage $PREFIX/storage"
echo "  2. edit $PREFIX/portal.conf if needed"
echo "  3. (optional) cd $PREFIX && python3 -m unittest discover -s tests          # a few minutes"
echo "  4. $PREFIX/run.sh          (then: ssh -L 8080:127.0.0.1:8080 <this-server>  ->  http://127.0.0.1:8080)"
echo "Rollback: stop the portal, restore the code from the .backup-* folder, start it again. See docs/ADMIN_GUIDE.md."
