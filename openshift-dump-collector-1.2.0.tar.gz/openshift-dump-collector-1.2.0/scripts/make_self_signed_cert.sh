#!/usr/bin/env bash
# Creates a SELF-SIGNED TLS certificate + private key for the portal (uses the openssl already on RHEL).
# Browsers will warn about a self-signed certificate until you trust it; if your organisation has an internal CA,
# ask for a proper certificate instead and pass it with TLS_CERT / TLS_KEY.
#
#   ./scripts/make_self_signed_cert.sh --host jump01.corp.example,10.20.30.40 [--out certs] [--days 825] [--force]
#
# --host   comma-separated names and/or IP addresses users will type in the browser (the first one becomes the CN)
set -euo pipefail
OUT="certs"; DAYS=825; HOSTS=""; FORCE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --host) HOSTS="$2"; shift 2;;
    --out) OUT="$2"; shift 2;;
    --days) DAYS="$2"; shift 2;;
    --force) FORCE=1; shift;;
    -h|--help) sed -n '2,9p' "$0"; exit 0;;
    *) echo "unknown option: $1" >&2; exit 2;;
  esac
done
[ -n "$HOSTS" ] || { echo "Please give --host name-or-ip[,name-or-ip...]" >&2; exit 2; }
command -v openssl >/dev/null 2>&1 || { echo "openssl was not found in PATH." >&2; exit 1; }
case "$DAYS" in ''|*[!0-9]*) echo "--days must be a whole number" >&2; exit 2;; esac

san="DNS:localhost,IP:127.0.0.1"; cn=""
IFS=',' read -ra items <<< "$HOSTS"
for h in "${items[@]}"; do
  h="$(echo "$h" | tr -d '[:space:]')"; [ -n "$h" ] || continue
  if ! echo "$h" | grep -Eq '^[A-Za-z0-9._:-]{1,253}$'; then echo "Not a plain host name or IP address: $h" >&2; exit 2; fi
  [ -n "$cn" ] || cn="$h"
  if echo "$h" | grep -Eq '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$|:'; then san="$san,IP:$h"; else san="$san,DNS:$h"; fi
done
[ -n "$cn" ] || { echo "No usable host given." >&2; exit 2; }
[ "${#cn}" -le 64 ] || cn="portal"

umask 077
mkdir -p "$OUT"; chmod 700 "$OUT"
CRT="$OUT/portal.crt"; KEY="$OUT/portal.key"
if { [ -e "$CRT" ] || [ -e "$KEY" ]; } && [ "$FORCE" != 1 ]; then
  echo "$CRT or $KEY already exists; use --force to replace them." >&2; exit 1
fi
openssl req -x509 -newkey rsa:3072 -sha256 -nodes -days "$DAYS" -keyout "$KEY" -out "$CRT" \
  -subj "/CN=$cn/O=OpenShift Dump Collector" -addext "subjectAltName=$san" \
  -addext "keyUsage=digitalSignature,keyEncipherment" -addext "extendedKeyUsage=serverAuth" >/dev/null 2>&1 \
  || { echo "openssl failed (needs OpenSSL 1.1.1 or newer for -addext)." >&2; rm -f "$CRT" "$KEY"; exit 1; }
chmod 600 "$KEY"; chmod 644 "$CRT"
echo "Created:"
echo "  certificate: $CRT"
echo "  private key: $KEY   (mode 600 - keep it secret, never share it)"
echo "  valid names: $san"
echo "  expires:     $(openssl x509 -in "$CRT" -noout -enddate | cut -d= -f2)"
echo "  fingerprint: $(openssl x509 -in "$CRT" -noout -fingerprint -sha256 | cut -d= -f2)"
echo
echo "Use it with:  TLS_CERT=$CRT  TLS_KEY=$KEY   in portal.conf (see docs/NETWORK_ACCESS.md)"
echo "Users should compare the fingerprint above with the one their browser shows before accepting the warning."
