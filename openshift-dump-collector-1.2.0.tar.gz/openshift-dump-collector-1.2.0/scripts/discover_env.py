#!/usr/bin/env python3
"""READ-ONLY environment check for OpenShift Dump Collector (run on the RHEL jump server).

Standard library only. Makes NO network calls to any cluster, installs nothing, changes nothing and
never prints credential values.  Usage: python3 scripts/discover_env.py [--clusters clusters.json] [--storage DIR] [--port 8080]
"""
import argparse, json, os, platform, shutil, socket, sqlite3, stat, subprocess, sys

SECRET_HINTS = ("password", "passwd", "secret", "token", "credential", "apikey", "api_key")
problems = []


def run(args, timeout=15):
    try:
        p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, timeout=timeout)
        return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", "not found"
    except Exception as exc:
        return 1, "", type(exc).__name__


def section(t): print("\n== %s ==" % t)
def line(k, v): print("  %-30s %s" % (k + ":", v))
def problem(msg): problems.append(msg); print("  PROBLEM: " + msg)


def os_python():
    section("Operating system / Python")
    pretty = platform.platform()
    try:
        with open("/etc/os-release") as fh:
            for ln in fh:
                if ln.startswith("PRETTY_NAME="):
                    pretty = ln.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    line("OS", pretty); line("Running as", "uid=%d user=%s" % (os.getuid(), os.environ.get("USER", "?")))
    rc, out, _ = run(["getenforce"]); line("SELinux", out if rc == 0 else "getenforce not available")
    line("Python", "%s (%s)" % (platform.python_version(), sys.executable))
    if sys.version_info < (3, 9):
        problem("Python 3.9 or newer is required")
    line("SQLite library", sqlite3.sqlite_version)
    line("third-party modules needed", "none (standard library only)")


def oc_info():
    section("OpenShift CLI")
    path = shutil.which("oc"); line("oc path", path or "NOT FOUND")
    if not path:
        return problem("oc not found in PATH (get it from your approved internal mirror)")
    rc, out, err = run(["oc", "version", "--client"]); line("oc client version", out.replace("\n", " | ") if rc == 0 else "error: " + err[:120])
    print("  (The portal never uses this account's oc login or kubeconfig; users bring their own tokens.)")


def runtime_info():
    section("Memory-backed runtime directory (holds temporary token files)")
    ok = os.path.isdir("/dev/shm") and os.access("/dev/shm", os.W_OK)
    line("/dev/shm writable", str(ok))
    if not ok:
        return problem("/dev/shm is not usable; set RUNTIME_DIR in portal.conf to another tmpfs directory")
    rc, out, _ = run(["df", "-PT", "/dev/shm"])
    if rc == 0 and out:
        row = out.splitlines()[-1].split(); line("filesystem type", row[1] if len(row) > 1 else "?")
        if len(row) > 1 and row[1] not in ("tmpfs", "ramfs"):
            problem("/dev/shm is not tmpfs; tokens could reach disk")


def other_info():
    section("Other tools")
    for t in ("tar", "gzip", "sha256sum", "systemctl", "openssl", "tcpdump"):
        line(t, shutil.which(t) or "not found")
    print("  (tcpdump here is only for opening captures locally; the portal runs tcpdump INSIDE target containers or on nodes.)")


def storage_info(path):
    section("Storage candidate: " + path)
    target = path if os.path.exists(path) else (os.path.dirname(os.path.abspath(path)) or ".")
    try:
        du = shutil.disk_usage(target); line("free / total (GiB)", "%.1f / %.1f" % (du.free / 2**30, du.total / 2**30))
        if du.free < 10 * 2**30:
            print("  NOTE: under 10 GiB free; heap dumps can be several GiB (see USER_QUOTA_MB / TOTAL_QUOTA_MB)")
    except OSError as exc:
        line("disk usage", "error: %s" % exc)
    line("exists / writable", "%s / %s" % (os.path.exists(path), os.access(target, os.W_OK)))


def port_info(port):
    section("Local port %d (loopback)" % port)
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", port)); line("bind 127.0.0.1:%d" % port, "free")
    except OSError as exc:
        line("bind 127.0.0.1:%d" % port, "NOT free (%s) - choose another PORT" % exc.strerror)
    finally:
        s.close()


def entries_of(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("clusters", "Clusters", "items"):
            if key in data:
                return entries_of(data[key])
        if data and all(isinstance(v, dict) for v in data.values()):
            return [dict(v, _key=k) for k, v in data.items()]
    return []


def clusters_info(path):
    section("clusters.json: " + path)
    if not os.path.exists(path):
        return line("file", "NOT FOUND (use --clusters PATH)")
    mode = stat.S_IMODE(os.stat(path).st_mode); line("file mode", "%o %s" % (mode, "OK" if mode & 0o077 == 0 else "READABLE BY OTHERS - chmod 600"))
    try:
        with open(path) as fh:
            data = json.load(fh)
    except Exception as exc:
        return problem("clusters.json could not be parsed (%s)" % type(exc).__name__)
    ents = [e for e in entries_of(data) if isinstance(e, dict)]
    line("cluster entries found", len(ents))
    populated = 0
    for e in ents:
        populated += sum(1 for k, v in e.items() if any(h in k.lower() for h in SECRET_HINTS) and v)
        safe = {k: v for k, v in e.items() if not any(h in k.lower() for h in SECRET_HINTS) and isinstance(v, (str, bool, int))}
        print("      - %s" % json.dumps(safe))
    line("credential-like fields", "%d populated (values NOT shown)" % populated)
    if populated:
        print("  NOTE: the portal IGNORES these. Users sign in with their own tokens. Remove them from the file and rotate those passwords.")
    if not ents:
        problem("no cluster entries were recognised; send the field names to the maintainer")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clusters", default="clusters.json"); ap.add_argument("--storage", default="storage"); ap.add_argument("--port", type=int, default=8080)
    a = ap.parse_args()
    print("OpenShift Dump Collector - environment check (read-only)")
    os_python(); oc_info(); runtime_info(); other_info(); storage_info(a.storage); port_info(a.port); clusters_info(a.clusters)
    print("\nResult: %s" % ("%d problem(s) found" % len(problems) if problems else "no blocking problems found"))
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
