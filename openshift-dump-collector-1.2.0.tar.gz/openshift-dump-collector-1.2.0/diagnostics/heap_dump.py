"""Heap-dump collection with jcmd GC.heap_dump (preferred) or jmap -dump.

Heap dumps are the riskiest diagnostic: the JVM pauses (and by default runs a full GC), the dump is written INSIDE the
container's /tmp first, and the file can be GBs and contain secrets that were in memory. Safeguards implemented here
and in the job manager:
  * the container's /tmp must be writable and have room for the ESTIMATED dump (+25 %)
  * the estimate must fit the requested size limit, and the jump server must have the space
  * the remote file name is server-generated; every remote command is a fixed argument list
  * the transfer is size-checked against the remote file and must start with an HPROF header
  * the remote file is ALWAYS deleted afterwards (retried once); if that fails the job says so
"""
import os
import re
import threading
import time

from backend.process import clean_text
from diagnostics.thread_dump import Cancelled, DiagnosticError, check_result, probe_jvm, single_pid

HPROF_MAGIC = b"JAVA PROFILE 1.0"
SAFETY = 1.25
_UNITS = {"K": 1024, "M": 1024 ** 2, "G": 1024 ** 3}
_TOTAL_USED = re.compile(r"total\s+(\d+)([KMG]),\s*used\s+(\d+)([KMG])")
_ZGC_USED = re.compile(r"used\s+(\d+)([KMG]),\s*capacity")


def probe(oc, ns, pod, container, cancel=None):
    info = probe_jvm(oc, ns, pod, container, cancel)
    tools = {k: v for k, v in info["tools"].items() if k in ("jcmd", "jmap")}
    if not tools:
        raise DiagnosticError("Neither jcmd nor jmap was found in container '%s' (JRE-only image?). "
                              "No other method was attempted." % container)
    if not info["tmpw"]:
        raise DiagnosticError("/tmp is not writable in container '%s', so the JVM cannot write a heap dump there." % container)
    pid = single_pid(info, container)
    tool = "jcmd" if "jcmd" in tools else "jmap"
    return {"tool": tool, "tool_path": tools[tool], "pid": pid, "tmpfree_kb": info["tmpfree_kb"], "jcmd_path": tools.get("jcmd")}


def parse_heap_used(text):
    """Sum of 'used' across heap regions from `jcmd GC.heap_info`; None if it cannot be determined."""
    total, found = 0, False
    for line in (text or "").splitlines():
        if re.search(r"(?i)metaspace|class space", line):
            continue
        m = _TOTAL_USED.search(line)
        if m:
            total += int(m.group(3)) * _UNITS[m.group(4)]
            found = True
            continue
        m = _ZGC_USED.search(line)
        if m:
            total += int(m.group(1)) * _UNITS[m.group(2)]
            found = True
    return total if found and total > 0 else None


def estimate_used(oc, ns, pod, container, probe_info, cancel=None):
    """Bytes of heap in use (an upper bound for a live-objects dump), or None when unknown."""
    path = probe_info.get("jcmd_path")
    if not path:
        return None
    res = oc.exec_run(ns, pod, container, [path, str(probe_info["pid"]), "GC.heap_info"], 30, cancel=cancel)
    check_result(res, "Heap size check")
    if res.rc != 0:
        return None
    return parse_heap_used(res.out)


def plan(est_used, tmpfree_kb, cap_bytes):
    """Return (ok, message, needed_bytes). needed_bytes is what is reserved on the jump server."""
    mb = 1024 * 1024
    if est_used is not None:
        need = int(est_used * SAFETY)
        if need > cap_bytes:
            return False, ("Estimated dump size is about %d MB (heap in use %d MB + 25%% margin), above your size limit of %d MB. "
                           "Raise the limit (up to the server maximum) or reduce what you are capturing."
                           % (need // mb, est_used // mb, cap_bytes // mb)), need
    else:
        need = cap_bytes
    if tmpfree_kb is None:
        return False, "Free space in the container's /tmp could not be determined (no df); refusing to start a heap dump blindly.", need
    if tmpfree_kb * 1024 < need:
        return False, ("The container's /tmp has %d MB free but about %d MB is needed. A heap dump would fill the container's "
                       "filesystem and could destabilise the application." % (tmpfree_kb // 1024, need // mb)), need
    note = ("Heap in use ~%d MB; reserving ~%d MB (container /tmp has %d MB free)." % (est_used // mb, need // mb, tmpfree_kb // 1024)
            if est_used is not None else
            "Heap size could not be estimated; reserving your full limit of %d MB (container /tmp has %d MB free)." % (need // mb, tmpfree_kb // 1024))
    return True, note, need


def remote_path(job_id):
    return "/tmp/portal-heap-%s.hprof" % job_id


def _remove_remote(oc, ns, pod, container, path):
    """Delete the in-container dump. Not cancellable on purpose. Returns True when removal succeeded."""
    ok = False
    for attempt in range(2):
        res = oc.exec_run(ns, pod, container, ["rm", "-f", path], 20)
        ok = (res.rc == 0 and not res.error and not res.timed_out)
        if ok and attempt == 1:
            break
        if attempt == 0:
            time.sleep(1.0 if ok else 3.0)    # a JVM cut off mid-dump may still be writing; sweep again
    return ok


# set of (job, path) whose in-container file could not be removed; read (and cleared) by the job manager
_CLEANUP_FAILED = []


def cleanup_failed_for(job_id):
    hit = [p for j, p in _CLEANUP_FAILED if j == job_id]
    _CLEANUP_FAILED[:] = [(j, p) for j, p in _CLEANUP_FAILED if j != job_id]
    return hit[0] if hit else None


def _fail(res, oc, tool):
    low = (res.err or "").lower()
    if "unable to open socket file" in low or "attachnotsupported" in low:
        return ("The JVM refused the attach request (attach disabled, different user, or /tmp not writable). Detail: "
                + clean_text(res.err, 200))
    return oc.describe_failure(res, tool)


def collect(oc, ns, pod, container, probe_info, job_id, timeout, cap_bytes, part_path, cancel, free_local_bytes, progress=None):
    """Dump, verify and stream a heap dump into part_path.
    Returns {'size': int, 'cleanup_note': str|None}. Raises DiagnosticError / Cancelled."""
    path = remote_path(job_id)
    deadline = time.monotonic() + timeout
    tool, tpath, pid = probe_info["tool"], probe_info["tool_path"], str(probe_info["pid"])
    try:
        if progress:
            progress("Dumping heap inside the container (the JVM is paused while this runs)")
        cmd = [tpath, pid, "GC.heap_dump", path] if tool == "jcmd" else [tpath, "-dump:live,format=b,file=" + path, pid]
        res = oc.exec_run(ns, pod, container, cmd, max(1.0, deadline - time.monotonic()), cancel=cancel)
        if res.cancelled:
            raise Cancelled()
        if res.timed_out:
            raise DiagnosticError("The heap dump did not finish within the collection timeout; it was abandoned.")
        if res.error:
            raise DiagnosticError(res.error)
        low = ((res.out or "") + (res.err or "")).lower()
        if res.rc != 0 or "heap dump file created" not in low:
            if "permission denied" in low or "unable to create" in low or "no space" in low:
                raise DiagnosticError("The JVM could not write the heap dump in /tmp: " + clean_text(res.out + " " + res.err, 200))
            raise DiagnosticError(_fail(res, oc, tool))

        res = oc.exec_run(ns, pod, container, ["wc", "-c", path], 30, cancel=cancel)
        check_result(res, "Heap dump size check")
        m = re.match(r"\s*(\d+)\b", res.out or "")
        if res.rc != 0 or not m or int(m.group(1)) == 0:
            raise DiagnosticError("The heap dump file inside the container is missing or empty.")
        remote_size = int(m.group(1))
        if remote_size > cap_bytes:
            raise DiagnosticError("The heap dump is %d MB, above your size limit of %d MB; it was not transferred and was deleted."
                                  % (remote_size // 1048576, cap_bytes // 1048576))
        if remote_size * 1.05 > free_local_bytes():
            raise DiagnosticError("Not enough free space on this server for the %d MB dump; it was not transferred and was deleted."
                                  % (remote_size // 1048576))

        stop = threading.Event()
        started = time.monotonic()

        def ticker():
            while not stop.wait(3.0):
                try:
                    got = os.path.getsize(part_path)
                except OSError:
                    got = 0
                progress("Transferring: %.0f of %.0f MB (%ds)" % (got / 1048576.0, remote_size / 1048576.0, time.monotonic() - started))

        t = None
        if progress:
            progress("Transferring %.0f MB to the portal" % (remote_size / 1048576.0))
            t = threading.Thread(target=ticker)
            t.daemon = True
            t.start()
        try:
            fd = os.open(part_path, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w+b") as fh:
                res = oc.exec_run(ns, pod, container, ["cat", path], max(1.0, deadline - time.monotonic()), cancel=cancel,
                                  sink=fh, max_bytes=remote_size + 1)
                fh.flush()
                os.fsync(fh.fileno())
        finally:
            stop.set()
            if t:
                t.join(3)
        if res.cancelled:
            raise Cancelled()
        if res.timed_out:
            raise DiagnosticError("The transfer did not finish within the collection timeout; the partial file was discarded.")
        if res.error:
            raise DiagnosticError(res.error)
        if res.rc != 0:
            raise DiagnosticError(oc.describe_failure(res, "Heap dump transfer"))
        got = os.path.getsize(part_path)
        if got != remote_size:
            raise DiagnosticError("Incomplete transfer: received %d of %d bytes; the partial file was discarded." % (got, remote_size))
        with open(part_path, "rb") as fh:
            if not fh.read(len(HPROF_MAGIC)).startswith(HPROF_MAGIC):
                raise DiagnosticError("The transferred file is not a valid HPROF heap dump (bad header); it was discarded.")
        return {"size": got, "cleanup_note": None}
    finally:
        if not _remove_remote(oc, ns, pod, container, path):
            _CLEANUP_FAILED.append((job_id, path))
