"""TCP packet capture, method "container": uses ONLY a tcpdump that is already inside the target container.

Least-privilege design (nothing is granted or escalated by this portal): tcpdump must already exist in the container
image and the container must already be permitted to capture (NET_RAW). If not, we stop with a clear message.
For images WITHOUT tcpdump use the "node" method in diagnostics/node_capture.py.

  * The capture streams through `oc exec` to a server-side .part file; nothing is written inside the container.
  * Bounded three ways: duration (remote `timeout`), packet count, and byte size.
  * The BPF filter comes ONLY from a fixed preset table plus validated integers / an ipaddress-validated peer;
    no user text reaches tcpdump or a shell.
  * Default is headers-only (128 bytes/packet); full payload needs explicit consent.
"""
import ipaddress
import os
import re
import threading
import time

from backend.process import clean_text
from diagnostics import pcap
from diagnostics.thread_dump import Cancelled, DiagnosticError, check_result

# PLACEHOLDERS for the filters your platform / security team approves; edit here to change what the portal may ever
# ask tcpdump to do (used by BOTH capture methods).
FILTER_PRESETS = {
    "all": None, "tcp": "tcp", "dns": "port 53",
    "web": "tcp and (port 80 or port 8080)", "tls": "tcp and (port 443 or port 8443)", "port": "tcp port {port}",
}
PAYLOAD_MODES = {"headers": 128, "full": 262144}
MAX_PACKETS = 500000
STOP_GRACE = 15
SELFTEST_SECONDS = 3
VERSION_RE = re.compile(r"tcpdump version ([0-9][0-9A-Za-z.\-]{0,20})")
NOT_FOUND = ("executable file not found", "no such file or directory", "not found in $path")


def build_expression(preset, port=None, peer_ip=None):
    """Return the BPF expression string (or None). Inputs are validated again here, so this is safe on its own."""
    if preset not in FILTER_PRESETS:
        raise ValueError("unknown filter preset")
    base = FILTER_PRESETS[preset]
    if preset == "port":
        p = int(port)
        if not 1 <= p <= 65535:
            raise ValueError("bad port")
        base = base.format(port=p)
    parts = []
    if peer_ip:
        parts.append("host %s" % ipaddress.ip_address(str(peer_ip)))
    if base:
        parts.insert(0, base if not peer_ip else "(%s)" % base)
    return " and ".join(parts) if parts else None


def capture_command(duration, snaplen, expression):
    cmd = ["timeout", "-s", "INT", str(int(duration)), "tcpdump", "-n", "-i", "any", "-U",
           "-s", str(int(snaplen)), "-c", str(MAX_PACKETS), "-w", "-"]
    if expression:
        cmd.append(expression)
    return cmd


def _missing(res):
    low = (res.err or "").lower()
    return res.rc in (126, 127) or any(s in low for s in NOT_FOUND)


def probe(oc, ns, pod, container, cancel=None):
    """Verify tcpdump exists and the container may actually capture. Returns {'version': ...}."""
    res = oc.exec_run(ns, pod, container, ["tcpdump", "--version"], 30, cancel=cancel, max_bytes=65536)
    check_result(res, "tcpdump check")
    m = VERSION_RE.search((res.out or "") + "\n" + (res.err or ""))
    if not m:
        if _missing(res):
            raise DiagnosticError(
                "tcpdump was not found in container '%s'. This portal does not install tools or start privileged debug pods "
                "in this method; use an image that already contains tcpdump, or ask the platform team for an approved capture "
                "method. No other method was attempted." % container)
        raise DiagnosticError(oc.describe_failure(res, "tcpdump check"))
    version = m.group(1)
    res = oc.exec_run(ns, pod, container, ["timeout", "-s", "INT", str(SELFTEST_SECONDS), "tcpdump", "-n", "-i", "any",
                                           "-s", "64", "-c", "1", "-w", "-"],
                      SELFTEST_SECONDS + STOP_GRACE, cancel=cancel, max_bytes=65536)
    check_result(res, "Capture permission check")
    low = (res.err or "").lower()
    if _missing(res) and "timeout" in low:
        raise DiagnosticError("The 'timeout' utility is missing in container '%s'; it is required so a capture "
                              "can never outlive its time limit. No capture was started." % container)
    if "permission" in low or "not permitted" in low:
        raise DiagnosticError(
            "The container is not permitted to capture packets (tcpdump needs the NET_RAW capability, which OpenShift's "
            "restricted SCCs drop by default). This portal never grants extra privileges; the platform team must approve "
            "a capture-enabled workload or method.")
    if "no suitable device" in low or "no such device" in low:
        raise DiagnosticError("tcpdump could not find a network interface in the container.")
    if res.rc not in (0, 124):
        raise DiagnosticError(oc.describe_failure(res, "Capture permission check"))
    return {"version": version}


def collect(oc, ns, pod, container, duration, snaplen, expression, timeout, max_bytes, part_path, cancel, progress=None):
    """Stream a capture into part_path, validate/trim it, return {'size','packets','trimmed'}.
    Raises DiagnosticError / Cancelled. The caller owns cleanup of part_path."""
    command = capture_command(duration, snaplen, expression)
    run_timeout = min(float(timeout), duration + STOP_GRACE)
    stop = threading.Event()
    started = time.monotonic()

    def ticker():
        while not stop.wait(2.0):
            try:
                size = os.path.getsize(part_path)
            except OSError:
                size = 0
            progress("Capturing: %ds of %ds elapsed, %.1f MB received" % (min(int(time.monotonic() - started), duration), duration, size / 1048576.0))

    t = None
    if progress:
        progress("Capturing: 0s of %ds elapsed" % duration)
        t = threading.Thread(target=ticker)
        t.daemon = True
        t.start()
    try:
        fd = os.open(part_path, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w+b") as fh:
            res = oc.exec_run(ns, pod, container, command, run_timeout, cancel=cancel, sink=fh, max_bytes=max_bytes)
            fh.flush()
            os.fsync(fh.fileno())
    finally:
        stop.set()
        if t:
            t.join(3)
    if res.cancelled:
        raise Cancelled()
    if res.too_big:
        raise DiagnosticError("The capture reached the %d MB size limit and was stopped; the incomplete file was discarded. "
                              "Narrow the filter, shorten the duration or raise the limit." % (max_bytes // 1048576))
    if res.timed_out:
        if run_timeout < duration + STOP_GRACE:
            raise DiagnosticError("The collection timeout (%d s) was reached before the capture finished; the partial file was "
                                  "discarded. Raise the timeout or shorten the capture." % int(timeout))
        raise DiagnosticError("The capture did not stop within %d s of its time limit; it was cut off and the partial file "
                              "discarded. (The remote tcpdump is bounded by its own timeout.)" % STOP_GRACE)
    if res.error:
        raise DiagnosticError(res.error)
    if res.rc not in (0, 124):   # 124 = the remote `timeout` fired, i.e. the normal end of a timed capture
        low = (res.err or "").lower()
        if "permission" in low or "not permitted" in low:
            raise DiagnosticError("The container is not permitted to capture packets (NET_RAW).")
        raise DiagnosticError(oc.describe_failure(res, "tcpdump"))
    try:
        info = pcap.trim_to_valid(part_path)
    except pcap.PcapError as exc:
        raise DiagnosticError("The output is not a valid pcap capture (%s); it was discarded. tcpdump said: %s"
                              % (exc, clean_text(res.err, 200) or "nothing"))
    return {"size": os.path.getsize(part_path), "packets": info["packets"], "trimmed": info["trailing_bytes"]}
