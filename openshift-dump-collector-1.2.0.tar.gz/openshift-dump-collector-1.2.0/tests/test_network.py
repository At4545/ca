"""Network-exposure tests for server.py: bind policy, TLS, client allow-list, Host/Origin checks, cookies, audit.
Run:  python3 -m unittest discover -s tests -p "test_network.py" -v      (stdlib + openssl; ~1 min)
Uses tests/clusters.test.json and tests/bin/oc (the same fakes as the main suite).
"""
import http.client, json, os, socket, ssl, subprocess, sys, tempfile, time, unittest

import fakes  # noqa: F401  (repairs permissions / line endings / interpreter path of tests/bin/* before anything runs)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
SERVER = os.path.join(ROOT, "server.py")
CLUSTERS = os.path.join(ROOT, "tests", "clusters.test.json")
FAKE_OC = os.path.join(ROOT, "tests", "bin", "oc")
CERT_SCRIPT = os.path.join(ROOT, "scripts", "make_self_signed_cert.sh")
TOKEN = "sha256~dev-alice-" + "x" * 24
TMP = tempfile.mkdtemp()
CERT = os.path.join(TMP, "certs", "portal.crt")
KEY = os.path.join(TMP, "certs", "portal.key")


def own_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except OSError:
        return None
    finally:
        s.close()
    return None if ip.startswith("127.") else ip


OWN_IP = own_ip()


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def setUpModule():
    if subprocess.call(["bash", CERT_SCRIPT, "--host", "admin.example,127.0.0.1" + ("," + OWN_IP if OWN_IP else ""), "--out", os.path.join(TMP, "certs")],
                       stdout=subprocess.DEVNULL) != 0:
        raise unittest.SkipTest("could not create a test certificate (openssl missing?)")


class Running(object):
    """A server process with its own port, storage and logs."""
    def __init__(self, *extra, **kw):
        self.port = free_port()
        self.dir = tempfile.mkdtemp(dir=TMP)
        self.logs = os.path.join(self.dir, "logs")
        cmd = [sys.executable, SERVER, "--port", str(self.port), "--clusters", CLUSTERS, "--storage", os.path.join(self.dir, "s"),
               "--logs", self.logs, "--runtime-dir", os.path.join(self.dir, "rt"), "--oc-path", FAKE_OC] + list(extra)
        env = dict(os.environ, TMPDIR=self.dir, KUBECONFIG="/nonexistent")
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, universal_newlines=True)
        self.tls = "--tls-cert" in extra
        if kw.get("expect_exit"):
            self.out, _ = self.proc.communicate(timeout=30)
            return
        for _ in range(100):
            if self.proc.poll() is not None:
                self.out, _ = self.proc.communicate()
                raise AssertionError("server exited early (%s):\n%s" % (self.proc.returncode, self.out))
            try:
                socket.create_connection(("127.0.0.1", self.port), timeout=0.3).close()
                break
            except OSError:
                time.sleep(0.2)
        else:
            raise AssertionError("server did not start")

    def stop(self):
        if self.proc.poll() is None:
            self.proc.terminate()
        try:
            self.out, _ = self.proc.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.kill(); self.out, _ = self.proc.communicate()

    def request(self, method="GET", path="/", host=None, headers=None, body=None, via="127.0.0.1", tls=None, timeout=15):
        tls = self.tls if tls is None else tls
        if tls:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            conn = http.client.HTTPSConnection(via, self.port, context=ctx, timeout=timeout)
        else:
            conn = http.client.HTTPConnection(via, self.port, timeout=timeout)
        try:
            conn.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
            conn.putheader("Host", host if host is not None else "%s:%d" % (via, self.port))
            hdrs = dict(headers or {})
            if body is not None:
                hdrs.setdefault("Content-Type", "application/json")
                hdrs["Content-Length"] = str(len(body))
            for k, v in hdrs.items():
                conn.putheader(k, v)
            conn.endheaders(body.encode() if body is not None else None)
            r = conn.getresponse()
            data = r.read()
            return r.status, data, r
        finally:
            conn.close()

    def login(self, **kw):
        body = json.dumps({"cluster": "example-dev-1", "token": TOKEN})
        return self.request("POST", "/api/auth/login", body=body, **kw)

    def audit(self):
        with open(os.path.join(self.logs, "audit.log")) as fh:
            return [json.loads(l) for l in fh]


# ======================================================================= pure functions
class TestHelpers(unittest.TestCase):
    def test_allow_list(self):
        import server as s
        nets = s.parse_networks("10.20.0.0/16, 192.168.1.5,2001:db8::/32")
        for ip, want in (("10.20.5.6", True), ("10.21.0.1", False), ("192.168.1.5", True), ("192.168.1.6", False),
                         ("2001:db8::7", True), ("2001:dead::1", False), ("::ffff:10.20.1.1", True), ("::ffff:10.99.1.1", False),
                         ("127.0.0.1", True), ("::1", True), ("fe80::1%eth0", False), ("garbage", False), ("", False)):
            self.assertEqual(s.client_allowed(ip, nets), want, ip)
        everyone = s.parse_networks("any")
        self.assertTrue(s.client_allowed("8.8.8.8", everyone) and s.client_allowed("2001:4860::1", everyone))
        for bad in ("", "  ", "10.0.0.0/33", "banana", "10.0.0.0/8, nope"):
            with self.assertRaises(ValueError):
                s.parse_networks(bad)

    def test_loopback_detection(self):
        import server as s
        for h in ("127.0.0.1", "localhost", "::1", "127.5.5.5"):
            self.assertTrue(s.is_loopback_host(h), h)
        for h in ("0.0.0.0", "::", "", "10.1.2.3", "jump01.corp.example"):
            self.assertFalse(s.is_loopback_host(h), h)

    def test_host_header_parsing(self):
        import server as s
        for value, want in (("a.example:8443", ("a.example", 8443)), ("A.Example", ("a.example", None)), ("[::1]:8080", ("::1", 8080)),
                            ("[::1]", ("::1", None)), ("::1", (None, None)), ("a:b", (None, None)), ("", (None, None)), (None, (None, None)),
                            ("[::1", (None, None)), ("x" * 400, (None, None)), ("a.example:99999999999", ("a.example", 99999999999))):
            self.assertEqual(s.split_host_header(value), want, value)

    def test_host_ok_port_rules(self):
        import server as s
        srv = s.PortalServer.__new__(s.PortalServer)
        srv.names, srv.public_port, srv.scheme = {"admin.example"}, 8443, "https"
        self.assertTrue(srv.host_ok("admin.example:8443")); self.assertFalse(srv.host_ok("admin.example"))
        self.assertFalse(srv.host_ok("admin.example:443")); self.assertFalse(srv.host_ok("other.example:8443"))
        srv.public_port = 443; self.assertTrue(srv.host_ok("admin.example")); self.assertTrue(srv.host_ok("admin.example:443"))
        srv.scheme, srv.public_port = "http", 80; self.assertTrue(srv.host_ok("admin.example"))

    def test_public_name_validation(self):
        import server as s
        for good in ("jump01", "jump01.corp.example", "10.1.2.3", "fe80::1"):
            self.assertTrue(s.valid_public_name(good), good)
        for bad in ("", "a b", "http://x", "x/y", "x;y", "a" * 300):
            self.assertFalse(s.valid_public_name(bad), bad)


# ======================================================================= startup guard-rails
class TestStartupPolicy(unittest.TestCase):
    def refuses(self, *args, code=2):
        r = Running(*args, expect_exit=True)
        self.assertEqual(r.proc.returncode, code, r.out)
        self.assertIn("Startup error", r.out)
        self.assertNotIn("Traceback", r.out)
        return r.out

    def test_network_bind_needs_allow_from(self):
        self.assertIn("--allow-from", self.refuses("--host", "0.0.0.0", "--tls-cert", CERT, "--tls-key", KEY))

    def test_network_bind_needs_tls_or_explicit_insecure_flag(self):
        out = self.refuses("--host", "0.0.0.0", "--allow-from", "10.0.0.0/8")
        self.assertIn("HTTPS", out); self.assertIn("--allow-insecure-http", out)
        self.refuses("--host", "", "--allow-from", "any")
        self.refuses("--host", "::", "--allow-from", "any")

    def test_bad_arguments(self):
        self.refuses("--host", "0.0.0.0", "--allow-from", "10.0.0.0/99", "--tls-cert", CERT, "--tls-key", KEY)
        self.refuses("--host", "0.0.0.0", "--allow-from", "nonsense", "--tls-cert", CERT, "--tls-key", KEY)
        self.refuses("--tls-cert", CERT)
        self.refuses("--tls-key", KEY)
        self.assertIn("file not found", self.refuses("--tls-cert", "/nope.crt", "--tls-key", "/nope.key"))
        bogus = os.path.join(TMP, "bogus.pem")
        with open(bogus, "w") as fh:
            fh.write("not a certificate")
        self.assertIn("could not load", self.refuses("--tls-cert", bogus, "--tls-key", bogus))
        self.refuses("--public-host", "http://evil.example")
        self.refuses("--public-host", "a b")

    def test_port_in_use_is_a_clear_error(self):
        blocker = socket.socket(); blocker.bind(("127.0.0.1", 0)); blocker.listen(1)
        try:
            cmd = [sys.executable, SERVER, "--port", str(blocker.getsockname()[1]), "--clusters", CLUSTERS, "--storage", os.path.join(TMP, "sx"),
                   "--logs", os.path.join(TMP, "lx"), "--runtime-dir", os.path.join(TMP, "rx"), "--oc-path", FAKE_OC]
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, timeout=30)
        finally:
            blocker.close()
        self.assertEqual(p.returncode, 1)
        self.assertIn("could not listen", p.stdout)
        self.assertNotIn("Traceback", p.stdout)


# ======================================================================= default (loopback) behaviour
class TestLoopbackDefault(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = Running()

    @classmethod
    def tearDownClass(cls):
        cls.s.stop()

    def test_basics(self):
        code, raw, _ = self.s.request("GET", "/api/me")
        me = json.loads(raw)
        self.assertEqual((code, me["transport"], me["network_exposed"]), (200, "http", False))
        self.assertEqual(self.s.request("GET", "/api/health", host="localhost:%d" % self.s.port)[0], 200)
        self.assertEqual(self.s.request("GET", "/api/health", host="[::1]:%d" % self.s.port)[0], 200)
        self.assertNotIn(b"NOT encrypted", self.s.request("GET", "/")[1])

    def test_host_and_origin_rules(self):
        code, raw, _ = self.s.request("GET", "/api/health", host="evil.com")
        self.assertEqual(code, 400); self.assertIn("Unexpected Host header", json.loads(raw)["error"])
        self.assertEqual(self.s.request("GET", "/api/health", host="127.0.0.1:1")[0], 400)           # wrong port
        self.assertEqual(self.s.login(headers={"Origin": "http://evil.example"})[0], 403)
        self.assertEqual(self.s.login(headers={"Origin": "https://127.0.0.1:%d" % self.s.port})[0], 403)   # scheme must match
        self.assertEqual(self.s.request("POST", "/api/auth/login", body="{}", headers={"Content-Type": "text/plain"})[0], 415)

    def test_cookie_not_secure_over_plain_http(self):
        code, _, r = self.s.login(headers={"Origin": "http://127.0.0.1:%d" % self.s.port})
        self.assertEqual(code, 200)
        c = r.getheader("Set-Cookie"); self.assertIn("HttpOnly", c); self.assertIn("SameSite=Strict", c); self.assertNotIn("Secure", c)

    def test_login_source_is_audited(self):
        self.s.login()
        ev = [e for e in self.s.audit() if e["event"] == "login_source"]
        self.assertTrue(ev); self.assertEqual((ev[-1]["ip"], ev[-1]["cluster_id"], ev[-1]["user"]), ("127.0.0.1", "example-dev-1", "alice"))
        self.s.request("POST", "/api/auth/login", body=json.dumps({"cluster": "example-dev-1", "token": "bad"}))
        rej = [e for e in self.s.audit() if e["event"] == "login_rejected"]
        self.assertTrue(rej); self.assertEqual((rej[-1]["ip"], rej[-1]["reason"]), ("127.0.0.1", "bad_token_format")); self.assertIsNone(rej[-1]["user"])
        with open(os.path.join(self.s.logs, "audit.log")) as fh:
            self.assertNotIn("sha256~", fh.read())

    def test_slow_client_does_not_block_others(self):
        idle = socket.create_connection(("127.0.0.1", self.s.port))      # connects and says nothing
        try:
            t0 = time.time()
            self.assertEqual(self.s.request("GET", "/api/health")[0], 200)
            self.assertLess(time.time() - t0, 3)
        finally:
            idle.close()


# ======================================================================= TLS on loopback
class TestTls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = Running("--tls-cert", CERT, "--tls-key", KEY)

    @classmethod
    def tearDownClass(cls):
        cls.s.stop()

    def test_https_works_and_reports_transport(self):
        code, raw, r = self.s.request("GET", "/api/me")
        me = json.loads(raw); self.assertEqual((code, me["transport"], me["network_exposed"]), (200, "https", False))

    def test_plain_http_to_the_tls_port_gets_nothing(self):
        with self.assertRaises((http.client.HTTPException, OSError)):
            self.s.request("GET", "/api/health", tls=False, timeout=5)
        self.assertEqual(self.s.request("GET", "/api/health")[0], 200)       # and the server is still fine

    def test_cookie_is_secure_and_origin_must_be_https(self):
        base = "127.0.0.1:%d" % self.s.port
        self.assertEqual(self.s.login(headers={"Origin": "http://" + base})[0], 403)
        code, _, r = self.s.login(headers={"Origin": "https://" + base})
        self.assertEqual(code, 200)
        c = r.getheader("Set-Cookie"); self.assertIn("Secure", c); self.assertIn("HttpOnly", c); self.assertIn("SameSite=Strict", c)
        sid = c.split(";")[0]
        code, raw, r = self.s.request("POST", "/api/auth/logout", body="{}", headers={"Cookie": sid, "Origin": "https://" + base})
        self.assertEqual(code, 200); self.assertIn("Secure", r.getheader("Set-Cookie")); self.assertIn("Max-Age=0", r.getheader("Set-Cookie"))

    def test_old_tls_versions_refused(self):
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            ctx.minimum_version = ssl.TLSVersion.TLSv1; ctx.maximum_version = ssl.TLSVersion.TLSv1_1
        except (ValueError, ssl.SSLError):
            self.skipTest("this OpenSSL cannot even offer TLS 1.0/1.1")
        with self.assertRaises((ssl.SSLError, OSError)):
            with socket.create_connection(("127.0.0.1", self.s.port), timeout=5) as raw:
                ctx.wrap_socket(raw, server_hostname="127.0.0.1")
        ctx2 = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx2.check_hostname = False; ctx2.verify_mode = ssl.CERT_NONE
        ctx2.minimum_version = ssl.TLSVersion.TLSv1_2
        with socket.create_connection(("127.0.0.1", self.s.port), timeout=5) as raw, ctx2.wrap_socket(raw, server_hostname="127.0.0.1") as t:
            self.assertIn(t.version(), ("TLSv1.2", "TLSv1.3"))

    def test_stalled_handshake_does_not_block_other_clients(self):
        stalled = [socket.create_connection(("127.0.0.1", self.s.port)) for _ in range(3)]    # TCP connect, never start TLS
        try:
            t0 = time.time()
            self.assertEqual(self.s.request("GET", "/api/health")[0], 200)
            self.assertLess(time.time() - t0, 3)
        finally:
            for c in stalled:
                c.close()

    def test_garbage_bytes_do_not_crash_the_server(self):
        for junk in (b"\x16\x03\x01\x00\x05hello", b"GET / HTTP/1.1\r\n\r\n", b"\x00" * 100, os.urandom(300)):
            with socket.create_connection(("127.0.0.1", self.s.port), timeout=5) as c:
                c.sendall(junk)
                try:
                    c.recv(100)
                except OSError:
                    pass
        self.assertEqual(self.s.request("GET", "/api/health")[0], 200)


# ======================================================================= network-exposed server (TLS)
@unittest.skipUnless(OWN_IP, "this machine has no non-loopback IPv4 address to test with")
class TestNetworkTls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.allow = Running("--host", "0.0.0.0", "--tls-cert", CERT, "--tls-key", KEY, "--allow-from", OWN_IP + "/32",
                            "--public-host", "admin.example")
        cls.deny = Running("--host", "0.0.0.0", "--tls-cert", CERT, "--tls-key", KEY, "--allow-from", "203.0.113.0/24",
                           "--public-host", "admin.example")

    @classmethod
    def tearDownClass(cls):
        cls.allow.stop(); cls.deny.stop()

    def test_allowed_client_reaches_the_portal_by_its_own_ip_and_by_public_host(self):
        a = self.allow
        code, raw, _ = a.request("GET", "/api/me", via=OWN_IP)             # Host: <own ip>:port is auto-allowed
        me = json.loads(raw); self.assertEqual((code, me["transport"], me["network_exposed"]), (200, "https", True))
        self.assertEqual(a.request("GET", "/api/health", via=OWN_IP, host="admin.example:%d" % a.port)[0], 200)

    def test_client_outside_allow_list_is_cut_off_before_any_response(self):
        d = self.deny
        with self.assertRaises((http.client.HTTPException, OSError)):
            d.request("GET", "/api/health", via=OWN_IP, timeout=5)
        with self.assertRaises((http.client.HTTPException, OSError)):
            d.request("GET", "/", via=OWN_IP, timeout=5)
        self.assertEqual(d.request("GET", "/api/health")[0], 200)           # loopback (an admin on the box) still works
        deadline = time.time() + 5
        while time.time() < deadline and "Refused a connection" not in self.read_log(d):
            time.sleep(0.2)
        self.assertIn("Refused a connection from %s" % OWN_IP, self.read_log(d))

    @staticmethod
    def read_log(r):
        with open(os.path.join(r.logs, "app.log")) as fh:
            return fh.read()

    def test_host_header_rules_when_exposed(self):
        a = self.allow
        for host in ("other.example:%d" % a.port, "admin.example", "admin.example:1", "evil.com", "127.0.0.1.evil.com:%d" % a.port):
            code, raw, _ = a.request("GET", "/api/health", via=OWN_IP, host=host)
            self.assertEqual(code, 400, host)
        err = json.loads(a.request("GET", "/api/health", via=OWN_IP, host="other.example:%d" % a.port)[1])["error"]
        self.assertIn("--public-host", err); self.assertIn("https://admin.example:%d" % a.port, err)

    def test_login_over_the_network_is_secure_and_records_the_source_ip(self):
        a = self.allow
        base = "%s:%d" % (OWN_IP, a.port)
        code, _, r = a.login(via=OWN_IP, headers={"Origin": "https://" + base})
        self.assertEqual(code, 200)
        self.assertIn("Secure", r.getheader("Set-Cookie"))
        self.assertEqual(a.login(via=OWN_IP, headers={"Origin": "https://evil.example"})[0], 403)
        ev = [e for e in a.audit() if e["event"] == "login_source"]
        self.assertEqual(ev[-1]["ip"], OWN_IP)

    def test_startup_log_lists_where_to_open_it_and_has_no_insecure_warning(self):
        out = self.read_log(self.allow)
        self.assertIn("network-exposed", out); self.assertIn("open: https://admin.example:%d/" % self.allow.port, out)
        self.assertNotIn("INSECURE", out)


# ======================================================================= explicit plain-HTTP opt-in
class TestInsecureOptIn(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = Running("--host", "0.0.0.0", "--allow-insecure-http", "--allow-from", "any")

    @classmethod
    def tearDownClass(cls):
        cls.s.stop()

    def test_page_shows_a_warning_and_cookie_is_not_secure(self):
        code, raw, _ = self.s.request("GET", "/")
        self.assertEqual(code, 200); self.assertIn(b"NOT encrypted", raw)
        self.assertLess(raw.index(b"NOT encrypted"), raw.index(b'<main id="view"'))
        me = json.loads(self.s.request("GET", "/api/me")[1]); self.assertEqual((me["transport"], me["network_exposed"]), ("http", True))
        code, _, r = self.s.login(headers={"Origin": "http://127.0.0.1:%d" % self.s.port})
        self.assertEqual(code, 200); self.assertNotIn("Secure", r.getheader("Set-Cookie"))
        for static in ("/style.css", "/script.js"):
            self.assertNotIn(b"NOT encrypted", self.s.request("GET", static)[1])

    def test_server_logs_loud_warnings(self):
        with open(os.path.join(self.s.logs, "app.log")) as fh:
            log = fh.read()
        self.assertIn("INSECURE", log); self.assertIn("--allow-from any", log)


if __name__ == "__main__":
    unittest.main(verbosity=2)
