"""Makes the FAKE `oc` programs in tests/bin runnable on ANY machine, whatever happened to them in transit.

Files that pass through a zip, a Windows editor or a Git checkout often lose their execute permission or gain Windows (CRLF)
line endings, and the interpreter named in their first line may not exist (for example /usr/bin/python3 on a machine whose
Python lives elsewhere). Each test module calls prepare() before starting anything, which repairs all three problems.
"""
import os
import stat
import sys

BIN = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bin")


def prepare():
    fixed = []
    for name in sorted(os.listdir(BIN)):
        path = os.path.join(BIN, name)
        if not os.path.isfile(path):
            continue
        with open(path, "rb") as fh:
            data = fh.read()
        new = data
        if b"\r" in new.split(b"\n", 1)[0] or b"\r\n" in new:
            new = new.replace(b"\r\n", b"\n")
        first, _, rest = new.partition(b"\n")
        if first.startswith(b"#!"):
            parts = first[2:].decode("utf-8", "replace").split()
            if parts and not os.path.exists(parts[0]):
                first = ("#!%s %s" % (sys.executable, " ".join(parts[1:]))).strip().encode()
                new = first + b"\n" + rest
        if new != data:
            with open(path, "wb") as fh:
                fh.write(new)
            fixed.append(name + " (rewritten)")
        mode = os.stat(path).st_mode
        if (mode & 0o755) != 0o755:
            os.chmod(path, (mode & 0o7777) | 0o755)
            fixed.append(name + " (made executable)")
    return fixed


prepare()
