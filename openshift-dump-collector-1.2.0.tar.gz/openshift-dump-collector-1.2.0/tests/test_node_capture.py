"""Tests for TCP capture on the node (method "node"), the node-capture settings, run.sh, plus a regression smoke of the
other diagnostics (thread dump, heap dump, in-container capture).
Run:  python3 -m unittest discover -s tests -p "test_node_capture.py" -v        (stdlib only; a few minutes)

Real server processes run against tests/bin/oc_nodes, a FAKE `oc` (wrapping tests/bin/oc) that simulates
`oc debug node/...`, nodes, permissions and many failure modes. Test tokens look like sha256~<env>-<name>-xxxx.
Users: alice and dave (cluster-admin-like), bob (no node rights), carol (reads nodes, no privileged SCC).
"""
import hashlib, http.cookies, json, os, socket, stat, struct, subprocess, sys, tempfile, threading, time, unittest
import urllib.error, urllib.request

import fakes  # noqa: F401  (repairs permissions / line endings / interpreter path of tests/bin/* before anything runs)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
FAKE = os.path.join(ROOT, "tests", "bin", "oc_nodes")
CLUSTERS = os.path.join(ROOT, "tests", "clusters.test.json")
SERVER = os.path.join(ROOT, "server.py")
IMAGE = "registry.example.com/tools/net:1.0"


def put(path, data, mode="wb"):
    with open(path, mode) as fh:
        fh.write(data)
    return path


def tok(env, name):
    return "sha256~%s-%s-%s" % (env, name, "x" * 24)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class Client(object):
    def __init__(self, port):
        self.base = "http://127.0.0.1:%d" % port
        self.cookie = None

    def call(self, method, path, body=None, raw=False):
        h = {"Content-Type": "application/json"} if method == "POST" else {}
        if self.cookie:
            h["Cookie"] = "dc_session=" + self.cookie
        data = json.dumps(body).encode() if body is not None else (b"{}" if method == "POST" else None)
        req = urllib.request.Request(self.base + path, data=data, method=method, headers=h)
        try:
            r = urllib.request.urlopen(req, timeout=60)
            code, content, hdrs = r.status, r.read(), r.headers
        except urllib.error.HTTPError as e:
            code, content, hdrs = e.code, e.read(), e.headers
        for sc in hdrs.get_all("Set-Cookie") or []:
            m = http.cookies.SimpleCookie(sc).get("dc_session")
            if m is not None:
                self.cookie = m.value or None
        if raw:
            return code, content, hdrs
        try:
            return code, json.loads(content or b"null")
        except ValueError:
            return code, content

    def login(self, cluster="example-dev-1", env="dev", name="alice"):
        return self.call("POST", "/api/auth/login", {"cluster": cluster, "token": tok(env, name)})


class ServerCase(unittest.TestCase):
    EXTRA = []

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.port = free_port()
        cls.storage, cls.logs, cls.rt = (os.path.join(cls.tmp, d) for d in ("storage", "logs", "rt"))
        env = dict(os.environ, TMPDIR=cls.tmp, KUBECONFIG="/nonexistent/admin-kubeconfig")
        cls.proc = subprocess.Popen(
            [sys.executable, SERVER, "--port", str(cls.port), "--clusters", CLUSTERS, "--storage", cls.storage, "--logs", cls.logs,
             "--runtime-dir", cls.rt, "--oc-path", FAKE, "--max-concurrent", "4", "--login-fail-limit", "100",
             "--heap-max-mb", "64"] + cls.EXTRA, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
        cls.admin = Client(cls.port)
        for _ in range(60):
            try:
                if cls.admin.call("GET", "/api/health")[0] == 200:
                    break
            except Exception:
                time.sleep(0.1)

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate(); cls.proc.wait(5)

    # ---- helpers
    def user(self, name="alice", env="dev", cluster="example-dev-1"):
        c = Client(self.port)
        code, r = c.login(cluster, env, name)
        self.assertEqual(code, 200, r)
        return c

    def req(self, dump_type="tcp", cluster="example-dev-1", ns="demo-dev", pod="nd-ok", container="app", **kw):
        opts = {"timeout": 300, "duration": 5, "size_limit_mb": 5, "method": "node"} if dump_type == "tcp" else {}
        opts.update(kw.pop("options", {}))
        body = {"cluster": cluster, "namespace": ns, "pod": pod, "container": container, "dump_type": dump_type, "options": opts}
        body.update(kw)
        return body

    def node(self, pod="nd-ok", **kw):
        kw.setdefault("confirm_node", True)
        return self.req(pod=pod, **kw)

    def wait(self, c, jid, want=("Completed", "Failed", "Cancelled"), t=60):
        end, j = time.time() + t, None
        while time.time() < end:
            j = c.call("GET", "/api/jobs/" + jid)[1]["job"]
            if j["status"] in want:
                return j
            time.sleep(0.3)
        self.fail("job did not finish: %s" % j)

    def run_job(self, c, body):
        code, r = c.call("POST", "/api/jobs", body)
        self.assertEqual(code, 202, r)
        return self.wait(c, r["job"]["id"])

    def validate(self, c, body):
        code, r = c.call("POST", "/api/validate", body)
        self.assertEqual(code, 200, r)
        return r

    def failing(self, c, body):
        r = self.validate(c, body)
        self.assertFalse(r["ok"], r)
        return [x for x in r["checks"] if not x["ok"]][0]

    def audit(self):
        with open(os.path.join(self.logs, "audit.log")) as fh:
            return [json.loads(l) for l in fh]

    def debug_calls(self):
        p = os.path.join(self.tmp, "fake-debug.log")
        if not os.path.exists(p):
            return []
        with open(p) as fh:
            return [json.loads(l) for l in fh]

    def oc_calls(self):
        p = os.path.join(self.tmp, "fake-oc.log")
        if not os.path.exists(p):
            return []
        with open(p) as fh:
            return [json.loads(l) for l in fh]

    def dumps_dir(self):
        return os.listdir(os.path.join(self.storage, "dumps"))

    def download(self, c, job):
        code, raw, _ = c.call("GET", "/api/jobs/%s/download" % job["id"], raw=True)
        self.assertEqual(code, 200)
        return raw

    def scan_pcap(self, raw):
        from diagnostics import pcap
        return pcap.scan(put(os.path.join(self.tmp, "dl-%d.pcap" % time.time_ns()), raw))

    def active_tmp_namespaces(self):
        p = os.path.join(self.tmp, "debug-ns.json")
        if not os.path.exists(p):
            return []
        with open(p) as fh:
            return [i["name"] for i in json.load(fh) if i["phase"] == "Active"]


# =========================================================================================== pure units
class TestUnits(unittest.TestCase):
    def test_scripts_are_constants_with_only_quoted_positional_parameters(self):
        import re
        from diagnostics.node_capture import CAPTURE_SCRIPT, DISCOVER_SCRIPT
        for script, allowed in ((DISCOVER_SCRIPT, {"1", "2"}), (CAPTURE_SCRIPT, {"1", "2", "3", "4", "5"})):
            self.assertEqual({m for m in re.findall(r"\$(\d)", script)}, allowed)
            for m in re.finditer(r"\$\d", script):                         # every use sits inside double quotes
                before = script[:m.start()]
                self.assertEqual(before.count('"') % 2, 1, script[max(0, m.start() - 30):m.end() + 5])
            for forbidden in ("eval", "`", "${", "$1$", "\\$"):
                self.assertNotIn(forbidden, script)
        self.assertIn("exec timeout -s INT", CAPTURE_SCRIPT); self.assertIn("-w -", CAPTURE_SCRIPT)
        self.assertNotIn("/host/var/tmp", CAPTURE_SCRIPT)                   # nothing is written on the node

    def test_marker_sink(self):
        import io
        from diagnostics.node_capture import MARKER, MarkerSink
        for chunks, want in (([b"noise\n" + MARKER + b"PCAPDATA"], b"PCAPDATA"),
                             ([b"x" * 5, MARKER[:7], MARKER[7:] + b"AB", b"CD"], b"ABCD"),
                             ([MARKER], b""), ([b"no marker at all"], None)):
            fh, started = io.BytesIO(), []
            s = MarkerSink(fh, on_start=lambda: started.append(1))
            for c in chunks:
                self.assertEqual(s.write(c), len(c))
            self.assertEqual(s.started, want is not None)
            self.assertEqual(fh.getvalue(), want if want is not None else b"")
            self.assertEqual(len(started), 1 if want is not None else 0)
        big = MarkerSink(io.BytesIO())                                      # unbounded noise does not grow memory
        for _ in range(100):
            big.write(b"y" * 10000)
        self.assertLess(len(big._buf), 70000)

    def test_discovery_parsing_ignores_noise(self):
        from diagnostics.node_capture import parse_discovery
        out = parse_discovery("Starting pod/x ...\nnoise\ntool=tcpdump\ntool=nsenter\ntool=timeout\ntool=evil\npodcount=1\npodid=" + "a" * 64 +
                              "\njson-begin\n{\"a\": 1}\njson-end\nRemoving debug pod\n")
        self.assertEqual((out["seen"], out["tools"], out["podcount"], out["podid"], out["json"]),
                         (True, {"tcpdump", "nsenter", "timeout"}, 1, "a" * 64, '{"a": 1}'))
        self.assertFalse(parse_discovery("error: something\n")["seen"])
        self.assertEqual(parse_discovery("podcount=x\n")["podcount"], None)

    def test_netns_from_inspect(self):
        from diagnostics.node_capture import netns_from_inspect as f
        doc = lambda spaces: json.dumps({"info": {"runtimeSpec": {"linux": {"namespaces": spaces}}}})
        self.assertEqual(f(doc([{"type": "pid"}, {"type": "network", "path": "/var/run/netns/cni-1"}])), "/var/run/netns/cni-1")
        self.assertEqual(f(doc([{"type": "network"}])), "")                 # host network
        self.assertEqual(f(json.dumps({})), "")
        with self.assertRaises(ValueError):
            f("not json")

    def test_validators(self):
        from diagnostics import node_capture as n
        for ok in ("/var/run/netns/cni-1a2b-3c", "/run/netns/abc", "/proc/1234/ns/net"):
            self.assertTrue(n.NETNS_RE.fullmatch(ok), ok)
        for bad in ("/etc/passwd", "/var/run/netns/", "/var/run/netns/../../etc/x", "/var/run/netns/a b", "/proc/x/ns/net",
                    "var/run/netns/x", "/var/run/netns/x;id", "/host/var/run/netns/x", "/var/run/netns/x\n"):
            self.assertIsNone(n.NETNS_RE.fullmatch(bad), bad)
        self.assertTrue(n.valid_node("worker-1.example")); self.assertTrue(n.valid_node("ip-10-0-1-2.ec2.internal"))
        for bad in ("Bad_Node!", "", "a b", "-x", "x;id", "a" * 300):
            self.assertFalse(n.valid_node(bad), bad)
        self.assertTrue(n.valid_image(IMAGE)); self.assertTrue(n.valid_image("quay.io/a/b@sha256:" + "0" * 64))
        for bad in ("", "a b", "x;id", "--privileged", "-x", "$(id)", "a" * 300, "img\n"):
            self.assertFalse(n.valid_image(bad), bad)
        self.assertEqual(n.pod_name_regex("my-app-7d9c.v1"), "^my-app-7d9c\\.v1$")
        for bad in ("A", "a b", "a;b", "", "a|b", ".x"):
            with self.assertRaises(ValueError):
                n.pod_name_regex(bad)

    def test_leftovers(self):
        from diagnostics.node_capture import leftover_namespaces as f, leftover_note
        self.assertEqual(f({"a": "Active"}, {"a": "Active", "b": "Active", "c": "Terminating", "d": "Active"}), ["b", "d"])
        self.assertEqual(f(None, {"x": "Active"}), []); self.assertEqual(f({}, None), [])
        self.assertIn("oc delete namespace b d", leftover_note(["b", "d"]))

    def test_request_validation(self):
        from backend.errors import ApiError
        from backend.validation import options_of, parse_request
        base = {"cluster": "example-dev-1", "namespace": "demo-dev", "pod": "p", "container": "app", "dump_type": "tcp"}
        c = parse_request(dict(base))
        self.assertEqual((c["method"], c["confirm_node"]), ("container", False))
        c = parse_request(dict(base, options={"method": "node", "duration": 30, "timeout": 210}, confirm_node=True))
        self.assertEqual((c["method"], c["confirm_node"], options_of(c)["method"]), ("node", True, "node"))
        self.assertFalse(parse_request(dict(base, confirm_node="yes"))["confirm_node"])
        self.assertFalse(parse_request(dict(base, confirm_node=1))["confirm_node"])
        bad = [dict(base, options={"method": "root"}), dict(base, options={"method": 5}), dict(base, options={"method": ["node"]}),
               dict(base, options={"method": "node", "duration": 30, "timeout": 60}),      # a debug pod needs time to start
               dict(base, options={"method": "node", "duration": 120, "timeout": 250}),
               dict(base, dump_type="thread", options={"method": "node"}), dict(base, dump_type="heap", options={"method": "node"}),
               dict(base, options={"method": "node", "node": "worker-1"}), dict(base, options={"method": "node", "image": "x"}),
               dict(base, options={"method": "node", "command": "id"})]
        for b in bad:
            with self.assertRaises(ApiError, msg=str(b["options"])) as cm:
                parse_request(b)
            self.assertEqual(cm.exception.code, 400)
        parse_request(dict(base, options={"method": "container", "duration": 30, "timeout": 60}))   # the old rule still holds

    def test_settings(self):
        from backend.configuration import Settings
        s = Settings("a", "b", "c")
        self.assertEqual((s.node_capture_envs, s.node_capture_users, s.node_capture_image, s.max_node_jobs), (("DEV", "TEST"), ("*",), "", 1))
        self.assertTrue(s.node_capture_allows("x", "anyone"))
        s = Settings("a", "b", "c", node_capture_envs=("DEV", "BOGUS"), node_capture_users=("c1:alice",))
        self.assertEqual(s.node_capture_envs, ("DEV",))
        self.assertTrue(s.node_capture_allows("c1", "alice")); self.assertFalse(s.node_capture_allows("c1", "bob")); self.assertFalse(s.node_capture_allows("c2", "alice"))
        self.assertEqual(Settings("a", "b", "c").tcp_envs, ("DEV", "TEST"))                  # the old setting is unchanged

    def test_fixture_repair_handles_the_three_ways_a_fake_oc_breaks(self):
        """The exact failure seen on a real jump server: tests/bin/oc lost its execute bit / got CRLF / named a missing python."""
        import importlib
        d = tempfile.mkdtemp()
        os.makedirs(os.path.join(d, "bin"))
        mods = {}
        for name, first, mode in (("noexec", "#!/usr/bin/python3 -S\n", 0o644), ("crlf", "#!/usr/bin/python3 -S\r\n", 0o755),
                                  ("nopython", "#!/nonexistent/python3 -S\n", 0o755)):
            put(os.path.join(d, "bin", name), first + "print('ok')\n", "w")
            os.chmod(os.path.join(d, "bin", name), mode)
        mod = importlib.import_module("fakes")
        old = mod.BIN
        mod.BIN = os.path.join(d, "bin")
        try:
            fixed = mod.prepare()
        finally:
            mod.BIN = old
        self.assertTrue(fixed)
        for name in ("noexec", "crlf", "nopython"):
            p = os.path.join(d, "bin", name)
            self.assertTrue(os.access(p, os.X_OK), name)
            with open(p, "rb") as fh:
                head = fh.readline()
            self.assertNotIn(b"\r", head, name)
            self.assertTrue(os.path.exists(head[2:].split()[0].decode()), name)
            r = subprocess.run([p], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertEqual((r.returncode, r.stdout.strip()), (0, b"ok"), (name, r.stderr))

    def test_node_fake_runs_even_if_the_plain_fake_is_not_executable(self):
        """oc_nodes starts the plain fake through the interpreter, so a missing execute bit on tests/bin/oc cannot break it."""
        d = tempfile.mkdtemp()
        for n in ("oc", "oc_nodes"):
            with open(os.path.join(ROOT, "tests", "bin", n), "rb") as fh:
                put(os.path.join(d, n), fh.read())
        os.chmod(os.path.join(d, "oc"), 0o644)                                        # NOT executable
        os.chmod(os.path.join(d, "oc_nodes"), 0o755)
        kc = os.path.join(d, "kc.json")
        put(kc, json.dumps({"clusters": [{"name": "t", "cluster": {"server": "https://api.dev.example.com:6443"}}],
                            "users": [{"name": "u", "user": {"token": tok("dev", "alice")}}], "contexts": []}), "w")
        os.chmod(kc, 0o600)
        os.chmod(d, 0o700)
        r = subprocess.run([os.path.join(d, "oc_nodes"), "whoami"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True,
                           env=dict(os.environ, KUBECONFIG=kc, TMPDIR=d))
        self.assertEqual((r.returncode, r.stdout.strip()), (0, "alice"), r.stderr)


# =========================================================================================== end to end
class TestNodeCapture(ServerCase):
    EXTRA = ["--tcp-envs", "DEV,PROD", "--node-capture-envs", "DEV,PROD", "--admin-users", "example-dev-1:alice"]

    def setUp(self):                                    # each test starts with a clean fake cluster (no leftover debug namespaces)
        for n in ("debug-ns.json",):
            if os.path.exists(os.path.join(self.tmp, n)):
                os.remove(os.path.join(self.tmp, n))

    def test_me_reports_node_capture_envs(self):
        me = self.admin.call("GET", "/api/me")[1]
        with open(os.path.join(ROOT, "VERSION")) as fh:
            version = fh.read().strip()
        self.assertEqual((me["node_capture_envs"], me["tcp_envs"], me["version"]), (["DEV", "PROD"], ["DEV", "PROD"], version))

    def test_the_fix_container_method_fails_node_method_works_on_the_same_pod(self):
        a = self.user()
        c = self.failing(a, self.req(pod="no-tcpdump", options={"method": "container", "timeout": 60}))       # old behaviour
        self.assertEqual(c["name"], "Capture tool and permission"); self.assertIn("tcpdump was not found", c["message"])
        self.assertIn("choose the capture method 'On the node'", c["message"])                                # and points at the fix
        before = len(self.debug_calls())
        r = self.validate(a, self.req(pod="no-tcpdump"))                                                      # dry run, node method
        self.assertTrue(r["ok"], r)
        names = {x["name"]: x for x in r["checks"]}
        self.assertTrue(names["Node debug permission"]["ok"])
        self.assertIn("worker-1.example", names["Node"]["message"]); self.assertIn("Ready", names["Node"]["message"])
        self.assertTrue(names["Debug pod and network namespace"]["skipped"])
        self.assertTrue(names["Node capture acknowledgement"]["skipped"])
        self.assertEqual(len(self.debug_calls()), before)                                                     # validation never starts a debug pod
        j = self.run_job(a, self.node(pod="no-tcpdump"))
        self.assertEqual(j["status"], "Completed", j)

    def test_end_to_end_pcap_and_exact_command_shape(self):
        from diagnostics.node_capture import CAPTURE_SCRIPT, DISCOVER_SCRIPT
        a = self.user()
        before = len(self.debug_calls())
        j = self.run_job(a, self.node(options={"filter": "port", "port": 8080, "peer_ip": "10.1.2.3", "duration": 5}))
        self.assertEqual(j["status"], "Completed", j)
        self.assertEqual((j["packets"], j["note"], j["node"], j["options"]["method"]), (3, None, "worker-1.example", "node"))
        info = self.scan_pcap(self.download(a, j))
        self.assertEqual((info["packets"], info["trailing_bytes"]), (3, 0))
        text = self.download(a, j).decode("latin1")
        for needle in ("node=worker-1.example", "expr=(tcp port 8080) and host 10.1.2.3", "snap=128", "secs=5", "c=500000", "image=-"):
            self.assertIn(needle, text)
        calls = self.debug_calls()[before:]
        self.assertEqual([c["mode"] for c in calls], ["discover", "capture"])
        d, c = calls
        sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
        self.assertEqual((d["script_sha"], c["script_sha"]), (sha(DISCOVER_SCRIPT), sha(CAPTURE_SCRIPT)))   # the scripts are exactly the constants
        self.assertEqual(d["argv"], ["debug", "node/worker-1.example", "--no-stdin", "--tty=false", "--", "sh", "-c", DISCOVER_SCRIPT, "portal", "demo-dev", "^nd-ok$"])
        self.assertEqual(c["argv"], ["debug", "node/worker-1.example", "--no-stdin", "--tty=false", "--", "sh", "-c", CAPTURE_SCRIPT, "portal",
                                     "5", "/var/run/netns/cni-nd-ok-1a2b3c", "128", "500000", "(tcp port 8080) and host 10.1.2.3"])
        for x in calls:
            self.assertEqual(x["violations"], []); self.assertTrue(x["no_stdin"] and x["tty_false"]); self.assertEqual(x["ident"], "alice")
        path = os.path.join(self.storage, "dumps", j["download_name"])
        self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")])
        self.assertEqual(self.active_tmp_namespaces(), [])                                                    # oc debug cleaned up after itself
        ev = {e["event"]: e for e in self.audit() if e.get("job_id") == j["id"]}
        self.assertEqual((ev["job_started"]["method"], ev["job_started"]["node"], ev["job_started"]["filter_expression"]),
                         ("node", "worker-1.example", "(tcp port 8080) and host 10.1.2.3"))
        self.assertTrue(ev["job_requested"]["node_acknowledged"]); self.assertEqual(ev["job_requested"]["options"]["method"], "node")
        self.assertEqual(ev["job_completed"]["packets"], 3)

    def test_full_payload_snaplen_after_consent_only(self):
        a = self.user()
        j = self.run_job(a, self.node(options={"payload": "full"}))
        self.assertEqual(j["status"], "Failed"); self.assertIn("credentials", j["error"])
        j = self.run_job(a, self.node(options={"payload": "full"}, confirm_payload=True))
        self.assertEqual(j["status"], "Completed", j); self.assertIn("snap=262144", self.download(a, j).decode("latin1"))

    def test_acknowledgement_is_enforced_by_the_server(self):
        a = self.user()
        before = len(self.debug_calls())
        j = self.run_job(a, self.req())                                                                      # no confirm_node
        self.assertEqual(j["status"], "Failed"); self.assertIn("PRIVILEGED debug pod", j["error"]); self.assertIn("Acknowledge", j["error"])
        self.assertEqual([c["name"] for c in j["checks"]], ["Cluster configuration", "Capture policy"])      # refused before any cluster call
        self.assertEqual(len(self.debug_calls()), before)

    def test_permissions_come_from_the_users_own_token(self):
        self.assertEqual(self.failing(self.user("bob"), self.req())["name"], "Node debug permission")
        c = self.failing(self.user("bob"), self.req()); self.assertIn("read nodes", c["message"]); self.assertIn("privileged", c["message"])
        c = self.failing(self.user("carol"), self.req()); self.assertEqual(c["name"], "Node debug permission")
        self.assertIn("privileged", c["message"]); self.assertNotIn("read nodes", c["message"])
        before = len(self.debug_calls())
        j = self.run_job(self.user("bob"), self.node()); self.assertEqual(j["status"], "Failed"); self.assertIn("cluster-level rights", j["error"])
        self.assertEqual(len(self.debug_calls()), before)                                                    # never tried a debug pod for bob
        self.assertTrue(self.validate(self.user("dave"), self.req())["ok"])

    def test_every_failure_is_explained_and_leaves_nothing_behind(self):
        a = self.user()
        cases = [("nd-nocrictl", "no Ready pod"), ("nd-twopods", "2 Ready sandboxes"), ("nd-notools", "does not contain: tcpdump, nsenter"),
                 ("nd-badns", "unexpected form"), ("nd-hostnet", "host network"), ("nd-forbidden", "not allowed for your account"),
                 ("nd-nomarker", "image pull"), ("nd-garbage", "not a valid pcap"), ("nd-notready", "is not Ready"),
                 ("nd-badnode", "unusable node name"), ("nd-nonode", "not scheduled")]
        before = set(self.dumps_dir())
        for pod, text in cases:
            n0 = len([c for c in self.debug_calls() if c["mode"] == "capture"])
            j = self.run_job(a, self.node(pod=pod))
            self.assertEqual(j["status"], "Failed", pod); self.assertIn(text, j["error"], pod); self.assertIsNone(j["download_name"], pod)
            if pod not in ("nd-garbage", "nd-nomarker"):                                                     # these two fail IN the capture phase
                self.assertEqual(len([c for c in self.debug_calls() if c["mode"] == "capture"]), n0, pod + ": capture must never start")
        self.assertEqual(set(self.dumps_dir()), before)
        self.assertEqual(os.listdir(self.rt), [])

    def test_stray_oc_output_and_exit_code_variants_are_tolerated(self):
        a = self.user()
        j = self.run_job(a, self.node(pod="nd-noise"))
        self.assertEqual(j["status"], "Completed", j); self.assertEqual(j["packets"], 3)
        self.assertIn("not part of the capture", j["note"]); self.assertNotIn("incomplete final packet", j["note"])
        self.assertEqual(self.scan_pcap(self.download(a, j))["trailing_bytes"], 0)                           # noise before AND after the pcap removed
        j = self.run_job(a, self.node(pod="nd-rc1"))                                                         # oc debug reports the remote exit code 124 as rc 1
        self.assertEqual(j["status"], "Completed", j); self.assertEqual(j["packets"], 3)

    def test_size_limit_enforced_and_cleaned(self):
        a = self.user(); before = set(self.dumps_dir())
        j = self.run_job(a, self.node(pod="nd-huge", options={"size_limit_mb": 1}))
        self.assertEqual(j["status"], "Failed"); self.assertIn("size limit", j["error"])
        self.assertEqual(set(self.dumps_dir()), before)

    def test_cancel_one_at_a_time_and_leftover_namespace_is_reported(self):
        a = self.user()
        code, r = a.call("POST", "/api/jobs", self.node(pod="nd-slow", options={"duration": 60}))
        self.assertEqual(code, 202, r); jid = r["job"]["id"]
        end = time.time() + 40
        while time.time() < end and not (a.call("GET", "/api/jobs/" + jid)[1]["job"]["stage"] or "").startswith("Capturing on node"):
            time.sleep(0.3)
        j = a.call("GET", "/api/jobs/" + jid)[1]["job"]
        self.assertTrue(j["stage"].startswith("Capturing on node worker-1.example"), j["stage"]); self.assertNotIn("%", j["stage"])
        code, r2 = a.call("POST", "/api/jobs", self.node(pod="nd-ok"))
        self.assertEqual(code, 429); self.assertIn("one at a time", r2["error"])                             # privileged jobs never overlap
        self.assertEqual(self.user("dave").call("POST", "/api/jobs", self.node(pod="nd-ok"))[0], 429)        # ... even from another user
        t0 = time.time()
        self.assertEqual(a.call("POST", "/api/jobs/%s/cancel" % jid)[0], 200)
        j = self.wait(a, jid, t=20)
        self.assertEqual(j["status"], "Cancelled"); self.assertLess(time.time() - t0, 15)
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")]); self.assertEqual(os.listdir(self.rt), [])
        self.assertIn("POSSIBLE LEFTOVER", j["note"])                                                        # the killed oc client left its namespace
        self.assertIn("openshift-debug-tmp", j["note"]); self.assertIn("oc delete namespace", j["note"])
        self.assertIn("debug_namespace_leftover", [e["event"] for e in self.audit() if e.get("job_id") == jid])

    def test_leftover_after_a_normal_run_is_reported_and_clean_runs_are_not(self):
        a = self.user()
        j = self.run_job(a, self.node(pod="nd-leftover"))
        self.assertEqual(j["status"], "Completed", j); self.assertIn("POSSIBLE LEFTOVER", j["note"])
        self.assertEqual(os.listdir(self.rt), [])
        j = self.run_job(a, self.node(pod="nd-ok"))                                                           # a second run must not re-report the old one
        self.assertEqual((j["status"], j["note"]), ("Completed", None))

    def test_prod_rules(self):
        p = self.user("alice", "prod", "example-prod-1")
        kw = dict(cluster="example-prod-1", ns="demo-prod")
        self.assertIn("narrowed", self.run_job(p, self.node(**kw))["error"])
        self.assertIn("PRIVILEGED", self.run_job(p, self.req(options={"filter": "tls", "method": "node"}, confirm_prod=True, **kw))["error"])
        self.assertIn("explicit confirmation", self.run_job(p, self.node(options={"filter": "tls"}, **kw))["error"])
        r = self.validate(p, self.req(options={"filter": "tls"}, **kw))                                      # dry run: nothing probed on PROD
        self.assertTrue(r["ok"], r); self.assertTrue([x for x in r["checks"] if x["skipped"] and x["name"] == "Debug pod and network namespace"])
        j = self.run_job(p, self.node(options={"filter": "tls"}, confirm_prod=True, **kw))
        self.assertEqual(j["status"], "Completed", j)
        self.assertIn("tcp and (port 443 or port 8443)", self.download(p, j).decode("latin1"))

    def test_jobs_stay_private_and_the_token_never_leaks(self):
        a, b = self.user(), self.user("dave")
        j = self.run_job(a, self.node())
        self.assertEqual(b.call("GET", "/api/jobs/%s/download" % j["id"], raw=True)[0], 404)
        self.assertEqual(b.call("GET", "/api/jobs")[1]["jobs"], [])
        self.assertEqual([e for e in self.oc_calls() if e["violations"]], [])
        self.assertEqual([e for e in self.debug_calls() if e["violations"]], [])
        self.assertTrue(all(e["kubeconfig"].startswith(self.rt + os.sep) for e in self.oc_calls()))
        self.assertEqual(os.listdir(self.rt), [])
        for root, _, files in os.walk(self.tmp):
            for f in files:
                p = os.path.join(root, f)
                if f.startswith("fake-") or "/fakefs/" in p or "/dumps/" in p or f.startswith("dl-"):
                    continue
                with open(p, "rb") as fh:
                    self.assertNotIn(b"sha256~", fh.read(), p)

    # ---- the existing diagnostics must be unchanged
    def test_regression_in_container_capture_thread_dump_and_heap(self):
        a = self.user()
        j = self.run_job(a, self.req(pod="tcp-ok", options={"method": "container", "timeout": 60}))
        self.assertEqual((j["status"], j["packets"]), ("Completed", 3), j)
        self.assertNotIn("node=", self.download(a, j).decode("latin1")); self.assertEqual(j["node"], None)
        j = self.run_job(a, dict(self.req(pod="tcp-ok"), options={"timeout": 60, "duration": 5, "size_limit_mb": 5}))        # default method
        self.assertEqual(j["status"], "Completed", j); self.assertEqual(j["options"]["method"], "container")
        self.assertIn("NET_RAW", self.failing(a, self.req(pod="tcp-noperm", options={"method": "container", "timeout": 60}))["message"])
        j = self.run_job(a, self.req("thread", pod="java-ok", options={"timeout": 60, "count": 1, "interval": 1, "size_limit_mb": 5}))
        self.assertEqual(j["status"], "Completed", j); self.assertIn("Full thread dump", self.download(a, j).decode())
        j = self.run_job(a, self.req("heap", pod="heap-ok", options={"timeout": 120, "size_limit_mb": 5}, confirm_heap=True))
        self.assertEqual((j["status"], j["size_bytes"]), ("Completed", 1572864), j)
        p = self.user("alice", "prod", "example-prod-1")
        h = self.req("heap", cluster="example-prod-1", ns="demo-prod", pod="heap-ok", options={"timeout": 120, "size_limit_mb": 5}, confirm_heap=True, confirm_prod=True)
        self.assertIn("type the exact cluster name", self.run_job(p, h)["error"].lower())
        self.assertEqual(self.run_job(p, dict(h, confirm_name="example-prod-1"))["status"], "Completed")

    def test_regression_auth_cancel_and_in_container_cancel(self):
        c = Client(self.port)
        self.assertEqual(c.login(name="expired")[0], 401)
        a = self.user()
        code, r = a.call("POST", "/api/jobs", self.req(pod="tcp-slow", options={"method": "container", "duration": 60, "timeout": 120})); jid = r["job"]["id"]
        end = time.time() + 30
        while time.time() < end and a.call("GET", "/api/jobs/" + jid)[1]["job"]["status"] != "Running":
            time.sleep(0.3)
        time.sleep(0.6)
        self.assertEqual(a.call("POST", "/api/jobs/%s/cancel" % jid)[0], 200)
        self.assertEqual(self.wait(a, jid, t=20)["status"], "Cancelled")
        self.assertFalse([n for n in self.dumps_dir() if n.endswith(".part")])


class TestNodeCaptureDisabledForEnvironment(ServerCase):
    EXTRA = ["--tcp-envs", "DEV", "--node-capture-envs", "TEST"]

    def test_policy_refuses_before_contacting_the_cluster_and_no_hint_is_given(self):
        a = self.user()
        n0 = len(self.oc_calls())
        j = self.run_job(a, self.node(pod="no-tcpdump"))
        self.assertEqual(j["status"], "Failed"); self.assertIn("not enabled for DEV", j["error"]); self.assertIn("--node-capture-envs", j["error"])
        self.assertEqual([x["name"] for x in j["checks"]], ["Cluster configuration", "Capture policy"])
        self.assertEqual(len(self.oc_calls()), n0); self.assertEqual(self.debug_calls(), [])
        c = self.failing(a, self.req(pod="no-tcpdump", options={"method": "container", "timeout": 60}))
        self.assertIn("tcpdump was not found", c["message"]); self.assertNotIn("On the node", c["message"])


class TestNodeCaptureSwitchedOff(ServerCase):
    EXTRA = ["--node-capture-envs", ""]

    def test_empty_setting_disables_the_method_entirely(self):
        a = self.user()
        c = self.failing(a, self.req())
        self.assertIn("not enabled for DEV", c["message"]); self.assertIn("none", c["message"])
        self.assertEqual(self.admin.call("GET", "/api/me")[1]["node_capture_envs"], [])


class TestNodeCaptureRestrictedUsersAndImage(ServerCase):
    EXTRA = ["--node-capture-envs", "DEV", "--node-capture-users", "example-dev-1:alice", "--node-capture-image", IMAGE]

    def test_only_listed_users_and_the_configured_image_is_used(self):
        c = self.failing(self.user("dave"), self.req())
        self.assertEqual(c["name"], "Capture policy"); self.assertIn("restricted to listed administrators", c["message"]); self.assertIn("'dave'", c["message"])
        self.assertEqual(self.debug_calls(), [])
        a = self.user("alice")
        r = self.validate(a, self.req()); self.assertTrue(r["ok"], r)
        self.assertIn("image: " + IMAGE, [x for x in r["checks"] if x["name"] == "Node"][0]["message"])
        j = self.run_job(a, self.node())
        self.assertEqual(j["status"], "Completed", j)
        for call in self.debug_calls():
            self.assertEqual(call["image"], IMAGE)
            self.assertEqual(call["argv"][2], "--image=" + IMAGE)                                            # one argv element, nothing else
        self.assertIn("image=" + IMAGE, self.download(a, j).decode("latin1"))
        self.assertTrue(self.run_job(self.user("dave"), self.node())["error"].startswith("Node-level capture is restricted"))


class TestScriptsInARealShell(unittest.TestCase):
    """Runs the two fixed scripts with a REAL /bin/sh and the real coreutils `timeout`, with stub chroot/crictl/nsenter/tcpdump on PATH.
    Proves quoting (hostile argument values stay data), the marker protocol, the remote time limit and the parsers."""

    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.mkdtemp()
        cls.log = os.path.join(cls.dir, "calls.log")
        stubs = {
            "chroot": '#!/bin/sh\nshift\nexec "$@"\n',                                              # chroot /host crictl ... -> run crictl
            "crictl": ('#!/bin/sh\n{ echo "crictl"; for a in "$@"; do printf "  <%s>\\n" "$a"; done; } >> "$STUB_LOG"\n'
                       'if [ "$1" = pods ]; then\n  i=0; while [ "$i" -lt "${STUB_COUNT:-1}" ]; do\n'
                       '    printf "%064d\\n" "$((i+1))"; i=$((i+1)); done\n'
                       'elif [ "$1" = inspectp ]; then\n  printf \'{"info":{"runtimeSpec":{"linux":{"namespaces":[{"type":"pid"},{"type":"network","path":"/var/run/netns/cni-abc-123"}]}}}}\\n\'\nfi\n'),
            "nsenter": ('#!/bin/sh\n{ echo "nsenter"; for a in "$@"; do printf "  <%s>\\n" "$a"; done; } >> "$STUB_LOG"\n'
                        'while [ "$1" != "--" ]; do shift; done; shift\nexec "$@"\n'),
            "tcpdump": ('#!/bin/sh\n{ echo "tcpdump"; for a in "$@"; do printf "  <%s>\\n" "$a"; done; } >> "$STUB_LOG"\n'
                        'if [ -n "$STUB_HANG" ]; then exec sleep 30; fi\nprintf "PCAPBYTES"\n'),
        }
        for name, body in stubs.items():
            put(os.path.join(cls.dir, name), body, "w")
            os.chmod(os.path.join(cls.dir, name), 0o755)

    def sh(self, script, args, shell="/bin/sh", timeout=20, **env):
        e = dict(os.environ, PATH=self.dir + os.pathsep + os.environ["PATH"], STUB_LOG=self.log)
        e.update({k: str(v) for k, v in env.items()})
        if os.path.exists(self.log):
            os.remove(self.log)
        t0 = time.time()
        r = subprocess.run([shell, "-c", script, "portal"] + [str(a) for a in args], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=e, timeout=timeout)
        calls = ""
        if os.path.exists(self.log):
            with open(self.log) as fh:
                calls = fh.read()
        return r, calls, time.time() - t0

    def shells(self):
        return [x for x in ("/bin/sh", "/bin/bash", "/bin/dash") if os.path.exists(x)]

    def test_discovery_script_output_is_parsed_by_the_python_side(self):
        from diagnostics.node_capture import DISCOVER_SCRIPT, netns_from_inspect, parse_discovery
        for shell in self.shells():
            r, calls, _ = self.sh(DISCOVER_SCRIPT, ["demo-dev", "^my-pod$"], shell)
            self.assertEqual(r.returncode, 0, shell)
            info = parse_discovery(r.stdout.decode())
            self.assertEqual((info["seen"], info["podcount"], info["tools"]), (True, 1, {"tcpdump", "nsenter", "timeout"}), shell)
            self.assertEqual(info["podid"], "%064d" % 1)
            self.assertEqual(netns_from_inspect(info["json"]), "/var/run/netns/cni-abc-123")
            self.assertIn("  <--namespace>\n  <demo-dev>\n  <--name>\n  <^my-pod$>\n  <--state>\n  <Ready>", calls)
            self.assertIn("crictl\n  <inspectp>\n  <%064d>" % 1, calls)
            for n, expect_json in ((0, False), (2, False)):
                r, calls, _ = self.sh(DISCOVER_SCRIPT, ["demo-dev", "^my-pod$"], shell, STUB_COUNT=n)
                info = parse_discovery(r.stdout.decode())
                self.assertEqual((info["podcount"], info["json"] is not None), (n, expect_json))
                self.assertNotIn("inspectp", calls)                                                     # never inspects when 0 or several match

    def test_hostile_argument_values_stay_data_in_both_scripts(self):
        from diagnostics.node_capture import CAPTURE_SCRIPT, DISCOVER_SCRIPT
        marker = os.path.join(self.dir, "PWNED")
        evil = ['x"; touch %s; "' % marker, "$(touch %s)" % marker, "`touch %s`" % marker, "a b\tc", "'", "*", "-n", "--help", "x\ny"]
        for shell in self.shells():
            for value in evil:
                r, calls, _ = self.sh(DISCOVER_SCRIPT, [value, value], shell)
                self.assertFalse(os.path.exists(marker), "discovery executed: %r in %s" % (value, shell))
                self.assertIn("  <%s>\n  <--name>\n  <%s>" % (value, value), calls)                 # arrived intact, as two separate arguments
                r, calls, _ = self.sh(CAPTURE_SCRIPT, [1, "/var/run/netns/cni-abc-123", 128, 500000, value], shell)
                self.assertFalse(os.path.exists(marker), "capture executed: %r in %s" % (value, shell))
                self.assertTrue(calls.rstrip("\n").endswith("  <->\n  <%s>" % value), "expression must be ONE intact argument: %r in %s" % (value, shell))
        r, calls, _ = self.sh(CAPTURE_SCRIPT, [1, "/var/run/netns/cni-abc-123", 128, 500000, "(tcp port 80) and host 10.0.0.1"])
        self.assertEqual(calls.split("tcpdump\n")[1], "  <-nn>\n  <-i>\n  <any>\n  <-U>\n  <-s>\n  <128>\n  <-c>\n  <500000>\n  <-w>\n  <->\n  <(tcp port 80) and host 10.0.0.1>\n")

    def test_capture_script_protocol_and_arguments(self):
        from diagnostics.node_capture import CAPTURE_SCRIPT, MARKER
        for shell in self.shells():
            r, calls, _ = self.sh(CAPTURE_SCRIPT, [5, "/var/run/netns/cni-abc-123", 128, 500000, ""], shell)
            self.assertEqual(r.stdout, MARKER + b"PCAPBYTES", shell)                                    # marker first, then exactly the tcpdump bytes
            self.assertIn("nsenter\n  <--net=/host/var/run/netns/cni-abc-123>\n  <-->\n  <tcpdump>", calls)
            self.assertTrue(calls.rstrip().endswith("<->"), "empty expression must pass NO filter argument")
            self.assertIn("  <-nn>\n  <-i>\n  <any>\n  <-U>\n  <-s>\n  <128>\n  <-c>\n  <500000>\n  <-w>\n  <->", calls)

    def test_the_remote_time_limit_stops_tcpdump_even_if_the_portal_never_returns(self):
        from diagnostics.node_capture import CAPTURE_SCRIPT
        r, calls, took = self.sh(CAPTURE_SCRIPT, [2, "/var/run/netns/cni-abc-123", 128, 500000, ""], STUB_HANG="1")
        self.assertEqual(r.returncode, 124)                                                             # what `timeout` returns when its timer fires
        self.assertLess(took, 8); self.assertGreaterEqual(took, 1.5)


class TestRunScript(unittest.TestCase):
    """run.sh must read portal.conf as DATA (never execute it) and turn the node-capture settings into the right options."""

    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.mkdtemp()
        cls.out = os.path.join(cls.dir, "argv.json")
        cls.stub = put(os.path.join(cls.dir, "stub-python"),
                       '#!/bin/sh\nshift\nexec python3 -c \'import json,sys; json.dump(sys.argv[1:], open("%s", "w"))\' "$@"\n' % cls.out, "w")
        os.chmod(cls.stub, 0o755)

    def args_for(self, conf, **env):
        c = put(os.path.join(self.dir, "portal.conf"), conf, "w")
        if os.path.exists(self.out):
            os.remove(self.out)
        e = dict(os.environ, PORTAL_CONF=c, PYTHON=self.stub)
        e.update(env)
        r = subprocess.run(["bash", os.path.join(ROOT, "run.sh")], stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, env=e, timeout=30)
        self.assertEqual(r.returncode, 0, r.stderr)
        with open(self.out) as fh:
            return json.load(fh), r.stderr

    @staticmethod
    def opt(args, name):
        return args[args.index(name) + 1]

    def test_defaults_and_node_capture_settings(self):
        a, _ = self.args_for("")
        self.assertEqual((self.opt(a, "--node-capture-envs"), self.opt(a, "--node-capture-users"), "--node-capture-image" in a), ("DEV,TEST", "*", False))
        a, _ = self.args_for("NODE_CAPTURE_ENVS=DEV,PROD\nNODE_CAPTURE_USERS=c1:alice,c2:alice\nNODE_CAPTURE_IMAGE=" + IMAGE + "\n")
        self.assertEqual((self.opt(a, "--node-capture-envs"), self.opt(a, "--node-capture-users"), self.opt(a, "--node-capture-image")), ("DEV,PROD", "c1:alice,c2:alice", IMAGE))
        a, _ = self.args_for("NODE_CAPTURE_ENVS=\n")                                       # explicitly empty = switched off, not "default"
        self.assertEqual(self.opt(a, "--node-capture-envs"), "")
        a, _ = self.args_for("NODE_CAPTURE_ENVS=    # off\n")
        self.assertEqual(self.opt(a, "--node-capture-envs"), "")

    def test_the_shipped_example_parses_to_the_documented_defaults(self):
        with open(os.path.join(ROOT, "deploy", "portal.conf.example")) as fh:
            a, err = self.args_for(fh.read())
        self.assertEqual(err, "")
        self.assertEqual((self.opt(a, "--port"), self.opt(a, "--idle-minutes"), self.opt(a, "--tcp-envs"), self.opt(a, "--node-capture-envs")), ("8080", "30", "DEV,TEST", "DEV,TEST"))
        for absent in ("--host", "--tls-cert", "--tls-key", "--allow-from", "--public-host", "--allow-insecure-http", "--admin-users", "--runtime-dir"):
            self.assertNotIn(absent, a)

    def test_quotes_comments_spaces_and_crlf(self):
        a, _ = self.args_for('PORT=9000   # comment\r\nALLOW_FROM="10.0.0.0/8, 10.1.0.0/16"  # quoted\r\nPUBLIC_HOSTS=\'a.example\'\r\n  IDLE_MINUTES = 12  \r\nBIND_HOST=\r\n'
                            '# a comment line\r\n\r\nTLS_CERT=certs/a b.crt\r\n')
        self.assertEqual((self.opt(a, "--port"), self.opt(a, "--allow-from"), self.opt(a, "--public-host"), self.opt(a, "--idle-minutes")),
                         ("9000", "10.0.0.0/8, 10.1.0.0/16", "a.example", "12"))
        self.assertNotIn("--host", a)
        self.assertEqual(self.opt(a, "--tls-cert"), os.path.join(ROOT, "certs/a b.crt"))     # relative paths are resolved, spaces survive

    def test_conf_is_data_never_code(self):
        marker = os.path.join(self.dir, "PWNED")
        a, err = self.args_for('NODE_CAPTURE_IMAGE=x; touch %s\nTLS_CERT=$(touch %s)\nTLS_KEY=`touch %s`\nPUBLIC_HOSTS="a; touch %s"\n'
                               'LD_PRELOAD=/tmp/evil.so\nPATH=/nonexistent\nrm -rf /tmp/zzz\nbad-key=1\nPORT=8123\n' % ((marker,) * 4))
        self.assertFalse(os.path.exists(marker), "portal.conf content was executed")
        self.assertEqual(self.opt(a, "--node-capture-image"), "x; touch " + marker)           # kept verbatim as ONE argument (server.py then rejects it)
        self.assertEqual(self.opt(a, "--public-host"), "a; touch " + marker)
        self.assertEqual(self.opt(a, "--port"), "8123")
        for text in ("unknown setting 'LD_PRELOAD' ignored", "unknown setting 'PATH' ignored", "line 7 ignored", "line 8 ignored"):
            self.assertIn(text, err)

    def test_proxy_settings_still_reach_the_environment(self):
        c = put(os.path.join(self.dir, "portal.conf"), "HTTPS_PROXY=http://proxy.example:3128\nNO_PROXY=.example.com\n", "w")
        probe = put(os.path.join(self.dir, "probe-python"), '#!/bin/sh\nprintf "%s|%s" "$HTTPS_PROXY" "$NO_PROXY" > ' + self.out + '\n', "w")
        os.chmod(probe, 0o755)
        subprocess.run(["bash", os.path.join(ROOT, "run.sh")], env=dict(os.environ, PORTAL_CONF=c, PYTHON=probe), timeout=30, check=True)
        with open(self.out) as fh:
            self.assertEqual(fh.read(), "http://proxy.example:3128|.example.com")


class TestStartupOptions(unittest.TestCase):
    def refuses(self, *args):
        env = dict(os.environ, TMPDIR=tempfile.mkdtemp())
        p = subprocess.run([sys.executable, SERVER, "--port", str(free_port()), "--clusters", CLUSTERS, "--oc-path", FAKE,
                            "--storage", tempfile.mkdtemp(), "--logs", tempfile.mkdtemp(), "--runtime-dir", tempfile.mkdtemp()] + list(args),
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, timeout=30, env=env)
        self.assertEqual(p.returncode, 2, p.stdout); self.assertIn("Startup error", p.stdout); self.assertNotIn("Traceback", p.stdout)
        return p.stdout

    def test_bad_values_are_refused_before_listening(self):
        self.assertIn("--node-capture-envs", self.refuses("--node-capture-envs", "DEV,BOGUS"))
        for image in ("bad image; id", "--privileged", "$(id)", "x" * 300):
            self.assertIn("--node-capture-image", self.refuses("--node-capture-image=" + image))


if __name__ == "__main__":
    unittest.main(verbosity=2)
