#!/usr/bin/env python3
"""OpenShift Dump Collector - server (v1.2).

Standard library only (Python 3.9 compatible).
  * Users authenticate to each cluster with THEIR OWN OpenShift OAuth token. Tokens live only in
    server memory; credentials in clusters.json and the server's own `oc login` are never used.
  * By default it binds to loopback only (reach it via an SSH tunnel).
  * It can also listen on the network, with guard-rails that must all be satisfied:
      - TLS with your certificate (--tls-cert/--tls-key), or an explicit --allow-insecure-http;
      - an explicit client allow-list (--allow-from CIDRs, or the word "any");
      - a Host allow-list (this machine's own names/IPs plus --public-host).
  * TCP capture works two ways: tcpdump inside the container, or (v1.2) on the pod's node with a temporary
    privileged debug pod, for images that have no tcpdump.
  * Serves only index.html, style.css, script.js. clusters.json is never served.
  * Mutating requests require Content-Type: application/json and a same-origin Origin; the
    session cookie is HttpOnly + SameSite=Strict (+ Secure when served over TLS).
"""
import argparse
import ipaddress
import json
import logging
import logging.handlers
import os
import re
import shutil
import socket
import ssl
import stat
import subprocess
import sys
import time
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from backend.app import App
from backend.configuration import VALID_ENVS, ConfigError, Settings, count_credential_fields
from backend.errors import ApiError
from backend.runtime import RuntimeError_
from backend.validation import CLUSTER_ID_RE, parse_request, valid_namespace
from diagnostics.node_capture import valid_image

ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"), "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"), "/script.js": ("script.js", "application/javascript; charset=utf-8"),
}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
       "base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
COOKIE = "dc_session"
MAX_BODY = 16 * 1024
LOOPBACK_NAMES = ("127.0.0.1", "localhost", "::1")
INSECURE_BANNER = (b'<div class="err-box" role="alert"><strong>Warning: this connection is NOT encrypted.</strong> '
                   b'Anything you type here, including your OpenShift token, can be read by others on the network. '
                   b'Ask your administrator to enable TLS.</div>\n  ')
R_NS = re.compile(r"/api/clusters/([^/]+)/namespaces")
R_PODS = re.compile(r"/api/clusters/([^/]+)/namespaces/([^/]+)/pods")
R_CL_ACT = re.compile(r"/api/clusters/([^/]+)/(check|enabled)")
R_JOB = re.compile(r"/api/jobs/([^/]+)")
R_JOB_ACT = re.compile(r"/api/jobs/([^/]+)/(cancel|download|delete)")
NO_TOUCH = ("/api/health", "/api/session", "/api/me")      # polling these must not keep a session alive
log = logging.getLogger("dumpcollector")


def version():
    try:
        with open(os.path.join(ROOT, "VERSION")) as fh:
            return fh.read().strip()
    except OSError:
        return "dev"


# ======================================================================= network policy helpers
def csv(value, upper=False):
    items = [x.strip() for x in (value or "").split(",") if x.strip()]
    return tuple(x.upper() for x in items) if upper else tuple(items)


def is_loopback_host(host):
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False            # "", "0.0.0.0", "::", names and real addresses all count as network-reachable


def parse_networks(text):
    """'10.0.0.0/8,192.168.1.5' or 'any' -> list of ip_network. Raises ValueError on junk."""
    nets = []
    for part in csv(text):
        if part.lower() == "any":
            nets += [ipaddress.ip_network("0.0.0.0/0"), ipaddress.ip_network("::/0")]
        else:
            nets.append(ipaddress.ip_network(part, strict=False))
    if not nets:
        raise ValueError("empty list")
    return nets


def normalize_ip(text):
    ip = ipaddress.ip_address(text.split("%", 1)[0])
    if ip.version == 6 and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    return ip


def client_allowed(addr, nets):
    """Loopback is always allowed (an admin sitting on the server); everyone else must match the list."""
    try:
        ip = normalize_ip(addr)
    except ValueError:
        return False
    if ip.is_loopback:
        return True
    return any(n.version == ip.version and ip in n for n in nets)


def split_host_header(value):
    """-> (name, port|None); (None, None) when malformed. Handles [ipv6]:port."""
    v = (value or "").strip().lower()
    if not v or len(v) > 300:
        return None, None
    if v.startswith("["):
        end = v.find("]")
        if end < 0:
            return None, None
        name, rest = v[1:end], v[end + 1:]
        if rest == "":
            return name, None
        if rest.startswith(":") and rest[1:].isdigit():
            return name, int(rest[1:])
        return None, None
    name, sep, port = v.partition(":")
    if sep and not port.isdigit():
        return None, None
    return name, (int(port) if sep else None)


def valid_public_name(name):
    return bool(name) and re.fullmatch(r"[A-Za-z0-9._:\-]{1,253}", name) is not None


def local_identities():
    """This machine's own host name, FQDN and addresses, so https://<those>:port works out of the box."""
    found = set()
    try:
        found.add(socket.gethostname().lower())
        found.add(socket.getfqdn().lower())
        for info in socket.getaddrinfo(socket.gethostname(), None):
            found.add(info[4][0].split("%", 1)[0].lower())
    except OSError:
        pass
    try:
        out = subprocess.run(["hostname", "-I"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             universal_newlines=True, timeout=3).stdout
        found.update(x.lower() for x in out.split())
    except (OSError, subprocess.SubprocessError):
        pass
    try:                                    # the address this machine would use to reach the network (no packet is sent)
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("10.255.255.255", 1))
            found.add(probe.getsockname()[0])
        finally:
            probe.close()
    except OSError:
        pass
    return {x for x in found if valid_public_name(x)}


def make_tls_context(cert, key):
    for p in (cert, key):
        if not os.path.isfile(p):
            raise ValueError("file not found: %s" % p)
    if stat.S_IMODE(os.stat(key).st_mode) & 0o077:
        log.warning("TLS private key %s is readable by other users; run: chmod 600 %s", key, key)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    try:
        ctx.load_cert_chain(cert, key)
    except (ssl.SSLError, OSError) as exc:
        raise ValueError("could not load the certificate/key pair (%s). Check they match and are PEM files." % (getattr(exc, "reason", None) or type(exc).__name__))
    return ctx


class PortalServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, app, scheme, names, public_port, nets, tls_ctx, insecure_network):
        self.address_family = socket.AF_INET6 if ":" in address[0] else socket.AF_INET
        self.app, self.scheme, self.names, self.public_port = app, scheme, set(names), public_port
        self.nets = nets                      # None = loopback-only server (the socket itself restricts who can connect)
        self.tls = tls_ctx is not None
        self.insecure_network = insecure_network
        self._denied = {}
        ThreadingHTTPServer.__init__(self, address, handler)
        if tls_ctx is not None:
            # Handshake happens later, inside each request's own thread, so one stalled client cannot block the others.
            self.socket = tls_ctx.wrap_socket(self.socket, server_side=True, do_handshake_on_connect=False)

    def host_ok(self, value):
        name, port = split_host_header(value)
        if name is None or name not in self.names:
            return False
        if port is None:
            return self.public_port == (443 if self.scheme == "https" else 80)
        return port == self.public_port

    def verify_request(self, request, client_address):
        if self.nets is None or client_allowed(client_address[0], self.nets):
            return True
        ip, now = client_address[0], time.time()
        if now - self._denied.get(ip, 0) > 60:
            if len(self._denied) > 1000:
                self._denied.clear()
            self._denied[ip] = now
            log.warning("Refused a connection from %s (not covered by --allow-from)", ip)
        return False

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ssl.SSLError, ConnectionError, socket.timeout)):
            log.info("Connection from %s dropped (%s)", client_address[0], type(exc).__name__)
            return
        log.exception("Error handling a request from %s", client_address[0])


class Handler(BaseHTTPRequestHandler):
    server_version = "DumpCollector/" + version()
    sys_version = ""
    timeout = 60            # a client that stalls mid-request is dropped after 60 s

    def setup(self):
        if self.server.tls:
            self.request.settimeout(10)
            self.request.do_handshake()
        BaseHTTPRequestHandler.setup(self)

    # ---- plumbing ------------------------------------------------------------------------
    def _headers(self, code, ctype, length, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        for c in self._set_cookies:
            self.send_header("Set-Cookie", c)
        self.end_headers()

    def _json(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self._headers(code, "application/json", len(body))
        self.wfile.write(body)

    def _read_body(self):
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(415, "Content-Type must be application/json")
        origin = self.headers.get("Origin")
        if origin and origin.lower() != "%s://%s" % (self.server.scheme, (self.headers.get("Host") or "").lower()):
            raise ApiError(403, "Cross-origin request refused")
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError(400, "Bad Content-Length")
        if n > MAX_BODY:
            raise ApiError(413, "Request too large")
        try:
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except ValueError:
            raise ApiError(400, "Body is not valid JSON")

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    do_DELETE = do_PATCH = do_PUT

    def _load_session(self, touch):
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        try:
            c = cookies.SimpleCookie(raw)
        except cookies.CookieError:
            return None
        m = c.get(COOKIE)
        return self.server.app.sessions.get(m.value, touch=touch) if m else None

    def _cookie_attrs(self):
        return "HttpOnly; SameSite=Strict; Path=/" + ("; Secure" if self.server.scheme == "https" else "")

    def _set_session_cookie(self, sid):
        self._set_cookies.append("%s=%s; %s" % (COOKIE, sid, self._cookie_attrs()))

    def _clear_session_cookie(self):
        self._set_cookies.append("%s=; %s; Max-Age=0" % (COOKIE, self._cookie_attrs()))

    def _index_bytes(self):
        with open(os.path.join(ROOT, "index.html"), "rb") as fh:
            data = fh.read()
        marker = b'<main id="view"'
        if self.server.insecure_network and marker in data:
            data = data.replace(marker, INSECURE_BANNER + marker, 1)
        return data

    def _dispatch(self, method):
        self._set_cookies = []
        try:
            if not self.server.host_ok(self.headers.get("Host")):
                names = sorted(n for n in self.server.names if n not in LOOPBACK_NAMES) or sorted(self.server.names)
                shown = ["%s://%s:%d" % (self.server.scheme, ("[%s]" % n) if ":" in n else n, self.server.public_port) for n in names[:8]]
                raise ApiError(400, "Unexpected Host header. Open the portal with one of: %s "
                               "(or start the server with --public-host for another name)." % ", ".join(shown))
            path = urlsplit(self.path).path
            if method == "GET" and path in STATIC:
                fname, ctype = STATIC[path]
                if fname == "index.html":
                    data = self._index_bytes()
                else:
                    with open(os.path.join(ROOT, fname), "rb") as fh:
                        data = fh.read()
                self._headers(200, ctype, len(data))
                self.wfile.write(data)
            elif method == "GET" and path == "/favicon.ico":
                self._headers(204, "image/x-icon", 0)
            elif path.startswith("/api/"):
                self._api(method, path)
            else:
                raise ApiError(404, "Not found")
        except ApiError as exc:
            payload = {"error": exc.message}
            if exc.details:
                payload["details"] = exc.details
            if exc.reason:
                payload["reason"] = exc.reason
            self._json(exc.code, payload)
        except ConfigError as exc:
            self._json(500, {"error": str(exc)})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            log.exception("Unhandled error")
            self._json(500, {"error": "Internal server error"})

    # ---- API -----------------------------------------------------------------------------
    def _need_session(self, session):
        if session is None:
            raise ApiError(401, "Not connected. Connect to a cluster with your OpenShift token first.", reason="no_session")
        return session

    def _audit_source(self, app, event, user, cluster_id, **extra):
        """Record WHERE a login came from (matters once the portal is reachable over the network)."""
        try:
            app.audit.log(event, user, cluster_id=cluster_id, ip=self.client_address[0], **extra)
        except Exception:
            log.exception("could not write %s audit record", event)

    def _api(self, method, path):
        app = self.server.app
        session = self._load_session(touch=path not in NO_TOUCH)
        if method == "GET":
            if path == "/api/health":
                return self._json(200, {"status": "ok"})
            if path == "/api/me":
                s = app.settings
                return self._json(200, {"oc_available": app.oc.available, "version": version(), "retention_days": s.retention_days,
                                        "purge_on_logout": s.purge_on_logout, "tcp_envs": list(s.tcp_envs),
                                        "node_capture_envs": list(s.node_capture_envs), "idle_seconds": s.idle_seconds,
                                        "user_quota_mb": s.user_quota_mb, "limits": {"heap_max_mb": s.heap_max_mb},
                                        "transport": self.server.scheme, "network_exposed": self.server.nets is not None})
            if path == "/api/session":
                return self._json(200, app.session_info(session))
            if path == "/api/clusters":
                mine = dict(session.tokens) if session else {}
                out = []
                for c in app.clusters():
                    c = dict(c)
                    c["connected_as"] = mine[c["id"]]["identity"] if c["id"] in mine else None
                    out.append(c)
                return self._json(200, {"clusters": out})
            m = R_PODS.fullmatch(path)
            if m:
                self._check_cluster_ns(m.group(1), m.group(2))
                return self._json(200, app.pods(session, m.group(1), m.group(2)))
            m = R_NS.fullmatch(path)
            if m:
                self._check_cluster_ns(m.group(1), None)
                return self._json(200, app.namespaces(session, m.group(1)))
            if path == "/api/jobs":
                return self._json(200, {"jobs": app.jobs.list_for(session)})
            m = R_JOB_ACT.fullmatch(path)
            if m and m.group(2) == "download":
                return self._download(app, session, m.group(1))
            m = R_JOB.fullmatch(path)
            if m:
                return self._json(200, {"job": app.jobs.public(app.jobs.get_for(session, m.group(1)))})
        elif method == "POST":
            if path == "/api/auth/login":
                body = self._read_body()
                cid = body.get("cluster") if isinstance(body, dict) else None
                if not isinstance(cid, str) or not CLUSTER_ID_RE.fullmatch(cid):
                    raise ApiError(400, "Choose a cluster.")
                was = session
                try:
                    session = app.login(session, cid, body.get("token"))
                except ApiError as exc:
                    self._audit_source(app, "login_rejected", None, cid, reason=exc.reason or str(exc.code))
                    raise
                if was is None:
                    self._set_session_cookie(session.sid)
                self._audit_source(app, "login_source", (session.tokens.get(cid) or {}).get("identity"), cid)
                return self._json(200, app.session_info(session))
            if path == "/api/auth/logout":
                body = self._read_body()
                if session is not None:
                    cid = body.get("cluster") if isinstance(body, dict) else None
                    if cid:
                        if not isinstance(cid, str) or not CLUSTER_ID_RE.fullmatch(cid):
                            raise ApiError(400, "Invalid cluster")
                        app.disconnect(session, cid)
                    else:
                        app.sign_out(session)
                    if not session.tokens:
                        self._clear_session_cookie()
                    return self._json(200, app.session_info(app.sessions.get(session.sid, touch=False)))
                self._clear_session_cookie()
                return self._json(200, app.session_info(None))
            if path == "/api/clusters/check":
                self._read_body()
                return self._json(200, {"clusters": app.check_all()})
            m = R_CL_ACT.fullmatch(path)
            if m:
                body = self._read_body()
                self._check_cluster_ns(m.group(1), None)
                if m.group(2) == "check":
                    c = [x for x in app.clusters() if x["id"] == m.group(1)]
                    if not c:
                        raise ApiError(404, "Unknown cluster")
                    app.check_cluster(c[0], force=True)
                else:
                    if not isinstance(body, dict) or not isinstance(body.get("enabled"), bool):
                        raise ApiError(400, "'enabled' must be true or false")
                    app.set_enabled(self._need_session(session), m.group(1), body["enabled"])
                return self._json(200, {"clusters": app.clusters()})
            if path == "/api/validate":
                clean = parse_request(self._read_body(), app.settings.heap_max_mb)
                return self._json(200, app.validate(self._need_session(session), clean))
            if path == "/api/jobs":
                clean = parse_request(self._read_body(), app.settings.heap_max_mb)
                return self._json(202, {"job": app.create_job(self._need_session(session), clean)})
            m = R_JOB_ACT.fullmatch(path)
            if m and m.group(2) in ("cancel", "delete"):
                self._read_body()
                fn = app.jobs.cancel if m.group(2) == "cancel" else app.jobs.delete_result
                return self._json(200, {"job": fn(self._need_session(session), m.group(1))})
        else:
            raise ApiError(405, "Method not allowed")
        raise ApiError(404, "Not found")

    @staticmethod
    def _check_cluster_ns(cluster_id, ns):
        if not CLUSTER_ID_RE.fullmatch(cluster_id):
            raise ApiError(404, "Unknown cluster")
        if ns is not None and not valid_namespace(ns):
            raise ApiError(400, "Invalid namespace name")

    def _download(self, app, session, job_id):
        path, name, size = app.jobs.download_info(self._need_session(session), job_id)
        self._headers(200, "application/octet-stream", size, {"Content-Disposition": 'attachment; filename="%s"' % name})
        with open(path, "rb") as fh:
            shutil.copyfileobj(fh, self.wfile, 1 << 20)

    def log_message(self, fmt, *args):     # request line only; never headers, cookies or bodies
        log.info("%s - %s", self.address_string(), fmt % args)


def harden_process():
    """No core dumps and no same-user ptrace/proc-mem reads of this process (tokens live in its memory)."""
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except Exception:
        pass
    try:
        import ctypes
        ctypes.CDLL(None).prctl(4, 0, 0, 0, 0)      # PR_SET_DUMPABLE = 0
    except Exception:
        pass


def fail(message, code=2):
    print("Startup error: " + message, file=sys.stderr)
    sys.exit(code)


def main():
    ap = argparse.ArgumentParser(description="OpenShift Dump Collector")
    ap.add_argument("--host", default="127.0.0.1", help="address to listen on (default 127.0.0.1 = this machine only; 0.0.0.0 = network, needs the options below)")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--tls-cert", default=None, help="PEM certificate (chain) file: serve HTTPS")
    ap.add_argument("--tls-key", default=None, help="PEM private key file for --tls-cert")
    ap.add_argument("--allow-from", default=None, help="REQUIRED when --host is not loopback: comma-separated client IPs/CIDRs allowed to connect (e.g. 10.20.0.0/16), or the word 'any'. Loopback is always allowed")
    ap.add_argument("--public-host", default="", help="extra host name(s)/IP(s) users type in the browser (comma-separated); this machine's own names/IPs are added automatically")
    ap.add_argument("--public-port", type=int, default=None, help="port users type in the browser if it differs from --port (e.g. behind a port redirect)")
    ap.add_argument("--allow-insecure-http", action="store_true", help="DANGEROUS: allow plain HTTP on a network address (tokens cross the network unencrypted)")
    ap.add_argument("--clusters", default=os.path.join(ROOT, "clusters.json"))
    ap.add_argument("--storage", default=os.path.join(ROOT, "storage"), help="dump files + portal.db (keep outside any web root)")
    ap.add_argument("--logs", default=os.path.join(ROOT, "logs"))
    ap.add_argument("--runtime-dir", default=None, help="memory-backed dir for temporary kubeconfigs (default /dev/shm/openshift-dump-collector-<uid>)")
    ap.add_argument("--oc-path", default="oc")
    ap.add_argument("--max-concurrent", type=int, default=2, help="jobs running at once")
    ap.add_argument("--max-user-jobs", type=int, default=3, help="active jobs per user per cluster")
    ap.add_argument("--retention-days", type=int, default=7, help="days a result is kept after its owner's last login")
    ap.add_argument("--purge-on-logout", action="store_true", help="delete a user's stored results as soon as their session ends")
    ap.add_argument("--idle-minutes", type=int, default=30, help="end a session after this many idle minutes (running jobs keep it alive)")
    ap.add_argument("--idle-seconds", type=int, default=None, help=argparse.SUPPRESS)       # testing: overrides --idle-minutes
    ap.add_argument("--tick-seconds", type=int, default=15, help=argparse.SUPPRESS)
    ap.add_argument("--login-fail-limit", type=int, default=10, help="failed connection attempts per minute before throttling")
    ap.add_argument("--min-free-mb", type=int, default=500, help="disk space always left free on the portal server")
    ap.add_argument("--user-quota-mb", type=int, default=20480)
    ap.add_argument("--total-quota-mb", type=int, default=51200)
    ap.add_argument("--heap-max-mb", type=int, default=8192, help="largest heap-dump size limit a user may request")
    ap.add_argument("--tcp-envs", default="DEV,TEST", help="environments where in-container TCP capture is allowed (PROD is opt-in)")
    ap.add_argument("--node-capture-envs", default="DEV,TEST",
                    help="environments where TCP capture ON THE NODE (privileged debug pod) is allowed; empty disables it (PROD is opt-in)")
    ap.add_argument("--node-capture-users", default="*",
                    help="who may use node-level capture: '*' (anyone whose own token the cluster allows) or comma-separated cluster-id:identity pairs")
    ap.add_argument("--node-capture-image", default="",
                    help="image for the temporary debug pod; it must contain tcpdump, nsenter and timeout (default: the one oc debug chooses)")
    ap.add_argument("--insecure-tls-clusters", default="", help="comma-separated cluster ids for which TLS verification is OFF (default: all verify)")
    ap.add_argument("--admin-users", default="", help="comma-separated cluster-id:identity pairs allowed to enable/disable clusters")
    a = ap.parse_args()

    # ---- network policy: every guard-rail must be satisfied before the port is opened ----
    loop = is_loopback_host(a.host)
    if bool(a.tls_cert) != bool(a.tls_key):
        fail("--tls-cert and --tls-key must be given together.")
    tls_ctx = None
    if a.tls_cert:
        try:
            tls_ctx = make_tls_context(a.tls_cert, a.tls_key)
        except ValueError as exc:
            fail("TLS: %s" % exc)
    nets = None
    if not loop:
        if not a.allow_from:
            fail("listening on %r exposes the portal to the network. Say who may connect with --allow-from (for example "
                 "--allow-from 10.20.0.0/16, or --allow-from any to accept everyone)." % a.host)
        try:
            nets = parse_networks(a.allow_from)
        except ValueError as exc:
            fail("--allow-from is not a valid list of IP addresses/networks (%s)." % exc)
        if tls_ctx is None and not a.allow_insecure_http:
            fail("users paste OpenShift tokens into this portal, so network access needs HTTPS. Provide --tls-cert/--tls-key "
                 "(see scripts/make_self_signed_cert.sh), or, if you accept that tokens cross the network unencrypted, add --allow-insecure-http.")
    names = set(LOOPBACK_NAMES)
    for h in csv(a.public_host):
        h = h.strip("[]").lower()
        if not valid_public_name(h):
            fail("--public-host entry %r is not a plain host name or IP address (no scheme, port or path)." % h)
        names.add(h)
    if not loop:
        if a.host not in ("", "0.0.0.0", "::"):
            names.add(a.host.lower())
        names |= local_identities()
    scheme = "https" if tls_ctx is not None else "http"
    public_port = a.public_port or a.port
    insecure_network = (not loop) and tls_ctx is None

    tcp_envs = csv(a.tcp_envs, upper=True)
    node_envs = csv(a.node_capture_envs, upper=True)
    for label, vals in (("--tcp-envs", tcp_envs), ("--node-capture-envs", node_envs)):
        bad = [e for e in vals if e not in VALID_ENVS]
        if bad:
            fail("Invalid %s value(s): %s (allowed: %s)" % (label, ", ".join(bad), ", ".join(VALID_ENVS)))
    node_users = csv(a.node_capture_users) or ("*",)
    if a.node_capture_image and not valid_image(a.node_capture_image):
        fail("--node-capture-image is not a plain image reference (letters, digits and . _ / : @ + - only).")
    os.umask(0o077)
    harden_process()
    os.makedirs(a.logs, mode=0o700, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[
        logging.StreamHandler(),
        logging.handlers.RotatingFileHandler(os.path.join(a.logs, "app.log"), maxBytes=10 * 1024 * 1024, backupCount=5)])
    settings = Settings(a.clusters, a.storage, a.logs, a.runtime_dir, a.oc_path, a.max_concurrent, 10, a.max_user_jobs, 1,
                        a.retention_days, a.purge_on_logout, a.min_free_mb, a.user_quota_mb, a.total_quota_mb, a.heap_max_mb, tcp_envs,
                        csv(a.insecure_tls_clusters), csv(a.admin_users), a.idle_seconds or a.idle_minutes * 60,
                        28800, a.login_fail_limit, a.tick_seconds,
                        node_capture_envs=node_envs, node_capture_users=node_users, node_capture_image=a.node_capture_image)
    try:
        n = count_credential_fields(a.clusters)
        if n:
            log.warning("clusters.json contains %d credential-like field(s). They are IGNORED by this portal (users supply their own "
                        "tokens). Remove them from the file and rotate those passwords.", n)
        app = App(settings)
    except (ConfigError, RuntimeError_) as exc:
        print("Startup error: %s" % exc, file=sys.stderr)
        sys.exit(1)
    for c in app.clusters():
        if not c["tls_verify"]:
            log.warning("TLS verification is OFF for cluster '%s' (explicit setting). Tokens sent there could be intercepted.", c["id"])
    try:
        srv = PortalServer((a.host, a.port), Handler, app, scheme, names, public_port, nets, tls_ctx, insecure_network)
    except OSError as exc:
        fail("could not listen on %s:%d (%s). Is the port already in use, or below 1024 (needs root)?" % (a.host, a.port, exc.strerror or exc), 1)
    if insecure_network:
        log.warning("INSECURE: plain HTTP is exposed to the network (--allow-insecure-http). OpenShift tokens typed into the page can be read by anyone on the path.")
    if nets is not None and any(str(n) in ("0.0.0.0/0", "::/0") for n in nets):
        log.warning("--allow-from any: every machine that can reach this port may open the portal. Prefer a specific network.")
    if node_envs:
        log.info("Node-level TCP capture (privileged debug pod) is enabled for: %s; allowed users: %s; debug image: %s",
                 ", ".join(node_envs), ", ".join(node_users), a.node_capture_image or "(oc debug default)")
    log.info("OpenShift Dump Collector %s listening on %s:%d (%s%s; oc: %s; sessions idle out after %d s; results kept %d days after last login%s)",
             version(), a.host or "*", a.port, scheme.upper(), "" if loop else ", network-exposed", app.oc.path or "NOT FOUND",
             settings.idle_seconds, a.retention_days, "; purge-on-logout ON" if a.purge_on_logout else "")
    shown = sorted(n for n in names if n not in LOOPBACK_NAMES) if not loop else ["127.0.0.1"]
    for n in shown[:10]:
        log.info("  open: %s://%s:%d/", scheme, ("[%s]" % n) if ":" in n else n, public_port)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        log.info("Stopped.")
    finally:
        app.close()


if __name__ == "__main__":
    main()
