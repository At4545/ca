# Thread dumps — update: same identity rule as TCP capture

## What changed

Thread dumps now choose *who runs the exec* exactly like TCP capture does
(`resolveBackendAuth` in `captures.go`):

| Where the backend runs | Exec is done by | API URL | Cluster rule |
|---|---|---|---|
| **Locally** (no ServiceAccount token file) | the **user's token** | the user's cluster URL | any cluster in `clusters.json` |
| **In OpenShift** (SA token mounted) | the **backend ServiceAccount** | `https://kubernetes.default.svc` | only the backend's own cluster (`BACKEND_CLUSTER_NAME`) |

In both modes the **user's token is still used** to log in, to check the user may `create pods/exec`
in that namespace (SelfSubjectAccessReview), and to look up the pod/container. The ServiceAccount
never widens who can dump what, and its token is never sent to the user-selected API URL.

Differences from TCP capture, on purpose:
* In-cluster, `BACKEND_CLUSTER_NAME` is **required** for thread dumps (captures skip the check when it is unset).
  Without it the backend cannot prove the user picked its own cluster, and the SA would exec on the wrong cluster
  with rights the user earned on another one.
* Optional escape hatch `DIAG_EXEC_IDENTITY=user`: always use the user's own token (the previous behaviour).

Audit: log lines and `.metadata.json` now record `exec_as` (`user` / `serviceaccount`) next to the owner.

## Install

From the repo root:

```bash
unzip -o thread-dump-update.zip
rm internal/diag/http_test.go internal/diag/export_test.go   # superseded by internal/handlers/diagnostics_test.go (delete both)
gofmt -l internal/diag internal/handlers/diagnostics*.go
go build ./... && go vet ./... && go test ./internal/diag/ ./internal/handlers/
```

`main.go`, `index.html`, `diagnostics.js` and the rest of the first package are unchanged.
Rebuild and redeploy the image.

## Deploy (only needed for in-cluster use)

1. **Backend cluster name** (must match a `name` in `clusters.json`, case-insensitive):
   ```bash
   oc set env deployment/<backend> -n <backend-ns> --list | grep BACKEND_CLUSTER_NAME   # already set for captures?
   oc set env deployment/<backend> -n <backend-ns> BACKEND_CLUSTER_NAME=<cluster-name>  # if not
   ```
2. **Let the ServiceAccount exec** (the new part of RBAC). Role once, then a binding per namespace you want dumpable:
   ```bash
   oc apply -f deploy/diag-exec-rbac.yaml          # edit <TARGET-NAMESPACE> first, or use the commands below
   oc create rolebinding tcpdump-thread-dump-exec --clusterrole=tcpdump-thread-dump-exec \
      --serviceaccount=openshift-tcpdump:tcpdump-backend-sa -n <target-ns>
   ```
   Check the names (`tcpdump-backend-sa`, `openshift-tcpdump`) against your deployment.
   Verify: `oc auth can-i create pods/exec -n <target-ns> --as=system:serviceaccount:openshift-tcpdump:tcpdump-backend-sa`
3. Users still need `create pods/exec` in the namespace (edit/admin roles have it).

Local development needs nothing: run without a ServiceAccount token and your own token is used.

## Errors you may see

| Message | Meaning |
|---|---|
| "Thread dumps are only supported on the cluster where the backend is deployed. Selected: …, Backend: …" | In-cluster, user picked another cluster. |
| "BACKEND_CLUSTER_NAME is not set …" | Set it (step 1) or use `DIAG_EXEC_IDENTITY=user`. |
| "Forbidden: the backend ServiceAccount is not allowed to exec into pods in namespace X …" | Missing RoleBinding in X (step 2). |
| "Your account cannot 'create' pods/exec in namespace X" | The *user* lacks access; the SA is not consulted. |

Fastest rollback without redeploying: `oc set env deployment/<backend> DIAG_EXEC_IDENTITY=user`.

## Verified here / not verified

Verified (real project source from `myproject.txt`, Go 1.27): `go build`, `go vet ./...`, tests (also `-race`) —
local mode execs with the user's token on the user's cluster; in-cluster execs with the SA token via
`kubernetes.default.svc`, the SA token never reaches the user-selected API, a user without `pods/exec` is refused
even though the SA could do it, other-cluster / unknown-backend requests are refused before any cluster call,
`DIAG_EXEC_IDENTITY=user` overrides, SA-403 gives the actionable message, plus all earlier job/HTTP tests.

Not verified: the live WebSocket exec against a real cluster (tests fake that one call), and the RBAC manifest
applied on a real cluster (YAML only checked for syntax).
