package handlers

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/openshift-tcpdump/openshift-tcpdump/internal/capture"
	"github.com/openshift-tcpdump/openshift-tcpdump/internal/diag"
	"github.com/openshift-tcpdump/openshift-tcpdump/internal/k8s"
	"github.com/openshift-tcpdump/openshift-tcpdump/internal/middleware"
)

// Seams for tests. In production they are exactly what captures.go uses.
var (
	diagReadSAToken       = capture.ReadSAToken
	diagBackendClusterURL = resolveBackendClusterURL
)

func diagJSON(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func diagErr(w http.ResponseWriter, code int, msg string) {
	diagJSON(w, code, map[string]string{"error": msg})
}

// diagIdentity resolves the AuthContext and re-validates the token to get the username.
// Used on every diagnostics call so job ownership can be enforced (dumps may contain sensitive data).
func diagIdentity(w http.ResponseWriter, r *http.Request) (*middleware.AuthContext, string, bool) {
	ac := middleware.GetAuthContext(r.Context())
	if ac == nil {
		diagErr(w, http.StatusInternalServerError, "missing auth context")
		return nil, "", false
	}
	u, err := k8s.ValidateToken(ac.ClusterURL, ac.Token)
	if err != nil {
		diagErr(w, http.StatusUnauthorized, "Invalid or expired token")
		return nil, "", false
	}
	return ac, u.Username, true
}

// ownedJob returns the job only if it was started by this user on this cluster.
func ownedJob(m *diag.Manager, id, username string, ac *middleware.AuthContext) (diag.Job, bool) {
	j, ok := m.Get(id)
	if !ok || j.Owner != username || j.Cluster != ac.ClusterName {
		return diag.Job{}, false
	}
	return j, true
}

// execAuth is the credential used for pods/exec.
type execAuth struct {
	apiURL string
	token  string
	as     string // diag.ExecAsUser or diag.ExecAsServiceAccount
}

// resolveDiagExecAuth decides which identity runs the exec, with the same rule as TCP capture
// (resolveBackendAuth in captures.go):
//
//   - in a cluster (ServiceAccount token mounted): the backend ServiceAccount, through the
//     in-cluster API URL, and only for the cluster the backend runs on;
//   - locally (no ServiceAccount token): the user's own token against the user's cluster URL.
//
// mode "user" (DIAG_EXEC_IDENTITY=user) always selects the user's token.
// Whatever is chosen here, the user must separately pass the pods/exec access check
// (done by the caller with the USER's token), so the ServiceAccount never widens who can dump what.
func resolveDiagExecAuth(mode string, ac *middleware.AuthContext) (execAuth, error) {
	userAuth := execAuth{apiURL: ac.ClusterURL, token: ac.Token, as: diag.ExecAsUser}
	if mode == "user" {
		return userAuth, nil
	}
	saToken, err := diagReadSAToken()
	if err != nil {
		log.Printf("WARNING: diag: error reading SA token: %v, falling back to user token", err)
		return userAuth, nil
	}
	if saToken == "" {
		log.Printf("diag: SA token not found (local dev mode), using the user's token for exec")
		return userAuth, nil
	}

	// In-cluster: the ServiceAccount token is only valid on the local cluster, and the exec would
	// run there. Refuse unless we can prove the user selected that very cluster; otherwise the
	// user's rights on one cluster would be "spent" by the ServiceAccount on another.
	backendURL := diagBackendClusterURL()
	if backendURL == "" {
		return execAuth{}, errors.New("BACKEND_CLUSTER_NAME is not set (or is not in the clusters config), so the backend cannot verify " +
			"that the selected cluster is the one it runs on. Set it, or set DIAG_EXEC_IDENTITY=user to use each user's own token.")
	}
	if ac.ClusterURL != backendURL {
		return execAuth{}, errors.New("Thread dumps are only supported on the cluster where the backend is deployed. Selected: " +
			ac.ClusterURL + ", Backend: " + backendURL)
	}
	return execAuth{apiURL: capture.InClusterAPIURL, token: saToken, as: diag.ExecAsServiceAccount}, nil
}

// precheckTarget verifies, with the USER's token, that the container exists and is running.
func precheckTarget(ac *middleware.AuthContext, ns, deployment, pod, ctr string) error {
	if err := diag.ValidateTarget(ns, deployment, pod, ctr); err != nil {
		return err
	}
	phase, containers, err := k8s.GetPodContainers(ac.ClusterURL, ac.Token, ns, pod)
	if err != nil {
		return fmt.Errorf("cannot read pod %s/%s: %w", ns, pod, err)
	}
	found, running := false, false
	for _, c := range containers {
		if c.Name == ctr {
			found, running = true, c.Running
		}
	}
	switch {
	case !found:
		return fmt.Errorf("container %q does not belong to pod %s", ctr, pod)
	case phase != "Running" || !running:
		return fmt.Errorf("pod %s (phase %s) / container %s is not running", pod, phase, ctr)
	}
	return nil
}

// NewDiagContainersHandler serves GET /api/namespaces/{namespace}/pods/{pod}/containers.
func NewDiagContainersHandler() http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ac := middleware.GetAuthContext(r.Context())
		if ac == nil {
			diagErr(w, http.StatusInternalServerError, "missing auth context")
			return
		}
		phase, cs, err := k8s.GetPodContainers(ac.ClusterURL, ac.Token, chi.URLParam(r, "namespace"), chi.URLParam(r, "pod"))
		if err != nil {
			diagErr(w, http.StatusBadGateway, err.Error())
			return
		}
		diagJSON(w, http.StatusOK, map[string]interface{}{"phase": phase, "containers": cs})
	}
}

type diagStartRequest struct {
	Type       string `json:"type"`
	Namespace  string `json:"namespace"`
	Deployment string `json:"deployment"`
	Pods       []struct {
		Name      string `json:"name"`
		Container string `json:"container"`
	} `json:"pods"`
	Options diag.Options `json:"options"`
}

type diagStartResult struct {
	Pod   string `json:"pod"`
	JobID string `json:"job_id,omitempty"`
	Error string `json:"error,omitempty"`
}

// NewDiagStartHandler serves POST /api/diagnostics/start (one job per selected pod).
func NewDiagStartHandler(m *diag.Manager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ac, username, ok := diagIdentity(w, r)
		if !ok {
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		var req diagStartRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			diagErr(w, http.StatusBadRequest, "invalid request body: "+err.Error())
			return
		}
		if req.Namespace == "" || len(req.Pods) == 0 {
			diagErr(w, http.StatusBadRequest, "namespace and at least one pod are required")
			return
		}
		if len(req.Pods) > 20 {
			diagErr(w, http.StatusBadRequest, "at most 20 pods per request")
			return
		}
		// Fail fast on option problems (PROD confirmation, limits) before touching the cluster.
		if _, err := m.Normalize(req.Type, req.Options, ac.ClusterName); err != nil {
			diagErr(w, http.StatusBadRequest, err.Error())
			return
		}
		// Which identity will exec (same rule as TCP capture); may refuse a cross-cluster request.
		ea, err := resolveDiagExecAuth(m.ExecIdentity(), ac)
		if err != nil {
			diagErr(w, http.StatusBadRequest, err.Error())
			return
		}
		// Authorization is ALWAYS checked with the user's token, even when a ServiceAccount will exec.
		allowed, err := k8s.CheckExecPermission(ac.ClusterURL, ac.Token, req.Namespace)
		if err != nil {
			diagErr(w, http.StatusBadGateway, "could not check exec permission: "+err.Error())
			return
		}
		if !allowed {
			diagErr(w, http.StatusForbidden,
				"Your account cannot 'create' pods/exec in namespace "+req.Namespace+". Ask for edit/admin access to that namespace.")
			return
		}

		caller := diag.Caller{APIURL: ea.apiURL, Token: ea.token, ExecAs: ea.as, Cluster: ac.ClusterName, Username: username}
		results := make([]diagStartResult, 0, len(req.Pods))
		for _, p := range req.Pods {
			res := diagStartResult{Pod: p.Name}
			if err := precheckTarget(ac, req.Namespace, req.Deployment, p.Name, p.Container); err != nil {
				res.Error = err.Error()
				results = append(results, res)
				continue
			}
			id, err := m.Start(caller, diag.StartRequest{
				Type: req.Type, Namespace: req.Namespace, Deployment: req.Deployment,
				Pod: diag.PodRef{Name: p.Name, Container: p.Container}, Options: req.Options,
			})
			if err != nil {
				res.Error = err.Error()
			} else {
				res.JobID = id
			}
			results = append(results, res)
		}
		diagJSON(w, http.StatusOK, map[string]interface{}{"jobs": results})
	}
}

// NewDiagStatusHandler serves GET /api/diagnostics/status?ids=a,b,c (batch, own jobs only).
func NewDiagStatusHandler(m *diag.Manager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ac, username, ok := diagIdentity(w, r)
		if !ok {
			return
		}
		views := []diag.JobView{}
		ids := strings.Split(r.URL.Query().Get("ids"), ",")
		if len(ids) > 100 {
			ids = ids[:100]
		}
		for _, id := range ids {
			if j, ok := ownedJob(m, strings.TrimSpace(id), username, ac); ok {
				views = append(views, diag.View(j))
			}
		}
		diagJSON(w, http.StatusOK, map[string]interface{}{"jobs": views})
	}
}

// NewDiagCancelHandler serves POST /api/diagnostics/{jobID}/cancel.
func NewDiagCancelHandler(m *diag.Manager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ac, username, ok := diagIdentity(w, r)
		if !ok {
			return
		}
		id := chi.URLParam(r, "jobID")
		if _, ok := ownedJob(m, id, username, ac); !ok {
			diagErr(w, http.StatusNotFound, "job not found")
			return
		}
		if err := m.Cancel(id); err != nil {
			if errors.Is(err, diag.ErrNotCancelOK) {
				diagErr(w, http.StatusConflict, err.Error())
				return
			}
			diagErr(w, http.StatusNotFound, err.Error())
			return
		}
		diagJSON(w, http.StatusOK, map[string]string{"status": "cancelling"})
	}
}

// NewDiagTicketHandler serves POST /api/diagnostics/{jobID}/ticket and returns a one-time
// download URL. A plain browser link cannot send the Bearer header; the ticket replaces it.
func NewDiagTicketHandler(m *diag.Manager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ac, username, ok := diagIdentity(w, r)
		if !ok {
			return
		}
		id := chi.URLParam(r, "jobID")
		if _, ok := ownedJob(m, id, username, ac); !ok {
			diagErr(w, http.StatusNotFound, "job not found")
			return
		}
		tk, err := m.IssueTicket(id)
		if err != nil {
			diagErr(w, http.StatusConflict, err.Error())
			return
		}
		diagJSON(w, http.StatusOK, map[string]string{"url": "/download/diag/" + tk})
	}
}

// NewDiagDownloadHandler serves GET /download/diag/{ticket}. Register it OUTSIDE the auth
// middleware group: the one-time ticket is the credential. Range requests are supported.
func NewDiagDownloadHandler(m *diag.Manager) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		j, err := m.RedeemTicket(chi.URLParam(r, "ticket"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusNotFound)
			return
		}
		full := filepath.Clean(filepath.Join(j.Dir, j.File))
		base := filepath.Clean(m.BaseDir()) + string(os.PathSeparator)
		if !strings.HasPrefix(full, base) {
			http.Error(w, "invalid path", http.StatusBadRequest)
			return
		}
		f, err := os.Open(full)
		if err != nil {
			http.Error(w, "file no longer available", http.StatusNotFound)
			return
		}
		defer f.Close()
		st, err := f.Stat()
		if err != nil || st.IsDir() {
			http.Error(w, "file no longer available", http.StatusNotFound)
			return
		}

		log.Printf("diag AUDIT: download job=%s owner=%s exec_as=%s target=%s/%s file=%s size=%d from=%s",
			j.ID, j.Owner, j.ExecAs, j.Namespace, j.Pod, j.File, st.Size(), r.RemoteAddr)

		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", j.File))
		w.Header().Set("Cache-Control", "no-store")
		http.ServeContent(w, r, j.File, st.ModTime(), f)
	}
}
