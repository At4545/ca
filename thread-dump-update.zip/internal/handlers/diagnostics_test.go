package handlers

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/openshift-tcpdump/openshift-tcpdump/internal/capture"
	"github.com/openshift-tcpdump/openshift-tcpdump/internal/diag"
	authmw "github.com/openshift-tcpdump/openshift-tcpdump/internal/middleware"
)

const testDump = "Full thread dump OpenJDK 64-Bit Server VM (17.0.9):\n\"main\" #1 RUNNABLE\n"

// fakeCluster implements just enough of the OpenShift/Kubernetes API, and records which
// bearer tokens were presented to it.
type fakeCluster struct {
	mu         sync.Mutex
	users      map[string]string // token -> username
	execAllow  map[string]bool   // username -> may create pods/exec
	ssarCalled int
	tokensSeen map[string]int
}

func (f *fakeCluster) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	tok := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	f.mu.Lock()
	f.tokensSeen[tok]++
	user, ok := f.users[tok]
	f.mu.Unlock()
	if !ok {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	switch {
	case r.URL.Path == "/apis/user.openshift.io/v1/users/~":
		fmt.Fprintf(w, `{"metadata":{"name":%q},"groups":["system:authenticated"]}`, user)
	case r.URL.Path == "/apis/authorization.k8s.io/v1/selfsubjectaccessreviews":
		f.mu.Lock()
		f.ssarCalled++
		f.mu.Unlock()
		var req struct {
			Spec struct {
				ResourceAttributes struct{ Namespace, Verb, Resource, Subresource string }
			}
		}
		json.NewDecoder(r.Body).Decode(&req)
		ra := req.Spec.ResourceAttributes
		allowed := f.execAllow[user] && ra.Verb == "create" && ra.Resource == "pods" && ra.Subresource == "exec"
		w.WriteHeader(http.StatusCreated)
		fmt.Fprintf(w, `{"status":{"allowed":%v}}`, allowed)
	case strings.HasPrefix(r.URL.Path, "/api/v1/namespaces/ns1/pods/"):
		if strings.HasSuffix(r.URL.Path, "/pending-pod") {
			fmt.Fprint(w, `{"spec":{"containers":[{"name":"app"}]},"status":{"phase":"Pending","containerStatuses":[{"name":"app","state":{"waiting":{}}}]}}`)
			return
		}
		fmt.Fprint(w, `{"spec":{"containers":[{"name":"app"},{"name":"istio-proxy"}]},"status":{"phase":"Running","containerStatuses":[{"name":"app","state":{"running":{}}},{"name":"istio-proxy","state":{"running":{}}}]}}`)
	default:
		http.NotFound(w, r)
	}
}

func (f *fakeCluster) saw(tok string) int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.tokensSeen[tok]
}

// execRecorder is the fake WebSocket exec; it records who exec'd where.
type execRecorder struct {
	mu      sync.Mutex
	targets []diag.Target
	failErr error
}

func (e *execRecorder) last() (diag.Target, bool) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if len(e.targets) == 0 {
		return diag.Target{}, false
	}
	return e.targets[len(e.targets)-1], true
}

type env struct {
	srv  *httptest.Server
	mgr  *diag.Manager
	dir  string
	fc   *fakeCluster
	api  *httptest.Server
	exec *execRecorder
}

// newEnv wires the router exactly like cmd/server/main.go. By default the backend runs LOCALLY
// (no ServiceAccount token); use inCluster() to simulate running inside a cluster.
func newEnv(t *testing.T, mutate ...func(*diag.Config)) *env {
	t.Helper()
	fc := &fakeCluster{
		users:      map[string]string{"tok-alice": "alice", "tok-bob": "bob", "tok-carol": "carol"},
		execAllow:  map[string]bool{"alice": true, "bob": true, "carol": false},
		tokensSeen: map[string]int{},
	}
	api := httptest.NewTLSServer(fc)
	t.Cleanup(api.Close)

	rec := &execRecorder{}
	diag.SetExecHookForTest(func(ctx context.Context, tg diag.Target, argv []string, out io.Writer) (diag.ExecResult, error) {
		rec.mu.Lock()
		rec.targets = append(rec.targets, tg)
		failErr := rec.failErr
		rec.mu.Unlock()
		if failErr != nil {
			return diag.ExecResult{}, failErr
		}
		if argv[0] == "sh" {
			io.WriteString(out, "TOOL jcmd /usr/bin/jcmd\nPID 1\nTMPW 1\n")
		} else {
			io.WriteString(out, testDump)
		}
		return diag.ExecResult{}, nil
	})
	t.Cleanup(func() { diag.SetExecHookForTest(nil) })

	// Local dev by default: no SA token, no backend cluster configured.
	origRead, origBackend := diagReadSAToken, diagBackendClusterURL
	diagReadSAToken = func() (string, error) { return "", nil }
	diagBackendClusterURL = func() string { return "" }
	t.Cleanup(func() { diagReadSAToken, diagBackendClusterURL = origRead, origBackend })

	cfg := diag.ConfigFromEnv()
	cfg.BaseDir = t.TempDir()
	cfg.ProdClusters = map[string]bool{}
	for _, m := range mutate {
		m(&cfg)
	}
	mgr := diag.NewManager(cfg)

	resolver := func(name string) (string, bool) {
		if name == "dev" || name == "prod-east" {
			return api.URL, true
		}
		return "", false
	}
	r := chi.NewRouter()
	r.Route("/api", func(a chi.Router) {
		a.Group(func(auth chi.Router) {
			auth.Use(authmw.AuthMiddleware(resolver))
			auth.Get("/namespaces/{namespace}/pods/{pod}/containers", NewDiagContainersHandler())
			auth.Post("/diagnostics/start", NewDiagStartHandler(mgr))
			auth.Get("/diagnostics/status", NewDiagStatusHandler(mgr))
			auth.Post("/diagnostics/{jobID}/cancel", NewDiagCancelHandler(mgr))
			auth.Post("/diagnostics/{jobID}/ticket", NewDiagTicketHandler(mgr))
		})
	})
	r.Get("/download/diag/{ticket}", NewDiagDownloadHandler(mgr))
	srv := httptest.NewServer(r)
	t.Cleanup(srv.Close)
	return &env{srv: srv, mgr: mgr, dir: cfg.BaseDir, fc: fc, api: api, exec: rec}
}

// inCluster simulates a pod with a mounted ServiceAccount token on cluster `backendURL`.
func inCluster(saToken, backendURL string) {
	diagReadSAToken = func() (string, error) { return saToken, nil }
	diagBackendClusterURL = func() string { return backendURL }
}

func (e *env) do(t *testing.T, method, path, token, cluster string, body any, hdr map[string]string) (int, []byte, http.Header) {
	t.Helper()
	var rd io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = strings.NewReader(string(b))
	}
	req, _ := http.NewRequest(method, e.srv.URL+path, rd)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	if cluster != "" {
		req.Header.Set("X-Cluster", cluster)
	}
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return resp.StatusCode, b, resp.Header
}

func (e *env) start(t *testing.T, token, cluster string, opts map[string]any) (int, map[string]any) {
	return e.startPod(t, token, cluster, "pod-a", "app", opts)
}

func (e *env) startPod(t *testing.T, token, cluster, pod, ctr string, opts map[string]any) (int, map[string]any) {
	t.Helper()
	code, b, _ := e.do(t, "POST", "/api/diagnostics/start", token, cluster, map[string]any{
		"type": "thread", "namespace": "ns1", "deployment": "dep1",
		"pods": []map[string]string{{"name": pod, "container": ctr}}, "options": opts,
	}, nil)
	var m map[string]any
	json.Unmarshal(b, &m)
	return code, m
}

func (e *env) waitDone(t *testing.T, token, cluster, id string) map[string]any {
	t.Helper()
	for i := 0; i < 300; i++ {
		_, b, _ := e.do(t, "GET", "/api/diagnostics/status?ids="+id, token, cluster, nil, nil)
		var res struct{ Jobs []map[string]any }
		json.Unmarshal(b, &res)
		if len(res.Jobs) == 1 {
			if s := res.Jobs[0]["status"].(string); s != "queued" && s != "in_progress" {
				return res.Jobs[0]
			}
		}
		time.Sleep(20 * time.Millisecond)
	}
	t.Fatal("job did not finish")
	return nil
}

func jobID(t *testing.T, m map[string]any) string {
	t.Helper()
	jobs, _ := m["jobs"].([]any)
	if len(jobs) != 1 {
		t.Fatalf("unexpected start response: %v", m)
	}
	id, _ := jobs[0].(map[string]any)["job_id"].(string)
	if id == "" {
		t.Fatalf("no job_id: %v", m)
	}
	return id
}

func (e *env) storedFiles() []string {
	var out []string
	filepath.Walk(e.dir, func(p string, i os.FileInfo, err error) error {
		if err == nil && !i.IsDir() {
			out = append(out, p)
		}
		return nil
	})
	return out
}

func (e *env) metadata(t *testing.T) diag.Metadata {
	t.Helper()
	for _, p := range e.storedFiles() {
		if strings.HasSuffix(p, ".metadata.json") {
			var md diag.Metadata
			raw, _ := os.ReadFile(p)
			if err := json.Unmarshal(raw, &md); err != nil {
				t.Fatal(err)
			}
			return md
		}
	}
	t.Fatal("no metadata file stored")
	return diag.Metadata{}
}

// ------------------------------------------------------------------------------------------
// Identity: local (user token) vs in-cluster (ServiceAccount), same rule as TCP capture
// ------------------------------------------------------------------------------------------

func TestLocalDevExecsWithUserToken(t *testing.T) {
	e := newEnv(t) // no SA token => local dev
	code, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	if code != 200 {
		t.Fatalf("start: %d %v", code, m)
	}
	e.waitDone(t, "tok-alice", "dev", jobID(t, m))
	tg, ok := e.exec.last()
	if !ok {
		t.Fatal("exec never ran")
	}
	if tg.Token != "tok-alice" || tg.APIURL != e.api.URL || tg.AsServiceAccount {
		t.Errorf("local mode must exec with the user's token on the user's cluster: %+v", tg)
	}
	if md := e.metadata(t); md.ExecAs != diag.ExecAsUser || md.Owner != "alice" {
		t.Errorf("metadata: %+v", md)
	}
}

func TestInClusterExecsWithServiceAccount(t *testing.T) {
	e := newEnv(t)
	inCluster("sa-secret-token", e.api.URL) // backend runs on the cluster the user selected
	code, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	if code != 200 {
		t.Fatalf("start: %d %v", code, m)
	}
	e.waitDone(t, "tok-alice", "dev", jobID(t, m))

	tg, _ := e.exec.last()
	if tg.Token != "sa-secret-token" || tg.APIURL != capture.InClusterAPIURL || !tg.AsServiceAccount {
		t.Errorf("in-cluster must exec with the ServiceAccount via the in-cluster URL: %+v", tg)
	}
	if tg.Token == "tok-alice" {
		t.Error("the user's token must not be used for exec in-cluster")
	}
	// The SA token must never be sent to the (user-selected) API endpoint, and the user's token
	// is still used for what the user is entitled to do: identity, access review, pod lookup.
	if e.fc.saw("sa-secret-token") != 0 {
		t.Error("ServiceAccount token leaked to the user-selected API URL")
	}
	if e.fc.saw("tok-alice") < 3 || e.fc.ssarCalled != 1 {
		t.Errorf("user token should be used for identity/SSAR/pod lookup: saw=%d ssar=%d", e.fc.saw("tok-alice"), e.fc.ssarCalled)
	}
	md := e.metadata(t)
	if md.ExecAs != diag.ExecAsServiceAccount || md.Owner != "alice" {
		t.Errorf("metadata must record who asked and who executed: %+v", md)
	}
}

func TestInClusterStillRequiresUserExecPermission(t *testing.T) {
	e := newEnv(t)
	inCluster("sa-secret-token", e.api.URL)
	code, m := e.start(t, "tok-carol", "dev", nil) // carol may not exec
	if code != 403 || !strings.Contains(fmt.Sprint(m["error"]), "pods/exec") {
		t.Errorf("a user without pods/exec must be refused even though the SA could do it: %d %v", code, m)
	}
	if _, ran := e.exec.last(); ran || len(e.storedFiles()) != 0 {
		t.Error("nothing may run or be stored for a forbidden user")
	}
}

func TestInClusterRefusesOtherCluster(t *testing.T) {
	e := newEnv(t)
	inCluster("sa-secret-token", "https://api.some-other-cluster:6443")
	code, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	msg := fmt.Sprint(m["error"])
	if code != 400 || !strings.Contains(msg, "only supported on the cluster where the backend is deployed") ||
		!strings.Contains(msg, e.api.URL) || !strings.Contains(msg, "https://api.some-other-cluster:6443") {
		t.Errorf("cross-cluster request: %d %v", code, m)
	}
	if e.fc.ssarCalled != 0 {
		t.Error("must be refused before any cluster call")
	}
	if _, ran := e.exec.last(); ran {
		t.Error("must not exec")
	}
}

func TestInClusterRefusesWhenBackendClusterUnknown(t *testing.T) {
	e := newEnv(t)
	inCluster("sa-secret-token", "") // BACKEND_CLUSTER_NAME not configured
	code, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	if code != 400 || !strings.Contains(fmt.Sprint(m["error"]), "BACKEND_CLUSTER_NAME") {
		t.Errorf("unverifiable cluster must be refused: %d %v", code, m)
	}
	if _, ran := e.exec.last(); ran {
		t.Error("must not exec")
	}
}

func TestExecIdentityUserOverrideIgnoresServiceAccount(t *testing.T) {
	e := newEnv(t, func(c *diag.Config) { c.ExecIdentity = "user" })
	inCluster("sa-secret-token", "https://api.some-other-cluster:6443") // would be refused in auto mode
	code, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	if code != 200 {
		t.Fatalf("override should allow it: %d %v", code, m)
	}
	e.waitDone(t, "tok-alice", "dev", jobID(t, m))
	if tg, _ := e.exec.last(); tg.Token != "tok-alice" || tg.APIURL != e.api.URL || tg.AsServiceAccount {
		t.Errorf("override must use the user's token on the user's cluster: %+v", tg)
	}
}

func TestServiceAccountForbiddenGivesActionableError(t *testing.T) {
	e := newEnv(t)
	inCluster("sa-secret-token", e.api.URL)
	e.exec.failErr = fmt.Errorf("exec refused by API server (HTTP 403): pods \"pod-a\" is forbidden")
	_, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	st := e.waitDone(t, "tok-alice", "dev", jobID(t, m))
	msg := fmt.Sprint(st["error"])
	if st["status"] != "error" || !strings.Contains(msg, "backend ServiceAccount is not allowed") || !strings.Contains(msg, "ns1") {
		t.Errorf("status=%v error=%q", st["status"], msg)
	}
}

func TestResolveDiagExecAuthUnit(t *testing.T) {
	ac := &authmw.AuthContext{Token: "u", ClusterURL: "https://c1", ClusterName: "dev"}
	origRead, origBackend := diagReadSAToken, diagBackendClusterURL
	defer func() { diagReadSAToken, diagBackendClusterURL = origRead, origBackend }()

	diagReadSAToken = func() (string, error) { return "", fmt.Errorf("permission denied") } // unreadable => fall back like captures.go
	if ea, err := resolveDiagExecAuth("auto", ac); err != nil || ea.token != "u" || ea.as != diag.ExecAsUser {
		t.Errorf("unreadable SA token must fall back to the user token: %+v %v", ea, err)
	}
	inCluster("sa", "https://c1/") // trailing slash differs from the user's URL -> refused (same strict equality as captures.go)
	if _, err := resolveDiagExecAuth("auto", ac); err == nil {
		t.Error("URL mismatch must be refused")
	}
	inCluster("sa", "https://c1")
	if ea, err := resolveDiagExecAuth("auto", ac); err != nil || ea.token != "sa" || ea.apiURL != capture.InClusterAPIURL || ea.as != diag.ExecAsServiceAccount {
		t.Errorf("matching cluster: %+v %v", ea, err)
	}
	if ea, _ := resolveDiagExecAuth("user", ac); ea.token != "u" {
		t.Errorf("user mode: %+v", ea)
	}
}

// ------------------------------------------------------------------------------------------
// Pod pre-check (with the user's token) and the rest of the HTTP behaviour
// ------------------------------------------------------------------------------------------

func TestPrecheckReportsPerPodWithoutStartingJobs(t *testing.T) {
	e := newEnv(t)
	for _, tc := range []struct{ pod, ctr, want string }{
		{"pending-pod", "app", "is not running"},
		{"pod-a", "nope", "does not belong to pod"},
		{"../bad", "app", "invalid or missing pod name"},
	} {
		code, m := e.startPod(t, "tok-alice", "dev", tc.pod, tc.ctr, map[string]any{"count": 1})
		jobs, _ := m["jobs"].([]any)
		if code != 200 || len(jobs) != 1 {
			t.Fatalf("%s: %d %v", tc.pod, code, m)
		}
		j := jobs[0].(map[string]any)
		if j["job_id"] != nil || !strings.Contains(fmt.Sprint(j["error"]), tc.want) {
			t.Errorf("%s: %v, want error containing %q", tc.pod, j, tc.want)
		}
	}
	if _, ran := e.exec.last(); ran || len(e.storedFiles()) != 0 {
		t.Error("rejected targets must not exec or store anything")
	}
}

func TestMixedPodsReportedIndividually(t *testing.T) {
	e := newEnv(t)
	code, b, _ := e.do(t, "POST", "/api/diagnostics/start", "tok-alice", "dev", map[string]any{
		"type": "thread", "namespace": "ns1",
		"pods":    []map[string]string{{"name": "ok-pod", "container": "app"}, {"name": "pending-pod", "container": "app"}},
		"options": map[string]any{"count": 1},
	}, nil)
	var res struct {
		Jobs []struct {
			Pod   string `json:"pod"`
			JobID string `json:"job_id"`
			Error string `json:"error"`
		}
	}
	json.Unmarshal(b, &res)
	if code != 200 || len(res.Jobs) != 2 || res.Jobs[0].JobID == "" || res.Jobs[1].Error == "" || res.Jobs[1].JobID != "" {
		t.Errorf("per-pod results: %d %s", code, b)
	}
	e.waitDone(t, "tok-alice", "dev", res.Jobs[0].JobID)
}

func TestEndToEndOverHTTP(t *testing.T) {
	e := newEnv(t)
	code, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 2, "interval_sec": 1})
	if code != 200 {
		t.Fatalf("start: %d %v", code, m)
	}
	id := jobID(t, m)
	if e.fc.ssarCalled != 1 {
		t.Errorf("exec permission must be checked exactly once per request, got %d", e.fc.ssarCalled)
	}
	if st := e.waitDone(t, "tok-alice", "dev", id); st["status"] != "complete" || st["downloadable"] != true {
		t.Fatalf("job: %v", st)
	}

	code, b, _ := e.do(t, "POST", "/api/diagnostics/"+id+"/ticket", "tok-alice", "dev", nil, nil)
	var tk struct{ URL string }
	json.Unmarshal(b, &tk)
	if code != 200 || !strings.HasPrefix(tk.URL, "/download/diag/") {
		t.Fatalf("ticket: %d %s", code, b)
	}
	// No Authorization header: a plain browser navigation.
	code, b, hdr := e.do(t, "GET", tk.URL, "", "", nil, nil)
	if code != 200 || strings.Count(string(b), "Full thread dump") != 2 {
		t.Fatalf("download: %d dumps=%d", code, strings.Count(string(b), "Full thread dump"))
	}
	if cd := hdr.Get("Content-Disposition"); !strings.Contains(cd, "attachment") || !strings.Contains(cd, "thread-dump-pod-a-") {
		t.Errorf("Content-Disposition = %q", cd)
	}
	if !strings.HasPrefix(hdr.Get("Content-Type"), "text/plain") || hdr.Get("Cache-Control") != "no-store" {
		t.Errorf("headers: %v", hdr)
	}
	if code, _, _ := e.do(t, "GET", tk.URL, "", "", nil, nil); code != 404 {
		t.Errorf("reusing a ticket must 404, got %d", code)
	}
	_, b, _ = e.do(t, "POST", "/api/diagnostics/"+id+"/ticket", "tok-alice", "dev", nil, nil)
	json.Unmarshal(b, &tk)
	code, b, hdr = e.do(t, "GET", tk.URL, "", "", nil, map[string]string{"Range": "bytes=0-9"})
	if code != 206 || len(b) != 10 || !strings.HasPrefix(hdr.Get("Content-Range"), "bytes 0-9/") {
		t.Errorf("range request: code=%d len=%d content-range=%q", code, len(b), hdr.Get("Content-Range"))
	}
}

func TestAuthAndIsolation(t *testing.T) {
	e := newEnv(t)
	if code, _ := e.start(t, "", "dev", nil); code != 401 {
		t.Errorf("no token: %d", code)
	}
	if code, _ := e.start(t, "tok-nobody", "dev", nil); code != 401 {
		t.Errorf("bad token: %d", code)
	}
	if code, _ := e.start(t, "tok-alice", "nowhere", nil); code != 400 {
		t.Errorf("unknown cluster: %d", code)
	}
	if code, m := e.start(t, "tok-carol", "dev", nil); code != 403 || !strings.Contains(fmt.Sprint(m["error"]), "pods/exec") {
		t.Errorf("no exec permission: %d %v", code, m)
	}

	_, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	id := jobID(t, m)
	e.waitDone(t, "tok-alice", "dev", id)

	var res struct{ Jobs []any }
	_, b, _ := e.do(t, "GET", "/api/diagnostics/status?ids="+id, "tok-bob", "dev", nil, nil)
	json.Unmarshal(b, &res)
	if len(res.Jobs) != 0 {
		t.Errorf("bob must not see alice's job: %s", b)
	}
	if code, _, _ := e.do(t, "POST", "/api/diagnostics/"+id+"/ticket", "tok-bob", "dev", nil, nil); code != 404 {
		t.Errorf("bob asking for a ticket: %d", code)
	}
	if code, _, _ := e.do(t, "POST", "/api/diagnostics/"+id+"/cancel", "tok-bob", "dev", nil, nil); code != 404 {
		t.Errorf("bob cancelling: %d", code)
	}
	_, b, _ = e.do(t, "GET", "/api/diagnostics/status?ids="+id, "tok-alice", "prod-east", nil, nil)
	json.Unmarshal(b, &res)
	if len(res.Jobs) != 0 {
		t.Errorf("job must be scoped to its cluster: %s", b)
	}
	_, b, _ = e.do(t, "GET", "/api/diagnostics/status?ids="+id, "tok-alice", "dev", nil, nil)
	json.Unmarshal(b, &res)
	if len(res.Jobs) != 1 {
		t.Errorf("alice must see her own job: %s", b)
	}
	if code, _, _ := e.do(t, "POST", "/api/diagnostics/"+id+"/cancel", "tok-alice", "dev", nil, nil); code != 409 {
		t.Errorf("cancelling finished job: %d", code)
	}
	if code, _, _ := e.do(t, "GET", "/download/diag/"+strings.Repeat("0", 32), "", "", nil, nil); code != 404 {
		t.Errorf("unknown ticket: %d", code)
	}
}

func TestProdConfirmationAndValidation(t *testing.T) {
	e := newEnv(t, func(c *diag.Config) { c.ProdClusters = map[string]bool{"prod-east": true} })

	code, m := e.start(t, "tok-alice", "prod-east", map[string]any{"count": 1})
	if code != 400 || !strings.Contains(fmt.Sprint(m["error"]), "production cluster") {
		t.Errorf("prod without confirmation: %d %v", code, m)
	}
	if e.fc.ssarCalled != 0 {
		t.Error("option validation must fail fast, before contacting the cluster")
	}
	if code, _ := e.start(t, "tok-alice", "prod-east", map[string]any{"count": 1, "confirm_cluster": "wrong"}); code != 400 {
		t.Errorf("prod with wrong confirmation: %d", code)
	}
	code, m = e.start(t, "tok-alice", "prod-east", map[string]any{"count": 1, "confirm_cluster": "prod-east"})
	if code != 200 {
		t.Fatalf("prod with exact confirmation: %d %v", code, m)
	}
	e.waitDone(t, "tok-alice", "prod-east", jobID(t, m))

	for _, o := range []map[string]any{{"count": 11}, {"count": -1}, {"interval_sec": 99}, {"max_size_mb": 1000}, {"timeout_sec": 5}} {
		if code, m := e.start(t, "tok-alice", "dev", o); code != 400 {
			t.Errorf("options %v should be rejected, got %d %v", o, code, m)
		}
	}
	for _, body := range []any{nil, map[string]any{"type": "thread"}, map[string]any{"type": "thread", "namespace": "ns1", "pods": []any{}}} {
		if code, _, _ := e.do(t, "POST", "/api/diagnostics/start", "tok-alice", "dev", body, nil); code != 400 {
			t.Errorf("body %v: %d", body, code)
		}
	}
}

func TestContainersEndpoint(t *testing.T) {
	e := newEnv(t)
	code, b, _ := e.do(t, "GET", "/api/namespaces/ns1/pods/pod-a/containers", "tok-alice", "dev", nil, nil)
	if code != 200 || !strings.Contains(string(b), `"name":"app"`) || !strings.Contains(string(b), `"phase":"Running"`) {
		t.Errorf("containers: %d %s", code, b)
	}
	if code, _, _ := e.do(t, "GET", "/api/namespaces/other/pods/pod-a/containers", "tok-alice", "dev", nil, nil); code != 502 {
		t.Errorf("missing pod should surface as 502, got %d", code)
	}
}

func TestDownloadAfterFileRemoved(t *testing.T) {
	e := newEnv(t)
	_, m := e.start(t, "tok-alice", "dev", map[string]any{"count": 1})
	id := jobID(t, m)
	e.waitDone(t, "tok-alice", "dev", id)
	for _, p := range e.storedFiles() {
		if strings.HasSuffix(p, ".txt") {
			os.Remove(p)
		}
	}
	_, b, _ := e.do(t, "POST", "/api/diagnostics/"+id+"/ticket", "tok-alice", "dev", nil, nil)
	var tk struct{ URL string }
	json.Unmarshal(b, &tk)
	if code, _, _ := e.do(t, "GET", tk.URL, "", "", nil, nil); code != 404 {
		t.Errorf("deleted file: %d", code)
	}
}
