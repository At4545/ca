package diag

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

const fullDump = "2024-01-01 00:00:00\nFull thread dump OpenJDK 64-Bit Server VM (17.0.9):\n\"main\" #1 prio=5 RUNNABLE\n"
const goodDiscovery = "TOOL jcmd /usr/bin/jcmd\nPID 1\nTMPW 1\nUID 1001\n"

type fakeContainer struct {
	discovery string
	dumpCount int32
	dumpOut   string
	dumpExit  int
	dumpSleep time.Duration
	lastToken atomic.Value // string: credential the last exec was made with
	lastURL   atomic.Value
	lastSA    atomic.Bool
}

func (f *fakeContainer) install(t *testing.T) {
	execHook = func(ctx context.Context, tg Target, argv []string, stdout io.Writer) (ExecResult, error) {
		f.lastToken.Store(tg.Token)
		f.lastURL.Store(tg.APIURL)
		f.lastSA.Store(tg.AsServiceAccount)
		if tg.Container != "app" {
			return ExecResult{}, fmt.Errorf("container not found")
		}
		switch {
		case len(argv) >= 3 && argv[0] == "sh" && argv[1] == "-c":
			io.WriteString(stdout, f.discovery)
			return ExecResult{}, nil
		case strings.HasSuffix(argv[0], "jcmd") || strings.HasSuffix(argv[0], "jstack"):
			atomic.AddInt32(&f.dumpCount, 1)
			if f.dumpSleep > 0 {
				select {
				case <-time.After(f.dumpSleep):
				case <-ctx.Done():
					return ExecResult{}, ctx.Err()
				}
			}
			io.WriteString(stdout, f.dumpOut)
			return ExecResult{ExitCode: f.dumpExit}, nil
		}
		return ExecResult{ExitCode: 127}, nil
	}
	t.Cleanup(func() { execHook = nil })
}

func newMgr(t *testing.T) *Manager {
	cfg := ConfigFromEnv()
	cfg.BaseDir = t.TempDir()
	cfg.ThreadConcurrency = 2
	cfg.MaxQueued = 3
	return NewManager(cfg)
}

func caller(execAs string) Caller {
	return Caller{APIURL: "https://api.example", Token: "exec-token", ExecAs: execAs, Cluster: "dev", Username: "alice"}
}

func waitTerminal(t *testing.T, m *Manager, id string, d time.Duration) Job {
	t.Helper()
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		j, ok := m.Get(id)
		if !ok {
			t.Fatalf("job %s vanished", id)
		}
		if IsTerminal(j.Status) {
			return j
		}
		time.Sleep(20 * time.Millisecond)
	}
	j, _ := m.Get(id)
	t.Fatalf("job %s not finished in %s (status=%s stage=%s)", id, d, j.Status, j.Stage)
	return j
}

func startReq(pod, ctr string, o Options) StartRequest {
	return StartRequest{Type: TypeThread, Namespace: "ns1", Deployment: "dep1", Pod: PodRef{Name: pod, Container: ctr}, Options: o}
}

func TestHappyPathAndExecCredential(t *testing.T) {
	fc := &fakeContainer{discovery: goodDiscovery, dumpOut: fullDump}
	fc.install(t)
	m := newMgr(t)

	id, err := m.Start(caller(ExecAsServiceAccount), startReq("pod-a", "app", Options{Count: 3, IntervalSec: 1}))
	if err != nil {
		t.Fatal(err)
	}
	j := waitTerminal(t, m, id, 15*time.Second)
	if j.Status != StatusComplete {
		t.Fatalf("status=%s error=%q", j.Status, j.Error)
	}
	if got := atomic.LoadInt32(&fc.dumpCount); got != 3 {
		t.Errorf("jcmd ran %d times, want 3", got)
	}
	// The exact credential chosen by the HTTP layer is what reaches the exec call.
	if fc.lastToken.Load() != "exec-token" || fc.lastURL.Load() != "https://api.example" || !fc.lastSA.Load() {
		t.Errorf("exec used token=%v url=%v sa=%v", fc.lastToken.Load(), fc.lastURL.Load(), fc.lastSA.Load())
	}

	data, err := os.ReadFile(filepath.Join(j.Dir, j.File))
	if err != nil {
		t.Fatal(err)
	}
	if n := strings.Count(string(data), "Full thread dump"); n != 3 {
		t.Errorf("file has %d dumps, want 3", n)
	}
	for _, want := range []string{"Thread dump 1/3", "Thread dump 3/3", "ns1/pod-a/app", "pid 1", "jcmd"} {
		if !strings.Contains(string(data), want) {
			t.Errorf("missing %q in output file", want)
		}
	}
	if strings.Contains(string(data), "exec-token") {
		t.Error("the credential must never be written to the output")
	}
	if want := filepath.Join(m.BaseDir(), "thread", "ns1", "dep1", "pod-a", id); j.Dir != want {
		t.Errorf("dir = %s, want %s", j.Dir, want)
	}
	var md Metadata
	raw, err := os.ReadFile(filepath.Join(j.Dir, metadataName))
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(raw, &md); err != nil || md.Owner != "alice" || md.ExecAs != ExecAsServiceAccount || md.Tool != "jcmd" {
		t.Errorf("bad metadata: %+v err=%v", md, err)
	}
	if parts, _ := filepath.Glob(filepath.Join(j.Dir, "*.part")); len(parts) != 0 {
		t.Errorf("leftover .part files: %v", parts)
	}
	if v := View(j); !v.Downloadable || v.File == "" || v.SizeBytes == 0 {
		t.Errorf("view not downloadable: %+v", v)
	}
	// Pod is free again after completion.
	id2, err := m.Start(caller(ExecAsUser), startReq("pod-a", "app", Options{Count: 1}))
	if err != nil {
		t.Fatalf("pod should be startable again: %v", err)
	}
	waitTerminal(t, m, id2, 10*time.Second) // don't leave a job writing into the temp dir
}

func TestUnknownExecAsDefaultsToUser(t *testing.T) {
	fc := &fakeContainer{discovery: goodDiscovery, dumpOut: fullDump}
	fc.install(t)
	m := newMgr(t)
	id, _ := m.Start(caller(""), startReq("pod-a", "app", Options{Count: 1}))
	j := waitTerminal(t, m, id, 10*time.Second)
	if j.ExecAs != ExecAsUser || fc.lastSA.Load() {
		t.Errorf("ExecAs=%q sa=%v", j.ExecAs, fc.lastSA.Load())
	}
}

func TestTicketIsOneTime(t *testing.T) {
	(&fakeContainer{discovery: goodDiscovery, dumpOut: fullDump}).install(t)
	m := newMgr(t)
	id, _ := m.Start(caller(ExecAsUser), startReq("pod-a", "app", Options{Count: 1}))
	waitTerminal(t, m, id, 10*time.Second)

	tk, err := m.IssueTicket(id)
	if err != nil || len(tk) != 32 {
		t.Fatalf("ticket %q err=%v", tk, err)
	}
	if j, err := m.RedeemTicket(tk); err != nil || j.ID != id {
		t.Fatalf("redeem: %v %v", j.ID, err)
	}
	if _, err := m.RedeemTicket(tk); err != ErrBadTicket {
		t.Errorf("second redeem must fail, got %v", err)
	}
	if _, err := m.RedeemTicket("nonsense"); err != ErrBadTicket {
		t.Errorf("unknown ticket must fail, got %v", err)
	}
}

func TestFailures(t *testing.T) {
	cases := []struct {
		name    string
		fc      *fakeContainer
		wantErr string
	}{
		{"no jcmd/jstack", &fakeContainer{discovery: "PID 1\nTMPW 1\n", dumpOut: fullDump}, "neither jcmd nor jstack"},
		{"no java process", &fakeContainer{discovery: "TOOL jcmd /usr/bin/jcmd\nTMPW 1\n", dumpOut: fullDump}, "no Java process"},
		{"two JVMs", &fakeContainer{discovery: "TOOL jcmd /usr/bin/jcmd\nPID 1\nPID 9\nTMPW 1\n", dumpOut: fullDump}, "2 Java processes"},
		{"tmp not writable", &fakeContainer{discovery: "TOOL jcmd /usr/bin/jcmd\nPID 1\n", dumpOut: fullDump}, "/tmp is not writable"},
		{"attach fails (exit 1)", &fakeContainer{discovery: goodDiscovery, dumpOut: "Unable to open socket file: target process 1 doesn't respond", dumpExit: 1}, "attach to the JVM"},
		{"output without header", &fakeContainer{discovery: goodDiscovery, dumpOut: "some garbage"}, "did not contain 'Full thread dump'"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			c.fc.install(t)
			m := newMgr(t)
			id, err := m.Start(caller(ExecAsUser), startReq("pod-a", "app", Options{Count: 2, IntervalSec: 1}))
			if err != nil {
				t.Fatal(err)
			}
			j := waitTerminal(t, m, id, 10*time.Second)
			if j.Status != StatusError || !strings.Contains(strings.ToLower(j.Error), strings.ToLower(c.wantErr)) {
				t.Errorf("status=%s error=%q, want error containing %q", j.Status, j.Error, c.wantErr)
			}
			var leftovers []string
			filepath.Walk(m.BaseDir(), func(p string, info os.FileInfo, err error) error {
				if err == nil && !info.IsDir() {
					leftovers = append(leftovers, p)
				}
				return nil
			})
			if len(leftovers) != 0 {
				t.Errorf("failed job left files behind: %v", leftovers)
			}
			if _, err := m.IssueTicket(id); err == nil {
				t.Error("failed job must not give out a download ticket")
			}
		})
	}
}

func TestExecErrorsAreExplainedPerIdentity(t *testing.T) {
	for _, tc := range []struct {
		execAs, want string
	}{
		{ExecAsServiceAccount, "backend ServiceAccount is not allowed"},
		{ExecAsUser, "your account needs"},
	} {
		execHook = func(ctx context.Context, tg Target, argv []string, out io.Writer) (ExecResult, error) {
			return ExecResult{}, fmt.Errorf("exec refused by API server (HTTP 403): forbidden")
		}
		m := newMgr(t)
		id, _ := m.Start(caller(tc.execAs), startReq("pod-a", "app", Options{Count: 1}))
		j := waitTerminal(t, m, id, 5*time.Second)
		if j.Status != StatusError || !strings.Contains(j.Error, tc.want) {
			t.Errorf("%s: status=%s error=%q, want %q", tc.execAs, j.Status, j.Error, tc.want)
		}
	}
	t.Cleanup(func() { execHook = nil })
}

func TestStaleContainerFailsAtExec(t *testing.T) {
	(&fakeContainer{discovery: goodDiscovery, dumpOut: fullDump}).install(t)
	m := newMgr(t)
	id, _ := m.Start(caller(ExecAsUser), startReq("pod-a", "gone", Options{Count: 1})) // fake: only "app" exists
	j := waitTerminal(t, m, id, 5*time.Second)
	if j.Status != StatusError || !strings.Contains(j.Error, "not found") {
		t.Errorf("status=%s error=%q", j.Status, j.Error)
	}
}

func TestPartialFailureDiscardsFile(t *testing.T) {
	var n int32
	execHook = func(ctx context.Context, tg Target, argv []string, stdout io.Writer) (ExecResult, error) {
		if argv[0] == "sh" {
			io.WriteString(stdout, goodDiscovery)
			return ExecResult{}, nil
		}
		if atomic.AddInt32(&n, 1) == 1 {
			io.WriteString(stdout, fullDump)
		} else {
			io.WriteString(stdout, "broken")
		}
		return ExecResult{}, nil
	}
	t.Cleanup(func() { execHook = nil })
	m := newMgr(t)
	id, _ := m.Start(caller(ExecAsUser), startReq("pod-a", "app", Options{Count: 3, IntervalSec: 1}))
	j := waitTerminal(t, m, id, 10*time.Second)
	if j.Status != StatusError || !strings.Contains(j.Error, "dump 2") {
		t.Errorf("status=%s err=%q", j.Status, j.Error)
	}
	if _, err := os.Stat(j.Dir); !os.IsNotExist(err) {
		t.Errorf("output dir should be removed, stat err=%v", err)
	}
}

func TestCancelRunning(t *testing.T) {
	(&fakeContainer{discovery: goodDiscovery, dumpOut: fullDump, dumpSleep: 5 * time.Second}).install(t)
	m := newMgr(t)
	id, _ := m.Start(caller(ExecAsUser), startReq("pod-a", "app", Options{Count: 2, IntervalSec: 1}))
	for i := 0; i < 200; i++ {
		if j, _ := m.Get(id); j.Status == StatusInProgress && strings.HasPrefix(j.Stage, "Taking thread dump") {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	if err := m.Cancel(id); err != nil {
		t.Fatal(err)
	}
	start := time.Now()
	j := waitTerminal(t, m, id, 3*time.Second)
	if j.Status != StatusCancelled || time.Since(start) > 2*time.Second {
		t.Errorf("status=%s err=%q after %s", j.Status, j.Error, time.Since(start))
	}
	if err := m.Cancel(id); err != ErrNotCancelOK {
		t.Errorf("cancelling a finished job: %v", err)
	}
	if err := m.Cancel("does-not-exist"); err != ErrNotFound {
		t.Errorf("unknown job: %v", err)
	}
	if _, err := os.Stat(j.Dir); !os.IsNotExist(err) {
		t.Errorf("cancelled job must remove its output dir (err=%v)", err)
	}
}

func TestTimeout(t *testing.T) {
	(&fakeContainer{discovery: goodDiscovery, dumpOut: fullDump, dumpSleep: 30 * time.Second}).install(t)
	m := newMgr(t)
	id, err := m.Start(caller(ExecAsUser), startReq("pod-a", "app", Options{Count: 1, TimeoutSec: 10}))
	if err != nil {
		t.Fatal(err)
	}
	if j := waitTerminal(t, m, id, 15*time.Second); j.Status != StatusTimedOut {
		t.Errorf("status=%s err=%q", j.Status, j.Error)
	}
}

func TestPodBusyAndQueueLimits(t *testing.T) {
	(&fakeContainer{discovery: goodDiscovery, dumpOut: fullDump, dumpSleep: 2 * time.Second}).install(t)
	m := newMgr(t) // concurrency 2, max queued 3
	c := caller(ExecAsUser)

	id1, err := m.Start(c, startReq("pod-1", "app", Options{Count: 1}))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := m.Start(c, startReq("pod-1", "app", Options{Count: 1})); err != ErrPodBusy {
		t.Errorf("same pod twice: got %v, want ErrPodBusy", err)
	}
	c2 := c
	c2.Cluster = "other"
	id2, err := m.Start(c2, startReq("pod-1", "app", Options{Count: 1}))
	if err != nil {
		t.Errorf("same pod name on another cluster must be allowed: %v", err)
	}
	var ids []string
	var lastErr error
	for i := 0; i < 8; i++ {
		id, err := m.Start(c, startReq(fmt.Sprintf("q-%d", i), "app", Options{Count: 1}))
		if err != nil {
			lastErr = err
			break
		}
		ids = append(ids, id)
	}
	if lastErr != ErrQueueFull {
		t.Errorf("expected ErrQueueFull, got %v after %d starts", lastErr, len(ids))
	}
	all := append(ids, id1, id2)
	for _, id := range all {
		m.Cancel(id)
	}
	for _, id := range all {
		waitTerminal(t, m, id, 5*time.Second)
	}
}

func TestInputValidation(t *testing.T) {
	m := newMgr(t)
	bad := []StartRequest{
		startReq("../etc", "app", Options{}),
		startReq("pod/a", "app", Options{}),
		startReq("POD", "app", Options{}),
		startReq("pod-a", "", Options{}),
		startReq("pod-a", "app;rm", Options{}),
		{Type: TypeThread, Namespace: "../x", Pod: PodRef{Name: "p", Container: "c"}},
		{Type: TypeThread, Namespace: "ns", Deployment: "a/b", Pod: PodRef{Name: "p", Container: "c"}},
		{Type: "heap", Namespace: "ns", Pod: PodRef{Name: "p", Container: "c"}},
	}
	for i, r := range bad {
		if id, err := m.Start(caller(ExecAsUser), r); err == nil {
			t.Errorf("case %d: expected rejection, got job %s", i, id)
		}
	}
}

func TestCleanup(t *testing.T) {
	m := newMgr(t)
	m.cfg.ThreadTTL = time.Hour
	mk := func(rel string, completed time.Time) string {
		dir := filepath.Join(m.BaseDir(), rel)
		os.MkdirAll(dir, 0o750)
		writeMetadata(dir, Metadata{JobID: "x", Type: TypeThread, File: "f.txt", CompletedAt: completed})
		os.WriteFile(filepath.Join(dir, "f.txt"), []byte("x"), 0o640)
		return dir
	}
	old := mk("thread/ns1/dep1/pod-old/aaa", time.Now().Add(-2*time.Hour))
	fresh := mk("thread/ns1/dep1/pod-new/bbb", time.Now().Add(-10*time.Minute))
	crashed := filepath.Join(m.BaseDir(), "thread/ns1/dep1/pod-crash/ccc")
	os.MkdirAll(crashed, 0o750)
	pf := filepath.Join(crashed, "x.txt.part")
	os.WriteFile(pf, []byte("partial"), 0o640)
	os.Chtimes(pf, time.Now().Add(-7*time.Hour), time.Now().Add(-7*time.Hour))

	m.cleanup()

	if _, err := os.Stat(old); !os.IsNotExist(err) {
		t.Error("expired dump should be deleted")
	}
	if _, err := os.Stat(filepath.Join(m.BaseDir(), "thread/ns1/dep1/pod-old")); !os.IsNotExist(err) {
		t.Error("empty parent directory should be pruned")
	}
	if _, err := os.Stat(fresh); err != nil {
		t.Error("fresh dump must be kept")
	}
	if _, err := os.Stat(crashed); !os.IsNotExist(err) {
		t.Error("stale .part directory should be deleted")
	}
	if _, err := os.Stat(m.BaseDir()); err != nil {
		t.Error("base dir must never be removed")
	}
}
