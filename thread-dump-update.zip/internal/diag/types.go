// Package diag adds on-demand JVM thread dumps to the OpenShift TCPDump tool.
//
// A thread dump runs INSIDE the target container through the Kubernetes pods/exec API.
// Which identity performs the exec is decided by the HTTP layer (see handlers/diagnostics.go)
// with the same rule as TCP capture: the backend ServiceAccount when running in a cluster,
// the user's own token when running locally.
package diag

import (
	"os"
	"strconv"
	"strings"
	"time"
)

// Diagnostic types.
const (
	TypeThread = "thread"
)

// Identity that performed the exec (recorded in logs and metadata).
const (
	ExecAsUser           = "user"
	ExecAsServiceAccount = "serviceaccount"
)

// Job status values.
const (
	StatusQueued     = "queued"
	StatusInProgress = "in_progress"
	StatusComplete   = "complete"
	StatusError      = "error"
	StatusTimedOut   = "timed_out"
	StatusCancelled  = "cancelled"
)

// IsTerminal reports whether a job status is final.
func IsTerminal(s string) bool {
	switch s {
	case StatusComplete, StatusError, StatusTimedOut, StatusCancelled:
		return true
	}
	return false
}

// DiskReserveBytes is the free space that must remain on the PVC after a dump is stored.
const DiskReserveBytes uint64 = 500 << 20

// Options are the user-supplied parameters. Zero values are replaced by defaults in Normalize().
type Options struct {
	Count       int `json:"count"`        // number of dumps, 1..10 (default 3)
	IntervalSec int `json:"interval_sec"` // seconds between dumps, 1..60 (default 5)
	TimeoutSec  int `json:"timeout_sec"`  // overall deadline, starts when the job leaves the queue
	MaxSizeMB   int `json:"max_size_mb"`  // total text cap across all dumps (default 50)

	// Production confirmation: user must type the exact cluster name.
	ConfirmCluster string `json:"confirm_cluster"`
}

// Job is the in-memory record of one diagnostic run against one pod/container.
// The exec credential (SA or user token) is NEVER stored here; it lives only on the runner goroutine's stack.
type Job struct {
	ID         string
	Type       string
	Cluster    string
	Owner      string // OpenShift username that started the job
	ExecAs     string // ExecAsUser or ExecAsServiceAccount
	Namespace  string
	Deployment string
	Pod        string
	Container  string
	Options    Options

	Status     string
	Stage      string
	Error      string
	Warning    string
	CreatedAt  time.Time
	StartedAt  time.Time
	FinishedAt time.Time

	BytesDone  int64
	BytesTotal int64

	Dir       string // directory on the PVC
	File      string // final file name inside Dir (set on success)
	SizeBytes int64

	cancel func()
}

// JobView is the JSON shape returned to the UI.
type JobView struct {
	JobID        string `json:"job_id"`
	Type         string `json:"type"`
	Namespace    string `json:"namespace"`
	Pod          string `json:"pod"`
	Container    string `json:"container"`
	Status       string `json:"status"`
	Stage        string `json:"stage,omitempty"`
	Error        string `json:"error,omitempty"`
	Warning      string `json:"warning,omitempty"`
	CreatedAt    string `json:"created_at"`
	StartedAt    string `json:"started_at,omitempty"`
	FinishedAt   string `json:"finished_at,omitempty"`
	ElapsedSec   int    `json:"elapsed_seconds"`
	BytesDone    int64  `json:"bytes_done"`
	BytesTotal   int64  `json:"bytes_total"`
	File         string `json:"file,omitempty"`
	SizeBytes    int64  `json:"size_bytes,omitempty"`
	Downloadable bool   `json:"downloadable"`
}

// View converts a Job snapshot to its JSON view.
func View(j Job) JobView {
	ts := func(t time.Time) string {
		if t.IsZero() {
			return ""
		}
		return t.UTC().Format(time.RFC3339)
	}
	elapsed := 0
	if !j.StartedAt.IsZero() {
		end := j.FinishedAt
		if end.IsZero() {
			end = time.Now()
		}
		elapsed = int(end.Sub(j.StartedAt).Seconds())
	}
	return JobView{
		JobID: j.ID, Type: j.Type, Namespace: j.Namespace, Pod: j.Pod, Container: j.Container,
		Status: j.Status, Stage: j.Stage, Error: j.Error, Warning: j.Warning,
		CreatedAt: ts(j.CreatedAt), StartedAt: ts(j.StartedAt), FinishedAt: ts(j.FinishedAt),
		ElapsedSec: elapsed, BytesDone: j.BytesDone, BytesTotal: j.BytesTotal,
		File: j.File, SizeBytes: j.SizeBytes,
		Downloadable: j.Status == StatusComplete && j.File != "",
	}
}

// Metadata is written next to every stored dump (used by the cleanup loop).
type Metadata struct {
	JobID       string    `json:"job_id"`
	Type        string    `json:"type"`
	Cluster     string    `json:"cluster"`
	Owner       string    `json:"owner"`
	ExecAs      string    `json:"exec_as"`
	Namespace   string    `json:"namespace"`
	Deployment  string    `json:"deployment"`
	Pod         string    `json:"pod"`
	Container   string    `json:"container"`
	JVMPid      int       `json:"jvm_pid"`
	Tool        string    `json:"tool"`
	File        string    `json:"file"`
	SizeBytes   int64     `json:"size_bytes"`
	CompletedAt time.Time `json:"completed_at"`
	Options     Options   `json:"options"`
}

// Config holds runtime settings, normally loaded from environment variables.
type Config struct {
	BaseDir           string
	ThreadConcurrency int
	MaxQueued         int
	ProdClusters      map[string]bool // lower-cased cluster names that need typed confirmation
	ThreadTTL         time.Duration
	// ExecIdentity: "auto" (default) = same rule as TCP capture (ServiceAccount in-cluster, user token
	// locally); "user" = always exec with the user's own token.
	ExecIdentity string
}

// ConfigFromEnv builds a Config from DIAG_* environment variables.
func ConfigFromEnv() Config {
	c := Config{
		BaseDir:           envStr("DIAG_BASE_DIR", "/data/diagnostics"),
		ThreadConcurrency: envInt("DIAG_THREAD_CONCURRENCY", 6),
		MaxQueued:         envInt("DIAG_MAX_QUEUED", 20),
		ProdClusters:      map[string]bool{},
		ThreadTTL:         time.Duration(envInt("DIAG_THREAD_TTL_HOURS", 168)) * time.Hour,
		ExecIdentity:      "auto",
	}
	if strings.EqualFold(strings.TrimSpace(os.Getenv("DIAG_EXEC_IDENTITY")), "user") {
		c.ExecIdentity = "user"
	}
	for _, n := range strings.Split(os.Getenv("DIAG_PROD_CLUSTERS"), ",") {
		if n = strings.TrimSpace(n); n != "" {
			c.ProdClusters[strings.ToLower(n)] = true
		}
	}
	return c
}

func envStr(key, def string) string {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		return v
	}
	return def
}

func envInt(key string, def int) int {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			return n
		}
	}
	return def
}
