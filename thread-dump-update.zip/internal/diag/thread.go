package diag

import (
	"context"
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"
)

// hooks lets the runner report progress without knowing about the Manager.
type hooks struct {
	stage    func(string)
	progress func(done, total int64)
	warn     func(string)
}

// runThreadDump takes o.Count thread dumps, o.IntervalSec apart, into one text stream.
//
//	jcmd <pid> Thread.print   (preferred)   or   jstack <pid>
//
// Every dump must contain "Full thread dump" in its first 4 KB, otherwise the whole job
// fails (the caller discards the partial file). A shared size cap applies across all dumps.
// Returns the tool name used.
func runThreadDump(ctx context.Context, t Target, jvm *JVMInfo, pid int, o Options, out io.Writer, h hooks) (string, error) {
	var argv []string
	var tool string
	if p, ok := jvm.Tools["jcmd"]; ok {
		tool = "jcmd"
		argv = []string{p, strconv.Itoa(pid), "Thread.print"}
	} else if p, ok := jvm.Tools["jstack"]; ok {
		tool = "jstack"
		argv = []string{p, strconv.Itoa(pid)}
	} else {
		return "", errors.New("neither jcmd nor jstack was found in the container (a JRE-only image has neither); no other method was attempted")
	}

	maxBytes := int64(o.MaxSizeMB) << 20
	var written int64

	for i := 1; i <= o.Count; i++ {
		if err := ctx.Err(); err != nil {
			return tool, err
		}
		h.stage(fmt.Sprintf("Taking thread dump %d of %d", i, o.Count))

		remaining := maxBytes - written
		if remaining <= 0 {
			return tool, fmt.Errorf("size limit of %d MB reached before dump %d", o.MaxSizeMB, i)
		}
		buf := &limitedBuffer{max: int(remaining)}
		res, err := t.Exec(ctx, argv, buf)
		if err != nil {
			if ctx.Err() != nil {
				return tool, ctx.Err()
			}
			return tool, errors.New(t.explainExecError(err))
		}
		if res.ExitCode != 0 {
			return tool, fmt.Errorf("%s failed (exit %d): %s", tool, res.ExitCode, explainAttachError(res.Stderr+"\n"+buf.String()))
		}
		if buf.over {
			return tool, fmt.Errorf("dump %d exceeds the remaining size limit (%d MB total)", i, o.MaxSizeMB)
		}

		body := buf.Bytes()
		head := body
		if len(head) > 4096 {
			head = head[:4096]
		}
		if !strings.Contains(string(head), "Full thread dump") {
			return tool, fmt.Errorf("dump %d did not contain 'Full thread dump'; output starts with: %s",
				i, explainAttachError(string(head)))
		}

		header := fmt.Sprintf("===== Thread dump %d/%d | %s | %s/%s/%s | pid %d | %s =====\n",
			i, o.Count, time.Now().UTC().Format(time.RFC3339), t.Namespace, t.Pod, t.Container, pid, tool)
		if _, err := io.WriteString(out, header); err != nil {
			return tool, err
		}
		n, err := out.Write(body)
		if err != nil {
			return tool, err
		}
		if _, err := io.WriteString(out, "\n"); err != nil {
			return tool, err
		}
		written += int64(len(header)) + int64(n) + 1
		h.progress(written, 0)

		if i < o.Count {
			select {
			case <-time.After(time.Duration(o.IntervalSec) * time.Second):
			case <-ctx.Done():
				return tool, ctx.Err()
			}
		}
	}
	return tool, nil
}
