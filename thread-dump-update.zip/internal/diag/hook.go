package diag

import (
	"context"
	"io"
)

// SetExecHookForTest replaces the real WebSocket exec with a fake. For tests only; pass nil to restore.
func SetExecHookForTest(f func(ctx context.Context, t Target, argv []string, stdout io.Writer) (ExecResult, error)) {
	execHook = f
}
