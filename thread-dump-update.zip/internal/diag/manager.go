package diag

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"
)

// Sentinel errors returned by Manager methods.
var (
	ErrQueueFull   = errors.New("too many diagnostics are queued; try again later")
	ErrPodBusy     = errors.New("a diagnostic is already running for this pod")
	ErrNotFound    = errors.New("job not found")
	ErrNotReady    = errors.New("job has no downloadable file")
	ErrBadTicket   = errors.New("download link is invalid or expired")
	ErrNotCancelOK = errors.New("job already finished")
)

// Kubernetes object names (DNS-1123 subdomain); also safe as path components.
var nameRe = regexp.MustCompile(`^[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?$`)

// ValidateTarget checks the names that end up in API URLs and directory paths.
// deployment may be empty.
func ValidateTarget(namespace, deployment, pod, container string) error {
	for label, v := range map[string]string{"namespace": namespace, "pod": pod, "container": container} {
		if !nameRe.MatchString(v) {
			return fmt.Errorf("invalid or missing %s name", label)
		}
	}
	if deployment != "" && !nameRe.MatchString(deployment) {
		return errors.New("invalid deployment name")
	}
	return nil
}

// Caller carries per-request identity. APIURL/Token are the EXEC credential chosen by the HTTP
// layer (ServiceAccount + in-cluster URL, or the user's token + the user's cluster URL).
// The credential is held only for the lifetime of the job goroutine.
type Caller struct {
	APIURL   string
	Token    string
	ExecAs   string // ExecAsUser or ExecAsServiceAccount
	Cluster  string // cluster display name (X-Cluster)
	Username string // who asked for the dump
}

// PodRef selects one container in one pod.
type PodRef struct {
	Name      string
	Container string
}

// StartRequest describes one job (one pod).
type StartRequest struct {
	Type       string
	Namespace  string
	Deployment string
	Pod        PodRef
	Options    Options
}

type ticket struct {
	jobID   string
	expires time.Time
}

// Manager owns all jobs, concurrency limits and download tickets.
type Manager struct {
	cfg Config

	mu      sync.RWMutex
	jobs    map[string]*Job
	podBusy map[string]string // "cluster/ns/pod" -> job id
	tickets map[string]ticket

	threadSem chan struct{}
}

// NewManager creates a Manager and ensures the base directory exists.
func NewManager(cfg Config) *Manager {
	if cfg.ThreadConcurrency < 1 {
		cfg.ThreadConcurrency = 1
	}
	if cfg.MaxQueued < 1 {
		cfg.MaxQueued = 1
	}
	if cfg.ExecIdentity != "user" {
		cfg.ExecIdentity = "auto"
	}
	if err := os.MkdirAll(cfg.BaseDir, 0o750); err != nil {
		log.Printf("WARNING: diag: creating %s: %v (thread dumps will fail until the volume is mounted)", cfg.BaseDir, err)
	}
	return &Manager{
		cfg:       cfg,
		jobs:      make(map[string]*Job),
		podBusy:   make(map[string]string),
		tickets:   make(map[string]ticket),
		threadSem: make(chan struct{}, cfg.ThreadConcurrency),
	}
}

// BaseDir returns the root directory for stored diagnostics.
func (m *Manager) BaseDir() string { return m.cfg.BaseDir }

// ExecIdentity returns "auto" (same rule as TCP capture) or "user" (always the user's token).
func (m *Manager) ExecIdentity() string { return m.cfg.ExecIdentity }

// Normalize validates options, applies defaults and enforces the safeguards that do not
// need the cluster (PROD typed confirmation, limits).
func (m *Manager) Normalize(typ string, o Options, cluster string) (Options, error) {
	if typ != TypeThread {
		return o, fmt.Errorf("unsupported diagnostic type %q", typ)
	}
	if m.cfg.ProdClusters[strings.ToLower(cluster)] && o.ConfirmCluster != cluster {
		return o, fmt.Errorf("%q is a production cluster: type the exact cluster name to confirm", cluster)
	}
	if o.Count == 0 {
		o.Count = 3
	}
	if o.Count < 1 || o.Count > 10 {
		return o, errors.New("count must be between 1 and 10")
	}
	if o.IntervalSec == 0 {
		o.IntervalSec = 5
	}
	if o.IntervalSec < 1 || o.IntervalSec > 60 {
		return o, errors.New("interval must be between 1 and 60 seconds")
	}
	if o.MaxSizeMB == 0 {
		o.MaxSizeMB = 50
	}
	if o.MaxSizeMB < 1 || o.MaxSizeMB > 200 {
		return o, errors.New("size limit must be between 1 and 200 MB")
	}
	if o.TimeoutSec == 0 {
		o.TimeoutSec = o.Count*o.IntervalSec + 120
	}
	if o.TimeoutSec < 10 || o.TimeoutSec > 1800 {
		return o, errors.New("timeout must be between 10 and 1800 seconds")
	}
	return o, nil
}

// Start registers a job and launches its runner goroutine. It returns immediately.
func (m *Manager) Start(c Caller, r StartRequest) (string, error) {
	if err := ValidateTarget(r.Namespace, r.Deployment, r.Pod.Name, r.Pod.Container); err != nil {
		return "", err
	}
	if c.ExecAs != ExecAsServiceAccount {
		c.ExecAs = ExecAsUser
	}
	opts, err := m.Normalize(r.Type, r.Options, c.Cluster)
	if err != nil {
		return "", err
	}

	id := randomHex(16)
	ctx, cancel := context.WithCancel(context.Background())
	busyKey := c.Cluster + "/" + r.Namespace + "/" + r.Pod.Name

	m.mu.Lock()
	if _, busy := m.podBusy[busyKey]; busy {
		m.mu.Unlock()
		cancel()
		return "", ErrPodBusy
	}
	queued := 0
	for _, j := range m.jobs {
		if j.Status == StatusQueued {
			queued++
		}
	}
	if queued >= m.cfg.MaxQueued {
		m.mu.Unlock()
		cancel()
		return "", ErrQueueFull
	}
	m.jobs[id] = &Job{
		ID: id, Type: r.Type, Cluster: c.Cluster, Owner: c.Username, ExecAs: c.ExecAs,
		Namespace: r.Namespace, Deployment: r.Deployment, Pod: r.Pod.Name, Container: r.Pod.Container,
		Options: opts, Status: StatusQueued, Stage: "Queued", CreatedAt: time.Now(), cancel: cancel,
	}
	m.podBusy[busyKey] = id
	m.mu.Unlock()

	log.Printf("diag: job=%s type=%s user=%s exec_as=%s cluster=%s target=%s/%s/%s queued",
		id, r.Type, c.Username, c.ExecAs, c.Cluster, r.Namespace, r.Pod.Name, r.Pod.Container)

	go m.run(ctx, id, c)
	return id, nil
}

// Get returns a copy of the job.
func (m *Manager) Get(id string) (Job, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	j, ok := m.jobs[id]
	if !ok {
		return Job{}, false
	}
	return *j, true
}

// Cancel requests cancellation of a queued or running job.
func (m *Manager) Cancel(id string) error {
	m.mu.RLock()
	j, ok := m.jobs[id]
	var cancel func()
	terminal := false
	if ok {
		cancel = j.cancel
		terminal = IsTerminal(j.Status)
	}
	m.mu.RUnlock()
	if !ok {
		return ErrNotFound
	}
	if terminal {
		return ErrNotCancelOK
	}
	cancel()
	return nil
}

func (m *Manager) mutate(id string, fn func(*Job)) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if j, ok := m.jobs[id]; ok {
		fn(j)
	}
}

func (m *Manager) finish(id, status, msg string) {
	m.mutate(id, func(j *Job) {
		if IsTerminal(j.Status) {
			return
		}
		j.Status, j.Error, j.Stage = status, msg, ""
		j.FinishedAt = time.Now()
		delete(m.podBusy, j.Cluster+"/"+j.Namespace+"/"+j.Pod)
		log.Printf("diag: job=%s status=%s exec_as=%s size=%d err=%q", j.ID, status, j.ExecAs, j.SizeBytes, msg)
	})
}

func (m *Manager) hooksFor(id string) hooks {
	return hooks{
		stage: func(s string) { m.mutate(id, func(j *Job) { j.Stage = s }) },
		progress: func(done, total int64) {
			m.mutate(id, func(j *Job) {
				j.BytesDone = done
				if total > 0 {
					j.BytesTotal = total
				}
			})
		},
		warn: func(s string) { m.mutate(id, func(j *Job) { j.Warning = s }) },
	}
}

// run waits for a concurrency slot, applies the timeout, and records the final status.
func (m *Manager) run(pctx context.Context, id string, c Caller) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("ERROR: diag: job %s panicked: %v", id, r)
			m.finish(id, StatusError, fmt.Sprintf("internal error: %v", r))
		}
	}()

	s, ok := m.Get(id)
	if !ok {
		return
	}
	select {
	case m.threadSem <- struct{}{}:
		defer func() { <-m.threadSem }()
	case <-pctx.Done():
		m.finish(id, StatusCancelled, "cancelled while queued")
		return
	}
	if pctx.Err() != nil {
		m.finish(id, StatusCancelled, "cancelled while queued")
		return
	}

	tctx, cancel := context.WithTimeout(pctx, time.Duration(s.Options.TimeoutSec)*time.Second)
	defer cancel()
	m.mutate(id, func(j *Job) { j.Status, j.StartedAt = StatusInProgress, time.Now() })

	err := m.execute(tctx, s, c)
	switch {
	case err == nil:
		m.finish(id, StatusComplete, "")
	case pctx.Err() != nil:
		m.finish(id, StatusCancelled, "cancelled by user")
	case errors.Is(tctx.Err(), context.DeadlineExceeded):
		m.finish(id, StatusTimedOut, fmt.Sprintf("timed out after %d seconds", s.Options.TimeoutSec))
	default:
		m.finish(id, StatusError, err.Error())
	}
}

// execute detects the JVM, runs the thread dump and stores the result on the PVC.
// The pod/container checks with the USER's token already happened in the HTTP layer.
func (m *Manager) execute(ctx context.Context, s Job, c Caller) error {
	h := m.hooksFor(s.ID)
	t := Target{
		APIURL: c.APIURL, Token: c.Token, Namespace: s.Namespace, Pod: s.Pod, Container: s.Container,
		AsServiceAccount: c.ExecAs == ExecAsServiceAccount,
	}

	h.stage("Detecting Java process")
	out, res, err := t.RunText(ctx, []string{"sh", "-c", discoverScript}, 64<<10)
	if err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return errors.New(t.explainExecError(err))
	}
	if res.ExitCode != 0 && strings.TrimSpace(out) == "" {
		return fmt.Errorf("JVM discovery failed (exit %d): %s", res.ExitCode, res.Stderr)
	}
	jvm := ParseDiscovery(out)
	pid, err := jvm.SinglePID()
	if err != nil {
		return err
	}
	if !jvm.TmpWritable {
		return errors.New("/tmp is not writable in the container; jcmd/jstack need it to attach to the JVM")
	}

	dep := s.Deployment
	if dep == "" {
		dep = "unknown"
	}
	dir := filepath.Join(m.cfg.BaseDir, s.Type, s.Namespace, dep, s.Pod, s.ID)
	if err := checkDisk(m.cfg.BaseDir, uint64(s.Options.MaxSizeMB)<<20*2); err != nil {
		return err
	}
	if err := os.MkdirAll(dir, 0o750); err != nil {
		return fmt.Errorf("creating output directory: %w", err)
	}
	m.mutate(s.ID, func(j *Job) { j.Dir = dir })

	name := fmt.Sprintf("thread-dump-%s-%s.txt", s.Pod, time.Now().UTC().Format("20060102-150405"))
	final := filepath.Join(dir, name)
	part := final + ".part"

	f, err := os.OpenFile(part, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0o640)
	if err != nil {
		os.RemoveAll(dir)
		return fmt.Errorf("creating output file: %w", err)
	}
	success := false
	defer func() {
		f.Close()
		if !success {
			os.RemoveAll(dir)
			pruneEmptyParents(dir, m.cfg.BaseDir)
		}
	}()

	tool, err := runThreadDump(ctx, t, jvm, pid, s.Options, f, h)
	if err != nil {
		return err
	}

	h.stage("Finalising")
	if err := f.Sync(); err != nil {
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	if err := os.Rename(part, final); err != nil {
		return fmt.Errorf("finalising output file: %w", err)
	}
	st, err := os.Stat(final)
	if err != nil {
		return err
	}
	md := Metadata{
		JobID: s.ID, Type: s.Type, Cluster: s.Cluster, Owner: s.Owner, ExecAs: s.ExecAs,
		Namespace: s.Namespace, Deployment: s.Deployment, Pod: s.Pod, Container: s.Container,
		JVMPid: pid, Tool: tool, File: name, SizeBytes: st.Size(), CompletedAt: time.Now(), Options: s.Options,
	}
	if err := writeMetadata(dir, md); err != nil {
		log.Printf("WARNING: diag: writing metadata for job %s: %v", s.ID, err)
	}
	m.mutate(s.ID, func(j *Job) { j.File, j.SizeBytes = name, st.Size() })
	success = true
	return nil
}

// IssueTicket creates a single-use download ticket valid for 2 minutes. A plain browser
// download link cannot send the Bearer header, so the UI first asks (authenticated) for a
// ticket and then navigates to it.
func (m *Manager) IssueTicket(jobID string) (string, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	j, ok := m.jobs[jobID]
	if !ok {
		return "", ErrNotFound
	}
	if j.Status != StatusComplete || j.File == "" {
		return "", ErrNotReady
	}
	now := time.Now()
	for k, t := range m.tickets {
		if now.After(t.expires) {
			delete(m.tickets, k)
		}
	}
	tk := randomHex(32)
	m.tickets[tk] = ticket{jobID: jobID, expires: now.Add(2 * time.Minute)}
	return tk, nil
}

// RedeemTicket consumes a ticket and returns the job it refers to.
func (m *Manager) RedeemTicket(tk string) (Job, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	t, ok := m.tickets[tk]
	if !ok {
		return Job{}, ErrBadTicket
	}
	delete(m.tickets, tk) // single use
	if time.Now().After(t.expires) {
		return Job{}, ErrBadTicket
	}
	j, ok := m.jobs[t.jobID]
	if !ok || j.Status != StatusComplete || j.File == "" {
		return Job{}, ErrNotReady
	}
	return *j, nil
}

// StartCleanupLoop deletes expired dumps (DIAG_THREAD_TTL_HOURS, default 168), stale .part
// files left by a crash, and forgets old finished jobs. Runs hourly.
func StartCleanupLoop(ctx context.Context, m *Manager) {
	log.Printf("diag cleanup loop started (thread dump TTL %s)", m.cfg.ThreadTTL)
	m.cleanup()
	tick := time.NewTicker(time.Hour)
	defer tick.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-tick.C:
			m.cleanup()
		}
	}
}

func (m *Manager) dirActive(dir string) bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	for _, j := range m.jobs {
		if j.Dir == dir && !IsTerminal(j.Status) {
			return true
		}
	}
	return false
}

func (m *Manager) cleanup() {
	now := time.Now()
	base := m.cfg.BaseDir

	var expired []string
	_ = filepath.Walk(base, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		dir := filepath.Dir(path)
		switch {
		case strings.HasSuffix(info.Name(), ".part"):
			if now.Sub(info.ModTime()) > 6*time.Hour && !m.dirActive(dir) {
				expired = append(expired, dir)
			}
		case info.Name() == metadataName:
			md, rerr := readMetadata(path)
			if rerr != nil {
				log.Printf("WARNING: diag cleanup: %s: %v", path, rerr)
				return nil
			}
			if now.Sub(md.CompletedAt) > m.cfg.ThreadTTL {
				expired = append(expired, dir)
			}
		}
		return nil
	})
	for _, dir := range expired {
		if err := os.RemoveAll(dir); err != nil {
			log.Printf("WARNING: diag cleanup: removing %s: %v", dir, err)
			continue
		}
		pruneEmptyParents(dir, base)
		log.Printf("diag cleanup: removed %s", dir)
	}

	m.mu.Lock()
	for id, j := range m.jobs {
		if IsTerminal(j.Status) && now.Sub(j.FinishedAt) > 24*time.Hour {
			delete(m.jobs, id)
		}
	}
	for k, t := range m.tickets {
		if now.After(t.expires) {
			delete(m.tickets, k)
		}
	}
	m.mu.Unlock()
}

func randomHex(n int) string {
	b := make([]byte, (n+1)/2)
	if _, err := rand.Read(b); err != nil {
		panic("crypto/rand failed: " + err.Error())
	}
	return hex.EncodeToString(b)[:n]
}
