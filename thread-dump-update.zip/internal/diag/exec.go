package diag

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/gorilla/websocket"
)

// Target identifies one container to exec into. Token is the exec credential chosen by the
// HTTP layer: the backend ServiceAccount token in-cluster, the user's token locally.
type Target struct {
	APIURL           string
	Token            string
	Namespace        string
	Pod              string
	Container        string
	AsServiceAccount bool // only used to word error messages
}

// ExecResult is the outcome of a command that ran to completion inside the container.
type ExecResult struct {
	ExitCode int
	Stderr   string
}

const maxStderrBytes = 8 << 10

// execHook, when set (tests only), replaces the real WebSocket exec.
var execHook func(ctx context.Context, t Target, argv []string, stdout io.Writer) (ExecResult, error)

// execStatus is the JSON document the API server sends on channel 3 when the command ends.
type execStatus struct {
	Status  string `json:"status"`
	Reason  string `json:"reason"`
	Message string `json:"message"`
	Details struct {
		Causes []struct {
			Reason  string `json:"reason"`
			Message string `json:"message"`
		} `json:"causes"`
	} `json:"details"`
}

// Exec runs argv inside the container and streams stdout to the given writer (may be nil).
//
// argv is always passed as a discrete argument list (no shell interpolation of user input).
// It uses the same WebSocket exec protocol (v4.channel.k8s.io) as capture.ExecInPod, but:
//   - the container name is a parameter (capture.ExecInPod hard-codes "capture"),
//   - the exit code is read from the status channel (channel 3),
//   - it honours ctx cancellation, and
//   - it sends a WebSocket ping every 30s so silent long-running commands are not
//     dropped by idle-timeout load balancers.
//
// A non-nil error means the command could not be run or the stream broke. A command that
// ran and exited non-zero is reported via ExecResult.ExitCode with a nil error.
func (t Target) Exec(ctx context.Context, argv []string, stdout io.Writer) (ExecResult, error) {
	var res ExecResult
	if len(argv) == 0 {
		return res, errors.New("empty command")
	}
	if execHook != nil {
		return execHook(ctx, t, argv, stdout)
	}

	wsURL := strings.Replace(t.APIURL, "https://", "wss://", 1)
	wsURL = strings.Replace(wsURL, "http://", "ws://", 1)

	params := url.Values{}
	for _, a := range argv {
		params.Add("command", a)
	}
	params.Set("container", t.Container)
	params.Set("stdout", "true")
	params.Set("stderr", "true")
	params.Set("stdin", "false")
	params.Set("tty", "false")

	wsURL = strings.TrimRight(wsURL, "/") +
		"/api/v1/namespaces/" + url.PathEscape(t.Namespace) +
		"/pods/" + url.PathEscape(t.Pod) +
		"/exec?" + params.Encode()

	dialer := websocket.Dialer{
		TLSClientConfig:  &tls.Config{InsecureSkipVerify: true}, //nolint:gosec // matches existing client (self-signed OpenShift API certs)
		Subprotocols:     []string{"v4.channel.k8s.io"},
		HandshakeTimeout: 20 * time.Second,
	}
	header := http.Header{}
	header.Set("Authorization", "Bearer "+t.Token)

	conn, resp, err := dialer.DialContext(ctx, wsURL, header)
	if err != nil {
		if resp != nil {
			defer resp.Body.Close()
			body, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
			return res, fmt.Errorf("exec refused by API server (HTTP %d): %s", resp.StatusCode, strings.TrimSpace(string(body)))
		}
		return res, fmt.Errorf("exec dial: %w", err)
	}
	defer conn.Close()

	// Keep-alive + cancellation watcher.
	done := make(chan struct{})
	defer close(done)
	go func() {
		tick := time.NewTicker(30 * time.Second)
		defer tick.Stop()
		for {
			select {
			case <-done:
				return
			case <-ctx.Done():
				_ = conn.WriteControl(websocket.CloseMessage,
					websocket.FormatCloseMessage(websocket.CloseNormalClosure, "cancelled"),
					time.Now().Add(time.Second))
				_ = conn.Close() // unblocks ReadMessage below
				return
			case <-tick.C:
				_ = conn.WriteControl(websocket.PingMessage, nil, time.Now().Add(5*time.Second))
			}
		}
	}()

	var stderr bytes.Buffer
	gotStatus := false
	var apiFailure string

	for {
		_, msg, rerr := conn.ReadMessage()
		if rerr != nil {
			if ctx.Err() != nil {
				return res, ctx.Err()
			}
			if gotStatus {
				break // normal: server closes after the status message
			}
			return res, fmt.Errorf("exec stream ended without an exit status: %w", rerr)
		}
		if len(msg) < 2 {
			continue
		}
		payload := msg[1:]
		switch msg[0] {
		case 1: // stdout
			if stdout != nil {
				if _, werr := stdout.Write(payload); werr != nil {
					return res, fmt.Errorf("writing command output: %w", werr)
				}
			}
		case 2: // stderr
			if stderr.Len() < maxStderrBytes {
				stderr.Write(payload)
			}
		case 3: // status
			gotStatus = true
			var st execStatus
			if json.Unmarshal(payload, &st) != nil {
				apiFailure = strings.TrimSpace(string(payload))
				continue
			}
			if st.Status == "Success" {
				res.ExitCode = 0
				continue
			}
			res.ExitCode = 1
			isExit := false
			for _, c := range st.Details.Causes {
				if c.Reason == "ExitCode" {
					if n, convErr := strconv.Atoi(c.Message); convErr == nil {
						res.ExitCode = n
						isExit = true
					}
				}
			}
			if !isExit {
				// e.g. "executable file not found in $PATH", "container not found"
				apiFailure = st.Message
			}
		}
	}

	res.Stderr = strings.TrimSpace(stderr.String())
	if apiFailure != "" {
		return res, errors.New(apiFailure)
	}
	return res, nil
}

// RunText runs argv and returns stdout as a string (capped at maxBytes).
func (t Target) RunText(ctx context.Context, argv []string, maxBytes int) (string, ExecResult, error) {
	buf := &limitedBuffer{max: maxBytes}
	res, err := t.Exec(ctx, argv, buf)
	return buf.String(), res, err
}

// limitedBuffer stores at most max bytes and always reports a full write so the exec
// stream keeps draining. Check over to see whether output was dropped.
type limitedBuffer struct {
	max  int
	buf  bytes.Buffer
	over bool
}

func (b *limitedBuffer) Write(p []byte) (int, error) {
	if b.over {
		return len(p), nil
	}
	if b.buf.Len()+len(p) > b.max {
		b.over = true
		return len(p), nil
	}
	b.buf.Write(p)
	return len(p), nil
}

func (b *limitedBuffer) String() string { return b.buf.String() }
func (b *limitedBuffer) Bytes() []byte  { return b.buf.Bytes() }

// explainExecError turns low-level exec errors into actionable messages. The wording depends on
// which identity was used, because the fix differs (RBAC for the ServiceAccount vs. the user's role).
func (t Target) explainExecError(err error) string {
	s := err.Error()
	l := strings.ToLower(s)
	switch {
	case strings.Contains(l, "executable file not found"),
		strings.Contains(l, "no such file or directory") && strings.Contains(l, "\"sh\""):
		return "The container has no shell (sh), so the JVM cannot be inspected. Distroless/scratch images are not supported."
	case strings.Contains(l, "http 403"), strings.Contains(l, "forbidden"):
		if t.AsServiceAccount {
			return "Forbidden: the backend ServiceAccount is not allowed to exec into pods in namespace " + t.Namespace +
				". Grant it get/create on pods/exec there (see the setup guide), or set DIAG_EXEC_IDENTITY=user. (" + s + ")"
		}
		return "Forbidden: your account needs 'create' permission on pods/exec in this namespace. (" + s + ")"
	case strings.Contains(l, "http 401"), strings.Contains(l, "unauthorized"):
		if t.AsServiceAccount {
			return "The API server rejected the backend ServiceAccount token. (" + s + ")"
		}
		return "Your token expired while the job was running. Start the job again with a fresh token."
	case strings.Contains(l, "not running"), strings.Contains(l, "stopped container"):
		return "The container is not running (it may have restarted). (" + s + ")"
	case strings.Contains(l, "container not found"), strings.Contains(l, "not valid for pod"), strings.Contains(l, "http 404"):
		return "Pod or container not found (it may have restarted or been replaced). (" + s + ")"
	}
	return s
}
