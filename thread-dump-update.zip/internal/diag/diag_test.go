package diag

import (
	"errors"
	"strings"
	"testing"
)

func TestParseDiscovery(t *testing.T) {
	out := `TOOL jcmd /opt/java/openjdk/bin/jcmd
TOOL jstack /opt/java/bin/js tack
TOOL jcmd ../evil
TOOL jmap /usr/bin/jmap
PID 1
PID abc
PID -5
TMPW 1
UID 1000680000
`
	info := ParseDiscovery(out)
	if info.Tools["jcmd"] != "/opt/java/openjdk/bin/jcmd" {
		t.Errorf("jcmd path wrong: %q", info.Tools["jcmd"])
	}
	if _, bad := info.Tools["jstack"]; bad {
		t.Error("path containing a space must be rejected")
	}
	if _, bad := info.Tools["jmap"]; bad {
		t.Error("unsupported tools must be ignored")
	}
	if len(info.PIDs) != 1 || info.PIDs[0] != 1 {
		t.Errorf("PIDs = %v, want [1]", info.PIDs)
	}
	if !info.TmpWritable || info.UID != 1000680000 {
		t.Errorf("unexpected tmp/uid: %+v", info)
	}
	if pid, err := info.SinglePID(); err != nil || pid != 1 {
		t.Errorf("SinglePID = %d, %v", pid, err)
	}
	multi := ParseDiscovery("PID 7\nPID 1\n")
	if _, err := multi.SinglePID(); err == nil || !strings.Contains(err.Error(), "2 Java processes") {
		t.Errorf("expected refusal for multiple JVMs, got %v", err)
	}
	if _, err := ParseDiscovery("TMPW 1\n").SinglePID(); err == nil {
		t.Error("expected error when no JVM present")
	}
}

func TestLimitedBuffer(t *testing.T) {
	b := &limitedBuffer{max: 5}
	if n, _ := b.Write([]byte("abc")); n != 3 {
		t.Fatal("short write")
	}
	if n, _ := b.Write([]byte("defg")); n != 4 { // reports a full write but drops data
		t.Fatal("must report full write so the exec stream keeps draining")
	}
	if !b.over || b.String() != "abc" {
		t.Errorf("over=%v content=%q", b.over, b.String())
	}
}

func TestNormalize(t *testing.T) {
	cfg := ConfigFromEnv()
	cfg.BaseDir = t.TempDir()
	cfg.ProdClusters = map[string]bool{"prod-east": true}
	m := NewManager(cfg)

	if _, err := m.Normalize(TypeThread, Options{}, "prod-east"); err == nil {
		t.Error("PROD cluster without typed confirmation must be refused")
	}
	if _, err := m.Normalize(TypeThread, Options{ConfirmCluster: "prod-east"}, "prod-east"); err != nil {
		t.Errorf("PROD cluster with exact confirmation must pass: %v", err)
	}
	if _, err := m.Normalize(TypeThread, Options{ConfirmCluster: "PROD-EAST"}, "prod-east"); err == nil {
		t.Error("confirmation must match the cluster name exactly (case-sensitive)")
	}
	o, err := m.Normalize(TypeThread, Options{}, "dev")
	if err != nil || o.Count != 3 || o.IntervalSec != 5 || o.MaxSizeMB != 50 || o.TimeoutSec != 3*5+120 {
		t.Errorf("thread defaults wrong: %+v %v", o, err)
	}
	if _, err := m.Normalize(TypeThread, Options{Count: 11}, "dev"); err == nil {
		t.Error("count > 10 must be refused")
	}
	if _, err := m.Normalize(TypeThread, Options{IntervalSec: 61}, "dev"); err == nil {
		t.Error("interval > 60 must be refused")
	}
	if _, err := m.Normalize("heap", Options{}, "dev"); err == nil {
		t.Error("unsupported type must be refused")
	}
}

func TestConfigExecIdentity(t *testing.T) {
	t.Setenv("DIAG_EXEC_IDENTITY", "")
	if got := ConfigFromEnv().ExecIdentity; got != "auto" {
		t.Errorf("default = %q, want auto", got)
	}
	t.Setenv("DIAG_EXEC_IDENTITY", " User ")
	if got := ConfigFromEnv().ExecIdentity; got != "user" {
		t.Errorf("user override = %q", got)
	}
	t.Setenv("DIAG_EXEC_IDENTITY", "serviceaccount") // unknown values must not silently change behaviour
	if got := ConfigFromEnv().ExecIdentity; got != "auto" {
		t.Errorf("unknown value = %q, want auto", got)
	}
}

func TestValidateTarget(t *testing.T) {
	if err := ValidateTarget("ns1", "dep-1", "pod-a", "app"); err != nil {
		t.Errorf("valid target rejected: %v", err)
	}
	if err := ValidateTarget("ns1", "", "pod-a", "app"); err != nil {
		t.Errorf("empty deployment must be allowed: %v", err)
	}
	for _, bad := range [][4]string{
		{"../x", "", "p", "c"}, {"ns", "", "p/q", "c"}, {"ns", "", "P", "c"}, {"ns", "", "p", ""},
		{"ns", "", "p", "c;rm"}, {"ns", "a/b", "p", "c"}, {"", "", "p", "c"},
	} {
		if ValidateTarget(bad[0], bad[1], bad[2], bad[3]) == nil {
			t.Errorf("%v should be rejected", bad)
		}
	}
}

func TestExplainExecErrorMentionsTheRightIdentity(t *testing.T) {
	forbidden := errors.New("exec refused by API server (HTTP 403): pods \"p\" is forbidden")
	user := Target{Namespace: "ns1"}.explainExecError(forbidden)
	sa := Target{Namespace: "ns1", AsServiceAccount: true}.explainExecError(forbidden)
	if !strings.Contains(user, "your account") || strings.Contains(user, "ServiceAccount") {
		t.Errorf("user wording wrong: %q", user)
	}
	for _, want := range []string{"backend ServiceAccount", "ns1", "pods/exec", "DIAG_EXEC_IDENTITY=user"} {
		if !strings.Contains(sa, want) {
			t.Errorf("SA wording misses %q: %q", want, sa)
		}
	}
	if m := (Target{}).explainExecError(errors.New("HTTP 401 unauthorized")); !strings.Contains(m, "token expired") {
		t.Errorf("user 401: %q", m)
	}
	if m := (Target{AsServiceAccount: true}).explainExecError(errors.New("HTTP 401 unauthorized")); !strings.Contains(m, "ServiceAccount token") {
		t.Errorf("SA 401: %q", m)
	}
	if m := (Target{}).explainExecError(errors.New("cannot exec in a stopped container")); !strings.Contains(m, "not running") {
		t.Errorf("stopped container: %q", m)
	}
	if m := (Target{}).explainExecError(errors.New("OCI runtime exec failed: exec: \"sh\": executable file not found in $PATH")); !strings.Contains(m, "no shell") {
		t.Errorf("no shell: %q", m)
	}
}
