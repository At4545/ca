#!/usr/bin/env python3
import argparse, json
from collections import defaultdict
from datetime import datetime, timezone
from html import escape
from pathlib import Path

def main():
    p=argparse.ArgumentParser(); p.add_argument('--results',type=Path,required=True); p.add_argument('--output',type=Path,required=True); p.add_argument('--execution-id',required=True); a=p.parse_args()
    rows=[]
    for f in sorted(a.results.glob('*.json')):
        rows.extend(json.loads(f.read_text(encoding='utf-8')))
    counts=defaultdict(int)
    for r in rows: counts[r.get('status','UNKNOWN')]+=1
    groups=defaultdict(list)
    for r in rows: groups[r.get('cluster','UNKNOWN')].append(r)
    details=[]
    for cluster, items in sorted(groups.items()):
        trs=''.join(f"<tr><td>{escape(str(x.get('environment','')))}</td><td>{escape(str(x.get('node','')))}</td><td>{escape(str(x.get('old_pod','')))}</td><td>{escape(str(x.get('new_pod','')))}</td><td>{escape(str(x.get('precheck','')))}</td><td>{escape(str(x.get('restart','')))}</td><td>{escape(str(x.get('postcheck','')))}</td><td class='{str(x.get('status','')).lower()}'>{escape(str(x.get('status','')))}</td><td>{escape(str(x.get('message','')))}</td></tr>" for x in items)
        details.append(f"<details><summary>{escape(cluster)}: {len(items)} node(s)</summary><div class='scroll'><table><thead><tr><th>Environment</th><th>Node</th><th>Old Pod</th><th>New Pod</th><th>Precheck</th><th>Restart</th><th>Postcheck</th><th>Status</th><th>Details</th></tr></thead><tbody>{trs}</tbody></table></div></details>")
    html=f'''<!doctype html><html><head><meta charset="utf-8"><title>Cortex Agent Restart Report</title><style>body{{font-family:Segoe UI,Arial;background:#f4f5f7;color:#242424;margin:0;padding:24px}}.wrap{{max-width:1300px;margin:auto;background:white;padding:24px;border-radius:10px}}h1{{color:#a80000}}.cards{{display:flex;gap:12px;flex-wrap:wrap}}.card{{padding:14px 20px;border-radius:8px;background:#eee;min-width:130px}}.success{{color:#107c10;font-weight:700}}.failed{{color:#d13438;font-weight:700}}.skipped{{color:#8a6d00;font-weight:700}}details{{border:1px solid #ddd;border-radius:6px;margin-top:12px}}summary{{cursor:pointer;padding:12px;background:#f6f6f6;font-weight:700}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:12px}}th,td{{border:1px solid #ddd;padding:8px;text-align:left}}th{{background:#a80000;color:white;position:sticky;top:0}}</style></head><body><div class="wrap"><h1>Cortex Agent Restart Report</h1><p><b>Execution ID:</b> {escape(a.execution_id)}<br><b>Generated:</b> {datetime.now(timezone.utc).isoformat()}</p><div class="cards"><div class="card"><b>Total</b><br>{len(rows)}</div><div class="card success"><b>Success</b><br>{counts['SUCCESS']}</div><div class="card failed"><b>Failed</b><br>{counts['FAILED']}</div><div class="card skipped"><b>Skipped</b><br>{counts['SKIPPED']}</div></div><h2>Cluster details</h2>{''.join(details) if details else '<p>No results found.</p>'}</div></body></html>'''
    a.output.write_text(html,encoding='utf-8')
if __name__=='__main__': main()
