#!/usr/bin/env python3
import argparse, csv, json, os, re, sys
from pathlib import Path

def truthy(value):
    return str(value).strip().lower() in {"1", "true", "yes", "y"}

def read_nodes(path):
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as f:
            return list(csv.DictReader(f))
    if suffix == ".xlsx":
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise SystemExit("openpyxl is required for .xlsx input; use CSV or install openpyxl") from exc
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb["Restart_Nodes"] if "Restart_Nodes" in wb.sheetnames else wb[wb.sheetnames[0]]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            return []
        headers = [str(v).strip() if v is not None else "" for v in rows[0]]
        return [dict(zip(headers, row)) for row in rows[1:] if any(v is not None for v in row)]
    raise SystemExit("Node input must be .csv or .xlsx")

def safe_name(name):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", name)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--clusters", required=True, type=Path)
    p.add_argument("--nodes", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    p.add_argument("--kubeconfig-dir", required=True, type=Path)
    args = p.parse_args()
    cfg = json.loads(args.clusters.read_text(encoding="utf-8"))
    rows = read_nodes(args.nodes)
    required = {"environment", "node_name", "enabled"}
    if rows and not required.issubset(rows[0]):
        raise SystemExit(f"Node file needs columns: {sorted(required)}")
    enabled_rows, seen = [], set()
    for line, row in enumerate(rows, start=2):
        env = str(row.get("environment") or "").strip()
        node = str(row.get("node_name") or "").strip()
        if not env or not node:
            raise SystemExit(f"Blank environment/node_name at row {line}")
        if not truthy(row.get("enabled", True)):
            continue
        key = (env, node)
        if key in seen:
            raise SystemExit(f"Duplicate environment/node: {env}/{node}")
        seen.add(key); enabled_rows.append((env, node))
    creds = cfg.get("credentials", {})
    clusters = [c for c in cfg.get("clusters", []) if c.get("enabled", True)]
    env_to_clusters = {}
    for c in clusters:
        env_to_clusters.setdefault(c["environment"], []).append(c)
    # Environment-only input is allowed only when that environment maps to one enabled cluster.
    inventory = {"target_clusters": {"hosts": {}}}
    args.kubeconfig_dir.mkdir(parents=True, exist_ok=True)
    for env, node in enabled_rows:
        matches = env_to_clusters.get(env, [])
        if len(matches) != 1:
            raise SystemExit(f"Environment '{env}' maps to {len(matches)} enabled clusters; add a cluster_name column to disambiguate.")
        c = matches[0]
        cred = creds.get(env, {})
        if not cred.get("npid") or not cred.get("password"):
            raise SystemExit(f"Missing npid/password for environment '{env}'")
        host = c["name"]
        h = inventory["target_clusters"]["hosts"].setdefault(host, {
            "ansible_connection": "local",
            "cluster_environment": env,
            "cluster_url": c["url"],
            "cluster_username": cred["npid"],
            "cluster_password": cred["password"],
            "skip_tls_verify": bool(c.get("skip_tls_verify", False)),
            "kubeconfig_path": str(args.kubeconfig_dir / f"{safe_name(host)}.kubeconfig"),
            "target_nodes": []
        })
        h["target_nodes"].append(node)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(inventory, indent=2), encoding="utf-8")
    os.chmod(args.output, 0o600)
    print(f"Prepared {len(inventory['target_clusters']['hosts'])} clusters and {len(enabled_rows)} nodes")
if __name__ == "__main__": main()
