#!/usr/bin/env bash
set -euo pipefail
CLUSTERS=${1:-input/cluster.json}
NODES=${2:-input/nodes.xlsx}
MAIL=${3:-input/mail.yml}
MAX_PARALLEL_CLUSTERS=${MAX_PARALLEL_CLUSTERS:-3}
EXECUTION_ID=${EXECUTION_ID:-$(date -u +%Y%m%dT%H%M%SZ)}
BASE=$(cd "$(dirname "$0")" && pwd)
cd "$BASE"
OUTPUT_DIR="$BASE/output/$EXECUTION_ID"
mkdir -p "$OUTPUT_DIR/results" "$OUTPUT_DIR/kubeconfigs"
chmod 700 "$OUTPUT_DIR" "$OUTPUT_DIR/kubeconfigs"
python3 scripts/prepare_inventory.py --clusters "$CLUSTERS" --nodes "$NODES" --output "$OUTPUT_DIR/inventory.json" --kubeconfig-dir "$OUTPUT_DIR/kubeconfigs"
export EXECUTION_ID OUTPUT_DIR
ANSIBLE_FORKS="$MAX_PARALLEL_CLUSTERS" ansible-playbook -i "$OUTPUT_DIR/inventory.json" playbooks/main.yml
ansible-playbook playbooks/report.yml -e "execution_id=$EXECUTION_ID" -e "output_dir=$OUTPUT_DIR" -e "mail_config=$MAIL"
echo "Report: $OUTPUT_DIR/cortex_restart_report.html"
