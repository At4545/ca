# Cortex Agent DaemonSet Restart Automation

OC CLI-driven Ansible automation for restarting one `cortex-agent` DaemonSet pod per requested OpenShift node in namespace `cortex-xdr`.

## Execution model

- Enabled clusters run in parallel, limited by `MAX_PARALLEL_CLUSTERS`.
- Nodes inside each cluster run sequentially.
- The current cluster queue stops after a node failure by default.
- Other clusters continue.
- Each pod is deleted gracefully; force deletion is not used.

## Inputs

1. `input/cluster.json`: credentials by environment and enabled cluster API definitions. Copy from `input/cluster.example.json` and protect with mode `0600` or Ansible Vault.
2. `input/nodes.xlsx` or CSV: columns `environment`, `node_name`, `enabled`. Copy from `input/nodes_template.xlsx`.
3. `input/mail.yml`: SMTP configuration. Copy from `input/mail.example.yml`.

Important: environment-only input must map to exactly one enabled cluster. If an environment contains several enabled clusters, extend the input with a `cluster_name` column and adjust `prepare_inventory.py` mapping accordingly.

## Prerequisites

- `ansible-core`
- `oc` CLI
- `community.general` collection
- `openpyxl` only when using `.xlsx`; not required for CSV
- Network access to OpenShift API and SMTP
- Permission to get nodes, get/list pods, get DaemonSets, and delete pods

Install collection:

```bash
ansible-galaxy collection install -r requirements.yml
```

## Run

```bash
cp input/cluster.example.json input/cluster.json
cp input/mail.example.yml input/mail.yml
cp input/nodes_template.xlsx input/nodes.xlsx
chmod 600 input/cluster.json input/mail.yml
MAX_PARALLEL_CLUSTERS=3 ./run.sh input/cluster.json input/nodes.xlsx input/mail.yml
```

## Pod selector

The default selector is `app=cortex-agent`. Confirm it using:

```bash
oc get ds cortex-agent -n cortex-xdr -o jsonpath='{.spec.selector.matchLabels}'
```

Update `pod_label_selector` in `playbooks/main.yml` if the actual label differs.

## HTML email

The message contains an HTML report with `<details>` sections. Email clients may ignore native expand/collapse behavior, so the same standalone HTML report is attached for reliable interactive viewing in a browser.

## Security

- Do not commit `cluster.json`, generated inventory, kubeconfigs, reports, or logs.
- Prefer a credential manager or Ansible Vault over plain-text passwords.
- `no_log` masks the `oc login` task, but the generated inventory still contains credentials and is created with mode `0600`.
- Set `skip_tls_verify` to `false` and use trusted cluster CA certificates whenever possible.
