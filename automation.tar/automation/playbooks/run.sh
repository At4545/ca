#!/bin/bash

# === Configuration ===
CLUSTER_NAME="arod01"
BASE_PATH="/home/ubuntu/Amit/automation/playbooks"
TARGET_PLAYBOOK="role2_pre_upgrade_validation.yml"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
INVENTORY_FILE="${BASE_PATH}/Logs/${CLUSTER_NAME}_${TIMESTAMP}_inventory.ini"
LOG_FILE="${BASE_PATH}/Logs/${CLUSTER_NAME}_${TIMESTAMP}.txt"

# Create Logs directory if not exists
mkdir -p "${BASE_PATH}/Logs"

# === Run Playbook with LIVE output + Log file ===
echo "=========================================="
echo " Cluster    : ${CLUSTER_NAME}"
echo " Playbook   : ${TARGET_PLAYBOOK}"
echo " Inventory  : ${INVENTORY_FILE}"
echo " Log File   : ${LOG_FILE}"
echo "=========================================="

ansible-playbook "${BASE_PATH}/${TARGET_PLAYBOOK}" -i "${INVENTORY_FILE}" 2>&1 | tee "${LOG_FILE}" 

#ansible-playbook "/home/ubuntu/Amit/automation/playbooks/test.yml" -i "${INVENTORY_FILE}" 2>&1 | tee "${LOG_FILE}"


echo ""
echo "? Log File created at => ${LOG_FILE}"


###Sending the mail
 
ansible-playbook SendEmail.yml

if [[ $? == 0 ]];then
 echo "Mail sent"
else
 echo "Mail not sent"
fi