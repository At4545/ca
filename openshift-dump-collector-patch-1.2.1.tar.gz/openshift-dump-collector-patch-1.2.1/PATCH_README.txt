OpenShift Dump Collector - patch 1.2.1  (node-level TCP capture on ARO / real clusters)
=========================================================================================
Symptom fixed:  "The output is not a valid pcap capture (missing pcap magic number); it was discarded."

Cause: `oc debug` delivered tcpdump's own message ("tcpdump: listening on any, link-type ...") on stdout, i.e. in FRONT of the
capture, so the file did not start with a pcap header. (Your screenshot shows the capture itself ran: the debug pod started, the
pod's network namespace was found, tcpdump ran for the whole time.)

Fix, in three layers:
  1. The capture script now sends tcpdump's messages to a private file inside the throw-away debug pod. They are shown only if
     tcpdump FAILED (exit code other than 0/124), so a good capture stream contains nothing but the pcap.
  2. Any text that still arrives in front of the pcap header (up to 8 KB) is removed, and text after the capture is trimmed. A capture
     with zero packets is accepted even if text follows its header.
  3. If the result is still not a pcap, the error now tells you how the output began (first bytes in hex + printable text), and a tcpdump
     failure shows its reason, so the next problem can be diagnosed from the screen alone.

Apply (stop the portal first):
    tar xzf openshift-dump-collector-patch-1.2.1.tar.gz && cd openshift-dump-collector-patch-1.2.1
    python3 apply_patch.py /path/to/installed/openshift-dump-collector --dry-run
    python3 apply_patch.py /path/to/installed/openshift-dump-collector
    cd /path/to/installed/openshift-dump-collector
    python3 -m unittest discover -s tests -p "test_node_capture_noise.py" -v          # about a minute
    python3 -m unittest discover -s tests -p "test_node_capture.py"                   # about two minutes: the older tests still pass
    ./run.sh

Then repeat the capture on the same pod. If it still fails, the message now contains "The output began with bytes ..." - send me that text.

Files replaced: diagnostics/node_capture.py  diagnostics/pcap.py  tests/bin/oc_nodes  VERSION
Files added:    tests/test_node_capture_noise.py
One edit:       backend/collection_service.py (wording of one note; exact-match, skipped if not found)
Rollback:       copy the files from <install>.backup-patch-<date> back.
