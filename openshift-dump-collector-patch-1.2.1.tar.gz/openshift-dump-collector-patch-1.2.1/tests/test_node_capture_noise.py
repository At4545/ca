"""Tests for the v1.2.1 fix: text mixed into the node-level capture ("missing pcap magic number" on a real ARO cluster).

Run:  python3 -m unittest discover -s tests -p "test_node_capture_noise.py" -v      (stdlib only; about 1 minute)

What happened on the real cluster: `oc debug` delivered tcpdump's own stderr message ("tcpdump: listening on any, ...") on STDOUT, i.e.
in front of the pcap header, so the file did not start with a pcap magic number and was rejected.  These tests cover
  * the capture script keeping tcpdump's messages out of stdout (real /bin/sh, real `timeout`, stub nsenter/tcpdump),
  * the same when stdout and stderr are merged (what `oc` did),
  * node_capture.capture() end to end through the real OcClient and the fake `oc debug` for clean, merged, zero-packet,
    noisy and failed captures,
  * the pcap helpers (strip leading text, tolerate text after a zero-packet capture, safe error previews).
The fake `oc` files are copied to a private folder and repaired there (execute bit, CRLF, missing interpreter).
"""
import json, os, shutil, struct, subprocess, sys, tempfile, threading, time, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
BIN = os.path.join(ROOT, "tests", "bin")
MB = 1024 * 1024

from backend.oc_client import Creds, OcClient                      # noqa: E402
from backend.runtime import RuntimeDir                             # noqa: E402
from diagnostics import node_capture, pcap                         # noqa: E402
from diagnostics.thread_dump import DiagnosticError                # noqa: E402


def tok(env, name):
    return "sha256~%s-%s-%s" % (env, name, "x" * 24)


def put(path, data, mode="wb"):
    with open(path, mode) as fh:
        fh.write(data)
    return path


def read(path):
    with open(path, "rb") as fh:
        return fh.read()


def header(order="<", magic=0xa1b2c3d4):
    return struct.pack(order + "IHHiIII", magic, 2, 4, 0, 0, 128, 276)


def record(d, order="<"):
    return struct.pack(order + "IIII", 1, 0, len(d), len(d)) + d


BANNER = b"tcpdump: listening on any, link-type LINUX_SLL2 (Linux cooked v2), snapshot length 128 bytes\n"
SUMMARY = b"3 packets captured\n3 packets received by filter\n0 packets dropped by kernel\n"


# =============================================================================================== pcap helpers
class TestPcapHelpers(unittest.TestCase):
    def tmp(self, data):
        return put(tempfile.mktemp(), data)

    def test_the_symptom_and_its_cure(self):
        """A banner in front of the pcap is exactly what produced 'missing pcap magic number'."""
        p = self.tmp(BANNER + header() + record(b"abc") + record(b"de"))
        with self.assertRaises(pcap.PcapError) as cm:
            pcap.scan(p)
        self.assertIn("missing pcap magic number", str(cm.exception))
        self.assertEqual(pcap.strip_leading_noise(p), len(BANNER))
        info = pcap.scan(p)
        self.assertEqual((info["packets"], info["trailing_bytes"]), (2, 0))
        self.assertEqual(read(p), header() + record(b"abc") + record(b"de"))

    def test_all_four_header_flavours_are_recognised_and_untouched_when_already_clean(self):
        for order, magic in (("<", 0xa1b2c3d4), (">", 0xa1b2c3d4), ("<", 0xa1b23c4d), (">", 0xa1b23c4d)):
            body = header(order, magic) + record(b"xy", order)
            p = self.tmp(b"noise\n" + body)
            self.assertEqual(pcap.strip_leading_noise(p), 6, (order, hex(magic)))
            self.assertEqual(read(p), body)
            self.assertEqual(pcap.strip_leading_noise(p), 0)                 # idempotent
            self.assertEqual(pcap.scan(p)["packets"], 1)

    def test_no_false_positives_and_limits(self):
        for data in (b"", b"hello world", b"tcpdump: any: permission denied\n" * 20, os.urandom(2000)[:0] + b"\x00" * 500):
            p = self.tmp(data)
            self.assertEqual(pcap.strip_leading_noise(p), 0)
            self.assertEqual(read(p), data)                      # never modified when there is no header
        far = self.tmp(b"x" * (pcap.NOISE_SCAN_BYTES + 100) + header() + record(b"a"))
        self.assertEqual(pcap.strip_leading_noise(far), 0)                    # a header beyond the scan window is not trusted
        near = self.tmp(b"x" * (pcap.NOISE_SCAN_BYTES - 10) + header() + record(b"a"))
        self.assertEqual(pcap.strip_leading_noise(near), pcap.NOISE_SCAN_BYTES - 10)

    def test_large_files_are_shifted_correctly_in_place(self):
        body = header() + b"".join(record(os.urandom(1000)) for _ in range(2500))            # about 2.5 MB: more than one chunk
        p = self.tmp(BANNER + body)
        removed = pcap.strip_leading_noise(p)
        self.assertEqual(removed, len(BANNER))
        self.assertEqual(os.path.getsize(p), len(body))
        with open(p, "rb") as fh:
            self.assertEqual(fh.read(), body)
        self.assertEqual(pcap.scan(p)["packets"], 2500)

    def test_zero_packet_capture_with_trailing_text(self):
        p = self.tmp(header() + SUMMARY)
        with self.assertRaises(pcap.PcapError):                               # strict mode is unchanged (a malformed first record is an error)
            pcap.scan(p)
        info = pcap.trim_to_valid(p, lenient_empty=True)
        self.assertEqual((info["packets"], info["trailing_bytes"], os.path.getsize(p)), (0, len(SUMMARY), 24))
        self.assertEqual(pcap.scan(p)["packets"], 0)

    def test_trailing_text_after_packets_is_trimmed_in_both_modes(self):
        for lenient in (False, True):
            p = self.tmp(header() + record(b"abc") + record(b"de") + SUMMARY)
            info = pcap.trim_to_valid(p, lenient_empty=lenient)
            self.assertEqual((info["packets"], info["trailing_bytes"]), (2, len(SUMMARY)))
            self.assertEqual(read(p), header() + record(b"abc") + record(b"de"))

    def test_genuine_garbage_is_still_rejected(self):
        for data, text in ((b"hello world, this is not a pcap file at all", "missing pcap magic number"), (b"short", "shorter than a pcap header"),
                           (b"\x0a\x0d\x0d\x0a" + b"\0" * 40, "pcapng")):
            p = self.tmp(data)
            pcap.strip_leading_noise(p)
            with self.assertRaises(pcap.PcapError) as cm:
                pcap.trim_to_valid(p, lenient_empty=True)
            self.assertIn(text, str(cm.exception))

    def test_head_preview_is_short_printable_and_safe(self):
        self.assertIn("empty", pcap.head_preview(self.tmp(b"")))
        s = pcap.head_preview(self.tmp(b"tcpdump: any: You don't have permission\n\x00\x01\xff" + b"A" * 500))
        self.assertIn("74 63 70 64 75 6d 70 3a", s); self.assertIn("tcpdump: any: You don't have permission", s)
        self.assertLess(len(s), 400)
        self.assertTrue(all(32 <= ord(c) < 127 or c in "\n" for c in s))        # control and binary bytes are shown as dots


# =============================================================================================== the capture script
class TestCaptureScriptInARealShell(unittest.TestCase):
    """Real /bin/sh, real coreutils `timeout`; stub nsenter and tcpdump on PATH.  The stub tcpdump behaves like the real one:
    banner and summary on STDERR, the pcap on STDOUT."""

    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.mkdtemp()
        put(os.path.join(cls.dir, "nsenter"), '#!/bin/sh\nwhile [ "$1" != "--" ]; do shift; done; shift\nexec "$@"\n', "w")
        put(os.path.join(cls.dir, "tcpdump"), r'''#!/bin/sh
if [ -n "$STUB_FAIL" ]; then
  echo "tcpdump: any: You don't have permission to capture on that device" >&2; echo "(socket: Operation not permitted)" >&2; exit 1
fi
echo "tcpdump: listening on any, link-type LINUX_SLL2 (Linux cooked v2), snapshot length 128 bytes" >&2
printf 'PCAPBYTES'
if [ -n "$STUB_HANG" ]; then sleep 30; fi
echo "3 packets captured" >&2; echo "3 packets received by filter" >&2; echo "0 packets dropped by kernel" >&2
''', "w")
        for n in ("nsenter", "tcpdump"):
            os.chmod(os.path.join(cls.dir, n), 0o755)

    def run_script(self, merged, args=(3, "/var/run/netns/cni-abc-123", 128, 500000, ""), **env):
        e = dict(os.environ, PATH=self.dir + os.pathsep + os.environ["PATH"])
        e.update({k: str(v) for k, v in env.items()})
        cmd = ["sh", "-c", node_capture.CAPTURE_SCRIPT, "portal"] + [str(a) for a in args]
        if merged:                                           # what `oc debug` did on the real cluster: stderr delivered on stdout
            cmd = ["sh", "-c", 'exec "$@" 2>&1', "x"] + cmd
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=e, timeout=30)

    def test_tcpdump_messages_never_reach_the_capture_stream(self):
        for merged in (False, True):
            r = self.run_script(merged)
            self.assertEqual(r.stdout, node_capture.MARKER + b"PCAPBYTES", "merged=%s" % merged)
            self.assertEqual(r.returncode, 0)
            self.assertEqual(r.stderr, b"" if not merged else r.stderr)
            self.assertNotIn(b"listening on", r.stdout); self.assertNotIn(b"packets captured", r.stdout)

    def test_with_a_filter_expression(self):
        r = self.run_script(True, args=(3, "/var/run/netns/cni-abc-123", 128, 500000, "(tcp port 80) and host 10.0.0.1"))
        self.assertEqual(r.stdout, node_capture.MARKER + b"PCAPBYTES")

    def test_failure_text_is_shown_but_only_on_failure(self):
        r = self.run_script(False, STUB_FAIL=1)
        self.assertEqual((r.returncode, r.stdout), (1, node_capture.MARKER))
        self.assertIn(b"You don't have permission", r.stderr)                 # the reason is still available for the error message
        m = self.run_script(True, STUB_FAIL=1)
        self.assertEqual(m.returncode, 1)
        self.assertTrue(m.stdout.startswith(node_capture.MARKER)); self.assertIn(b"Operation not permitted", m.stdout)

    def test_time_limit_exit_code_is_preserved_and_silent(self):
        t0 = time.time()
        r = self.run_script(False, args=(1, "/var/run/netns/cni-abc-123", 128, 500000, ""), STUB_HANG=1)
        self.assertEqual(r.returncode, 124)                                   # `timeout` fired: the normal end of a timed capture
        self.assertEqual(r.stderr, b"")
        self.assertLess(time.time() - t0, 10)

    def test_hostile_values_stay_data(self):
        marker = os.path.join(self.dir, "PWNED")
        for value in ('x"; touch %s; "' % marker, "$(touch %s)" % marker, "`touch %s`" % marker, "a b", "*"):
            self.run_script(False, args=(1, "/var/run/netns/cni-abc-123", 128, 500000, value))
            self.assertFalse(os.path.exists(marker), value)

    def test_script_is_still_a_safe_constant(self):
        import re
        s = node_capture.CAPTURE_SCRIPT
        self.assertEqual({m for m in re.findall(r"\$(\d)", s)}, {"1", "2", "3", "4", "5"})
        for m in re.finditer(r"\$\d", s):
            self.assertEqual(s[:m.start()].count('"') % 2, 1, s[max(0, m.start() - 30):m.end() + 5])
        for forbidden in ("eval", "`", "${", "$1$", "\\$", "/host/var/tmp"):
            self.assertNotIn(forbidden, s)
        self.assertIn("exec timeout -s INT", s); self.assertIn("-w -", s)
        self.assertNotIn("rm -f", s)                                            # nothing is ever deleted by the script


# =============================================================================================== capture() end to end
class TestCaptureThroughTheFakeOc(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.chmod(self.tmp, 0o700)
        self.bin = os.path.join(self.tmp, "bin")
        os.makedirs(self.bin)
        for n in ("oc", "oc_nodes"):                                            # private, repaired copies of the fake oc
            with open(os.path.join(BIN, n), "rb") as fh:
                data = fh.read().replace(b"\r\n", b"\n")
            first, _, rest = data.partition(b"\n")
            put(os.path.join(self.bin, n), ("#!%s -S" % sys.executable).encode() + b"\n" + rest)
            os.chmod(os.path.join(self.bin, n), 0o755)
        self._old = os.environ.get("TMPDIR")
        os.environ["TMPDIR"] = self.tmp                                         # the fake keeps its state (debug-ns.json, logs) here
        self.client = OcClient(os.path.join(self.bin, "oc_nodes"), RuntimeDir(os.path.join(self.tmp, "rt")))

    def tearDown(self):
        if self._old is None:
            os.environ.pop("TMPDIR", None)
        else:
            os.environ["TMPDIR"] = self._old
        shutil.rmtree(self.tmp, ignore_errors=True)

    def capture(self, pod, duration=5, snap=128):
        cl = {"id": "example-dev-1", "api_url": "https://api.dev.example.com:6443", "tls_verify": True}
        part = os.path.join(self.tmp, pod + ".part")
        with self.client.open(Creds(cl, tok("dev", "alice"), "alice")) as s:
            info = node_capture.discover(s, "worker-1.example", "", "demo-dev", pod, threading.Event())
            try:
                r = node_capture.capture(s, "worker-1.example", "", info["netns"], duration, snap, None, 300, 5 * MB, part, threading.Event())
            except DiagnosticError as exc:
                return None, part, str(exc)
        return r, part, None

    def test_clean_capture_is_unchanged(self):
        r, part, err = self.capture("nd-ok")
        self.assertIsNone(err)
        self.assertEqual((r["packets"], r["trimmed"]), (3, 0))
        self.assertEqual(pcap.scan(part)["packets"], 3)

    def test_the_real_cluster_case_banner_before_and_summary_after(self):
        r, part, err = self.capture("nd-merged")
        self.assertIsNone(err, err)
        self.assertEqual(r["packets"], 3)
        self.assertEqual(r["trimmed"], len(BANNER) + len(SUMMARY))              # both pieces of text were reported as removed
        with open(part, "rb") as fh:
            data = fh.read()
        self.assertTrue(data.startswith(b"\xd4\xc3\xb2\xa1"))                   # a real pcap magic number is the first thing in the file
        self.assertNotIn(b"listening on", data); self.assertNotIn(b"packets captured", data)
        self.assertEqual(pcap.scan(part), dict(pcap.scan(part), packets=3, trailing_bytes=0))

    def test_zero_packet_capture_is_valid_even_with_text_around_it(self):
        r, part, err = self.capture("nd-merged-empty")
        self.assertIsNone(err, err)
        self.assertEqual((r["packets"], r["size"]), (0, 24))
        self.assertEqual(pcap.scan(part)["packets"], 0)

    def test_text_printed_by_oc_before_and_after_is_still_handled(self):
        r, part, err = self.capture("nd-noise")
        self.assertIsNone(err, err)
        self.assertEqual(r["packets"], 3); self.assertGreater(r["trimmed"], 0)
        self.assertEqual(pcap.scan(part)["trailing_bytes"], 0)

    def test_a_failed_capture_explains_itself_with_what_the_output_began_with(self):
        r, part, err = self.capture("nd-badhead")
        self.assertIsNone(r)
        self.assertIn("tcpdump on node 'worker-1.example' failed", err)         # exit code 1 = tcpdump itself failed (not a pcap problem)
        self.assertIn("You don't have permission", err)                         # ... and the reason is in the message
        self.assertLess(len(err), 700)

    def test_garbage_output_is_rejected_with_a_preview(self):
        r, part, err = self.capture("nd-garbage")
        self.assertIsNone(r)
        self.assertIn("not a valid pcap", err); self.assertIn("hello world", err)
        self.assertIn("oc said", err)


if __name__ == "__main__":
    unittest.main(verbosity=2)
