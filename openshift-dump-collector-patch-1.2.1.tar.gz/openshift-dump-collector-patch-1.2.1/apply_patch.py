#!/usr/bin/env python3
"""Applies patch 1.2.1 (node-level TCP capture: "The output is not a valid pcap capture (missing pcap magic number)") to an installed
OpenShift Dump Collector 1.2.x.   Usage:  python3 apply_patch.py /path/to/installed/openshift-dump-collector [--dry-run]

Replaces:  diagnostics/node_capture.py  diagnostics/pcap.py  tests/bin/oc_nodes  VERSION
Adds:      tests/test_node_capture_noise.py
Edits:     backend/collection_service.py (one note sentence; exact-match, skipped if it is not found)
Keeps everything else (portal.conf, clusters.json, storage/, logs/, certs/ ...). A backup of each replaced file is saved to
<install>.backup-patch-<timestamp>.  Stop the portal first and start it again afterwards.  Standard library only.
"""
import os, shutil, sys, time

SRC = os.path.dirname(os.path.abspath(__file__))
FILES = ["diagnostics/node_capture.py", "diagnostics/pcap.py", "tests/bin/oc_nodes", "tests/test_node_capture_noise.py", "VERSION"]   # VERSION last
OLD = '"%d trailing bytes that were not part of the capture (for example text printed by oc) were removed."'
NEW = '"%d bytes of text that were not part of the capture (for example messages printed by oc or tcpdump) were removed."'


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--dry-run" in sys.argv
    if len(args) != 1:
        print(__doc__); return 2
    target = os.path.abspath(args[0])
    for need in ("server.py", "backend", "diagnostics", "VERSION"):
        if not os.path.exists(os.path.join(target, need)):
            print("%s does not look like an installed portal (%s is missing)." % (target, need)); return 2
    if not os.path.isfile(os.path.join(target, "diagnostics", "node_capture.py")):
        print("This patch is for version 1.2.x (it needs diagnostics/node_capture.py). Apply the 1.2.0 release or update first."); return 2
    with open(os.path.join(target, "VERSION")) as fh:
        cur = fh.read().strip()
    if cur == "1.2.1":
        print("Already at version 1.2.1 - nothing to do."); return 0
    if not cur.startswith("1.2."):
        print("Installed version is %r; this patch is for 1.2.x." % cur); return 2
    for f in FILES:
        if not os.path.isfile(os.path.join(SRC, f)):
            print("The patch bundle is incomplete (missing %s). Nothing was changed." % f); return 1
    bk = "%s.backup-patch-%s" % (target, time.strftime("%Y%m%d-%H%M%S"))
    for f in FILES:
        dst = os.path.join(target, f)
        if os.path.exists(dst):
            print("%sbackup  %s" % ("[dry-run] " if dry else "", f))
            if not dry:
                os.makedirs(os.path.dirname(os.path.join(bk, f)), exist_ok=True); shutil.copy2(dst, os.path.join(bk, f))
        print("%sinstall %s" % ("[dry-run] " if dry else "", f))
        if not dry:
            os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copyfile(os.path.join(SRC, f), dst)
    cs = os.path.join(target, "backend", "collection_service.py")
    if os.path.isfile(cs):
        with open(cs, encoding="utf-8") as fh:
            text = fh.read()
        if OLD in text:
            print("%sedit    backend/collection_service.py (note wording)" % ("[dry-run] " if dry else ""))
            if not dry:
                os.makedirs(os.path.dirname(os.path.join(bk, "backend/collection_service.py")), exist_ok=True)
                shutil.copy2(cs, os.path.join(bk, "backend/collection_service.py"))
                with open(cs, "w", encoding="utf-8") as fh:
                    fh.write(text.replace(OLD, NEW))
        else:
            print("note    backend/collection_service.py already has the new wording (or differs); left unchanged")
    if not dry:
        for rel in ("tests/bin/oc_nodes", "tests/bin/oc"):
            p = os.path.join(target, rel)
            if os.path.isfile(p):
                os.chmod(p, os.stat(p).st_mode | 0o755)
        for root, dirs, _ in os.walk(target):
            for d in list(dirs):
                if d == "__pycache__":
                    shutil.rmtree(os.path.join(root, d), ignore_errors=True); dirs.remove(d)
    print("\n%s %s from %s to 1.2.1.%s" % ("Would update" if dry else "Updated", target, cur, "" if dry else "  Backup: " + bk))
    print("Next: restart the portal; then run  python3 -m unittest discover -s tests -p \"test_node_capture_noise.py\"  (about a minute).")
    print("Rollback: stop the portal and copy the files from the backup folder back over the install.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
