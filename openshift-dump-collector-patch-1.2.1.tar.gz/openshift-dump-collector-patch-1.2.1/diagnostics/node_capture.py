"""Node-level TCP capture, for pods whose image has no tcpdump (capture method "node").

How it works (the same idea as the manual runbook: debug pod on the node -> pod's network namespace -> tcpdump):

  1. Phase 1, ONE temporary privileged debug pod on the node that runs the target pod:
       - checks the debug image has tcpdump, nsenter and timeout
       - asks the node's container runtime (crictl) for the Ready sandbox of the target pod
       - prints that sandbox's CRI description; THIS MODULE extracts the network-namespace path from it in Python
         (no jq, no shell parsing of JSON)
  2. Phase 2, a second debug pod: enters ONLY that network namespace with nsenter and runs the tcpdump that ships in
     the debug image, streaming the pcap to stdout. The capture goes straight to the portal's .part file; nothing is
     written on the node.

Safety properties (all enforced here, on top of the cluster's own RBAC for the user's token):
  * The two shell scripts below are CONSTANTS. Variable values (namespace, pod-name regex, duration, namespace path,
    snap length, packet count, filter expression) are passed as separate arguments ($1, $2, ...) and only ever
    expanded inside double quotes. No user text is ever concatenated into a command line or a script.
  * Everything learned from the cluster is validated before use: node name (DNS-1123), image name, 64-hex sandbox id
    count, network-namespace path (strict pattern under /var/run/netns or /proc/<pid>/ns/net).
  * Capture is bounded three ways: duration (remote `timeout`), packet count and byte size.
  * Pods on the host network are refused (capturing them would capture the whole node).
  * Text around the capture is handled three ways (v1.2.1): the capture script keeps tcpdump's own messages OFF stdout, text
    printed by `oc` before the capture is dropped (marker), and any text still sitting before/after the pcap is stripped
    and the result is verified as a real pcap before it is offered for download.
"""
import json
import os
import re
import threading
import time

from backend.process import clean_text
from diagnostics import pcap
from diagnostics.tcp_dump import MAX_PACKETS, STOP_GRACE
from diagnostics.thread_dump import Cancelled, DiagnosticError

NODE_RE = re.compile(r"[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?")
POD_RE = re.compile(r"[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?")
IMAGE_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/:@+-]{0,254}")
POD_ID_RE = re.compile(r"[0-9a-f]{64}")
NETNS_RE = re.compile(r"/(?:var/)?run/netns/[A-Za-z0-9_.-]{1,120}|/proc/[0-9]{1,9}/ns/net")
MARKER = b"PORTAL-PCAP-BEGIN\n"
REQUIRED_TOOLS = ("tcpdump", "nsenter", "timeout")
DISCOVERY_TIMEOUT = 150        # seconds for a debug pod to start (image pull) and answer
START_ALLOWANCE = 150          # extra seconds the capture's debug pod may need to start, on top of the duration
MIN_CAPTURE_SLACK = 30         # least time that must remain for the capture itself, beyond its duration

# Phase 1.  $1 = namespace, $2 = anchored pod-name regex.  Prints only simple "key=value" lines and the JSON block.
DISCOVER_SCRIPT = r'''
for t in tcpdump nsenter timeout; do
  if command -v "$t" >/dev/null 2>&1; then echo "tool=$t"; fi
done
ids=$(chroot /host crictl pods --namespace "$1" --name "$2" --state Ready -q 2>/dev/null)
n=$(printf '%s\n' "$ids" | grep -c .)
echo "podcount=$n"
if [ "$n" = "1" ]; then
  echo "podid=$ids"
  echo "json-begin"
  chroot /host crictl inspectp "$ids" 2>/dev/null
  echo "json-end"
fi
exit 0
'''

# Phase 2.  $1 = duration (s), $2 = network-namespace path on the node, $3 = snap length, $4 = packet cap,
# $5 = capture filter expression (may be empty).  The portal discards everything before the marker line.
# tcpdump's own messages ("listening on ...", "N packets captured") go to stderr; depending on the oc version they can be
# delivered on STDOUT, i.e. inside the capture. They are therefore redirected to a private file inside the (throw-away) debug pod
# and shown only if tcpdump FAILED (exit code other than 0 / 124 = normal end of a timed capture).
CAPTURE_SCRIPT = r'''
printf 'PORTAL-PCAP-BEGIN\n'
e=$(mktemp 2>/dev/null) || e=/dev/null
if [ -n "$5" ]; then
  ( exec timeout -s INT "$1" nsenter --net="/host$2" -- tcpdump -nn -i any -U -s "$3" -c "$4" -w - "$5" 2>"$e" )
else
  ( exec timeout -s INT "$1" nsenter --net="/host$2" -- tcpdump -nn -i any -U -s "$3" -c "$4" -w - 2>"$e" )
fi
rc=$?
if [ "$rc" != 0 ] && [ "$rc" != 124 ]; then cat "$e" >&2; fi
exit "$rc"
'''


# ---------------------------------------------------------------------------------------------------- validation
def valid_node(name):
    return isinstance(name, str) and NODE_RE.fullmatch(name) is not None


def valid_image(image):
    return isinstance(image, str) and IMAGE_RE.fullmatch(image) is not None


def pod_name_regex(pod):
    """Anchored regular expression for crictl's --name filter (a regex match, so it must be exact)."""
    if not isinstance(pod, str) or POD_RE.fullmatch(pod) is None:
        raise ValueError("invalid pod name")
    return "^" + pod.replace(".", r"\.") + "$"


def permission_problems(oc):
    """What the user's token is clearly NOT allowed to do (a fast, early hint; the debug pod itself is the real test)."""
    problems = []
    if oc.can_i("get", "nodes") is False:
        problems.append("read nodes")
    if oc.can_i("use", "scc/privileged") is False:
        problems.append("use the 'privileged' security context constraint")
    return problems


def lookup_node(oc, namespace, pod):
    """Return the validated name of the node the pod runs on, or raise DiagnosticError."""
    node = oc.pod_node(namespace, pod)
    if not node:
        raise DiagnosticError("Pod '%s' is not scheduled on a node yet." % pod)
    if not valid_node(node):
        raise DiagnosticError("The cluster reported an unusable node name for pod '%s'; refusing to continue." % pod)
    return node


# ---------------------------------------------------------------------------------------------------- phase 1
def parse_discovery(text):
    """-> {'seen': bool, 'tools': set, 'podcount': int|None, 'podid': str|None, 'json': str|None}.  Noise lines
    (for example informational messages from `oc debug`) are ignored."""
    out = {"seen": False, "tools": set(), "podcount": None, "podid": None, "json": None}
    in_json, buf = False, []
    for raw in (text or "").splitlines():
        line = raw.rstrip("\r")
        if in_json:
            if line.strip() == "json-end":
                in_json = False
                out["json"] = "\n".join(buf)
            else:
                buf.append(line)
            continue
        s = line.strip()
        if s == "json-begin":
            in_json, buf = True, []
        elif s.startswith("tool=") and s[5:] in REQUIRED_TOOLS:
            out["tools"].add(s[5:])
        elif s.startswith("podcount=") and s[9:].isdigit():
            out["podcount"] = int(s[9:])
            out["seen"] = True
        elif s.startswith("podid="):
            out["podid"] = s[6:]
    return out


def netns_from_inspect(text):
    """Network-namespace path from `crictl inspectp` JSON ('' when the pod has no separate network namespace)."""
    data = json.loads(text)
    spaces = ((((data.get("info") or {}).get("runtimeSpec") or {}).get("linux") or {}).get("namespaces")) or []
    for ns in spaces:
        if isinstance(ns, dict) and ns.get("type") == "network":
            return str(ns.get("path") or "")
    return ""


def _debug_failure(res, oc, node):
    low = (res.err or "").lower()
    if "forbidden" in low:
        return ("Starting a privileged debug pod on node '%s' is not allowed for your account. This method needs cluster-level "
                "rights (typically cluster-admin). The cluster said: %s" % (node, clean_text(res.err, 200)))
    if "imagepull" in low or "errimage" in low or "pull" in low:
        return ("The debug pod on node '%s' could not start (image pull problem). If the cluster cannot reach its default tools "
                "image, an administrator can set an approved image with --node-capture-image. Detail: %s" % (node, clean_text(res.err, 200)))
    return oc.describe_failure(res, "Debug pod on node '%s'" % node)


def discover(oc, node, image, namespace, pod, cancel=None, timeout=DISCOVERY_TIMEOUT):
    """Phase 1.  Returns {'pod_id', 'netns'} or raises DiagnosticError / Cancelled."""
    if not valid_node(node):
        raise DiagnosticError("Invalid node name.")
    if image and not valid_image(image):
        raise DiagnosticError("The configured debug image name is not valid.")
    regex = pod_name_regex(pod)
    res = oc.debug_node(node, image, DISCOVER_SCRIPT, [namespace, regex], timeout, cancel=cancel, max_bytes=2 * 1024 * 1024)
    if res.cancelled:
        raise Cancelled()
    if res.timed_out:
        raise DiagnosticError("The debug pod on node '%s' did not answer within %d s (is the node busy, or the image slow to pull?). "
                              "Nothing was captured." % (node, timeout))
    if res.error:
        raise DiagnosticError(res.error)
    info = parse_discovery(res.out)
    if not info["seen"]:
        raise DiagnosticError(_debug_failure(res, oc, node))
    missing = [t for t in REQUIRED_TOOLS if t not in info["tools"]]
    if missing:
        raise DiagnosticError("The debug image on node '%s' does not contain: %s. Ask an administrator to set an approved image "
                              "that has them (--node-capture-image). Nothing was captured." % (node, ", ".join(missing)))
    if info["podcount"] == 0:
        raise DiagnosticError("The node's container runtime reports no Ready pod '%s' in namespace '%s' (it may have restarted or "
                              "moved). Try again." % (pod, namespace))
    if info["podcount"] != 1:
        raise DiagnosticError("%d Ready sandboxes match pod '%s' on node '%s'; refusing to guess." % (info["podcount"], pod, node))
    pod_id = info["podid"] or ""
    if POD_ID_RE.fullmatch(pod_id) is None:
        raise DiagnosticError("The container runtime returned an unexpected sandbox id; refusing to continue.")
    if not info["json"]:
        raise DiagnosticError("The container runtime did not describe the pod's sandbox; refusing to continue.")
    try:
        netns = netns_from_inspect(info["json"])
    except (ValueError, AttributeError):
        raise DiagnosticError("The sandbox description could not be read; refusing to continue.")
    if not netns:
        raise DiagnosticError("Pod '%s' uses the node's own network (host network). Capturing it would capture all traffic of the "
                              "node, so this method refuses." % pod)
    if NETNS_RE.fullmatch(netns) is None:
        raise DiagnosticError("The pod's network namespace path has an unexpected form; refusing to continue.")
    return {"pod_id": pod_id, "netns": netns}


# ---------------------------------------------------------------------------------------------------- phase 2
class MarkerSink(object):
    """File-like sink that drops everything before MARKER (informational text printed by `oc`) and then writes through.
    The marker may be split across chunks."""

    def __init__(self, fh, on_start=None):
        self.fh = fh
        self.on_start = on_start
        self.started = False
        self._buf = b""

    def write(self, chunk):
        if self.started:
            self.fh.write(chunk)
            return len(chunk)
        self._buf += chunk
        i = self._buf.find(MARKER)
        if i >= 0:
            rest = self._buf[i + len(MARKER):]
            self._buf = b""
            self.started = True
            if self.on_start:
                self.on_start()
            if rest:
                self.fh.write(rest)
        elif len(self._buf) > 65536:
            self._buf = self._buf[-len(MARKER):]
        return len(chunk)


def capture(oc, node, image, netns, duration, snaplen, expression, timeout, max_bytes, part_path, cancel, progress=None):
    """Phase 2.  Stream the capture into part_path.  Returns {'size', 'packets', 'trimmed'} ('trimmed' = bytes of text that were
    not part of the capture and were removed).  Raises DiagnosticError / Cancelled.  The caller owns clean-up of part_path."""
    if not valid_node(node) or NETNS_RE.fullmatch(netns or "") is None:
        raise DiagnosticError("Refusing to start a capture with an invalid node or network namespace.")
    if image and not valid_image(image):
        raise DiagnosticError("The configured debug image name is not valid.")
    if timeout < duration + MIN_CAPTURE_SLACK:
        raise DiagnosticError("Starting the debug pod used up most of the collection timeout (%d s left for a %d s capture). "
                              "Raise the timeout and try again." % (int(timeout), duration))
    run_timeout = min(float(timeout), duration + START_ALLOWANCE + STOP_GRACE)
    stop = threading.Event()
    began = {"t": None}
    args = [int(duration), netns, int(snaplen), MAX_PACKETS, expression or ""]

    def ticker():
        while not stop.wait(2.0):
            if began["t"] is None:
                progress("Starting a temporary debug pod on node %s (this can take up to a minute)" % node)
                continue
            try:
                size = os.path.getsize(part_path)
            except OSError:
                size = 0
            progress("Capturing on node %s: %ds of %ds elapsed, %.1f MB received" % (
                node, min(int(time.monotonic() - began["t"]), duration), duration, size / 1048576.0))

    t = None
    if progress:
        progress("Starting a temporary debug pod on node %s (this can take up to a minute)" % node)
        t = threading.Thread(target=ticker)
        t.daemon = True
        t.start()
    sink = None
    try:
        fd = os.open(part_path, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w+b") as fh:
            sink = MarkerSink(fh, on_start=lambda: began.__setitem__("t", time.monotonic()))
            res = oc.debug_node(node, image, CAPTURE_SCRIPT, args, run_timeout, cancel=cancel, sink=sink, max_bytes=max_bytes + 4096)
            fh.flush()
            os.fsync(fh.fileno())
    finally:
        stop.set()
        if t:
            t.join(3)

    low = (res.err or "").lower()
    if res.cancelled:
        raise Cancelled()
    if res.too_big:
        raise DiagnosticError("The capture reached the %d MB size limit and was stopped; the incomplete file was discarded. "
                              "Narrow the filter, shorten the duration or raise the limit." % (max_bytes // 1048576))
    if res.timed_out:
        if not sink.started:
            raise DiagnosticError("The debug pod on node '%s' did not start the capture in time (image pull or a busy node); "
                                  "nothing was captured." % node)
        raise DiagnosticError("The capture did not stop within its time limit; it was cut off and the partial file discarded.")
    if res.error:
        raise DiagnosticError(res.error)
    if not sink.started:
        raise DiagnosticError(_debug_failure(res, oc, node))
    normal = res.rc in (0, 124) or "exit code 124" in low
    if not normal:
        if "reassociate" in low or "setns" in low or "no such file" in low and "netns" in low:
            raise DiagnosticError("nsenter could not enter the pod's network namespace (the pod may have restarted since it was "
                                  "looked up). Detail: %s" % clean_text(res.err, 200))
        detail = oc.describe_failure(res, "tcpdump on node '%s'" % node)
        if os.path.getsize(part_path):                       # when oc delivers stderr on stdout the reason is in the output
            detail += " " + pcap.head_preview(part_path) + "."
        raise DiagnosticError(detail)
    leading = pcap.strip_leading_noise(part_path)            # e.g. tcpdump's own "listening on ..." line, if it reached stdout
    try:
        info = pcap.trim_to_valid(part_path, lenient_empty=True)
    except pcap.PcapError as exc:
        raise DiagnosticError("The output is not a valid pcap capture (%s); it was discarded. %s. oc said: %s"
                              % (exc, pcap.head_preview(part_path), clean_text(res.err, 200) or "nothing"))
    return {"size": os.path.getsize(part_path), "packets": info["packets"], "trimmed": info["trailing_bytes"] + leading}


# ---------------------------------------------------------------------------------------------------- leftovers
def leftover_namespaces(before, after):
    """Temporary debug namespaces that appeared during the job and are not being deleted.  `oc debug` normally removes
    its namespace itself; if the client was killed (cancel, timeout) it may not.  Best effort: [] when unknown."""
    if before is None or after is None:
        return []
    return sorted(n for n, phase in after.items() if n not in before and phase != "Terminating")


def leftover_note(names):
    return ("POSSIBLE LEFTOVER: the temporary debug namespace%s %s may still exist on the cluster. If nothing else is using %s, a "
            "cluster administrator can remove %s with: oc delete namespace %s" % (
                "s" if len(names) > 1 else "", ", ".join(names), "them" if len(names) > 1 else "it",
                "them" if len(names) > 1 else "it", " ".join(names)))
