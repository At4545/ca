"""Minimal classic-pcap structure check (stdlib only): a file is only ever presented as a successful capture if it
parses; a trailing incomplete record is trimmed to the last whole packet.

v1.2.1: captures taken through `oc debug` can arrive with extra text around the pcap (tcpdump's own "listening on ..." banner
before it and "N packets captured" after it when the tool's stderr is delivered on stdout). strip_leading_noise() removes text
in front of the pcap header and trim_to_valid(lenient_empty=True) tolerates text after a header-only (zero packet) capture.
"""
import os
import struct

_MAGICS = {0xA1B2C3D4: (">", False), 0xD4C3B2A1: ("<", False), 0xA1B23C4D: (">", True), 0x4D3CB2A1: ("<", True)}
GLOBAL_HDR = 24
REC_HDR = 16
MAX_PACKET = 262144 + 65536
# magic number + format version 2.4, in both byte orders and for micro/nanosecond timestamps (8 distinctive bytes)
HEADER_PATTERNS = (b"\xa1\xb2\xc3\xd4\x00\x02\x00\x04", b"\xd4\xc3\xb2\xa1\x02\x00\x04\x00",
                   b"\xa1\xb2\x3c\x4d\x00\x02\x00\x04", b"\x4d\x3c\xb2\xa1\x02\x00\x04\x00")
NOISE_SCAN_BYTES = 8192


class PcapError(Exception):
    pass


def scan(path, lenient_empty=False):
    """Validate a classic pcap. With lenient_empty=True a valid header followed by something that is not a packet record
    (text after a zero-packet capture) is reported as 0 packets instead of an error."""
    total = os.path.getsize(path)
    if total < GLOBAL_HDR:
        raise PcapError("file is shorter than a pcap header (%d bytes)" % total)
    with open(path, "rb") as fh:
        head = fh.read(GLOBAL_HDR)
        magic = struct.unpack(">I", head[:4])[0]
        if magic not in _MAGICS:
            if head[:4] == b"\x0a\x0d\x0d\x0a":
                raise PcapError("pcapng format is not supported")
            raise PcapError("missing pcap magic number")
        order = _MAGICS[magic][0]
        _, vmaj, vmin, _, _, snaplen, linktype = struct.unpack(order + "IHHiIII", head)
        if vmaj != 2:
            raise PcapError("unsupported pcap version %d.%d" % (vmaj, vmin))
        limit = min(max(snaplen if snaplen else MAX_PACKET, 65535), MAX_PACKET)
        pos, packets = GLOBAL_HDR, 0
        while True:
            fh.seek(pos)
            rec = fh.read(REC_HDR)
            if len(rec) < REC_HDR:
                break
            _, _, incl, orig = struct.unpack(order + "IIII", rec)
            if incl > limit or incl > orig:
                if packets == 0 and pos == GLOBAL_HDR and not lenient_empty:
                    raise PcapError("first packet record is malformed")
                break
            if pos + REC_HDR + incl > total:
                break
            pos += REC_HDR + incl
            packets += 1
    return {"valid_len": pos, "packets": packets, "snaplen": snaplen, "linktype": linktype, "trailing_bytes": total - pos}


def trim_to_valid(path, lenient_empty=False):
    info = scan(path, lenient_empty=lenient_empty)
    if info["trailing_bytes"]:
        os.truncate(path, info["valid_len"])
    return info


def find_header(data):
    """Index of the earliest pcap header (magic + version 2.4) in `data`, or -1."""
    best = -1
    for pat in HEADER_PATTERNS:
        i = data.find(pat)
        if i >= 0 and (best < 0 or i < best):
            best = i
    return best


def strip_leading_noise(path, scan_bytes=NOISE_SCAN_BYTES):
    """If the file does not start with a pcap header but one begins within the first `scan_bytes`, delete everything before it
    (in place, in chunks). Returns the number of bytes removed (0 when nothing was done)."""
    with open(path, "r+b") as fh:
        idx = find_header(fh.read(scan_bytes + len(HEADER_PATTERNS[0])))
        if idx <= 0 or idx > scan_bytes:
            return 0
        rpos, wpos = idx, 0
        while True:
            fh.seek(rpos)
            chunk = fh.read(1 << 20)
            if not chunk:
                break
            fh.seek(wpos)
            fh.write(chunk)
            rpos += len(chunk)
            wpos += len(chunk)
        fh.truncate(wpos)
        fh.flush()
        os.fsync(fh.fileno())
    return idx


def head_preview(path, n=96):
    """A short, safe description of how a rejected file begins (hex of the first bytes + printable text), for error messages."""
    with open(path, "rb") as fh:
        b = fh.read(n)
    if not b:
        return "The captured output was empty"
    text = "".join(chr(c) if 32 <= c < 127 else "." for c in b)
    return "The output began with bytes %s, as text: \"%s\"" % (" ".join("%02x" % c for c in b[:8]), text)
